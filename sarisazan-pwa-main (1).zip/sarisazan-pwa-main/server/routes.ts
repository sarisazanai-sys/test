import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { db } from "./db";
import { projects, bitumenRecords, tenders, alerts, alertRecipients, alertComments, users, userProjects, conversations, conversationMembers, messages, messageFiles, messageReads, sheets, sheetFiles, roles, permissions, rolePermissions, statements, adjustments, bitumenDiffs, weeklyReports, tasks, dailyNotes, followUpTasks, taskAttachments, stickyNotes, stickyNoteItems, letters, letterRecipients, letterAttachments, calendarNotes, projectFiles } from "@shared/schema";
import { eq, and, sql as sqlOperator, or, like, desc } from "drizzle-orm";
import bcrypt from "bcryptjs";
import multer from "multer";
import path from "path";
import fs from "fs";
import express from "express";
import { chatWithAssistant } from "./ai-assistant";
import { agentService } from "./agent-service";
import { multiSourceAgent } from "./multi-source-agent";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/agent/ask", async (req, res) => {
    try {
      const { query, projectId } = req.body;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "سؤال معتبر نیست" });
      }

      const result = await multiSourceAgent.ask(query);
      res.json(result);
    } catch (error: any) {
      console.error('❌ Agent ask error:', error);
      res.status(500).json({ 
        message: "خطا در پردازش سؤال",
        error: error.message 
      });
    }
  });

  app.get("/api/agent/article/:id", async (req, res) => {
    try {
      const articleId = parseInt(req.params.id);
      
      if (isNaN(articleId)) {
        return res.status(400).json({ message: "شماره ماده معتبر نیست" });
      }

      const article = agentService.getArticle(articleId);
      
      if (!article) {
        return res.status(404).json({ message: "ماده مورد نظر یافت نشد" });
      }

      res.json(article);
    } catch (error: any) {
      console.error('❌ Agent article error:', error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/agent/execute", async (req, res) => {
    try {
      const { action, data } = req.body;
      
      res.json({ 
        success: false,
        message: "این قابلیت به زودی اضافه می‌شود" 
      });
    } catch (error: any) {
      console.error('❌ Agent execute error:', error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/agent/status", async (req, res) => {
    try {
      const isConfigured = agentService.isConfigured();
      res.json({ 
        connected: isConfigured,
        status: isConfigured ? 'connected' : 'disconnected'
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const agentUploadDir = path.join(process.cwd(), "uploads", "agent-documents");
  if (!fs.existsSync(agentUploadDir)) {
    fs.mkdirSync(agentUploadDir, { recursive: true });
  }

  const agentUpload = multer({
    dest: agentUploadDir,
    limits: { fileSize: 10 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
      const allowedExts = ['.jsonl', '.json'];
      const ext = path.extname(file.originalname).toLowerCase();
      if (allowedExts.includes(ext)) {
        cb(null, true);
      } else {
        cb(new Error('فقط فایل‌های JSONL و JSON مجاز هستند'));
      }
    }
  });

  app.post("/api/agent/upload-document", agentUpload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "فایلی آپلود نشده است" });
      }

      const result = await agentService.loadFromFile(req.file.path);
      
      if (!result.success) {
        return res.status(400).json({ message: result.error || "خطا در پردازش فایل" });
      }

      res.json({ 
        success: true,
        articlesCount: result.articlesCount,
        message: `${result.articlesCount} ماده با موفقیت بارگذاری شد`
      });
    } catch (error: any) {
      console.error('❌ Document upload error:', error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/needs-action", async (req, res) => {
    try {
      const today = new Date();
      const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      const endOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
      
      const allActionItems = await db.select()
        .from(tasks)
        .where(
          or(
            and(
              sqlOperator`${tasks.reminderDateTime}::date = CURRENT_DATE`,
              eq(tasks.isCompleted, false)
            ),
            and(
              eq(tasks.requiresConfirmation, true),
              eq(tasks.isConfirmed, false)
            )
          )
        );
      
      const uniqueItems = Array.from(new Map(allActionItems.map(item => [item.id, item])).values());
      res.json({ count: uniqueItems.length, items: uniqueItems });
    } catch (error: any) {
      res.status(500).json({ message: error.message, count: 0, items: [] });
    }
  });

  app.get("/api/projects", async (req, res) => {
    try {
      const allProjects = await db.select().from(projects);
      res.json(allProjects);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const [project] = await db.insert(projects).values(req.body).returning();
      res.json(project);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const projectFilesUploadDir = path.join(process.cwd(), "uploads", "project-files");
  if (!fs.existsSync(projectFilesUploadDir)) {
    fs.mkdirSync(projectFilesUploadDir, { recursive: true });
  }

  const projectFilesStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const projectId = req.body.projectId || req.params.projectId || "temp";
      const uploadPath = path.join(projectFilesUploadDir, projectId);
      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
      const timestamp = Date.now();
      const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9._\u0600-\u06FF-]/g, '_');
      cb(null, `${timestamp}_${sanitizedName}`);
    }
  });

  const projectFilesUpload = multer({
    storage: projectFilesStorage,
    limits: { fileSize: 50 * 1024 * 1024 },
  });

  app.get("/api/projects/:projectId/files", async (req, res) => {
    try {
      const files = await db.select()
        .from(projectFiles)
        .where(eq(projectFiles.projectId, req.params.projectId));
      res.json(files);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/projects/:projectId/files", projectFilesUpload.single('file'), async (req, res) => {
    try {
      const file = req.file as Express.Multer.File;
      if (!file) {
        return res.status(400).json({ message: "فایل ارسال نشده است" });
      }

      const { title, uploadedBy } = req.body;
      const filePath = `/uploads/project-files/${req.params.projectId}/${file.filename}`;

      const [projectFile] = await db.insert(projectFiles).values({
        projectId: req.params.projectId,
        title: title || file.originalname,
        fileName: file.filename,
        filePath: filePath,
        fileType: file.mimetype,
        fileSize: file.size,
        uploadedBy: uploadedBy || null,
      }).returning();

      res.json(projectFile);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/projects/:projectId/files/:fileId", async (req, res) => {
    try {
      const [fileData] = await db.select()
        .from(projectFiles)
        .where(eq(projectFiles.id, req.params.fileId));

      if (fileData) {
        const fullPath = path.join(projectFilesUploadDir, fileData.projectId, fileData.fileName);
        if (fs.existsSync(fullPath)) {
          fs.unlinkSync(fullPath);
        }
      }

      await db.delete(projectFiles).where(eq(projectFiles.id, req.params.fileId));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/bitumen", async (req, res) => {
    try {
      const projectId = req.query.projectId as string;
      if (projectId) {
        const records = await db.select()
          .from(bitumenRecords)
          .where(eq(bitumenRecords.projectId, projectId));
        res.json(records);
      } else {
        const records = await db.select().from(bitumenRecords);
        res.json(records);
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/bitumen", async (req, res) => {
    try {
      const [record] = await db.insert(bitumenRecords).values(req.body).returning();
      res.json(record);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/bitumen/:id", async (req, res) => {
    try {
      const [record] = await db.update(bitumenRecords)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(bitumenRecords.id, req.params.id))
        .returning();
      res.json(record);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/bitumen/:id", async (req, res) => {
    try {
      await db.delete(bitumenRecords).where(eq(bitumenRecords.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tenders", async (req, res) => {
    try {
      const allTenders = await db.select().from(tenders);
      res.json(allTenders);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tenders", async (req, res) => {
    try {
      const [tender] = await db.insert(tenders).values(req.body).returning();
      res.json(tender);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/tenders/:id", async (req, res) => {
    try {
      const [tender] = await db.update(tenders)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(tenders.id, req.params.id))
        .returning();
      res.json(tender);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/tenders/:id", async (req, res) => {
    try {
      await db.delete(tenders).where(eq(tenders.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tenders/:id/approve", async (req, res) => {
    try {
      const { approvalStatus, approvalNotes, approvedBy } = req.body;
      const [tender] = await db.update(tenders)
        .set({ 
          approvalStatus, 
          approvalNotes, 
          approvedBy,
          approvedAt: new Date(),
          updatedAt: new Date() 
        })
        .where(eq(tenders.id, req.params.id))
        .returning();
      
      const tenderData = await db.select().from(tenders).where(eq(tenders.id, req.params.id));
      if (tenderData.length > 0 && tenderData[0].createdBy) {
        const statusText = approvalStatus === "approved" ? "تایید شد" : "رد شد";
        await db.insert(alerts).values({
          title: `نتیجه بررسی مناقصه: ${tenderData[0].title}`,
          description: `مناقصه شما ${statusText}. ${approvalNotes || ''}`,
          severity: approvalStatus === "approved" ? "low" : "medium",
          status: "open",
          assigneeId: tenderData[0].createdBy,
          createdBy: approvedBy,
          entityType: "tender",
          entityId: req.params.id,
        });
      }
      
      res.json(tender);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tenders/pending-approval/:userId", async (req, res) => {
    try {
      const pendingTenders = await db.select()
        .from(tenders)
        .where(
          and(
            eq(tenders.assignedToId, req.params.userId),
            eq(tenders.approvalStatus, "pending")
          )
        );
      res.json(pendingTenders);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/alerts", async (req, res) => {
    try {
      const { projectId, status, severity, entityType } = req.query;
      let query = db.select().from(alerts);
      
      const conditions = [];
      if (projectId) conditions.push(eq(alerts.projectId, projectId as string));
      if (status) conditions.push(eq(alerts.status, status as string));
      if (severity) conditions.push(eq(alerts.severity, severity as string));
      if (entityType) conditions.push(eq(alerts.entityType, entityType as string));
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as any;
      }
      
      const allAlerts = await query;
      res.json(allAlerts);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/alerts", async (req, res) => {
    try {
      const { recipientIds, ...alertData } = req.body;
      const [alert] = await db.insert(alerts).values(alertData).returning();
      
      if (recipientIds && Array.isArray(recipientIds) && recipientIds.length > 0) {
        const recipientRecords = recipientIds.map((userId: string) => ({
          alertId: alert.id,
          userId,
          isRead: false,
        }));
        await db.insert(alertRecipients).values(recipientRecords);
      }
      
      res.json(alert);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/alerts/:id", async (req, res) => {
    try {
      const updateData = { ...req.body, updatedAt: new Date() };
      
      if (req.body.status === 'closed' && !req.body.closedAt) {
        updateData.closedAt = new Date();
      }
      
      const [alert] = await db.update(alerts)
        .set(updateData)
        .where(eq(alerts.id, req.params.id))
        .returning();
      res.json(alert);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/alerts/:id", async (req, res) => {
    try {
      await db.delete(alerts).where(eq(alerts.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/alerts/csv", async (req, res) => {
    try {
      const allAlerts = await db.select().from(alerts);
      
      const csvHeader = "شناسه,پروژه,نوع موجودیت,عنوان,توضیحات,شدت,وضعیت,تاریخ ایجاد,تاریخ بسته شدن\n";
      const csvRows = allAlerts.map(alert => {
        const row = [
          alert.id,
          alert.projectId || '',
          alert.entityType || '',
          alert.title,
          alert.description || '',
          alert.severity,
          alert.status,
          alert.createdAt?.toISOString() || '',
          alert.closedAt?.toISOString() || ''
        ];
        return row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(',');
      }).join('\n');
      
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="alerts.csv"');
      res.send('\ufeff' + csvHeader + csvRows);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/alerts/:id/recipients", async (req, res) => {
    try {
      const recipients = await db.select({
        id: alertRecipients.id,
        alertId: alertRecipients.alertId,
        userId: alertRecipients.userId,
        isRead: alertRecipients.isRead,
        readAt: alertRecipients.readAt,
        firstName: users.firstName,
        lastName: users.lastName,
        username: users.username,
      })
        .from(alertRecipients)
        .leftJoin(users, eq(alertRecipients.userId, users.id))
        .where(eq(alertRecipients.alertId, req.params.id));
      
      res.json(recipients);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/alerts/:id/mark-read", async (req, res) => {
    try {
      const { userId } = req.body;
      
      await db.update(alertRecipients)
        .set({ isRead: true, readAt: new Date() })
        .where(
          and(
            eq(alertRecipients.alertId, req.params.id),
            eq(alertRecipients.userId, userId)
          )
        );
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/alerts/:id/recipients", async (req, res) => {
    try {
      const { recipientIds } = req.body;
      
      await db.delete(alertRecipients)
        .where(eq(alertRecipients.alertId, req.params.id));
      
      if (recipientIds && Array.isArray(recipientIds) && recipientIds.length > 0) {
        const recipientRecords = recipientIds.map((userId: string) => ({
          alertId: req.params.id,
          userId,
          isRead: false,
        }));
        await db.insert(alertRecipients).values(recipientRecords);
      }
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/alerts/:id/comments", async (req, res) => {
    try {
      const comments = await db.select({
        id: alertComments.id,
        alertId: alertComments.alertId,
        userId: alertComments.userId,
        content: alertComments.content,
        createdAt: alertComments.createdAt,
        updatedAt: alertComments.updatedAt,
        firstName: users.firstName,
        lastName: users.lastName,
        username: users.username,
        avatarPath: users.avatarPath,
      })
        .from(alertComments)
        .leftJoin(users, eq(alertComments.userId, users.id))
        .where(eq(alertComments.alertId, req.params.id))
        .orderBy(alertComments.createdAt);
      
      res.json(comments);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/alerts/:id/comments", async (req, res) => {
    try {
      const { userId, content } = req.body;
      
      const [comment] = await db.insert(alertComments)
        .values({
          alertId: req.params.id,
          userId,
          content,
        })
        .returning();
      
      const commentWithUser = await db.select({
        id: alertComments.id,
        alertId: alertComments.alertId,
        userId: alertComments.userId,
        content: alertComments.content,
        createdAt: alertComments.createdAt,
        updatedAt: alertComments.updatedAt,
        firstName: users.firstName,
        lastName: users.lastName,
        username: users.username,
        avatarPath: users.avatarPath,
      })
        .from(alertComments)
        .leftJoin(users, eq(alertComments.userId, users.id))
        .where(eq(alertComments.id, comment.id));
      
      res.json(commentWithUser[0]);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Sheets Management Endpoints
  const sheetsUploadDir = path.join(process.cwd(), "uploads", "sheets");
  if (!fs.existsSync(sheetsUploadDir)) {
    fs.mkdirSync(sheetsUploadDir, { recursive: true });
  }

  const sheetsStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const projectId = req.body.projectId || "temp";
      const sheetId = req.params.id || req.body.sheetId || "temp";
      const uploadPath = path.join(sheetsUploadDir, projectId, sheetId);
      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
      const timestamp = Date.now();
      const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
      cb(null, `${timestamp}_${sanitizedName}`);
    }
  });

  const sheetsUpload = multer({
    storage: sheetsStorage,
    limits: { fileSize: 15 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
      const allowedTypes = /jpeg|jpg|png|pdf|xlsx|xls|doc|docx/;
      const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
      const mimetype = allowedTypes.test(file.mimetype);
      if (extname && mimetype) {
        cb(null, true);
      } else {
        cb(new Error('فقط فایل‌های تصویر، PDF و Excel مجاز هستند'));
      }
    }
  });

  app.get("/api/sheets", async (req, res) => {
    try {
      const { projectId, sheetType, status, dateFrom, dateTo } = req.query;
      
      const conditions = [sqlOperator`${sheets.deletedAt} IS NULL`];
      if (projectId) conditions.push(eq(sheets.projectId, projectId as string));
      if (sheetType) conditions.push(eq(sheets.sheetType, sheetType as string));
      if (status) conditions.push(eq(sheets.status, status as string));
      if (dateFrom) conditions.push(sqlOperator`${sheets.sampleDate} >= ${dateFrom}`);
      if (dateTo) conditions.push(sqlOperator`${sheets.sampleDate} <= ${dateTo}`);
      
      const query = db.select().from(sheets).where(and(...conditions));
      const allSheets = await query;
      res.json(allSheets);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/sheets/:id", async (req, res) => {
    try {
      const [sheet] = await db.select()
        .from(sheets)
        .where(and(eq(sheets.id, req.params.id), sqlOperator`${sheets.deletedAt} IS NULL`));
      
      if (!sheet) {
        return res.status(404).json({ message: "شیت یافت نشد" });
      }

      const files = await db.select()
        .from(sheetFiles)
        .where(eq(sheetFiles.sheetId, req.params.id));

      res.json({ ...sheet, files });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/sheets", sheetsUpload.array('files', 5), async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[] || [];
      const { projectId, sheetType, sampleDate, status, createdBy, ...otherData } = req.body;

      const [sheet] = await db.insert(sheets).values({
        projectId,
        sheetType,
        sampleDate,
        status: status || 'pending',
        createdBy,
        ...otherData
      }).returning();

      if (files.length > 0) {
        const sheetId = sheet.id;
        const newPath = path.join(sheetsUploadDir, projectId, sheetId);
        
        if (!fs.existsSync(newPath)) {
          fs.mkdirSync(newPath, { recursive: true });
        }

        for (const file of files) {
          const oldPath = file.path;
          const newFilePath = path.join(newPath, file.filename);
          fs.renameSync(oldPath, newFilePath);

          await db.insert(sheetFiles).values({
            sheetId: sheet.id,
            fileName: file.filename,
            filePath: newFilePath,
            fileType: file.mimetype,
            uploadedBy: createdBy
          });
        }
      }

      res.json(sheet);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/sheets/:id", async (req, res) => {
    try {
      const [sheet] = await db.update(sheets)
        .set({ ...req.body, updatedAt: new Date() })
        .where(and(eq(sheets.id, req.params.id), sqlOperator`${sheets.deletedAt} IS NULL`))
        .returning();
      res.json(sheet);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/sheets/:id", async (req, res) => {
    try {
      await db.update(sheets)
        .set({ deletedAt: new Date() })
        .where(eq(sheets.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/sheets/csv", async (req, res) => {
    try {
      const allSheets = await db.select().from(sheets).where(sqlOperator`${sheets.deletedAt} IS NULL`);
      
      const csvHeader = "شناسه,پروژه,کد شیت,نوع,تاریخ نمونه,تاریخ آزمایش,محل,آزمایشگاه,وضعیت,توضیحات\n";
      const csvRows = allSheets.map(sheet => {
        const row = [
          sheet.id,
          sheet.projectId,
          sheet.sheetCode || '',
          sheet.sheetType,
          sheet.sampleDate,
          sheet.testDate || '',
          sheet.location || '',
          sheet.labName || '',
          sheet.status,
          sheet.notes || ''
        ];
        return row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(',');
      }).join('\n');
      
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="sheets.csv"');
      res.send('\ufeff' + csvHeader + csvRows);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/sheets/files/:fileId", async (req, res) => {
    try {
      const [file] = await db.select()
        .from(sheetFiles)
        .where(eq(sheetFiles.id, req.params.fileId));

      if (!file) {
        return res.status(404).json({ message: "فایل یافت نشد" });
      }

      res.download(file.filePath, file.fileName);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Statements Endpoints
  app.get("/api/statements", async (req, res) => {
    try {
      const { projectId, status } = req.query;
      let query = db.select().from(statements);
      
      const conditions = [sqlOperator`${statements.deletedAt} IS NULL`];
      if (projectId) conditions.push(eq(statements.projectId, projectId as string));
      if (status) conditions.push(eq(statements.status, status as string));
      
      query = query.where(and(...conditions)) as any;
      const allStatements = await query.orderBy(desc(statements.createdAt));
      res.json(allStatements);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/statements/:id", async (req, res) => {
    try {
      const [statement] = await db.select()
        .from(statements)
        .where(and(
          eq(statements.id, req.params.id),
          sqlOperator`${statements.deletedAt} IS NULL`
        ));
      
      if (!statement) {
        return res.status(404).json({ message: "صورت‌وضعیت یافت نشد" });
      }
      res.json(statement);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/statements", async (req, res) => {
    try {
      const [statement] = await db.insert(statements).values(req.body).returning();
      res.json(statement);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/statements/:id", async (req, res) => {
    try {
      const [statement] = await db.update(statements)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(statements.id, req.params.id))
        .returning();
      res.json(statement);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/statements/:id", async (req, res) => {
    try {
      await db.update(statements)
        .set({ deletedAt: new Date() })
        .where(eq(statements.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Adjustments Endpoints
  app.get("/api/adjustments", async (req, res) => {
    try {
      const { projectId, status } = req.query;
      let query = db.select().from(adjustments);
      
      const conditions = [sqlOperator`${adjustments.deletedAt} IS NULL`];
      if (projectId) conditions.push(eq(adjustments.projectId, projectId as string));
      if (status) conditions.push(eq(adjustments.status, status as string));
      
      query = query.where(and(...conditions)) as any;
      const allAdjustments = await query.orderBy(desc(adjustments.createdAt));
      res.json(allAdjustments);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/adjustments/:id", async (req, res) => {
    try {
      const [adjustment] = await db.select()
        .from(adjustments)
        .where(and(
          eq(adjustments.id, req.params.id),
          sqlOperator`${adjustments.deletedAt} IS NULL`
        ));
      
      if (!adjustment) {
        return res.status(404).json({ message: "تعدیل یافت نشد" });
      }
      res.json(adjustment);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/adjustments", async (req, res) => {
    try {
      const [adjustment] = await db.insert(adjustments).values(req.body).returning();
      res.json(adjustment);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/adjustments/:id", async (req, res) => {
    try {
      const [adjustment] = await db.update(adjustments)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(adjustments.id, req.params.id))
        .returning();
      res.json(adjustment);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/adjustments/:id", async (req, res) => {
    try {
      await db.update(adjustments)
        .set({ deletedAt: new Date() })
        .where(eq(adjustments.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Bitumen Differences Endpoints
  app.get("/api/bitumen-diffs", async (req, res) => {
    try {
      const { projectId, status } = req.query;
      let query = db.select().from(bitumenDiffs);
      
      const conditions = [sqlOperator`${bitumenDiffs.deletedAt} IS NULL`];
      if (projectId) conditions.push(eq(bitumenDiffs.projectId, projectId as string));
      if (status) conditions.push(eq(bitumenDiffs.status, status as string));
      
      query = query.where(and(...conditions)) as any;
      const allBitumenDiffs = await query.orderBy(desc(bitumenDiffs.createdAt));
      res.json(allBitumenDiffs);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/bitumen-diffs/:id", async (req, res) => {
    try {
      const [bitumenDiff] = await db.select()
        .from(bitumenDiffs)
        .where(and(
          eq(bitumenDiffs.id, req.params.id),
          sqlOperator`${bitumenDiffs.deletedAt} IS NULL`
        ));
      
      if (!bitumenDiff) {
        return res.status(404).json({ message: "مابه‌التفاوت قیر یافت نشد" });
      }
      res.json(bitumenDiff);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/bitumen-diffs", async (req, res) => {
    try {
      const [bitumenDiff] = await db.insert(bitumenDiffs).values(req.body).returning();
      res.json(bitumenDiff);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/bitumen-diffs/:id", async (req, res) => {
    try {
      const [bitumenDiff] = await db.update(bitumenDiffs)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(bitumenDiffs.id, req.params.id))
        .returning();
      res.json(bitumenDiff);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/bitumen-diffs/:id", async (req, res) => {
    try {
      await db.update(bitumenDiffs)
        .set({ deletedAt: new Date() })
        .where(eq(bitumenDiffs.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Project Financial History Endpoint
  app.get("/api/projects/:projectId/financial-history", async (req, res) => {
    try {
      const { projectId } = req.params;
      
      // Get all statements for this project
      const projectStatements = await db.select()
        .from(statements)
        .where(and(
          eq(statements.projectId, projectId),
          sqlOperator`${statements.deletedAt} IS NULL`
        ))
        .orderBy(statements.createdAt);
      
      // Get all adjustments for this project
      const projectAdjustments = await db.select()
        .from(adjustments)
        .where(and(
          eq(adjustments.projectId, projectId),
          sqlOperator`${adjustments.deletedAt} IS NULL`
        ))
        .orderBy(adjustments.createdAt);
      
      // Get all bitumen differences for this project
      const projectBitumenDiffs = await db.select()
        .from(bitumenDiffs)
        .where(and(
          eq(bitumenDiffs.projectId, projectId),
          sqlOperator`${bitumenDiffs.deletedAt} IS NULL`
        ))
        .orderBy(bitumenDiffs.createdAt);
      
      res.json({
        statements: projectStatements,
        adjustments: projectAdjustments,
        bitumenDiffs: projectBitumenDiffs,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Helper function to parse Persian/Farsi numbers
  function parsePersianNumber(str: string | null | undefined): number {
    if (!str) return 0;
    // Convert Persian/Arabic digits to English
    const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    let result = str;
    
    // Replace Persian digits
    persianDigits.forEach((digit, index) => {
      result = result.replace(new RegExp(digit, 'g'), index.toString());
    });
    
    // Replace Arabic digits
    arabicDigits.forEach((digit, index) => {
      result = result.replace(new RegExp(digit, 'g'), index.toString());
    });
    
    // Remove both Persian comma (٬) and ASCII comma (,)
    result = result.replace(/[,٬]/g, '');
    
    return parseFloat(result) || 0;
  }

  // Dashboard Financial Statistics Endpoint
  app.get("/api/dashboard/financial-stats", async (req, res) => {
    try {
      // Get all projects
      const allProjects = await db.select().from(projects);
      
      // Get all approved statements
      const allStatements = await db.select()
        .from(statements)
        .where(and(
          eq(statements.status, "تایید شده"),
          sqlOperator`${statements.deletedAt} IS NULL`
        ));
      
      // Get all approved adjustments
      const allAdjustments = await db.select()
        .from(adjustments)
        .where(and(
          eq(adjustments.status, "تایید شده"),
          sqlOperator`${adjustments.deletedAt} IS NULL`
        ));
      
      // Get all approved bitumen diffs
      const allBitumenDiffs = await db.select()
        .from(bitumenDiffs)
        .where(and(
          eq(bitumenDiffs.status, "تایید شده"),
          sqlOperator`${bitumenDiffs.deletedAt} IS NULL`
        ));
      
      // Calculate totals using Persian number parser
      const totalContractAmount = allProjects.reduce((sum, p) => {
        return sum + parsePersianNumber(p.amount);
      }, 0);
      
      const totalStatements = allStatements.reduce((sum, s) => sum + parsePersianNumber(s.amount), 0);
      const totalAdjustments = allAdjustments.reduce((sum, a) => sum + parsePersianNumber(a.amount), 0);
      const totalBitumenDiffs = allBitumenDiffs.reduce((sum, b) => sum + parsePersianNumber(b.amount), 0);
      
      const totalFinancialProgress = totalStatements + totalAdjustments + totalBitumenDiffs;
      const financialProgressPercentage = totalContractAmount > 0 ? (totalFinancialProgress / totalContractAmount) * 100 : 0;
      
      // Calculate monthly progress (last 6 months)
      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
      
      const recentStatements = allStatements.filter(s => s.createdAt && new Date(s.createdAt) >= sixMonthsAgo);
      const monthlyData: Record<string, number> = {};
      
      recentStatements.forEach(s => {
        if (s.createdAt) {
          const month = new Date(s.createdAt).toISOString().slice(0, 7); // YYYY-MM
          monthlyData[month] = (monthlyData[month] || 0) + parsePersianNumber(s.amount);
        }
      });
      
      res.json({
        totalContractAmount,
        totalStatements,
        totalAdjustments,
        totalBitumenDiffs,
        totalFinancialProgress,
        financialProgressPercentage,
        monthlyProgress: Object.entries(monthlyData).map(([month, amount]) => ({
          month,
          amount
        })).sort((a, b) => a.month.localeCompare(b.month)),
        projectCount: allProjects.length,
        statementCount: allStatements.length,
        adjustmentCount: allAdjustments.length,
        bitumenDiffCount: allBitumenDiffs.length,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/weekly-reports", async (req, res) => {
    try {
      const { projectId, status } = req.query;
      let query = db.select().from(weeklyReports);
      
      const conditions = [];
      if (projectId) conditions.push(eq(weeklyReports.projectId, projectId as string));
      if (status) conditions.push(eq(weeklyReports.status, status as string));
      
      query = query.where(conditions.length > 0 ? and(...conditions) : undefined) as any;
      const reports = await query.orderBy(desc(weeklyReports.createdAt));
      res.json(reports);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/weekly-reports/:id", async (req, res) => {
    try {
      const [report] = await db.select()
        .from(weeklyReports)
        .where(eq(weeklyReports.id, req.params.id));
      
      if (!report) {
        return res.status(404).json({ message: "گزارش یافت نشد" });
      }
      res.json(report);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/weekly-reports", async (req, res) => {
    try {
      const [report] = await db.insert(weeklyReports).values(req.body).returning();
      
      if (req.body.projectId) {
        const [project] = await db.select()
          .from(projects)
          .where(eq(projects.id, req.body.projectId));
        
        if (project) {
          const projectManagers = await db.select()
            .from(users)
            .leftJoin(roles, eq(users.roleId, roles.id))
            .where(eq(roles.name, 'project_manager'));
          
          for (const pm of projectManagers) {
            if (pm.users) {
              await db.insert(alerts).values({
                projectId: req.body.projectId,
                title: "گزارش هفتگی جدید",
                description: `گزارش هفتگی جدید برای پروژه ${project.title} ثبت شد`,
                severity: "low",
                status: "open",
                assigneeId: pm.users.id,
                createdBy: req.body.createdBy || null,
              });
            }
          }
        }
      }
      
      res.json(report);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/weekly-reports/:id", async (req, res) => {
    try {
      const [report] = await db.update(weeklyReports)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(weeklyReports.id, req.params.id))
        .returning();
      res.json(report);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/weekly-reports/:id/refer", async (req, res) => {
    try {
      const { referredTo } = req.body;
      const [report] = await db.update(weeklyReports)
        .set({ 
          referredTo, 
          referredAt: new Date(),
          status: "ارجاع شده",
          updatedAt: new Date() 
        })
        .where(eq(weeklyReports.id, req.params.id))
        .returning();
      
      if (referredTo) {
        const [project] = await db.select()
          .from(projects)
          .where(eq(projects.id, report.projectId));
        
        await db.insert(alerts).values({
          projectId: report.projectId,
          title: "گزارش هفتگی ارجاع داده شد",
          description: `گزارش هفتگی پروژه ${project?.title || ''} به شما ارجاع داده شد`,
          severity: "medium",
          status: "open",
          assigneeId: referredTo,
        });
      }
      
      res.json(report);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/weekly-reports/:id", async (req, res) => {
    try {
      await db.delete(weeklyReports).where(eq(weeklyReports.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // User Management Endpoints
  app.get("/api/users", async (req, res) => {
    try {
      const { search, roleId, isActive } = req.query;
      
      const conditions = [];
      if (search) {
        conditions.push(
          or(
            like(users.firstName, `%${search}%`),
            like(users.lastName, `%${search}%`),
            like(users.username, `%${search}%`),
            like(users.email, `%${search}%`)
          )
        );
      }
      if (roleId) conditions.push(eq(users.roleId, roleId as string));
      if (isActive !== undefined) conditions.push(eq(users.isActive, isActive === 'true'));
      
      const allUsers = await db.select({
        id: users.id,
        username: users.username,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        phone: users.phone,
        roleId: users.roleId,
        isActive: users.isActive,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        roleDisplayName: roles.displayName,
        roleName: roles.name,
      })
      .from(users)
      .leftJoin(roles, eq(users.roleId, roles.id))
      .where(conditions.length > 0 ? and(...conditions) : undefined);
      
      res.json(allUsers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const result = await db.select({
        id: users.id,
        username: users.username,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        phone: users.phone,
        roleId: users.roleId,
        isActive: users.isActive,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        roleDisplayName: roles.displayName,
        roleName: roles.name,
      })
      .from(users)
      .leftJoin(roles, eq(users.roleId, roles.id))
      .where(eq(users.id, req.params.id));
      
      if (!result || result.length === 0) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(result[0]);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const { password, role, ...userData } = req.body;
      const hashedPassword = await bcrypt.hash(password, 10);
      
      const [user] = await db.insert(users)
        .values({
          ...userData,
          password: hashedPassword,
        })
        .returning({
          id: users.id,
          username: users.username,
          firstName: users.firstName,
          lastName: users.lastName,
          email: users.email,
          phone: users.phone,
          roleId: users.roleId,
          isActive: users.isActive,
          createdAt: users.createdAt,
        });
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      const { password, role, ...userData } = req.body;
      const updateData: any = {
        ...userData,
        updatedAt: new Date(),
      };
      
      if (password) {
        updateData.password = await bcrypt.hash(password, 10);
      }
      
      const [user] = await db.update(users)
        .set(updateData)
        .where(eq(users.id, req.params.id))
        .returning({
          id: users.id,
          username: users.username,
          firstName: users.firstName,
          lastName: users.lastName,
          email: users.email,
          phone: users.phone,
          roleId: users.roleId,
          isActive: users.isActive,
          updatedAt: users.updatedAt,
        });
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/users/:id", async (req, res) => {
    try {
      await db.delete(users).where(eq(users.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // User-Project Assignments
  app.get("/api/users/:id/projects", async (req, res) => {
    try {
      const assignments = await db.select({
        id: userProjects.id,
        userId: userProjects.userId,
        projectId: userProjects.projectId,
        assignedAt: userProjects.assignedAt,
        projectTitle: projects.title,
        projectLocation: projects.location,
        projectStatus: projects.status,
      })
      .from(userProjects)
      .leftJoin(projects, eq(userProjects.projectId, projects.id))
      .where(eq(userProjects.userId, req.params.id));
      
      res.json(assignments);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/users/:id/projects", async (req, res) => {
    try {
      const { projectId } = req.body;
      const [assignment] = await db.insert(userProjects)
        .values({
          userId: req.params.id,
          projectId,
        })
        .returning();
      res.json(assignment);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/users/:userId/projects/:projectId", async (req, res) => {
    try {
      await db.delete(userProjects)
        .where(
          and(
            eq(userProjects.userId, req.params.userId),
            eq(userProjects.projectId, req.params.projectId)
          )
        );
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Authentication endpoints
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const result = await db.select({
        id: users.id,
        username: users.username,
        password: users.password,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        roleId: users.roleId,
        isActive: users.isActive,
        forcePasswordReset: users.forcePasswordReset,
        roleDisplayName: roles.displayName,
        roleName: roles.name,
      })
      .from(users)
      .leftJoin(roles, eq(users.roleId, roles.id))
      .where(eq(users.username, username));
      
      if (!result || result.length === 0) {
        return res.status(401).json({ message: "نام کاربری یا رمز عبور اشتباه است" });
      }
      
      const user = result[0];
      
      if (!user.isActive) {
        return res.status(403).json({ message: "حساب کاربری غیرفعال است" });
      }
      
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "نام کاربری یا رمز عبور اشتباه است" });
      }
      
      res.json({
        id: user.id,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        roleId: user.roleId,
        role: user.roleName || 'user',
        roleDisplayName: user.roleDisplayName,
        forcePasswordReset: user.forcePasswordReset || false,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { username, email } = req.body;
      const [user] = await db.select().from(users)
        .where(
          and(
            eq(users.username, username),
            eq(users.email, email)
          )
        );
      
      if (!user) {
        return res.status(404).json({ message: "کاربر یافت نشد" });
      }
      
      const resetToken = Math.random().toString(36).substring(2, 15);
      const resetTokenExpiry = new Date(Date.now() + 3600000); // 1 hour
      
      await db.update(users)
        .set({
          resetToken,
          resetTokenExpiry,
        })
        .where(eq(users.id, user.id));
      
      res.json({ resetToken, message: "توکن ریست رمز ایجاد شد" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/auth/confirm-reset", async (req, res) => {
    try {
      const { resetToken, newPassword } = req.body;
      const [user] = await db.select().from(users)
        .where(eq(users.resetToken, resetToken));
      
      if (!user || !user.resetTokenExpiry || user.resetTokenExpiry < new Date()) {
        return res.status(400).json({ message: "توکن نامعتبر یا منقضی شده است" });
      }
      
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await db.update(users)
        .set({
          password: hashedPassword,
          resetToken: null,
          resetTokenExpiry: null,
        })
        .where(eq(users.id, user.id));
      
      res.json({ message: "رمز عبور با موفقیت تغییر یافت" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/auth/change-password", async (req, res) => {
    try {
      const { userId, currentPassword, newPassword } = req.body;
      
      const [user] = await db.select().from(users).where(eq(users.id, userId));
      
      if (!user) {
        return res.status(404).json({ message: "کاربر یافت نشد" });
      }

      const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "رمز عبور فعلی اشتباه است" });
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await db.update(users)
        .set({
          password: hashedPassword,
          forcePasswordReset: false,
        })
        .where(eq(users.id, user.id));

      res.json({ message: "رمز عبور با موفقیت تغییر یافت" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const uploadDir = path.join(process.cwd(), "uploads", "messages");
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  const storageConfig = multer.diskStorage({
    destination: (req, file, cb) => {
      const conversationId = req.params.conversationId || "temp";
      const messageId = req.body.messageId || "temp";
      const uploadPath = path.join(uploadDir, conversationId, messageId);
      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, uniqueSuffix + "-" + file.originalname);
    },
  });

  const upload = multer({ storage: storageConfig });

  app.get("/api/conversations", async (req, res) => {
    try {
      const { userId, projectId, type } = req.query;
      const conditions = [];
      
      if (type) conditions.push(eq(conversations.type, type as string));
      if (projectId) conditions.push(eq(conversations.projectId, projectId as string));

      let query = db.select().from(conversations);
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as any;
      }

      let allConversations = await query;

      if (userId) {
        const memberConversations = await db
          .select({ conversationId: conversationMembers.conversationId })
          .from(conversationMembers)
          .where(eq(conversationMembers.userId, userId as string));
        
        const conversationIds = memberConversations.map(m => m.conversationId);
        allConversations = allConversations.filter(c => conversationIds.includes(c.id));
      }

      res.json(allConversations);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/conversations", async (req, res) => {
    try {
      const { type, title, projectId, createdBy, memberIds } = req.body;
      
      const [conversation] = await db.insert(conversations)
        .values({ type, title, projectId, createdBy })
        .returning();

      if (memberIds && Array.isArray(memberIds)) {
        for (const memberId of memberIds) {
          await db.insert(conversationMembers)
            .values({ conversationId: conversation.id, userId: memberId });
        }
      }

      res.json(conversation);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/conversations/:id", async (req, res) => {
    try {
      const [conversation] = await db.select()
        .from(conversations)
        .where(eq(conversations.id, req.params.id));
      
      if (!conversation) {
        return res.status(404).json({ message: "گفتگو یافت نشد" });
      }

      const members = await db.select()
        .from(conversationMembers)
        .where(eq(conversationMembers.conversationId, req.params.id));

      res.json({ ...conversation, members });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/conversations/:id", async (req, res) => {
    try {
      await db.delete(conversations).where(eq(conversations.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/conversations/:conversationId/messages", async (req, res) => {
    try {
      const conversationId = req.params.conversationId;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      
      const allMessages = await db.select()
        .from(messages)
        .where(eq(messages.conversationId, conversationId))
        .orderBy(desc(messages.createdAt))
        .limit(limit);

      const messageIds = allMessages.map(m => m.id);
      const files = messageIds.length > 0 
        ? await db.select()
            .from(messageFiles)
            .where(sqlOperator`${messageFiles.messageId} = ANY(${messageIds})`)
        : [];

      const reads = messageIds.length > 0
        ? await db.select()
            .from(messageReads)
            .where(sqlOperator`${messageReads.messageId} = ANY(${messageIds})`)
        : [];

      const messagesWithFiles = allMessages.map(msg => ({
        ...msg,
        files: files.filter(f => f.messageId === msg.id),
        reads: reads.filter(r => r.messageId === msg.id),
      }));

      res.json(messagesWithFiles.reverse());
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/conversations/:conversationId/messages", upload.array("files", 5), async (req, res) => {
    try {
      const { conversationId } = req.params;
      const { senderId, content } = req.body;

      const [message] = await db.insert(messages)
        .values({ conversationId, senderId, content })
        .returning();

      if (req.files && Array.isArray(req.files)) {
        const messageId = message.id;
        const uploadPath = path.join(uploadDir, conversationId, messageId);
        
        if (!fs.existsSync(uploadPath)) {
          fs.mkdirSync(uploadPath, { recursive: true });
        }

        for (const file of req.files) {
          const newPath = path.join(uploadPath, file.filename);
          fs.renameSync(file.path, newPath);

          await db.insert(messageFiles).values({
            messageId,
            filename: file.filename,
            originalName: file.originalname,
            mimeType: file.mimetype,
            size: file.size,
            path: `/uploads/messages/${conversationId}/${messageId}/${file.filename}`,
          });
        }
      }

      const files = await db.select()
        .from(messageFiles)
        .where(eq(messageFiles.messageId, message.id));

      res.json({ ...message, files, reads: [] });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/messages/:messageId/read", async (req, res) => {
    try {
      const { messageId } = req.params;
      const { userId } = req.body;

      const existing = await db.select()
        .from(messageReads)
        .where(and(
          eq(messageReads.messageId, messageId),
          eq(messageReads.userId, userId)
        ));

      if (existing.length === 0) {
        const [read] = await db.insert(messageReads)
          .values({ messageId, userId })
          .returning();
        res.json(read);
      } else {
        res.json(existing[0]);
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/messages/search", async (req, res) => {
    try {
      const { userId, projectId, query: searchQuery } = req.query;
      
      let conversationIds: string[] = [];

      if (userId) {
        const userConversations = await db.select({ conversationId: conversationMembers.conversationId })
          .from(conversationMembers)
          .where(eq(conversationMembers.userId, userId as string));
        conversationIds = userConversations.map(c => c.conversationId);
      }

      if (projectId) {
        const projectConversations = await db.select({ id: conversations.id })
          .from(conversations)
          .where(eq(conversations.projectId, projectId as string));
        const projectConvIds = projectConversations.map(c => c.id);
        
        if (conversationIds.length > 0) {
          conversationIds = conversationIds.filter(id => projectConvIds.includes(id));
        } else {
          conversationIds = projectConvIds;
        }
      }

      let query = db.select().from(messages);

      const conditions = [];
      if (conversationIds.length > 0) {
        conditions.push(sqlOperator`${messages.conversationId} = ANY(${conversationIds})`);
      }
      if (searchQuery) {
        conditions.push(like(messages.content, `%${searchQuery}%`));
      }

      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as any;
      }

      const results = await query.orderBy(desc(messages.createdAt)).limit(50);
      res.json(results);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Roles and Permissions Management
  app.get("/api/roles", async (req, res) => {
    try {
      const allRoles = await db.select().from(roles);
      res.json(allRoles);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/roles/:id", async (req, res) => {
    try {
      const [role] = await db.select().from(roles).where(eq(roles.id, req.params.id));
      if (!role) {
        return res.status(404).json({ message: "نقش یافت نشد" });
      }
      
      const rolePerms = await db.select()
        .from(rolePermissions)
        .innerJoin(permissions, eq(rolePermissions.permissionId, permissions.id))
        .where(eq(rolePermissions.roleId, req.params.id));
      
      res.json({ ...role, permissions: rolePerms.map(rp => rp.permissions) });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/roles", async (req, res) => {
    try {
      const { name, displayName, description, permissionIds } = req.body;
      const [role] = await db.insert(roles).values({ name, displayName, description }).returning();
      
      if (permissionIds && permissionIds.length > 0) {
        await db.insert(rolePermissions).values(
          permissionIds.map((permId: string) => ({ roleId: role.id, permissionId: permId }))
        );
      }
      
      res.json(role);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/roles/:id", async (req, res) => {
    try {
      const { name, displayName, description, permissionIds } = req.body;
      const [role] = await db.update(roles)
        .set({ name, displayName, description, updatedAt: new Date() })
        .where(eq(roles.id, req.params.id))
        .returning();
      
      if (permissionIds !== undefined) {
        await db.delete(rolePermissions).where(eq(rolePermissions.roleId, req.params.id));
        
        if (permissionIds.length > 0) {
          await db.insert(rolePermissions).values(
            permissionIds.map((permId: string) => ({ roleId: req.params.id, permissionId: permId }))
          );
        }
      }
      
      res.json(role);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/roles/:id", async (req, res) => {
    try {
      const [role] = await db.select().from(roles).where(eq(roles.id, req.params.id));
      if (role?.isSystem) {
        return res.status(400).json({ message: "نقش سیستمی قابل حذف نیست" });
      }
      
      await db.delete(roles).where(eq(roles.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Permissions Management
  app.get("/api/permissions", async (req, res) => {
    try {
      const allPermissions = await db.select().from(permissions);
      res.json(allPermissions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/permissions", async (req, res) => {
    try {
      const [permission] = await db.insert(permissions).values(req.body).returning();
      res.json(permission);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/permissions/:id", async (req, res) => {
    try {
      const [permission] = await db.update(permissions)
        .set(req.body)
        .where(eq(permissions.id, req.params.id))
        .returning();
      res.json(permission);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/permissions/:id", async (req, res) => {
    try {
      await db.delete(permissions).where(eq(permissions.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Profile Management
  const avatarStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const avatarDir = path.join(process.cwd(), "uploads", "avatars");
      if (!fs.existsSync(avatarDir)) {
        fs.mkdirSync(avatarDir, { recursive: true });
      }
      cb(null, avatarDir);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      const filename = `avatar-${Date.now()}${ext}`;
      cb(null, filename);
    }
  });

  const avatarUpload = multer({ 
    storage: avatarStorage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
      const allowedTypes = /jpeg|jpg|png|gif/;
      const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
      const mimetype = allowedTypes.test(file.mimetype);
      if (extname && mimetype) {
        cb(null, true);
      } else {
        cb(new Error('فقط فایل‌های تصویری مجاز هستند'));
      }
    }
  });

  app.get("/api/profile/:userId", async (req, res) => {
    try {
      const [user] = await db.select({
        id: users.id,
        username: users.username,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        phone: users.phone,
        role: users.role,
        roleId: users.roleId,
        isActive: users.isActive,
        avatarPath: users.avatarPath,
        createdAt: users.createdAt,
      }).from(users).where(eq(users.id, req.params.userId));

      if (!user) {
        return res.status(404).json({ message: "کاربر یافت نشد" });
      }

      const userProj = await db.select()
        .from(userProjects)
        .innerJoin(projects, eq(userProjects.projectId, projects.id))
        .where(eq(userProjects.userId, req.params.userId));

      const roleInfo = user.roleId ? await db.select().from(roles).where(eq(roles.id, user.roleId)) : [];

      res.json({ 
        ...user, 
        projects: userProj.map(up => up.projects),
        roleInfo: roleInfo[0] || null
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/profile/:userId", async (req, res) => {
    try {
      const { firstName, lastName, email, phone } = req.body;
      const [updatedUser] = await db.update(users)
        .set({ firstName, lastName, email, phone, updatedAt: new Date() })
        .where(eq(users.id, req.params.userId))
        .returning();
      
      res.json(updatedUser);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/profile/:userId/avatar", avatarUpload.single('avatar'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "فایل تصویر ارسال نشده است" });
      }

      const avatarPath = `/uploads/avatars/${req.file.filename}`;
      
      const [user] = await db.select().from(users).where(eq(users.id, req.params.userId));
      if (user?.avatarPath) {
        const oldAvatarPath = path.join(process.cwd(), user.avatarPath);
        if (fs.existsSync(oldAvatarPath)) {
          fs.unlinkSync(oldAvatarPath);
        }
      }

      const [updatedUser] = await db.update(users)
        .set({ avatarPath, updatedAt: new Date() })
        .where(eq(users.id, req.params.userId))
        .returning();

      res.json(updatedUser);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/profile/:userId/change-password", async (req, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      
      const [user] = await db.select().from(users).where(eq(users.id, req.params.userId));
      
      if (!user) {
        return res.status(404).json({ message: "کاربر یافت نشد" });
      }

      const isValid = await bcrypt.compare(currentPassword, user.password);
      
      if (!isValid) {
        return res.status(400).json({ message: "رمز عبور فعلی اشتباه است" });
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      
      await db.update(users)
        .set({ password: hashedPassword, updatedAt: new Date() })
        .where(eq(users.id, req.params.userId));

      res.json({ success: true, message: "رمز عبور با موفقیت تغییر یافت" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get user permissions
  app.get("/api/users/:userId/permissions", async (req, res) => {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, req.params.userId));
      
      if (!user || !user.roleId) {
        return res.json([]);
      }

      const userPermissions = await db.select()
        .from(rolePermissions)
        .innerJoin(permissions, eq(rolePermissions.permissionId, permissions.id))
        .where(eq(rolePermissions.roleId, user.roleId));

      res.json(userPermissions.map(up => up.permissions));
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/ai-assistant/chat", async (req, res) => {
    try {
      const { message, projectId } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "پیام الزامی است" });
      }

      const response = await chatWithAssistant(message, projectId);
      res.json({ response });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Tasks API
  app.get("/api/tasks", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const category = req.query.category as string;
      
      let query = db.select().from(tasks);
      const conditions = [];
      
      if (userId) conditions.push(eq(tasks.userId, userId));
      if (category) conditions.push(eq(tasks.category, category));
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as any;
      }
      
      const allTasks = await query.orderBy(desc(tasks.createdAt));
      res.json(allTasks);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const [task] = await db.insert(tasks).values(req.body).returning();
      res.json(task);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/tasks/:id", async (req, res) => {
    try {
      const [task] = await db.update(tasks)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(tasks.id, req.params.id))
        .returning();
      res.json(task);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const updateData: any = { ...req.body, updatedAt: new Date() };
      
      if (req.body.isCompleted === true) {
        updateData.completedAt = new Date();
      } else if (req.body.isCompleted === false) {
        updateData.completedAt = null;
      }
      
      const [task] = await db.update(tasks)
        .set(updateData)
        .where(eq(tasks.id, req.params.id))
        .returning();
      res.json(task);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      await db.delete(tasks).where(eq(tasks.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Daily Notes API
  app.get("/api/daily-notes", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const noteDate = req.query.noteDate as string;
      
      let query = db.select().from(dailyNotes);
      const conditions = [];
      
      if (userId) conditions.push(eq(dailyNotes.userId, userId));
      if (noteDate) conditions.push(eq(dailyNotes.noteDate, noteDate));
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as any;
      }
      
      const notes = await query.orderBy(desc(dailyNotes.createdAt));
      res.json(notes);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/daily-notes", async (req, res) => {
    try {
      const { userId, noteDate, content } = req.body;
      
      // Check if note exists for this date
      const [existing] = await db.select().from(dailyNotes)
        .where(and(
          eq(dailyNotes.userId, userId),
          eq(dailyNotes.noteDate, noteDate)
        ));
      
      if (existing) {
        // Update existing note
        const [note] = await db.update(dailyNotes)
          .set({ content, updatedAt: new Date() })
          .where(eq(dailyNotes.id, existing.id))
          .returning();
        return res.json(note);
      }
      
      // Create new note
      const [note] = await db.insert(dailyNotes).values(req.body).returning();
      res.json(note);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/daily-notes/:id", async (req, res) => {
    try {
      await db.delete(dailyNotes).where(eq(dailyNotes.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Follow-up Tasks API
  app.get("/api/follow-up-tasks", async (req, res) => {
    try {
      const fromUserId = req.query.fromUserId as string;
      const toUserId = req.query.toUserId as string;
      
      let query = db.select({
        task: followUpTasks,
        fromUser: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
        },
        toUser: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
        },
      })
      .from(followUpTasks)
      .leftJoin(users, eq(followUpTasks.fromUserId, users.id));
      
      const conditions = [];
      if (fromUserId) conditions.push(eq(followUpTasks.fromUserId, fromUserId));
      if (toUserId) conditions.push(eq(followUpTasks.toUserId, toUserId));
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as any;
      }
      
      const followUpTasksList = await query.orderBy(desc(followUpTasks.createdAt));
      res.json(followUpTasksList);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/follow-up-tasks", async (req, res) => {
    try {
      const [task] = await db.insert(followUpTasks).values(req.body).returning();
      res.json(task);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/follow-up-tasks/:id", async (req, res) => {
    try {
      const [task] = await db.update(followUpTasks)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(followUpTasks.id, req.params.id))
        .returning();
      res.json(task);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/follow-up-tasks/:id/confirm", async (req, res) => {
    try {
      const [task] = await db.update(followUpTasks)
        .set({ 
          isConfirmed: true, 
          confirmedAt: new Date(),
          status: 'completed',
          updatedAt: new Date() 
        })
        .where(eq(followUpTasks.id, req.params.id))
        .returning();
      res.json(task);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/follow-up-tasks/:id", async (req, res) => {
    try {
      await db.delete(followUpTasks).where(eq(followUpTasks.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const tasksUploadDir = path.join(process.cwd(), "uploads", "tasks");
  if (!fs.existsSync(tasksUploadDir)) {
    fs.mkdirSync(tasksUploadDir, { recursive: true });
  }

  const tasksStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, tasksUploadDir);
    },
    filename: (req, file, cb) => {
      const timestamp = Date.now();
      const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
      cb(null, `${timestamp}_${sanitizedName}`);
    }
  });

  const tasksUpload = multer({
    storage: tasksStorage,
    limits: { fileSize: 10 * 1024 * 1024 },
  });

  app.post("/api/tasks/with-attachment", tasksUpload.single('file'), async (req, res) => {
    try {
      const file = req.file as Express.Multer.File;
      const taskData = JSON.parse(req.body.taskData);
      
      const [task] = await db.insert(tasks).values(taskData).returning();

      if (file) {
        await db.insert(taskAttachments).values({
          taskId: task.id,
          fileName: file.filename,
          filePath: file.path,
          fileType: file.mimetype,
        });
      }

      if (taskData.assigneeId && taskData.assigneeId !== taskData.userId) {
        await db.insert(letters).values({
          fromUserId: taskData.userId,
          subject: `وظیفه جدید: ${taskData.title}`,
          content: `یک وظیفه جدید به شما اختصاص داده شد:\n\n${taskData.description || ''}`,
          projectId: taskData.projectId || null,
        }).returning().then(async ([letter]) => {
          await db.insert(letterRecipients).values({
            letterId: letter.id,
            userId: taskData.assigneeId,
          });
        });
      }

      res.json(task);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tasks/:id/attachments", async (req, res) => {
    try {
      const attachments = await db.select()
        .from(taskAttachments)
        .where(eq(taskAttachments.taskId, req.params.id));
      res.json(attachments);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/tasks/:id/confirm", async (req, res) => {
    try {
      const { confirmed } = req.body;
      const [task] = await db.update(tasks)
        .set({ 
          isConfirmed: confirmed, 
          confirmedAt: confirmed ? new Date() : null,
          updatedAt: new Date() 
        })
        .where(eq(tasks.id, req.params.id))
        .returning();
      res.json(task);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tasks/by-project/:projectId", async (req, res) => {
    try {
      const projectTasks = await db.select()
        .from(tasks)
        .where(eq(tasks.projectId, req.params.projectId));
      
      const total = projectTasks.length;
      const completed = projectTasks.filter(t => t.isCompleted).length;
      const pending = total - completed;

      res.json({ tasks: projectTasks, stats: { total, completed, pending } });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/sticky-notes", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      let query = db.select().from(stickyNotes);
      
      if (userId) {
        query = query.where(eq(stickyNotes.userId, userId)) as any;
      }
      
      const notes = await query.orderBy(desc(stickyNotes.createdAt));
      res.json(notes);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/sticky-notes", async (req, res) => {
    try {
      const [note] = await db.insert(stickyNotes).values(req.body).returning();
      res.json(note);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.put("/api/sticky-notes/:id", async (req, res) => {
    try {
      const [note] = await db.update(stickyNotes)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(stickyNotes.id, req.params.id))
        .returning();
      res.json(note);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/sticky-notes/:id", async (req, res) => {
    try {
      await db.delete(stickyNotes).where(eq(stickyNotes.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/sticky-notes/:id/items", async (req, res) => {
    try {
      const items = await db.select()
        .from(stickyNoteItems)
        .where(eq(stickyNoteItems.noteId, req.params.id))
        .orderBy(stickyNoteItems.orderIndex);
      res.json(items);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/sticky-notes/:id/items", async (req, res) => {
    try {
      const [item] = await db.insert(stickyNoteItems).values({
        noteId: req.params.id,
        ...req.body
      }).returning();
      res.json(item);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/sticky-notes/items/:id", async (req, res) => {
    try {
      const [item] = await db.update(stickyNoteItems)
        .set(req.body)
        .where(eq(stickyNoteItems.id, req.params.id))
        .returning();
      res.json(item);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/sticky-notes/items/:id", async (req, res) => {
    try {
      await db.delete(stickyNoteItems).where(eq(stickyNoteItems.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const lettersUploadDir = path.join(process.cwd(), "uploads", "letters");
  if (!fs.existsSync(lettersUploadDir)) {
    fs.mkdirSync(lettersUploadDir, { recursive: true });
  }

  const lettersStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, lettersUploadDir);
    },
    filename: (req, file, cb) => {
      const timestamp = Date.now();
      const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
      cb(null, `${timestamp}_${sanitizedName}`);
    }
  });

  const lettersUpload = multer({
    storage: lettersStorage,
    limits: { fileSize: 10 * 1024 * 1024 },
  });

  app.get("/api/letters/inbox/:userId", async (req, res) => {
    try {
      const inboxLetters = await db.select({
        letter: letters,
        sender: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
        },
        recipient: letterRecipients,
      })
        .from(letterRecipients)
        .innerJoin(letters, eq(letterRecipients.letterId, letters.id))
        .leftJoin(users, eq(letters.fromUserId, users.id))
        .where(eq(letterRecipients.userId, req.params.userId))
        .orderBy(desc(letters.createdAt));
      
      res.json(inboxLetters);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/letters/outbox/:userId", async (req, res) => {
    try {
      const outboxLetters = await db.select()
        .from(letters)
        .where(eq(letters.fromUserId, req.params.userId))
        .orderBy(desc(letters.createdAt));
      
      res.json(outboxLetters);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/letters/project/:projectId", async (req, res) => {
    try {
      const projectLetters = await db.select()
        .from(letters)
        .where(eq(letters.projectId, req.params.projectId))
        .orderBy(desc(letters.createdAt));
      
      res.json(projectLetters);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/letters", lettersUpload.array('files', 5), async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[] || [];
      const { fromUserId, recipientIds, subject, content, projectId } = req.body;
      
      const [letter] = await db.insert(letters).values({
        fromUserId,
        subject,
        content,
        projectId: projectId || null,
      }).returning();

      const recipientList = JSON.parse(recipientIds);
      for (const recipientId of recipientList) {
        await db.insert(letterRecipients).values({
          letterId: letter.id,
          userId: recipientId,
        });
      }

      if (files.length > 0) {
        for (const file of files) {
          await db.insert(letterAttachments).values({
            letterId: letter.id,
            fileName: file.filename,
            filePath: file.path,
            fileType: file.mimetype,
          });
        }
      }

      res.json(letter);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/letters/:id/read", async (req, res) => {
    try {
      const { userId } = req.body;
      await db.update(letterRecipients)
        .set({ isRead: true, readAt: new Date() })
        .where(and(
          eq(letterRecipients.letterId, req.params.id),
          eq(letterRecipients.userId, userId)
        ));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/calendar-notes", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const date = req.query.date as string;
      
      let query = db.select().from(calendarNotes);
      const conditions = [];
      
      if (userId) conditions.push(eq(calendarNotes.userId, userId));
      if (date) conditions.push(eq(calendarNotes.date, date));
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as any;
      }
      
      const notes = await query.orderBy(desc(calendarNotes.createdAt));
      res.json(notes);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/calendar-notes", async (req, res) => {
    try {
      const { userId, date, content } = req.body;
      
      const [existing] = await db.select().from(calendarNotes)
        .where(and(
          eq(calendarNotes.userId, userId),
          eq(calendarNotes.date, date)
        ));
      
      if (existing) {
        const [note] = await db.update(calendarNotes)
          .set({ content, updatedAt: new Date() })
          .where(eq(calendarNotes.id, existing.id))
          .returning();
        return res.json(note);
      }
      
      const [note] = await db.insert(calendarNotes).values(req.body).returning();
      res.json(note);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/calendar-notes/:id", async (req, res) => {
    try {
      await db.delete(calendarNotes).where(eq(calendarNotes.id, req.params.id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Auto-Import Projects API Endpoint (Development Only)
  app.post("/api/admin/import-projects", async (req, res) => {
    try {
      // Security: Only allow in development environment
      if (process.env.NODE_ENV !== 'development') {
        return res.status(403).json({ message: 'این عملیات فقط در محیط توسعه مجاز است' });
      }
      
      console.log('🚀 شروع import خودکار پروژه‌ها...');
      
      // Import and run the real projects import script
      const importModule = await import('./import-real-projects.js');
      // The script runs automatically on import, so we just need to wait a bit
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const projectCount = await db.select().from(projects);
      res.json({ 
        success: true, 
        message: 'پروژه‌ها با موفقیت وارد شدند',
        projectCount: projectCount.length 
      });
    } catch (error: any) {
      console.error('❌ خطا در import پروژه‌ها:', error);
      res.status(500).json({ message: error.message });
    }
  });

  const staticUploadPath = path.join(process.cwd(), "uploads");
  if (!fs.existsSync(staticUploadPath)) {
    fs.mkdirSync(staticUploadPath, { recursive: true });
  }
  
  app.use("/uploads", express.static(staticUploadPath));

  const httpServer = createServer(app);

  return httpServer;
}
