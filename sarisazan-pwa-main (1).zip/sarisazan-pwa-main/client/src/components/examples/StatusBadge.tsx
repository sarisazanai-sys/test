import StatusBadge from '../StatusBadge';

export default function StatusBadgeExample() {
  return (
    <div className="p-4 flex gap-2 flex-wrap">
      <StatusBadge status="active" />
      <StatusBadge status="completed" />
      <StatusBadge status="pending" />
      <StatusBadge status="suspended" />
      <StatusBadge status="approved" />
      <StatusBadge status="rejected" />
    </div>
  );
}
