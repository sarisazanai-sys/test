import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import ThemeToggle from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { LogOut, Calendar, User } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import PersonalDashboard from "@/components/PersonalDashboard";
import ManagementDashboard from "@/components/ManagementDashboard";
import ProjectsPage from "@/components/ProjectsPage";
import ProjectDetailsPage from "@/pages/ProjectDetailsPage";
import WeeklyReportsPage from "@/components/WeeklyReportsPage";
import ExecutionReportsPage from "@/pages/ExecutionReportsPage";
import BitumenPage from "@/components/BitumenPage";
import TendersPage from "@/components/TendersPage";
import AlertsPage from "@/components/AlertsPage";
import UsersPage from "@/components/UsersPage";
import MessagesPage from "@/components/MessagesPage";
import SheetsPage from "@/components/SheetsPage";
import StatementsPage from "@/components/StatementsPage";
import BitumenDiffsPage from "@/components/BitumenDiffsPage";
import RolesPage from "@/components/RolesPage";
import ProfilePage from "@/components/ProfilePage";
import AIAssistantPage from "@/components/AIAssistantPage";
import TasksPage from "@/components/TasksPage";
import CalendarPage from "@/components/CalendarPage";
import NotesPage from "@/components/NotesPage";
import LettersPage from "@/components/LettersPage";
import LoginForm from "@/components/LoginForm";
import NotFound from "@/pages/not-found";
import { GlobalSearch } from "@/components/GlobalSearch";
import { StatusBar } from "@/components/StatusBar";
import { useState, useEffect } from "react";
import { format } from "date-fns-jalali";
import { toPersianDigits } from "@/lib/persian-utils";
import { ProjectProvider } from "@/lib/project-context";
import { AuthProvider, useAuth } from "@/lib/auth-context";

function PersianDate() {
  const [currentDate, setCurrentDate] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDate(new Date());
    }, 60000); // Update every minute

    return () => clearInterval(timer);
  }, []);

  const persianWeekDays = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه'];
  const dayName = persianWeekDays[currentDate.getDay()];
  const formattedDate = toPersianDigits(format(currentDate, 'yyyy/MM/dd'));

  return (
    <div className="flex items-center gap-2 text-sm text-muted-foreground">
      <Calendar className="w-4 h-4" />
      <span className="hidden sm:inline">{dayName}</span>
      <span>{formattedDate}</span>
    </div>
  );
}

function AuthenticatedRoutes() {
  return (
    <Switch>
      <Route path="/" component={ManagementDashboard} />
      <Route path="/dashboard" component={ManagementDashboard} />
      <Route path="/tasks" component={TasksPage} />
      <Route path="/calendar" component={CalendarPage} />
      <Route path="/notes" component={NotesPage} />
      <Route path="/letters" component={LettersPage} />
      <Route path="/projects" component={ProjectsPage} />
      <Route path="/projects/:id" component={ProjectDetailsPage} />
      <Route path="/reports/execution" component={ExecutionReportsPage} />
      <Route path="/reports/technical" component={WeeklyReportsPage} />
      <Route path="/reports" component={WeeklyReportsPage} />
      <Route path="/statements" component={StatementsPage} />
      <Route path="/bitumen-diffs" component={BitumenDiffsPage} />
      <Route path="/bitumen" component={BitumenPage} />
      <Route path="/sheets" component={SheetsPage} />
      <Route path="/tenders" component={TendersPage} />
      <Route path="/alerts" component={AlertsPage} />
      <Route path="/ai-assistant" component={AIAssistantPage} />
      <Route path="/analysis">
        <div className="p-6">
          <h1 className="text-3xl font-bold mb-4">تحلیل پروژه</h1>
          <p className="text-muted-foreground">نمودارها و تحلیل‌های مالی</p>
        </div>
      </Route>
      <Route path="/users" component={UsersPage} />
      <Route path="/roles" component={RolesPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/messages" component={MessagesPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const { user, setUser, logout, isAuthenticated } = useAuth();
  
  const style = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  const handleLogin = async (username: string, password: string) => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (!response.ok) {
        const error = await response.json();
        alert(error.message || "خطا در ورود");
        return;
      }

      const userData = await response.json();
      setUser(userData);
    } catch (error) {
      alert("خطا در ارتباط با سرور");
    }
  };

  const displayName = user?.firstName && user?.lastName 
    ? `${user.firstName} ${user.lastName}` 
    : user?.username || "کاربر";
  const userRole = user?.roleDisplayName || "کاربر سیستم";

  return (
    <TooltipProvider>
      {!isAuthenticated ? (
        <LoginForm onLogin={handleLogin} />
      ) : (
        <SidebarProvider style={style as React.CSSProperties}>
          <div className="flex h-screen w-full">
            <div className="flex flex-col flex-1">
              <header className="flex items-center justify-between p-4 border-b gap-4 bg-white dark:bg-card">
                <div className="flex items-center gap-3">
                  <Avatar className="w-9 h-9">
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      <User className="w-4 h-4" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden sm:block">
                    <p className="text-sm font-medium">{displayName}</p>
                    <p className="text-xs text-muted-foreground">{userRole}</p>
                  </div>
                </div>
                <div className="flex-1 flex justify-center px-4 max-w-2xl mx-auto">
                  <GlobalSearch />
                </div>
                <div className="flex items-center gap-3">
                  <PersianDate />
                  <div className="h-6 w-px bg-border"></div>
                  <ThemeToggle />
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={logout}
                    data-testid="button-logout"
                    title="خروج"
                  >
                    <LogOut className="w-4 h-4" />
                  </Button>
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                </div>
              </header>
              <StatusBar />
              <main className="flex-1 overflow-auto p-6">
                <AuthenticatedRoutes />
              </main>
            </div>
            <AppSidebar currentUser={user ? {
              name: `${user.firstName} ${user.lastName}`,
              role: user.roleDisplayName,
            } : undefined} />
          </div>
        </SidebarProvider>
      )}
      <Toaster />
    </TooltipProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ProjectProvider>
          <AppContent />
        </ProjectProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
