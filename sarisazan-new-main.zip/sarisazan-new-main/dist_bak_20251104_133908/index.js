var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/index.ts
import express3 from "express";

// server/routes.ts
import { createServer } from "http";

// server/db.ts
import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  adjustments: () => adjustments,
  alertComments: () => alertComments,
  alertRecipients: () => alertRecipients,
  alerts: () => alerts,
  bitumenDiffs: () => bitumenDiffs,
  bitumenRecords: () => bitumenRecords,
  calendarNotes: () => calendarNotes,
  conversationMembers: () => conversationMembers,
  conversations: () => conversations,
  dailyNotes: () => dailyNotes,
  followUpTasks: () => followUpTasks,
  insertAdjustmentSchema: () => insertAdjustmentSchema,
  insertAlertCommentSchema: () => insertAlertCommentSchema,
  insertAlertRecipientSchema: () => insertAlertRecipientSchema,
  insertAlertSchema: () => insertAlertSchema,
  insertBitumenDiffSchema: () => insertBitumenDiffSchema,
  insertBitumenRecordSchema: () => insertBitumenRecordSchema,
  insertCalendarNoteSchema: () => insertCalendarNoteSchema,
  insertConversationMemberSchema: () => insertConversationMemberSchema,
  insertConversationSchema: () => insertConversationSchema,
  insertDailyNoteSchema: () => insertDailyNoteSchema,
  insertFollowUpTaskSchema: () => insertFollowUpTaskSchema,
  insertLetterAttachmentSchema: () => insertLetterAttachmentSchema,
  insertLetterRecipientSchema: () => insertLetterRecipientSchema,
  insertLetterSchema: () => insertLetterSchema,
  insertMessageFileSchema: () => insertMessageFileSchema,
  insertMessageReadSchema: () => insertMessageReadSchema,
  insertMessageSchema: () => insertMessageSchema,
  insertPermissionSchema: () => insertPermissionSchema,
  insertProjectFileSchema: () => insertProjectFileSchema,
  insertProjectSchema: () => insertProjectSchema,
  insertRolePermissionSchema: () => insertRolePermissionSchema,
  insertRoleSchema: () => insertRoleSchema,
  insertSheetFileSchema: () => insertSheetFileSchema,
  insertSheetSchema: () => insertSheetSchema,
  insertStatementSchema: () => insertStatementSchema,
  insertStickyNoteItemSchema: () => insertStickyNoteItemSchema,
  insertStickyNoteSchema: () => insertStickyNoteSchema,
  insertTaskAttachmentSchema: () => insertTaskAttachmentSchema,
  insertTaskSchema: () => insertTaskSchema,
  insertTenderSchema: () => insertTenderSchema,
  insertUserPreferencesSchema: () => insertUserPreferencesSchema,
  insertUserProjectSchema: () => insertUserProjectSchema,
  insertUserSchema: () => insertUserSchema,
  insertWeeklyReportSchema: () => insertWeeklyReportSchema,
  letterAttachments: () => letterAttachments,
  letterRecipients: () => letterRecipients,
  letters: () => letters,
  messageFiles: () => messageFiles,
  messageReads: () => messageReads,
  messages: () => messages,
  permissions: () => permissions,
  projectFiles: () => projectFiles,
  projects: () => projects,
  rolePermissions: () => rolePermissions,
  roles: () => roles,
  sheetFiles: () => sheetFiles,
  sheets: () => sheets,
  statements: () => statements,
  stickyNoteItems: () => stickyNoteItems,
  stickyNotes: () => stickyNotes,
  taskAttachments: () => taskAttachments,
  tasks: () => tasks,
  tenders: () => tenders,
  userPreferences: () => userPreferences,
  userProjects: () => userProjects,
  users: () => users,
  weeklyReports: () => weeklyReports
});
import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
var roles = pgTable("roles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  displayName: text("display_name").notNull(),
  description: text("description"),
  isSystem: boolean("is_system").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var permissions = pgTable("permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: text("key").notNull().unique(),
  displayName: text("display_name").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});
var rolePermissions = pgTable("role_permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roleId: varchar("role_id").notNull().references(() => roles.id, { onDelete: "cascade" }),
  permissionId: varchar("permission_id").notNull().references(() => permissions.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow()
});
var users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  email: text("email"),
  phone: text("phone"),
  roleId: varchar("role_id").references(() => roles.id, { onDelete: "set null" }),
  role: text("role").default("user"),
  isActive: boolean("is_active").default(true),
  avatarPath: text("avatar_path"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  resetToken: text("reset_token"),
  resetTokenExpiry: timestamp("reset_token_expiry"),
  forcePasswordReset: boolean("force_password_reset").default(false)
});
var projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectNumber: text("project_number"),
  title: text("title").notNull(),
  contractNumber: text("contract_number"),
  contractDate: text("contract_date"),
  location: text("location"),
  employer: text("employer"),
  contractor: text("contractor"),
  amount: text("amount"),
  amount25Percent: text("amount_25_percent"),
  link: text("link"),
  progress: integer("progress").default(0),
  status: text("status").default("active"),
  startDate: text("start_date"),
  createdAt: timestamp("created_at").defaultNow()
});
var bitumenRecords = pgTable("bitumen_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  invoiceNumber: text("invoice_number"),
  invoiceDate: text("invoice_date"),
  quantity: decimal("quantity", { precision: 10, scale: 2 }),
  billNumber: text("bill_number"),
  supplier: text("supplier"),
  transportContractor: text("transport_contractor"),
  guaranteeType: text("guarantee_type"),
  type: text("type").default("PG64-22"),
  unitPrice: decimal("unit_price", { precision: 15, scale: 2 }),
  totalAmount: decimal("total_amount", { precision: 15, scale: 2 }),
  hasInvoice: boolean("has_invoice").default(false),
  hasBill: boolean("has_bill").default(false),
  hasWaybill: boolean("has_waybill").default(false),
  bitumenEntry: decimal("bitumen_entry", { precision: 10, scale: 2 }),
  bitumenDeduction: decimal("bitumen_deduction", { precision: 10, scale: 2 }),
  bitumenUsed: decimal("bitumen_used", { precision: 10, scale: 2 }),
  notes: text("notes"),
  invoiceFile: text("invoice_file"),
  billFile: text("bill_file"),
  waybillFile: text("waybill_file"),
  invoices: text("invoices"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var tenders = pgTable("tenders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  city: text("city"),
  amount: decimal("amount", { precision: 15, scale: 2 }),
  announcedDate: text("announced_date"),
  deadlineDate: text("deadline_date"),
  client: text("client"),
  companies: text("companies"),
  status: text("status").default("\u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631 \u0628\u0631\u0631\u0633\u06CC"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
  assignedToId: varchar("assigned_to_id").references(() => users.id, { onDelete: "set null" }),
  approvalStatus: text("approval_status").default("pending"),
  approvalNotes: text("approval_notes"),
  approvedBy: varchar("approved_by").references(() => users.id, { onDelete: "set null" }),
  approvedAt: timestamp("approved_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id, { onDelete: "cascade" }),
  entityType: text("entity_type"),
  entityId: varchar("entity_id"),
  title: text("title").notNull(),
  description: text("description"),
  severity: text("severity").notNull().default("medium"),
  status: text("status").notNull().default("open"),
  assigneeId: varchar("assignee_id").references(() => users.id, { onDelete: "set null" }),
  createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
  isPersonal: boolean("is_personal").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  closedAt: timestamp("closed_at")
});
var alertRecipients = pgTable("alert_recipients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  alertId: varchar("alert_id").notNull().references(() => alerts.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  isRead: boolean("is_read").default(false),
  readAt: timestamp("read_at")
});
var alertComments = pgTable("alert_comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  alertId: varchar("alert_id").notNull().references(() => alerts.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var userProjects = pgTable("user_projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  assignedBy: varchar("assigned_by").references(() => users.id, { onDelete: "set null" }),
  assignedAt: timestamp("assigned_at").defaultNow()
});
var sheets = pgTable("sheets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  sheetCode: text("sheet_code"),
  sheetType: text("sheet_type").notNull(),
  sampleDate: text("sample_date").notNull(),
  testDate: text("test_date"),
  location: text("location"),
  labName: text("lab_name"),
  specRef: text("spec_ref"),
  resultsJson: text("results_json"),
  status: text("status").notNull().default("pending"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  deletedAt: timestamp("deleted_at")
});
var sheetFiles = pgTable("sheet_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sheetId: varchar("sheet_id").notNull().references(() => sheets.id, { onDelete: "cascade" }),
  fileName: text("file_name").notNull(),
  filePath: text("file_path").notNull(),
  fileType: text("file_type").notNull(),
  uploadedBy: varchar("uploaded_by").references(() => users.id, { onDelete: "set null" }),
  uploadedAt: timestamp("uploaded_at").defaultNow()
});
var insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  resetToken: true,
  resetTokenExpiry: true
});
var insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true });
var insertBitumenRecordSchema = createInsertSchema(bitumenRecords).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertTenderSchema = createInsertSchema(tenders).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertAlertRecipientSchema = createInsertSchema(alertRecipients).omit({
  id: true,
  readAt: true
});
var insertAlertCommentSchema = createInsertSchema(alertComments).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertUserProjectSchema = createInsertSchema(userProjects).omit({
  id: true,
  assignedAt: true
});
var insertSheetSchema = createInsertSchema(sheets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  deletedAt: true
});
var insertSheetFileSchema = createInsertSchema(sheetFiles).omit({
  id: true,
  uploadedAt: true
});
var conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(),
  title: text("title"),
  projectId: varchar("project_id").references(() => projects.id, { onDelete: "cascade" }),
  createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var conversationMembers = pgTable("conversation_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  isAdmin: boolean("is_admin").default(false),
  joinedAt: timestamp("joined_at").defaultNow(),
  lastReadAt: timestamp("last_read_at")
});
var messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  senderId: varchar("sender_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  content: text("content"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var messageFiles = pgTable("message_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  messageId: varchar("message_id").notNull().references(() => messages.id, { onDelete: "cascade" }),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type"),
  size: integer("size"),
  path: text("path").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});
var messageReads = pgTable("message_reads", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  messageId: varchar("message_id").notNull().references(() => messages.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  readAt: timestamp("read_at").defaultNow()
});
var statements = pgTable("statements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  number: text("number").notNull(),
  amount: decimal("amount", { precision: 20, scale: 2 }).notNull(),
  status: text("status").notNull().default("\u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631"),
  filePath: text("file_path"),
  announcedDate: text("announced_date"),
  submissionDate: text("submission_date"),
  startDate: text("start_date"),
  endDate: text("end_date"),
  workPeriod: text("work_period"),
  baseMaterials: text("base_materials"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  deletedAt: timestamp("deleted_at")
});
var adjustments = pgTable("adjustments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  number: text("number").notNull(),
  amount: decimal("amount", { precision: 20, scale: 2 }).notNull(),
  status: text("status").notNull().default("\u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631"),
  startDate: text("start_date"),
  endDate: text("end_date"),
  indexType: text("index_type"),
  upToStatementNumber: text("up_to_statement_number"),
  filePath: text("file_path"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  deletedAt: timestamp("deleted_at")
});
var bitumenDiffs = pgTable("bitumen_diffs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  number: text("number").notNull(),
  amount: decimal("amount", { precision: 20, scale: 2 }).notNull(),
  status: text("status").notNull().default("\u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631"),
  filePath: text("file_path"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  deletedAt: timestamp("deleted_at")
});
var weeklyReports = pgTable("weekly_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  weekStartDate: text("week_start_date").notNull(),
  weekEndDate: text("week_end_date").notNull(),
  activities: text("activities").notNull(),
  notes: text("notes"),
  status: text("status").notNull().default("\u062B\u0628\u062A \u0634\u062F\u0647"),
  createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
  referredTo: varchar("referred_to").references(() => users.id, { onDelete: "set null" }),
  referredAt: timestamp("referred_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertConversationMemberSchema = createInsertSchema(conversationMembers).omit({
  id: true,
  joinedAt: true
});
var insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertMessageFileSchema = createInsertSchema(messageFiles).omit({
  id: true,
  createdAt: true
});
var insertMessageReadSchema = createInsertSchema(messageReads).omit({
  id: true,
  readAt: true
});
var insertStatementSchema = createInsertSchema(statements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  deletedAt: true
});
var insertAdjustmentSchema = createInsertSchema(adjustments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  deletedAt: true
});
var insertBitumenDiffSchema = createInsertSchema(bitumenDiffs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  deletedAt: true
});
var insertWeeklyReportSchema = createInsertSchema(weeklyReports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  referredAt: true
});
var tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull().default("today"),
  status: text("status").notNull().default("\u0628\u0627\u0632"),
  priority: text("priority").notNull().default("medium"),
  dueDate: text("due_date"),
  reminderDateTime: text("reminder_date_time"),
  assigneeId: varchar("assignee_id").references(() => users.id, { onDelete: "set null" }),
  projectId: varchar("project_id").references(() => projects.id, { onDelete: "set null" }),
  requiresConfirmation: boolean("requires_confirmation").default(false),
  isConfirmed: boolean("is_confirmed").default(false),
  confirmedAt: timestamp("confirmed_at"),
  isCompleted: boolean("is_completed").default(false),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var dailyNotes = pgTable("daily_notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  noteDate: text("note_date").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var calendarNotes = pgTable("calendar_notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: text("date").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var stickyNotes = pgTable("sticky_notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  content: text("content"),
  color: text("color").notNull().default("yellow"),
  date: text("date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var stickyNoteItems = pgTable("sticky_note_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  noteId: varchar("note_id").notNull().references(() => stickyNotes.id, { onDelete: "cascade" }),
  content: text("content").notNull(),
  isCompleted: boolean("is_completed").default(false),
  orderIndex: integer("order_index").default(0),
  createdAt: timestamp("created_at").defaultNow()
});
var taskAttachments = pgTable("task_attachments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  fileName: text("file_name").notNull(),
  filePath: text("file_path").notNull(),
  fileType: text("file_type"),
  uploadedAt: timestamp("uploaded_at").defaultNow()
});
var letters = pgTable("letters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fromUserId: varchar("from_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  projectId: varchar("project_id").references(() => projects.id, { onDelete: "set null" }),
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false),
  isReceiptConfirmed: boolean("is_receipt_confirmed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var letterRecipients = pgTable("letter_recipients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  letterId: varchar("letter_id").notNull().references(() => letters.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  isRead: boolean("is_read").default(false),
  isReceiptConfirmed: boolean("is_receipt_confirmed").default(false),
  readAt: timestamp("read_at")
});
var letterAttachments = pgTable("letter_attachments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  letterId: varchar("letter_id").notNull().references(() => letters.id, { onDelete: "cascade" }),
  fileName: text("file_name").notNull(),
  filePath: text("file_path").notNull(),
  fileType: text("file_type"),
  uploadedAt: timestamp("uploaded_at").defaultNow()
});
var followUpTasks = pgTable("follow_up_tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fromUserId: varchar("from_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  toUserId: varchar("to_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: text("due_date"),
  status: text("status").notNull().default("pending"),
  isConfirmed: boolean("is_confirmed").default(false),
  confirmedAt: timestamp("confirmed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var projectFiles = pgTable("project_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  fileName: text("file_name").notNull(),
  filePath: text("file_path").notNull(),
  fileType: text("file_type"),
  fileSize: integer("file_size"),
  uploadedBy: varchar("uploaded_by").references(() => users.id, { onDelete: "set null" }),
  uploadedAt: timestamp("uploaded_at").defaultNow()
});
var userPreferences = pgTable("user_preferences", {
  userId: varchar("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  theme: text("theme").notNull().default("light"),
  customTheme: text("custom_theme"),
  dashboardLayout: text("dashboard_layout"),
  displaySettings: text("display_settings"),
  version: integer("version").default(1),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  completedAt: true,
  confirmedAt: true
});
var insertDailyNoteSchema = createInsertSchema(dailyNotes).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertFollowUpTaskSchema = createInsertSchema(followUpTasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  confirmedAt: true
});
var insertCalendarNoteSchema = createInsertSchema(calendarNotes).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertStickyNoteSchema = createInsertSchema(stickyNotes).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertStickyNoteItemSchema = createInsertSchema(stickyNoteItems).omit({
  id: true,
  createdAt: true
});
var insertTaskAttachmentSchema = createInsertSchema(taskAttachments).omit({
  id: true,
  uploadedAt: true
});
var insertLetterSchema = createInsertSchema(letters).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertLetterRecipientSchema = createInsertSchema(letterRecipients).omit({
  id: true,
  readAt: true
});
var insertLetterAttachmentSchema = createInsertSchema(letterAttachments).omit({
  id: true,
  uploadedAt: true
});
var insertProjectFileSchema = createInsertSchema(projectFiles).omit({
  id: true,
  uploadedAt: true
});
var insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  createdAt: true,
  updatedAt: true
});
var insertRoleSchema = createInsertSchema(roles).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var insertPermissionSchema = createInsertSchema(permissions).omit({
  id: true,
  createdAt: true
});
var insertRolePermissionSchema = createInsertSchema(rolePermissions).omit({
  id: true,
  createdAt: true
});

// server/db.ts
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?"
  );
}
var connectionString = process.env.DATABASE_URL;
var sslConfig = connectionString.includes("sslmode=disable") ? false : { rejectUnauthorized: false };
var pool = new Pool({
  connectionString,
  ssl: sslConfig
});
var db = drizzle(pool, { schema: schema_exports });

// server/routes.ts
import { eq as eq3, and, sql as sqlOperator2, or as or2, like as like2, desc } from "drizzle-orm";
import bcrypt from "bcryptjs";
import multer from "multer";
import path2 from "path";
import fs2 from "fs";
import express from "express";

// server/ai-assistant.ts
import { eq } from "drizzle-orm";
async function getProjectContext(projectId) {
  const context = {
    projects: [],
    alerts: [],
    tenders: [],
    statements: []
  };
  if (projectId) {
    const project = await db.select().from(projects).where(eq(projects.id, projectId));
    context.projects = project;
    const projectAlerts = await db.select().from(alerts).where(eq(alerts.projectId, projectId));
    context.alerts = projectAlerts;
    const allTenders = await db.select().from(tenders);
    context.tenders = allTenders;
    const projectStatements = await db.select().from(statements).where(eq(statements.projectId, projectId));
    context.statements = projectStatements;
  } else {
    context.projects = await db.select().from(projects);
    context.alerts = await db.select().from(alerts);
    context.tenders = await db.select().from(tenders);
    context.statements = await db.select().from(statements);
  }
  return context;
}
function cleanPersianText(text2) {
  return text2.replace(/\u200C/g, "").replace(/\u200B/g, "").replace(/\u200D/g, "").replace(/\s+/g, " ").toLowerCase().trim();
}
function convertPersianDigits(text2) {
  const persianDigits = ["\u06F0", "\u06F1", "\u06F2", "\u06F3", "\u06F4", "\u06F5", "\u06F6", "\u06F7", "\u06F8", "\u06F9"];
  const arabicDigits = ["\u0660", "\u0661", "\u0662", "\u0663", "\u0664", "\u0665", "\u0666", "\u0667", "\u0668", "\u0669"];
  let result = text2;
  persianDigits.forEach((digit, index) => {
    result = result.replace(new RegExp(digit, "g"), index.toString());
  });
  arabicDigits.forEach((digit, index) => {
    result = result.replace(new RegExp(digit, "g"), index.toString());
  });
  return result;
}
function containsKeywords(text2, keywords) {
  const cleanedText = cleanPersianText(text2);
  return keywords.some((keyword) => cleanedText.includes(cleanPersianText(keyword)));
}
function normalizeText(text2) {
  return cleanPersianText(text2).replace(/[؟!,،.\?\:\;«»\(\)]/g, " ").split(/\s+/).filter((word) => word.length > 1).filter((word) => !["\u062F\u0631", "\u0628\u0647", "\u0627\u0632", "\u0628\u0627", "\u06A9\u0647", "\u0627\u06CC\u0646", "\u0622\u0646", "\u0648", "\u06CC\u0627", "\u0631\u0627", "\u0647\u0627\u06CC"].includes(word));
}
function searchProjects(query, projects2) {
  const queryTokens = normalizeText(query);
  return projects2.filter((p) => {
    const titleTokens = normalizeText(p.title || "");
    const contractTokens = normalizeText(p.contractNumber || "");
    const locationTokens = normalizeText(p.location || "");
    const contractorTokens = normalizeText(p.contractor || "");
    const hasCommonWithTitle = queryTokens.some((qt) => titleTokens.some((tt) => tt.includes(qt) || qt.includes(tt)));
    const hasCommonWithContract = queryTokens.some((qt) => contractTokens.some((ct) => ct.includes(qt) || qt.includes(ct)));
    const hasCommonWithLocation = queryTokens.some((qt) => locationTokens.some((lt2) => lt2.includes(qt) || qt.includes(lt2)));
    const hasCommonWithContractor = queryTokens.some((qt) => contractorTokens.some((ct) => ct.includes(qt) || qt.includes(ct)));
    return hasCommonWithTitle || hasCommonWithContract || hasCommonWithLocation || hasCommonWithContractor;
  });
}
function parseAmount(amountStr) {
  if (!amountStr) return 0;
  const cleaned = amountStr.replace(/[,،\s]/g, "").replace(/ریال/g, "");
  return parseInt(cleaned) || 0;
}
function formatNumber(num) {
  return num.toLocaleString("fa-IR");
}
async function chatWithAssistant(message, projectId) {
  try {
    const context = await getProjectContext(projectId);
    const lowerMessage = message.toLowerCase();
    if (containsKeywords(lowerMessage, ["\u0634\u0645\u0627\u0631\u0647 \u0642\u0631\u0627\u0631\u062F\u0627\u062F", "\u0634\u0645\u0627\u0631\u0647 \u067E\u0631\u0648\u0698\u0647", "\u06A9\u062F \u0642\u0631\u0627\u0631\u062F\u0627\u062F"])) {
      const foundProjects = searchProjects(message, context.projects);
      if (foundProjects.length > 0) {
        const project = foundProjects[0];
        return `\u{1F4CB} **\u0634\u0645\u0627\u0631\u0647 \u0642\u0631\u0627\u0631\u062F\u0627\u062F \u067E\u0631\u0648\u0698\u0647 "${project.title}":**

\u2022 \u0634\u0645\u0627\u0631\u0647: ${project.contractNumber || "\u062B\u0628\u062A \u0646\u0634\u062F\u0647"}
\u2022 \u062A\u0627\u0631\u06CC\u062E: ${project.contractDate || "\u062B\u0628\u062A \u0646\u0634\u062F\u0647"}
\u2022 \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631: ${project.contractor || "\u062B\u0628\u062A \u0646\u0634\u062F\u0647"}`;
      }
      return "\u062F\u0631 \u062D\u0627\u0644 \u062D\u0627\u0636\u0631 \u0627\u0637\u0644\u0627\u0639\u0627\u062A\u06CC \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u0645\u0648\u0631\u062F \u062B\u0628\u062A \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.";
    }
    if (containsKeywords(lowerMessage, ["\u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631", "contractor", "\u06A9\u06CC\u0633\u062A", "\u06A9\u062F\u0627\u0645 \u0634\u0631\u06A9\u062A"])) {
      const foundProjects = searchProjects(message, context.projects);
      if (foundProjects.length > 0) {
        const project = foundProjects[0];
        return `\u{1F3E2} **\u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631 \u067E\u0631\u0648\u0698\u0647 "${project.title}":**

\u2022 \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631: ${project.contractor || "\u062B\u0628\u062A \u0646\u0634\u062F\u0647"}
\u2022 \u06A9\u0627\u0631\u0641\u0631\u0645\u0627: ${project.employer || "\u062B\u0628\u062A \u0646\u0634\u062F\u0647"}
\u2022 \u0634\u0645\u0627\u0631\u0647 \u0642\u0631\u0627\u0631\u062F\u0627\u062F: ${project.contractNumber || "\u062B\u0628\u062A \u0646\u0634\u062F\u0647"}`;
      }
      return "\u062F\u0631 \u062D\u0627\u0644 \u062D\u0627\u0636\u0631 \u0627\u0637\u0644\u0627\u0639\u0627\u062A\u06CC \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u0645\u0648\u0631\u062F \u062B\u0628\u062A \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.";
    }
    if ((containsKeywords(lowerMessage, ["\u067E\u06CC\u0634\u0631\u0641\u062A", "\u062F\u0631\u0635\u062F"]) || containsKeywords(lowerMessage, ["\u0627\u0639\u0644\u0627\u0645 \u06A9\u0646", "\u0646\u0634\u0627\u0646 \u0628\u062F\u0647"])) && (containsKeywords(lowerMessage, ["\u0633\u0631\u06CC\u0639 \u0633\u0627\u0632\u0627\u0646", "\u0633\u0631\u06CC\u0639\u0633\u0627\u0632\u0627\u0646", "\u0627\u0644\u0628\u0631\u0632"]) || containsKeywords(lowerMessage, ["\u0628\u0647\u06CC\u0646\u0647 \u0645\u0637\u0628\u0648\u0639", "\u06A9\u0627\u0648\u0634 \u06A9\u0627\u0631", "\u0628\u0647\u06CC\u0646\u0647", "\u0645\u0637\u0628\u0648\u0639"]) || containsKeywords(lowerMessage, ["\u062E\u0627\u06A9 \u067E\u06CC \u062F\u0646\u0627", "\u062F\u0646\u0627"]) || containsKeywords(lowerMessage, ["\u0633\u0627\u0632\u0646\u062F\u06AF\u06CC", "\u0627\u0644\u0645\u0627\u0633 \u0633\u0627\u0632", "\u0627\u0637\u0644\u0633"]))) {
      let contractorName = "";
      if (containsKeywords(lowerMessage, ["\u0633\u0631\u06CC\u0639 \u0633\u0627\u0632\u0627\u0646", "\u0633\u0631\u06CC\u0639\u0633\u0627\u0632\u0627\u0646", "\u0627\u0644\u0628\u0631\u0632"])) {
        contractorName = "\u0633\u0631\u06CC\u0639 \u0633\u0627\u0632\u0627\u0646 \u0627\u0644\u0628\u0631\u0632";
      } else if (containsKeywords(lowerMessage, ["\u0628\u0647\u06CC\u0646\u0647 \u0645\u0637\u0628\u0648\u0639", "\u06A9\u0627\u0648\u0634 \u06A9\u0627\u0631", "\u0628\u0647\u06CC\u0646\u0647", "\u0645\u0637\u0628\u0648\u0639"])) {
        contractorName = "\u0628\u0647\u06CC\u0646\u0647 \u0645\u0637\u0628\u0648\u0639 \u06A9\u0627\u0648\u0634 \u06A9\u0627\u0631";
      } else if (containsKeywords(lowerMessage, ["\u062E\u0627\u06A9 \u067E\u06CC \u062F\u0646\u0627", "\u062F\u0646\u0627"])) {
        contractorName = "\u062E\u0627\u06A9 \u067E\u06CC \u062F\u0646\u0627";
      } else if (containsKeywords(lowerMessage, ["\u0633\u0627\u0632\u0646\u062F\u06AF\u06CC", "\u0627\u0644\u0645\u0627\u0633 \u0633\u0627\u0632", "\u0627\u0637\u0644\u0633"])) {
        contractorName = "\u0633\u0627\u0632\u0646\u062F\u06AF\u06CC \u0627\u0644\u0645\u0627\u0633 \u0633\u0627\u0632 \u0627\u0637\u0644\u0633";
      }
      const contractorProjects = context.projects.filter(
        (p) => p.contractor && p.contractor.includes(contractorName)
      );
      if (contractorProjects.length > 0) {
        let response = `\u{1F4CA} **\u067E\u06CC\u0634\u0631\u0641\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC ${contractorName}:**

`;
        contractorProjects.forEach((p, i) => {
          response += `${i + 1}. ${p.title}
   \u2022 \u067E\u06CC\u0634\u0631\u0641\u062A: ${p.progress || 0}%

`;
        });
        const avgProgress = contractorProjects.reduce((sum, p) => sum + (p.progress || 0), 0) / contractorProjects.length;
        response += `\u{1F4C8} **\u0645\u06CC\u0627\u0646\u06AF\u06CC\u0646 \u067E\u06CC\u0634\u0631\u0641\u062A:** ${avgProgress.toFixed(1)}%`;
        return response;
      }
      return "\u062F\u0631 \u062D\u0627\u0644 \u062D\u0627\u0636\u0631 \u0627\u0637\u0644\u0627\u0639\u0627\u062A\u06CC \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631 \u062B\u0628\u062A \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.";
    }
    if (containsKeywords(lowerMessage, ["\u0645\u062C\u0645\u0648\u0639", "\u062C\u0645\u0639", "total"]) && containsKeywords(lowerMessage, ["\u0645\u0628\u0644\u063A", "\u0642\u0631\u0627\u0631\u062F\u0627\u062F", "amount"])) {
      const convertedForYear = convertPersianDigits(lowerMessage);
      let yearMatch = convertedForYear.match(/\d{4}/);
      if (yearMatch) {
        const year = yearMatch[0];
        const yearProjects = context.projects.filter(
          (p) => p.contractDate && p.contractDate.includes(year)
        );
        if (yearProjects.length > 0) {
          const total2 = yearProjects.reduce((sum, p) => sum + parseAmount(p.amount || ""), 0);
          return `\u{1F4B0} **\u0645\u062C\u0645\u0648\u0639 \u0645\u0628\u0644\u063A \u0642\u0631\u0627\u0631\u062F\u0627\u062F\u0647\u0627\u06CC \u0633\u0627\u0644 ${year}:**

\u2022 \u062A\u0639\u062F\u0627\u062F: ${yearProjects.length} \u0642\u0631\u0627\u0631\u062F\u0627\u062F
\u2022 \u0645\u062C\u0645\u0648\u0639: ${formatNumber(total2)} \u0631\u06CC\u0627\u0644
\u2022 \u0645\u06CC\u0627\u0646\u06AF\u06CC\u0646: ${formatNumber(Math.floor(total2 / yearProjects.length))} \u0631\u06CC\u0627\u0644`;
        }
        return `\u062F\u0631 \u062D\u0627\u0644 \u062D\u0627\u0636\u0631 \u0642\u0631\u0627\u0631\u062F\u0627\u062F\u06CC \u0628\u0631\u0627\u06CC \u0633\u0627\u0644 ${year} \u062B\u0628\u062A \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.`;
      }
      const total = context.projects.reduce((sum, p) => sum + parseAmount(p.amount || ""), 0);
      return `\u{1F4B0} **\u0645\u062C\u0645\u0648\u0639 \u06A9\u0644 \u0642\u0631\u0627\u0631\u062F\u0627\u062F\u0647\u0627:**

\u2022 \u062A\u0639\u062F\u0627\u062F: ${context.projects.length} \u0642\u0631\u0627\u0631\u062F\u0627\u062F
\u2022 \u0645\u062C\u0645\u0648\u0639: ${formatNumber(total)} \u0631\u06CC\u0627\u0644`;
    }
    const convertedMessage = convertPersianDigits(lowerMessage);
    const percentMatch = convertedMessage.match(/(\d+)\s*%|(\d+)\s*درصد/);
    if (percentMatch && (containsKeywords(lowerMessage, ["\u0628\u06CC\u0634 \u0627\u0632", "\u0628\u0627\u0644\u0627\u06CC", "above", "\u0628\u06CC\u0634\u062A\u0631"]) || containsKeywords(lowerMessage, ["\u06A9\u0645\u062A\u0631 \u0627\u0632", "\u0632\u06CC\u0631", "\u067E\u0627\u06CC\u06CC\u0646"]))) {
      const threshold = parseInt(percentMatch[1] || percentMatch[2]);
      const isAbove = containsKeywords(lowerMessage, ["\u0628\u06CC\u0634 \u0627\u0632", "\u0628\u0627\u0644\u0627\u06CC", "above", "\u0628\u06CC\u0634\u062A\u0631"]);
      const filteredProjects = context.projects.filter(
        (p) => isAbove ? (p.progress || 0) > threshold : (p.progress || 0) < threshold
      );
      if (filteredProjects.length > 0) {
        let response = `\u{1F4CA} **\u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC ${isAbove ? "\u0628\u06CC\u0634 \u0627\u0632" : "\u06A9\u0645\u062A\u0631 \u0627\u0632"} ${threshold}% \u067E\u06CC\u0634\u0631\u0641\u062A:**

`;
        filteredProjects.slice(0, 10).forEach((p, i) => {
          response += `${i + 1}. ${p.title}
   \u2022 \u067E\u06CC\u0634\u0631\u0641\u062A: ${p.progress || 0}%
   \u2022 \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631: ${p.contractor || "\u0646\u062F\u0627\u0631\u062F"}

`;
        });
        if (filteredProjects.length > 10) {
          response += `
... \u0648 ${filteredProjects.length - 10} \u067E\u0631\u0648\u0698\u0647 \u062F\u06CC\u06AF\u0631`;
        }
        return response;
      }
      return `\u067E\u0631\u0648\u0698\u0647\u200C\u0627\u06CC \u0628\u0627 \u067E\u06CC\u0634\u0631\u0641\u062A ${isAbove ? "\u0628\u06CC\u0634 \u0627\u0632" : "\u06A9\u0645\u062A\u0631 \u0627\u0632"} ${threshold}% \u06CC\u0627\u0641\u062A \u0646\u0634\u062F.`;
    }
    if (containsKeywords(lowerMessage, ["\u06A9\u0627\u0631\u0641\u0631\u0645\u0627", "employer", "\u0631\u0627\u0647\u062F\u0627\u0631\u06CC", "\u0641\u0647\u0631\u0633\u062A \u067E\u0631\u0648\u0698\u0647"])) {
      let employerName = "";
      if (containsKeywords(lowerMessage, ["\u0631\u0627\u0647\u062F\u0627\u0631\u06CC \u0642\u0632\u0648\u06CC\u0646", "\u0631\u0627\u0647\u062F\u0627\u0631\u06CC"])) {
        employerName = "\u0631\u0627\u0647\u062F\u0627\u0631\u06CC \u0642\u0632\u0648\u06CC\u0646";
      } else if (containsKeywords(lowerMessage, ["\u0631\u0627\u0647 \u0648 \u0634\u0647\u0631\u0633\u0627\u0632\u06CC", "\u0634\u0647\u0631\u0633\u0627\u0632\u06CC"])) {
        employerName = "\u0631\u0627\u0647 \u0648 \u0634\u0647\u0631\u0633\u0627\u0632\u06CC";
      } else if (containsKeywords(lowerMessage, ["\u0646\u0648\u0633\u0627\u0632\u06CC \u0645\u062F\u0627\u0631\u0633"])) {
        employerName = "\u0646\u0648\u0633\u0627\u0632\u06CC \u0645\u062F\u0627\u0631\u0633";
      }
      if (employerName) {
        const employerProjects = context.projects.filter(
          (p) => p.employer && p.employer.includes(employerName)
        );
        if (employerProjects.length > 0) {
          let response = `\u{1F4CB} **\u0641\u0647\u0631\u0633\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC ${employerName}:**

`;
          employerProjects.slice(0, 10).forEach((p, i) => {
            response += `${i + 1}. ${p.title}
   \u2022 \u0642\u0631\u0627\u0631\u062F\u0627\u062F: ${p.contractNumber || "\u0646\u062F\u0627\u0631\u062F"}
   \u2022 \u067E\u06CC\u0634\u0631\u0641\u062A: ${p.progress || 0}%

`;
          });
          if (employerProjects.length > 10) {
            response += `
... \u0648 ${employerProjects.length - 10} \u067E\u0631\u0648\u0698\u0647 \u062F\u06CC\u06AF\u0631`;
          }
          const total = employerProjects.reduce((sum, p) => sum + parseAmount(p.amount || ""), 0);
          response += `
\u{1F4B0} \u0645\u062C\u0645\u0648\u0639 \u0645\u0628\u0644\u063A: ${formatNumber(total)} \u0631\u06CC\u0627\u0644`;
          return response;
        }
      }
    }
    if (containsKeywords(lowerMessage, ["\u0686\u0646\u062F \u067E\u0631\u0648\u0698\u0647", "\u062A\u0639\u062F\u0627\u062F \u067E\u0631\u0648\u0698\u0647", "\u0686\u0646\u062F\u062A\u0627 \u067E\u0631\u0648\u0698\u0647", "\u0686\u0642\u062F\u0631 \u067E\u0631\u0648\u0698\u0647"])) {
      const totalProjects = context.projects.length;
      const activeProjects = context.projects.filter((p) => p.status === "active").length;
      const completedProjects = context.projects.filter((p) => p.status === "completed").length;
      return `\u{1F4CA} **\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627:**
      
\u2022 \u0645\u062C\u0645\u0648\u0639 \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627: ${totalProjects} \u067E\u0631\u0648\u0698\u0647
\u2022 \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u0641\u0639\u0627\u0644: ${activeProjects} \u067E\u0631\u0648\u0698\u0647
\u2022 \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u062A\u06A9\u0645\u06CC\u0644 \u0634\u062F\u0647: ${completedProjects} \u067E\u0631\u0648\u0698\u0647
\u2022 \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u062F\u0631 \u062D\u0627\u0644 \u0628\u0631\u0646\u0627\u0645\u0647\u200C\u0631\u06CC\u0632\u06CC: ${context.projects.filter((p) => p.status === "planning").length} \u067E\u0631\u0648\u0698\u0647`;
    }
    if (containsKeywords(lowerMessage, ["\u0647\u0634\u062F\u0627\u0631", "\u0627\u062E\u0637\u0627\u0631", "alert", "\u0686\u0646\u062F \u0647\u0634\u062F\u0627\u0631", "\u062A\u0639\u062F\u0627\u062F \u0647\u0634\u062F\u0627\u0631"])) {
      const openAlerts = context.alerts.filter((a) => a.status === "open");
      const criticalAlerts = openAlerts.filter((a) => a.severity === "critical");
      const warningAlerts = openAlerts.filter((a) => a.severity === "warning");
      if (openAlerts.length === 0) {
        return "\u2705 \u0647\u06CC\u0686 \u0647\u0634\u062F\u0627\u0631 \u0628\u0627\u0632\u06CC \u062F\u0631 \u0633\u06CC\u0633\u062A\u0645 \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F.";
      }
      let response = `\u{1F514} **\u0647\u0634\u062F\u0627\u0631\u0647\u0627\u06CC \u0628\u0627\u0632:**

\u2022 \u0645\u062C\u0645\u0648\u0639 \u0647\u0634\u062F\u0627\u0631\u0647\u0627: ${openAlerts.length}
`;
      if (criticalAlerts.length > 0) {
        response += `\u2022 \u0647\u0634\u062F\u0627\u0631\u0647\u0627\u06CC \u0628\u062D\u0631\u0627\u0646\u06CC: ${criticalAlerts.length}
`;
      }
      if (warningAlerts.length > 0) {
        response += `\u2022 \u0647\u0634\u062F\u0627\u0631\u0647\u0627\u06CC \u0647\u0634\u062F\u0627\u0631: ${warningAlerts.length}
`;
      }
      response += "\n**\u0622\u062E\u0631\u06CC\u0646 \u0647\u0634\u062F\u0627\u0631\u0647\u0627:**\n";
      openAlerts.slice(0, 3).forEach((alert, i) => {
        response += `
${i + 1}. ${alert.title} (${alert.severity === "critical" ? "\u{1F534} \u0628\u062D\u0631\u0627\u0646\u06CC" : alert.severity === "warning" ? "\u{1F7E1} \u0647\u0634\u062F\u0627\u0631" : "\u{1F535} \u0627\u0637\u0644\u0627\u0639\u0627\u062A"})`;
      });
      return response;
    }
    if (containsKeywords(lowerMessage, ["\u0645\u0646\u0627\u0642\u0635\u0647", "tender", "\u0686\u0646\u062F \u0645\u0646\u0627\u0642\u0635\u0647", "\u062A\u0639\u062F\u0627\u062F \u0645\u0646\u0627\u0642\u0635\u0647", "\u062F\u062F\u0644\u0627\u06CC\u0646", "deadline"])) {
      const totalTenders = context.tenders.length;
      const openTenders = context.tenders.filter((t) => t.status === "open").length;
      return `\u{1F4CB} **\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0645\u0646\u0627\u0642\u0635\u0647\u200C\u0647\u0627:**
      
\u2022 \u0645\u062C\u0645\u0648\u0639 \u0645\u0646\u0627\u0642\u0635\u0647\u200C\u0647\u0627: ${totalTenders}
\u2022 \u0645\u0646\u0627\u0642\u0635\u0647\u200C\u0647\u0627\u06CC \u0628\u0627\u0632: ${openTenders}
\u2022 \u0645\u0646\u0627\u0642\u0635\u0647\u200C\u0647\u0627\u06CC \u0628\u0633\u062A\u0647: ${context.tenders.filter((t) => t.status === "closed").length}`;
    }
    if (containsKeywords(lowerMessage, ["\u0635\u0648\u0631\u062A \u0648\u0636\u0639\u06CC\u062A", "\u0635\u0648\u0631\u062A\u200C\u0648\u0636\u0639\u06CC\u062A", "\u0648\u0636\u0639\u06CC\u062A", "statement"])) {
      const totalStatements = context.statements.length;
      const approvedStatements = context.statements.filter((s) => s.status === "\u062A\u0623\u06CC\u06CC\u062F \u0634\u062F\u0647").length;
      return `\u{1F4DD} **\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0635\u0648\u0631\u062A\u200C\u0648\u0636\u0639\u06CC\u062A\u200C\u0647\u0627:**
      
\u2022 \u0645\u062C\u0645\u0648\u0639 \u0635\u0648\u0631\u062A\u200C\u0648\u0636\u0639\u06CC\u062A\u200C\u0647\u0627: ${totalStatements}
\u2022 \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F\u0647: ${approvedStatements}
\u2022 \u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631: ${context.statements.filter((s) => s.status === "\u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631").length}`;
    }
    if (containsKeywords(lowerMessage, ["\u067E\u0631\u0648\u0698\u0647", "\u0642\u0631\u0627\u0631\u062F\u0627\u062F", "project"])) {
      const foundProjects = searchProjects(message, context.projects);
      if (foundProjects.length > 0) {
        let response = `\u{1F50D} **\u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u06CC\u0627\u0641\u062A \u0634\u062F\u0647:**

`;
        foundProjects.slice(0, 5).forEach((project, i) => {
          response += `${i + 1}. **${project.title}**
`;
          response += `   \u2022 \u0634\u0645\u0627\u0631\u0647 \u0642\u0631\u0627\u0631\u062F\u0627\u062F: ${project.contractNumber || "\u0646\u062F\u0627\u0631\u062F"}
`;
          response += `   \u2022 \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631: ${project.contractor || "\u0646\u062F\u0627\u0631\u062F"}
`;
          response += `   \u2022 \u0648\u0636\u0639\u06CC\u062A: ${project.status === "active" ? "\u0641\u0639\u0627\u0644" : project.status === "completed" ? "\u062A\u06A9\u0645\u06CC\u0644 \u0634\u062F\u0647" : "\u0628\u0631\u0646\u0627\u0645\u0647\u200C\u0631\u06CC\u0632\u06CC"}
`;
          response += `   \u2022 \u067E\u06CC\u0634\u0631\u0641\u062A: ${project.progress || 0}%

`;
        });
        return response;
      } else {
        if (context.projects.length > 0) {
          return `\u{1F50D} \u067E\u0631\u0648\u0698\u0647 \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F.

**\u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u0645\u0648\u062C\u0648\u062F:**
${context.projects.slice(0, 5).map((p, i) => `${i + 1}. ${p.title}`).join("\n")}

\u0627\u0632 \u0646\u0648\u0627\u0631 \u062C\u0633\u062A\u062C\u0648 \u0628\u0631\u0627\u06CC \u06CC\u0627\u0641\u062A\u0646 \u067E\u0631\u0648\u0698\u0647 \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u06A9\u0646\u06CC\u062F.`;
        } else {
          return "\u{1F4C2} \u0647\u06CC\u0686 \u067E\u0631\u0648\u0698\u0647\u200C\u0627\u06CC \u062F\u0631 \u0633\u06CC\u0633\u062A\u0645 \u062B\u0628\u062A \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.";
        }
      }
    }
    if (containsKeywords(lowerMessage, ["\u067E\u06CC\u0634\u0631\u0641\u062A", "\u062F\u0631\u0635\u062F", "progress"])) {
      if (context.projects.length === 0) {
        return "\u{1F4C8} \u0647\u06CC\u0686 \u067E\u0631\u0648\u0698\u0647\u200C\u0627\u06CC \u062F\u0631 \u0633\u06CC\u0633\u062A\u0645 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F.";
      }
      const avgProgress = context.projects.reduce((sum, p) => sum + (p.progress || 0), 0) / context.projects.length;
      const maxProgress = Math.max(...context.projects.map((p) => p.progress || 0));
      const minProgress = Math.min(...context.projects.map((p) => p.progress || 0));
      return `\u{1F4C8} **\u0648\u0636\u0639\u06CC\u062A \u067E\u06CC\u0634\u0631\u0641\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627:**
      
\u2022 \u0645\u06CC\u0627\u0646\u06AF\u06CC\u0646 \u067E\u06CC\u0634\u0631\u0641\u062A \u06A9\u0644\u06CC: ${avgProgress.toFixed(1)}%
\u2022 \u0628\u0627\u0644\u0627\u062A\u0631\u06CC\u0646 \u067E\u06CC\u0634\u0631\u0641\u062A: ${maxProgress}%
\u2022 \u067E\u0627\u06CC\u06CC\u0646\u200C\u062A\u0631\u06CC\u0646 \u067E\u06CC\u0634\u0631\u0641\u062A: ${minProgress}%`;
    }
    if (containsKeywords(lowerMessage, ["\u06AF\u0632\u0627\u0631\u0634 \u06A9\u0644\u06CC", "\u062E\u0644\u0627\u0635\u0647", "summary", "overview"])) {
      const totalProjects = context.projects.length;
      const activeProjects = context.projects.filter((p) => p.status === "active").length;
      const avgProgress = context.projects.reduce((sum, p) => sum + (p.progress || 0), 0) / context.projects.length;
      const totalAmount = context.projects.reduce((sum, p) => sum + parseAmount(p.amount || ""), 0);
      return `\u{1F4CA} **\u06AF\u0632\u0627\u0631\u0634 \u06A9\u0644\u06CC \u0633\u06CC\u0633\u062A\u0645:**

**\u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627:**
\u2022 \u0645\u062C\u0645\u0648\u0639: ${totalProjects} \u067E\u0631\u0648\u0698\u0647
\u2022 \u0641\u0639\u0627\u0644: ${activeProjects} \u067E\u0631\u0648\u0698\u0647
\u2022 \u0645\u06CC\u0627\u0646\u06AF\u06CC\u0646 \u067E\u06CC\u0634\u0631\u0641\u062A: ${avgProgress.toFixed(1)}%
\u2022 \u0645\u062C\u0645\u0648\u0639 \u0645\u0628\u0644\u063A \u0642\u0631\u0627\u0631\u062F\u0627\u062F\u0647\u0627: ${formatNumber(totalAmount)} \u0631\u06CC\u0627\u0644

**\u0647\u0634\u062F\u0627\u0631\u0647\u0627:**
\u2022 \u0647\u0634\u062F\u0627\u0631\u0647\u0627\u06CC \u0628\u0627\u0632: ${context.alerts.filter((a) => a.status === "open").length}

**\u0645\u0646\u0627\u0642\u0635\u0627\u062A:**
\u2022 \u0645\u0646\u0627\u0642\u0635\u0627\u062A \u0641\u0639\u0627\u0644: ${context.tenders.filter((t) => t.status === "open").length}`;
    }
    if (containsKeywords(lowerMessage, ["\u0633\u0644\u0627\u0645", "hi", "hello", "\u062F\u0631\u0648\u062F"])) {
      return `\u0633\u0644\u0627\u0645! \u{1F44B}

\u0645\u0646 \u062F\u0633\u062A\u06CC\u0627\u0631 \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC \u0633\u06CC\u0633\u062A\u0645 \u0645\u062F\u06CC\u0631\u06CC\u062A \u067E\u0631\u0648\u0698\u0647 \u0647\u0633\u062A\u0645. \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u0645 \u0628\u0647 \u0634\u0645\u0627 \u062F\u0631 \u0645\u0648\u0627\u0631\u062F \u0632\u06CC\u0631 \u06A9\u0645\u06A9 \u06A9\u0646\u0645:

\u{1F539} \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627 \u0648 \u0642\u0631\u0627\u0631\u062F\u0627\u062F\u0647\u0627
\u{1F539} \u0648\u0636\u0639\u06CC\u062A \u067E\u06CC\u0634\u0631\u0641\u062A \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631\u0627\u0646
\u{1F539} \u0645\u062C\u0645\u0648\u0639 \u0645\u0628\u0644\u063A \u0642\u0631\u0627\u0631\u062F\u0627\u062F\u0647\u0627
\u{1F539} \u0647\u0634\u062F\u0627\u0631\u0647\u0627 \u0648 \u0645\u0646\u0627\u0642\u0635\u0647\u200C\u0647\u0627
\u{1F539} \u062C\u0633\u062A\u062C\u0648\u06CC \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627
\u{1F539} \u06AF\u0632\u0627\u0631\u0634\u200C\u0647\u0627\u06CC \u0645\u0627\u0644\u06CC

\u0633\u0648\u0627\u0644 \u062E\u0648\u062F \u0631\u0627 \u0628\u067E\u0631\u0633\u06CC\u062F!`;
    }
    return `\u0645\u062A\u0648\u062C\u0647 \u0633\u0648\u0627\u0644 \u0634\u0645\u0627 \u0646\u0634\u062F\u0645. \u0646\u0645\u0648\u0646\u0647 \u0633\u0648\u0627\u0644\u0627\u062A:

\u2022 \u0634\u0645\u0627\u0631\u0647 \u0642\u0631\u0627\u0631\u062F\u0627\u062F \u067E\u0631\u0648\u0698\u0647 [\u0646\u0627\u0645] \u0686\u06CC\u0633\u062A\u061F
\u2022 \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631 \u067E\u0631\u0648\u0698\u0647 [\u0634\u0645\u0627\u0631\u0647 \u0642\u0631\u0627\u0631\u062F\u0627\u062F] \u06A9\u06CC\u0633\u062A\u061F
\u2022 \u067E\u06CC\u0634\u0631\u0641\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u0633\u0631\u06CC\u0639\u200C\u0633\u0627\u0632\u0627\u0646 \u0627\u0644\u0628\u0631\u0632 \u0686\u0642\u062F\u0631 \u0627\u0633\u062A\u061F
\u2022 \u0645\u062C\u0645\u0648\u0639 \u0645\u0628\u0644\u063A \u0642\u0631\u0627\u0631\u062F\u0627\u062F\u0647\u0627\u06CC \u0633\u0627\u0644 \u06F1\u06F4\u06F0\u06F1 \u0686\u0642\u062F\u0631 \u0627\u0633\u062A?
\u2022 \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u0628\u0627\u0644\u0627\u06CC \u06F8\u06F0% \u067E\u06CC\u0634\u0631\u0641\u062A \u0631\u0627 \u0646\u0634\u0627\u0646 \u0628\u062F\u0647
\u2022 \u0641\u0647\u0631\u0633\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u0631\u0627\u0647\u062F\u0627\u0631\u06CC \u0642\u0632\u0648\u06CC\u0646 \u0631\u0627 \u0628\u062F\u0647
\u2022 \u06AF\u0632\u0627\u0631\u0634 \u06A9\u0644\u06CC \u0633\u06CC\u0633\u062A\u0645 \u0631\u0627 \u0628\u062F\u0647

\u06CC\u0627 \u0627\u0632 \u0646\u0648\u0627\u0631 \u062C\u0633\u062A\u062C\u0648 \u0628\u0631\u0627\u06CC \u06CC\u0627\u0641\u062A\u0646 \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627 \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u06A9\u0646\u06CC\u062F.`;
  } catch (error) {
    console.error("\u062E\u0637\u0627 \u062F\u0631 \u062F\u0633\u062A\u06CC\u0627\u0631:", error);
    return "\u0645\u062A\u0623\u0633\u0641\u0627\u0646\u0647 \u062F\u0631 \u067E\u0631\u062F\u0627\u0632\u0634 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0634\u0645\u0627 \u062E\u0637\u0627\u06CC\u06CC \u0631\u062E \u062F\u0627\u062F. \u0644\u0637\u0641\u0627\u064B \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.";
  }
}

// server/agent-service.ts
import Fuse from "fuse.js";
import OpenAI from "openai";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var AgentService = class {
  articles = [];
  fuse = null;
  cache = /* @__PURE__ */ new Map();
  openai = null;
  CACHE_DURATION = 7 * 24 * 60 * 60 * 1e3;
  API_TIMEOUT = 3e4;
  async initialize() {
    const apiKey = process.env.XAI_API_KEY;
    if (apiKey) {
      this.openai = new OpenAI({
        apiKey,
        baseURL: "https://api.x.ai/v1"
      });
      console.log("\u2705 Grok AI API connected - ready to answer questions");
    } else {
      console.error(
        "\u274C XAI_API_KEY not set - agent cannot function without API key"
      );
    }
  }
  normalizeQuery(query) {
    return query.replace(/[؟،؛]/g, "").replace(/\s+/g, " ").trim();
  }
  extractKeywords(query) {
    const normalized = this.normalizeQuery(query);
    const stopWords = [
      "\u0686\u06CC\u0633\u062A",
      "\u0686\u06CC\u0647",
      "\u0686\u0646\u062F",
      "\u0686\u0637\u0648\u0631",
      "\u0686\u06AF\u0648\u0646\u0647",
      "\u06A9\u062F\u0627\u0645",
      "\u06A9\u062F\u0627\u0645\u0646\u062F",
      "\u0627\u0633\u062A",
      "\u0647\u0633\u062A",
      "\u0645\u06CC",
      "\u0631\u0627",
      "\u0631\u0648",
      "\u0628\u0647",
      "\u062F\u0631",
      "\u0627\u0632",
      "\u06A9\u0647"
    ];
    const words = normalized.split(" ").filter((w) => w.length > 2 && !stopWords.includes(w));
    return words;
  }
  searchLocal(query) {
    if (!this.fuse) {
      return { articles: [], score: 0 };
    }
    const normalized = this.normalizeQuery(query);
    const keywords = this.extractKeywords(query);
    let results = this.fuse.search(normalized);
    if (results.length === 0 && keywords.length > 0) {
      const allMatches = /* @__PURE__ */ new Map();
      for (const keyword of keywords) {
        const keywordResults = this.fuse.search(keyword);
        for (const result of keywordResults) {
          const articleNum = result.item.article_number;
          if (!allMatches.has(articleNum) || (result.score || 1) < (allMatches.get(articleNum).score || 1)) {
            allMatches.set(articleNum, result);
          }
        }
      }
      results = Array.from(allMatches.values()).sort(
        (a, b) => (a.score || 0) - (b.score || 0)
      );
    }
    if (results.length === 0) {
      return { articles: [], score: 0 };
    }
    const topResults = results.slice(0, 3);
    const avgScore = topResults.reduce((sum, r) => sum + (1 - (r.score || 1)), 0) / topResults.length;
    return {
      articles: topResults.map((r) => r.item),
      score: avgScore
    };
  }
  canAnswerLocally(query, searchResults) {
    if (searchResults.articles.length === 0) return false;
    const lowerQuery = query.toLowerCase();
    const simpleQuestions = [
      "\u0686\u0646\u062F \u0631\u0648\u0632",
      "\u0686\u0647 \u0645\u062F\u062A",
      "\u0686\u0642\u062F\u0631",
      "\u06A9\u06CC",
      "\u06A9\u062C\u0627",
      "\u0645\u0647\u0644\u062A",
      "\u062A\u0639\u0631\u06CC\u0641",
      "\u0686\u06CC\u0633\u062A",
      "\u0686\u06CC\u0647",
      "\u06CC\u0639\u0646\u06CC",
      "\u0645\u0646\u0638\u0648\u0631 \u0627\u0632",
      "\u062A\u0641\u0627\u0648\u062A",
      "\u0641\u0631\u0642"
    ];
    const isSimpleQuestion = simpleQuestions.some(
      (keyword) => lowerQuery.includes(keyword)
    );
    if (isSimpleQuestion && searchResults.score > 0.5) {
      return true;
    }
    if (searchResults.score > 0.7) {
      return true;
    }
    return false;
  }
  generateLocalAnswer(query, articles) {
    const references = articles.map((a) => `\u0645\u0627\u062F\u0647 ${a.article_number}`);
    let answer = "";
    if (articles.length === 1) {
      const art = articles[0];
      answer = `\u0637\u0628\u0642 \u0645\u0627\u062F\u0647 ${art.article_number} (${art.article_title}):

${art.text}`;
    } else {
      answer = "\u0628\u0631 \u0627\u0633\u0627\u0633 \u0634\u0631\u0627\u06CC\u0637 \u0639\u0645\u0648\u0645\u06CC \u067E\u06CC\u0645\u0627\u0646:\n\n";
      articles.forEach((art) => {
        answer += `\u{1F4CC} \u0645\u0627\u062F\u0647 ${art.article_number} - ${art.article_title}:
${art.text}

`;
      });
    }
    return { answer, references };
  }
  async askAPI(query, articles) {
    if (!this.openai) {
      throw new Error("Grok API not configured");
    }
    const context = articles.map((a) => `\u0645\u0627\u062F\u0647 ${a.article_number} - ${a.article_title}:
${a.text}`).join("\n\n");
    const systemPrompt = `\u062A\u0648 \u06CC\u06A9 \u0645\u0634\u0627\u0648\u0631 \u062D\u0642\u0648\u0642\u06CC \u0645\u062A\u062E\u0635\u0635 \u062F\u0631 \u0634\u0631\u0627\u06CC\u0637 \u0639\u0645\u0648\u0645\u06CC \u067E\u06CC\u0645\u0627\u0646\u200C\u0647\u0627\u06CC \u0633\u0627\u062E\u062A\u0645\u0627\u0646\u06CC \u0627\u06CC\u0631\u0627\u0646 \u0647\u0633\u062A\u06CC.
\u0628\u0647 \u0633\u0624\u0627\u0644\u0627\u062A \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u0628\u0631 \u0627\u0633\u0627\u0633 \u0645\u0648\u0627\u062F \u0642\u0627\u0646\u0648\u0646\u06CC \u0627\u0631\u0627\u0626\u0647 \u0634\u062F\u0647 \u067E\u0627\u0633\u062E \u0628\u062F\u0647.
\u067E\u0627\u0633\u062E\u200C\u0647\u0627\u06CC\u062A \u0628\u0627\u06CC\u062F:
- \u062F\u0642\u06CC\u0642 \u0648 \u0645\u0633\u062A\u0646\u062F \u0628\u0627\u0634\u0646\u062F
- \u0628\u0647 \u0632\u0628\u0627\u0646 \u0641\u0627\u0631\u0633\u06CC \u0631\u0633\u0645\u06CC \u0648 \u0631\u0648\u0627\u0646 \u0628\u0627\u0634\u0646\u062F
- \u062D\u062F\u0627\u06A9\u062B\u0631 300 \u06A9\u0644\u0645\u0647 \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u0646\u062F
- \u0645\u0633\u062A\u0642\u06CC\u0645\u0627\u064B \u0628\u0647 \u0633\u0624\u0627\u0644 \u067E\u0627\u0633\u062E \u062F\u0647\u0646\u062F
- \u0627\u0632 \u0645\u0648\u0627\u062F \u0642\u0627\u0646\u0648\u0646\u06CC \u0627\u0631\u0627\u0626\u0647 \u0634\u062F\u0647 \u0627\u0633\u062A\u0646\u0627\u062F \u06A9\u0646\u0646\u062F`;
    const userPrompt = `\u0645\u0648\u0627\u062F \u0645\u0631\u062A\u0628\u0637:
${context}

\u0633\u0624\u0627\u0644: ${query}

\u0644\u0637\u0641\u0627\u064B \u0628\u0631 \u0627\u0633\u0627\u0633 \u0645\u0648\u0627\u062F \u0628\u0627\u0644\u0627\u060C \u067E\u0627\u0633\u062E \u062F\u0642\u06CC\u0642 \u0648 \u0645\u0633\u062A\u0646\u062F \u0627\u0631\u0627\u0626\u0647 \u06A9\u0646.`;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.API_TIMEOUT);
      const completion = await this.openai.chat.completions.create(
        {
          model: "grok-2-1212",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt }
          ],
          temperature: 0.2,
          max_tokens: 1e3
        },
        { signal: controller.signal }
      );
      clearTimeout(timeout);
      const answer = completion.choices[0]?.message?.content || "\u0645\u062A\u0623\u0633\u0641\u0627\u0646\u0647 \u0646\u062A\u0648\u0627\u0646\u0633\u062A\u0645 \u067E\u0627\u0633\u062E \u0645\u0646\u0627\u0633\u0628\u06CC \u062A\u0648\u0644\u06CC\u062F \u06A9\u0646\u0645.";
      const references = articles.map((a) => `\u0645\u0627\u062F\u0647 ${a.article_number}`);
      return { answer, references };
    } catch (error) {
      if (error.name === "AbortError") {
        throw new Error(
          "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0647 \u062F\u0644\u06CC\u0644 \u0637\u0648\u0644\u0627\u0646\u06CC \u0634\u062F\u0646 \u0645\u062A\u0648\u0642\u0641 \u0634\u062F. \u0644\u0637\u0641\u0627\u064B \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F."
        );
      }
      throw error;
    }
  }
  async ask(query) {
    const cacheKey = this.normalizeQuery(query);
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < this.CACHE_DURATION) {
      console.log("\u2705 Returning cached response");
      return {
        answer: cached.answer,
        references: cached.references,
        source: cached.source
      };
    }
    if (!this.openai && process.env.XAI_API_KEY) {
      await this.initialize();
    }
    if (!this.openai) {
      return {
        answer: "\u0645\u062A\u0623\u0633\u0641\u0627\u0646\u0647 \u0633\u0631\u0648\u06CC\u0633 Grok AI \u067E\u06CC\u06A9\u0631\u0628\u0646\u062F\u06CC \u0646\u0634\u062F\u0647 \u0627\u0633\u062A. \u0644\u0637\u0641\u0627\u064B \u06A9\u0644\u06CC\u062F API \u0631\u0627 \u062A\u0646\u0638\u06CC\u0645 \u06A9\u0646\u06CC\u062F.",
        references: [],
        source: "api"
      };
    }
    console.log("\u{1F916} Using Grok AI to answer question");
    try {
      const systemPrompt = `\u062A\u0648 \u06CC\u06A9 \u0645\u0634\u0627\u0648\u0631 \u062D\u0642\u0648\u0642\u06CC \u0645\u062A\u062E\u0635\u0635 \u062F\u0631 \u0634\u0631\u0627\u06CC\u0637 \u0639\u0645\u0648\u0645\u06CC \u067E\u06CC\u0645\u0627\u0646\u200C\u0647\u0627\u06CC \u0633\u0627\u062E\u062A\u0645\u0627\u0646\u06CC \u0627\u06CC\u0631\u0627\u0646 \u0647\u0633\u062A\u06CC.
\u062A\u062E\u0635\u0635 \u0627\u0635\u0644\u06CC \u062A\u0648 \u062F\u0631 \u0642\u0648\u0627\u0646\u06CC\u0646 \u0648 \u0645\u0642\u0631\u0631\u0627\u062A \u0633\u0627\u062E\u062A\u0645\u0627\u0646\u06CC\u060C \u0634\u0631\u0627\u06CC\u0637 \u0639\u0645\u0648\u0645\u06CC \u067E\u06CC\u0645\u0627\u0646\u060C \u0648 \u0642\u0631\u0627\u0631\u062F\u0627\u062F\u0647\u0627\u06CC \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631\u06CC \u0627\u0633\u062A.

\u0628\u0647 \u0633\u0624\u0627\u0644\u0627\u062A \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u067E\u0627\u0633\u062E\u200C\u0647\u0627\u06CC \u062F\u0642\u06CC\u0642\u060C \u06A9\u0627\u0645\u0644 \u0648 \u06A9\u0627\u0631\u0628\u0631\u062F\u06CC \u0628\u062F\u0647.
\u067E\u0627\u0633\u062E\u200C\u0647\u0627\u06CC\u062A \u0628\u0627\u06CC\u062F:
- \u0645\u0633\u062A\u0646\u062F \u0628\u0647 \u0642\u0648\u0627\u0646\u06CC\u0646 \u0648 \u0645\u0642\u0631\u0631\u0627\u062A \u0627\u06CC\u0631\u0627\u0646 \u0628\u0627\u0634\u0646\u062F
- \u062F\u0642\u06CC\u0642 \u0648 \u0628\u062F\u0648\u0646 \u062D\u062F\u0633 \u0648 \u06AF\u0645\u0627\u0646 \u0628\u0627\u0634\u0646\u062F
- \u0628\u0647 \u0632\u0628\u0627\u0646 \u0641\u0627\u0631\u0633\u06CC \u0631\u0633\u0645\u06CC \u0648 \u0631\u0648\u0627\u0646 \u0628\u0627\u0634\u0646\u062F
- \u0645\u0633\u062A\u0642\u06CC\u0645\u0627\u064B \u0628\u0647 \u0633\u0624\u0627\u0644 \u067E\u0627\u0633\u062E \u062F\u0647\u0646\u062F
- \u062F\u0631 \u0635\u0648\u0631\u062A \u0646\u06CC\u0627\u0632\u060C \u0645\u062B\u0627\u0644\u200C\u0647\u0627\u06CC \u0639\u0645\u0644\u06CC \u0648 \u0645\u062D\u0627\u0633\u0628\u0627\u062A \u062F\u0642\u06CC\u0642 \u0627\u0631\u0627\u0626\u0647 \u06A9\u0646\u0646\u062F
- \u0627\u06AF\u0631 \u0646\u06CC\u0627\u0632 \u0628\u0647 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0628\u06CC\u0634\u062A\u0631 \u062F\u0627\u0631\u06CC\u060C \u0635\u0631\u0627\u062D\u062A\u0627\u064B \u0628\u06AF\u0648

\u0628\u0631\u0627\u06CC \u0633\u0648\u0627\u0644\u0627\u062A \u0645\u0631\u0628\u0648\u0637 \u0628\u0647 \u0634\u0631\u0627\u06CC\u0637 \u0639\u0645\u0648\u0645\u06CC \u067E\u06CC\u0645\u0627\u0646\u060C \u0628\u0647 \u0645\u0648\u0627\u062F \u0645\u0631\u062A\u0628\u0637 \u0627\u0634\u0627\u0631\u0647 \u06A9\u0646 \u0648 \u062A\u0648\u0636\u06CC\u062D\u0627\u062A \u06A9\u0627\u0645\u0644 \u0628\u062F\u0647.`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.API_TIMEOUT);
      const completion = await this.openai.chat.completions.create(
        {
          model: "grok-2-1212",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: query }
          ],
          temperature: 0.1,
          max_tokens: 2e3
        },
        { signal: controller.signal }
      );
      clearTimeout(timeout);
      const answer = completion.choices[0]?.message?.content || "\u0645\u062A\u0623\u0633\u0641\u0627\u0646\u0647 \u0646\u062A\u0648\u0627\u0646\u0633\u062A\u0645 \u067E\u0627\u0633\u062E \u0645\u0646\u0627\u0633\u0628\u06CC \u062A\u0648\u0644\u06CC\u062F \u06A9\u0646\u0645.";
      const response = { answer, references: [], source: "api" };
      this.cache.set(cacheKey, { ...response, timestamp: Date.now() });
      return response;
    } catch (error) {
      console.error("\u274C Grok API error:", error);
      if (error.name === "AbortError") {
        return {
          answer: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0647 \u062F\u0644\u06CC\u0644 \u0637\u0648\u0644\u0627\u0646\u06CC \u0634\u062F\u0646 \u0645\u062A\u0648\u0642\u0641 \u0634\u062F. \u0644\u0637\u0641\u0627\u064B \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.",
          references: [],
          source: "api"
        };
      }
      return {
        answer: `\u0645\u062A\u0623\u0633\u0641\u0627\u0646\u0647 \u062F\u0631 \u0627\u0631\u062A\u0628\u0627\u0637 \u0628\u0627 Grok \u062E\u0637\u0627\u06CC\u06CC \u0631\u062E \u062F\u0627\u062F: ${error instanceof Error ? error.message : "\u062E\u0637\u0627\u06CC \u0646\u0627\u0634\u0646\u0627\u062E\u062A\u0647"}`,
        references: [],
        source: "api"
      };
    }
  }
  getArticle(articleNumber) {
    return this.articles.find((a) => a.article_number === articleNumber) || null;
  }
  isConfigured() {
    return this.openai !== null;
  }
  clearExpiredCache() {
    const now = Date.now();
    const entries = Array.from(this.cache.entries());
    for (const [key, value] of entries) {
      if (now - value.timestamp > this.CACHE_DURATION) {
        this.cache.delete(key);
      }
    }
  }
  async loadFromFile(filePath) {
    try {
      if (!fs.existsSync(filePath)) {
        return { success: false, articlesCount: 0, error: "\u0641\u0627\u06CC\u0644 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" };
      }
      const content = fs.readFileSync(filePath, "utf-8");
      let newArticles = [];
      const ext = path.extname(filePath).toLowerCase();
      if (ext === ".jsonl") {
        const lines = content.trim().split("\n").filter((line) => line.trim());
        newArticles = lines.map((line) => JSON.parse(line));
      } else if (ext === ".json") {
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed)) {
          newArticles = parsed;
        } else {
          return {
            success: false,
            articlesCount: 0,
            error: "\u0641\u0627\u06CC\u0644 JSON \u0628\u0627\u06CC\u062F \u06CC\u06A9 \u0622\u0631\u0627\u06CC\u0647 \u0627\u0632 \u0645\u0648\u0627\u062F \u0628\u0627\u0634\u062F"
          };
        }
      } else if (ext === ".txt") {
        return {
          success: false,
          articlesCount: 0,
          error: "\u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC TXT \u0641\u0639\u0644\u0627\u064B \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0646\u0645\u06CC\u200C\u0634\u0648\u0646\u062F. \u0644\u0637\u0641\u0627\u064B \u0627\u0632 JSONL \u06CC\u0627 JSON \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u06A9\u0646\u06CC\u062F."
        };
      } else {
        return {
          success: false,
          articlesCount: 0,
          error: "\u0641\u0631\u0645\u062A \u0641\u0627\u06CC\u0644 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0646\u0645\u06CC\u200C\u0634\u0648\u062F. \u0641\u0642\u0637 JSONL \u0648 JSON \u0645\u062C\u0627\u0632 \u0647\u0633\u062A\u0646\u062F."
        };
      }
      if (newArticles.length === 0) {
        return {
          success: false,
          articlesCount: 0,
          error: "\u0647\u06CC\u0686 \u0645\u0627\u062F\u0647\u200C\u0627\u06CC \u062F\u0631 \u0641\u0627\u06CC\u0644 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F"
        };
      }
      this.articles = newArticles;
      this.fuse = new Fuse(this.articles, {
        keys: [
          { name: "article_title", weight: 0.4 },
          { name: "text", weight: 0.6 }
        ],
        threshold: 0.4,
        includeScore: true,
        minMatchCharLength: 3
      });
      this.cache.clear();
      console.log(
        `\u2705 Agent reloaded with ${this.articles.length} articles from ${filePath}`
      );
      return { success: true, articlesCount: this.articles.length };
    } catch (error) {
      console.error("\u274C Error loading file:", error);
      return {
        success: false,
        articlesCount: 0,
        error: `\u062E\u0637\u0627 \u062F\u0631 \u067E\u0631\u062F\u0627\u0632\u0634 \u0641\u0627\u06CC\u0644: ${error.message}`
      };
    }
  }
};
var agentService = new AgentService();

// server/multi-source-agent.ts
import { eq as eq2 } from "drizzle-orm";
import OpenAI2 from "openai";

// server/web-search-helper.ts
async function searchWeb(query) {
  try {
    const encodedQuery = encodeURIComponent(query);
    const timeoutPromise = new Promise(
      (_, reject) => setTimeout(() => reject(new Error("Request timeout")), 1e4)
    );
    const response = await Promise.race([
      fetch(
        `https://api.duckduckgo.com/?q=${encodedQuery}&format=json&no_html=1&skip_disambig=1`,
        {
          headers: {
            "User-Agent": "Sarisazan Construction Management System/1.0"
          }
        }
      ),
      timeoutPromise
    ]);
    if (!response.ok) {
      throw new Error(`Search API returned ${response.status}`);
    }
    const data = await response.json();
    let answer = "";
    const sources = [];
    if (data.AbstractText) {
      answer = data.AbstractText;
      if (data.AbstractSource) {
        sources.push(data.AbstractSource);
      }
    } else if (data.RelatedTopics && data.RelatedTopics.length > 0) {
      const firstTopic = data.RelatedTopics[0];
      if (firstTopic.Text) {
        answer = firstTopic.Text;
      }
      if (firstTopic.FirstURL) {
        sources.push(firstTopic.FirstURL);
      }
    }
    if (!answer) {
      return {
        success: false,
        answer: "\u0645\u062A\u0623\u0633\u0641\u0627\u0646\u0647 \u0646\u062A\u06CC\u062C\u0647\u200C\u0627\u06CC \u0627\u0632 \u062C\u0633\u062A\u062C\u0648\u06CC \u0627\u06CC\u0646\u062A\u0631\u0646\u062A \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F. \u0644\u0637\u0641\u0627\u064B \u0633\u0624\u0627\u0644 \u062E\u0648\u062F \u0631\u0627 \u0628\u0627 \u062C\u0632\u0626\u06CC\u0627\u062A \u0628\u06CC\u0634\u062A\u0631\u06CC \u0645\u0637\u0631\u062D \u06A9\u0646\u06CC\u062F.",
        sources: []
      };
    }
    return {
      success: true,
      answer: `\u{1F310} \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0632 \u0627\u06CC\u0646\u062A\u0631\u0646\u062A:

${answer}

\u{1F4CC} \u0645\u0646\u0628\u0639: ${sources.join(", ") || "\u062C\u0633\u062A\u062C\u0648\u06CC \u0648\u0628"}`,
      sources
    };
  } catch (error) {
    console.error("\u274C Web search error:", error);
    return {
      success: false,
      answer: "\u0645\u062A\u0623\u0633\u0641\u0627\u0646\u0647 \u062F\u0631 \u062C\u0633\u062A\u062C\u0648\u06CC \u0627\u06CC\u0646\u062A\u0631\u0646\u062A \u0645\u0634\u06A9\u0644\u06CC \u067E\u06CC\u0634 \u0622\u0645\u062F.",
      sources: []
    };
  }
}
async function searchConstructionInfo(query) {
  const webResult = await searchWeb(query);
  if (webResult.success) {
    return webResult.answer;
  }
  return `\u{1F50D} \u0628\u0631\u0627\u06CC \u062C\u0633\u062A\u062C\u0648\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0628\u06CC\u0634\u062A\u0631 \u062F\u0631\u0628\u0627\u0631\u0647 "${query}"\u060C \u067E\u06CC\u0634\u0646\u0647\u0627\u062F \u0645\u06CC\u200C\u06A9\u0646\u0645:

\u2022 \u0627\u0632 \u0645\u0646\u0627\u0628\u0639 \u0645\u0639\u062A\u0628\u0631 \u0633\u0627\u062E\u062A\u0645\u0627\u0646\u06CC \u0627\u06CC\u0631\u0627\u0646 \u0645\u0627\u0646\u0646\u062F:
  - \u0633\u0627\u06CC\u062A \u0646\u0638\u0627\u0645 \u0645\u0647\u0646\u062F\u0633\u06CC \u0633\u0627\u062E\u062A\u0645\u0627\u0646
  - \u0645\u0631\u06A9\u0632 \u062A\u062D\u0642\u06CC\u0642\u0627\u062A \u0631\u0627\u0647\u060C \u0645\u0633\u06A9\u0646 \u0648 \u0634\u0647\u0631\u0633\u0627\u0632\u06CC
  - \u062F\u0641\u062A\u0631 \u0646\u0638\u0627\u0645 \u0641\u0646\u06CC \u0648 \u0627\u062C\u0631\u0627\u06CC\u06CC

\u2022 \u06CC\u0627 \u0633\u0624\u0627\u0644 \u062E\u0648\u062F \u0631\u0627 \u0628\u0627 \u062C\u0632\u0626\u06CC\u0627\u062A \u0628\u06CC\u0634\u062A\u0631\u06CC \u062F\u0631 \u0633\u06CC\u0633\u062A\u0645 \u0645\u0637\u0631\u062D \u06A9\u0646\u06CC\u062F.

\u{1F527} \u0627\u06AF\u0631 \u0633\u0624\u0627\u0644 \u0634\u0645\u0627 \u062F\u0631\u0628\u0627\u0631\u0647 \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u0645\u0648\u062C\u0648\u062F \u062F\u0631 \u0633\u06CC\u0633\u062A\u0645 \u0627\u0633\u062A\u060C \u0627\u0632 \u06A9\u0644\u0645\u0627\u062A \u06A9\u0644\u06CC\u062F\u06CC \u0645\u0627\u0646\u0646\u062F "\u067E\u0631\u0648\u0698\u0647"\u060C "\u0642\u0631\u0627\u0631\u062F\u0627\u062F"\u060C "\u0635\u0648\u0631\u062A\u200C\u0648\u0636\u0639\u06CC\u062A" \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u06A9\u0646\u06CC\u062F.`;
}

// server/multi-source-agent.ts
var MultiSourceAgentService = class {
  openai = null;
  constructor() {
    const apiKey = process.env.XAI_API_KEY;
    if (apiKey) {
      this.openai = new OpenAI2({
        apiKey,
        baseURL: "https://api.x.ai/v1"
      });
    }
  }
  normalizeText(text2) {
    return text2.replace(/[ًٌٍَُِّْٰ]/g, "").replace(/[؟،؛]/g, "").replace(/‌/g, "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  async classifyQuery(query) {
    const normalized = this.normalizeText(query);
    const databaseKeywords = [
      "\u067E\u0631\u0648\u0698\u0647",
      "\u0642\u0631\u0627\u0631\u062F\u0627\u062F",
      "\u06A9\u0627\u0631\u0641\u0631\u0645\u0627",
      "\u067E\u06CC\u0634\u0631\u0641\u062A",
      "\u0645\u0628\u0644\u063A",
      "\u0642\u06CC\u0645\u062A",
      "\u0628\u0648\u062F\u062C\u0647",
      "\u0647\u0632\u06CC\u0646\u0647",
      "\u0635\u0648\u0631\u062A",
      "\u0648\u0636\u0639\u06CC\u062A",
      "\u0633\u0631\u06CC\u0639",
      "\u0633\u0627\u0632\u0627\u0646",
      "\u0628\u0647\u06CC\u0646\u0647",
      "\u0645\u0637\u0628\u0648\u0639",
      "\u062E\u0627\u06A9",
      "\u067E\u06CC",
      "\u062F\u0646\u0627",
      "\u0642\u0632\u0648\u06CC\u0646",
      "\u062A\u0627\u06A9\u0633\u062A\u0627\u0646",
      "\u0622\u0648\u062C",
      "\u0627\u0644\u0628\u0631\u0632",
      "\u0647\u0645\u0647",
      "\u0686\u0646\u062F",
      "\u06A9\u062F\u0627\u0645",
      "\u062F\u0631\u0635\u062F",
      "\u062A\u06A9\u0645\u06CC\u0644",
      "\u0627\u0646\u062C\u0627\u0645",
      "\u0634\u062F\u0647"
    ];
    const legalKeywords = [
      "\u0645\u0627\u062F\u0647",
      "\u0642\u0627\u0646\u0648\u0646",
      "\u0634\u0631\u0627\u06CC\u0637",
      "\u0639\u0645\u0648\u0645\u06CC",
      "\u067E\u06CC\u0645\u0627\u0646",
      "\u0641\u0633\u062E",
      "\u062A\u0639\u0647\u062F",
      "\u0645\u0633\u0626\u0648\u0644\u06CC\u062A",
      "\u062D\u0642",
      "\u062A\u06A9\u0644\u06CC\u0641",
      "\u0645\u0647\u0644\u062A",
      "\u062A\u062D\u0648\u06CC\u0644",
      "\u062A\u0636\u0645\u06CC\u0646",
      "\u062E\u0633\u0627\u0631\u062A",
      "\u062C\u0631\u06CC\u0645\u0647",
      "\u0628\u06CC\u0645\u0647"
    ];
    const hasDatabaseKeyword = databaseKeywords.some((kw) => normalized.includes(kw));
    const hasLegalKeyword = legalKeywords.some((kw) => normalized.includes(kw));
    if (normalized.includes("\u0644\u06CC\u0633\u062A") && normalized.includes("\u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631")) {
      return "database";
    }
    if (hasDatabaseKeyword && !hasLegalKeyword) {
      return "database";
    }
    if (hasLegalKeyword) {
      return "legal";
    }
    if (normalized.includes("\u0644\u06CC\u0633\u062A") || normalized.includes("\u0647\u0645\u0647") || normalized.includes("\u0686\u0646\u062F")) {
      return "database";
    }
    const questionWords = ["\u0686\u0637\u0648\u0631", "\u0686\u06AF\u0648\u0646\u0647", "\u0686\u0631\u0627"];
    if (questionWords.some((qw) => normalized.includes(qw))) {
      return "general";
    }
    return "general";
  }
  async queryStatements(query, allProjects) {
    const normalized = this.normalizeText(query);
    const contractMatch = query.match(/\d{4}/);
    if (contractMatch) {
      const contractNum = contractMatch[0];
      const project = allProjects.find((p) => p.contractNumber?.includes(contractNum));
      if (project) {
        const projectStatements = await db.select().from(statements).where(eq2(statements.projectId, project.id));
        const projectAdjustments = await db.select().from(adjustments).where(eq2(adjustments.projectId, project.id));
        let answer = `\u{1F4DD} \u0635\u0648\u0631\u062A\u200C\u0648\u0636\u0639\u06CC\u062A\u200C\u0647\u0627\u06CC \u0642\u0631\u0627\u0631\u062F\u0627\u062F ${project.contractNumber}:

`;
        answer += `\u{1F4CB} \u067E\u0631\u0648\u0698\u0647: ${project.title}

`;
        if (projectStatements.length > 0) {
          answer += `\u{1F4B0} \u0635\u0648\u0631\u062A\u200C\u0648\u0636\u0639\u06CC\u062A\u200C\u0647\u0627 (${projectStatements.length} \u0645\u0648\u0631\u062F):
`;
          projectStatements.forEach((stmt, i) => {
            answer += `
${i + 1}. \u0635\u0648\u0631\u062A\u200C\u0648\u0636\u0639\u06CC\u062A \u0634\u0645\u0627\u0631\u0647 ${stmt.number}
`;
            answer += `   \u2022 \u0645\u0628\u0644\u063A: ${stmt.amount} \u0631\u06CC\u0627\u0644
`;
            if (stmt.startDate) answer += `   \u2022 \u062A\u0627\u0631\u06CC\u062E \u0634\u0631\u0648\u0639: ${stmt.startDate}
`;
            if (stmt.endDate) answer += `   \u2022 \u062A\u0627\u0631\u06CC\u062E \u067E\u0627\u06CC\u0627\u0646: ${stmt.endDate}
`;
            answer += `   \u2022 \u0648\u0636\u0639\u06CC\u062A: ${stmt.status}
`;
          });
        } else {
          answer += `\u0635\u0648\u0631\u062A\u200C\u0648\u0636\u0639\u06CC\u062A\u06CC \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u067E\u0631\u0648\u0698\u0647 \u062B\u0628\u062A \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.
`;
        }
        if (projectAdjustments.length > 0) {
          answer += `
\u{1F4CA} \u062A\u0639\u062F\u06CC\u0644\u200C\u0647\u0627 (${projectAdjustments.length} \u0645\u0648\u0631\u062F):
`;
          projectAdjustments.forEach((adj, i) => {
            answer += `
${i + 1}. \u062A\u0639\u062F\u06CC\u0644 \u0634\u0645\u0627\u0631\u0647 ${adj.number}
`;
            answer += `   \u2022 \u0645\u0628\u0644\u063A: ${adj.amount} \u0631\u06CC\u0627\u0644
`;
            if (adj.startDate) answer += `   \u2022 \u062A\u0627\u0631\u06CC\u062E \u0634\u0631\u0648\u0639: ${adj.startDate}
`;
            if (adj.endDate) answer += `   \u2022 \u062A\u0627\u0631\u06CC\u062E \u067E\u0627\u06CC\u0627\u0646: ${adj.endDate}
`;
          });
        }
        return {
          answer,
          references: [project.contractNumber || project.id],
          source: "database"
        };
      }
    }
    return null;
  }
  async queryDatabase(query) {
    try {
      const normalized = this.normalizeText(query);
      const allProjects = await db.select().from(projects);
      if (normalized.includes("\u0635\u0648\u0631\u062A") && normalized.includes("\u0648\u0636\u0639\u06CC\u062A")) {
        const statementsResult = await this.queryStatements(query, allProjects);
        if (statementsResult) return statementsResult;
      }
      const matches = allProjects.filter((p) => {
        const searchText = this.normalizeText([
          p.title,
          p.contractor,
          p.employer,
          p.contractNumber,
          p.location
        ].filter(Boolean).join(" "));
        const queryWords = normalized.split(" ").filter((w) => w.length > 1);
        return queryWords.some((word) => searchText.includes(word));
      });
      if (matches.length > 0) {
        const answer = this.formatProjectResults(query, matches);
        return {
          answer,
          references: matches.map((p) => p.contractNumber || p.id),
          source: "database"
        };
      }
      if (normalized.includes("\u0644\u06CC\u0633\u062A") || normalized.includes("\u0647\u0645\u0647") || normalized.includes("\u062A\u0645\u0627\u0645") || normalized.includes("\u067E\u0631\u0648\u0698\u0647")) {
        const answer = this.formatProjectList(allProjects);
        return {
          answer,
          references: allProjects.map((p) => p.contractNumber || p.id),
          source: "database"
        };
      }
      if (normalized.includes("\u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631")) {
        const contractorSet = new Set(allProjects.map((p) => p.contractor).filter(Boolean));
        const contractors = Array.from(contractorSet);
        return {
          answer: `\u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631\u0627\u0646 \u0645\u0648\u062C\u0648\u062F \u062F\u0631 \u0633\u06CC\u0633\u062A\u0645:

${contractors.map((c, i) => `${i + 1}. ${c}`).join("\n")}

\u0628\u0631\u0627\u06CC \u062C\u0632\u0626\u06CC\u0627\u062A \u0628\u06CC\u0634\u062A\u0631\u060C \u0646\u0627\u0645 \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631 \u0631\u0627 \u0645\u0634\u062E\u0635 \u06A9\u0646\u06CC\u062F.`,
          references: [],
          source: "database"
        };
      }
      return {
        answer: '\u0645\u062A\u0623\u0633\u0641\u0627\u0646\u0647 \u067E\u0631\u0648\u0698\u0647\u200C\u0627\u06CC \u0628\u0627 \u0627\u06CC\u0646 \u0645\u0634\u062E\u0635\u0627\u062A \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F. \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F:\n\u2022 \u0627\u0632 \u06A9\u0644\u0645\u0627\u062A \u06A9\u0644\u06CC\u062F\u06CC \u062F\u06CC\u06AF\u0631\u06CC \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u06A9\u0646\u06CC\u062F\n\u2022 "\u0644\u06CC\u0633\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627" \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F\n\u2022 \u0646\u0627\u0645 \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631 \u0631\u0627 \u0628\u067E\u0631\u0633\u06CC\u062F',
        references: [],
        source: "database"
      };
    } catch (error) {
      console.error("\u274C Database query error:", error);
      return {
        answer: "\u0645\u062A\u0623\u0633\u0641\u0627\u0646\u0647 \u062F\u0631 \u062C\u0633\u062A\u062C\u0648\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u067E\u0631\u0648\u0698\u0647 \u0645\u0634\u06A9\u0644\u06CC \u067E\u06CC\u0634 \u0622\u0645\u062F.",
        references: [],
        source: "database"
      };
    }
  }
  formatProjectList(projects2) {
    if (projects2.length === 0) {
      return "\u0647\u06CC\u0686 \u067E\u0631\u0648\u0698\u0647\u200C\u0627\u06CC \u062F\u0631 \u0633\u06CC\u0633\u062A\u0645 \u062B\u0628\u062A \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.";
    }
    let answer = `\u{1F4CB} \u0644\u06CC\u0633\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627 (${projects2.length} \u067E\u0631\u0648\u0698\u0647):

`;
    projects2.forEach((p, index) => {
      answer += `${index + 1}. ${p.title}
`;
      answer += `   \u{1F4DD} \u0634\u0645\u0627\u0631\u0647 \u0642\u0631\u0627\u0631\u062F\u0627\u062F: ${p.contractNumber || "\u062B\u0628\u062A \u0646\u0634\u062F\u0647"}
`;
      answer += `   \u{1F477} \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631: ${p.contractor || "\u062B\u0628\u062A \u0646\u0634\u062F\u0647"}
`;
      if (p.progress !== null && p.progress !== void 0) {
        answer += `   \u{1F4CA} \u067E\u06CC\u0634\u0631\u0641\u062A: ${p.progress}%
`;
      }
      answer += "\n";
    });
    return answer;
  }
  formatProjectResults(query, results) {
    const normalized = this.normalizeText(query);
    if (normalized.includes("\u067E\u06CC\u0634\u0631\u0641\u062A") || normalized.includes("\u062F\u0631\u0635\u062F")) {
      let answer2 = "\u{1F4CA} \u0648\u0636\u0639\u06CC\u062A \u067E\u06CC\u0634\u0631\u0641\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627:\n\n";
      results.forEach((p) => {
        answer2 += `\u2022 ${p.title}
`;
        answer2 += `  \u067E\u06CC\u0634\u0631\u0641\u062A: ${p.progress || 0}% | \u0642\u0631\u0627\u0631\u062F\u0627\u062F: ${p.contractNumber}

`;
      });
      return answer2;
    }
    if (normalized.includes("\u0645\u0628\u0644\u063A") || normalized.includes("\u0642\u06CC\u0645\u062A") || normalized.includes("\u0628\u0648\u062F\u062C\u0647")) {
      let answer2 = "\u{1F4B0} \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0645\u0627\u0644\u06CC \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627:\n\n";
      results.forEach((p) => {
        answer2 += `\u2022 ${p.title}
`;
        answer2 += `  \u0645\u0628\u0644\u063A \u0642\u0631\u0627\u0631\u062F\u0627\u062F: ${p.amount || "\u062B\u0628\u062A \u0646\u0634\u062F\u0647"} \u0631\u06CC\u0627\u0644
`;
        answer2 += `  \u0634\u0645\u0627\u0631\u0647 \u0642\u0631\u0627\u0631\u062F\u0627\u062F: ${p.contractNumber}

`;
      });
      return answer2;
    }
    if (results.length === 1) {
      const p = results[0];
      let answer2 = `\u{1F4CB} \u0645\u0634\u062E\u0635\u0627\u062A \u067E\u0631\u0648\u0698\u0647:

`;
      answer2 += `\u{1F537} \u0639\u0646\u0648\u0627\u0646: ${p.title}

`;
      if (p.contractNumber) answer2 += `\u{1F4DD} \u0634\u0645\u0627\u0631\u0647 \u0642\u0631\u0627\u0631\u062F\u0627\u062F: ${p.contractNumber}
`;
      if (p.contractDate) answer2 += `\u{1F4C5} \u062A\u0627\u0631\u06CC\u062E \u0642\u0631\u0627\u0631\u062F\u0627\u062F: ${p.contractDate}
`;
      if (p.contractor) answer2 += `\u{1F477} \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631: ${p.contractor}
`;
      if (p.employer) answer2 += `\u{1F3E2} \u06A9\u0627\u0631\u0641\u0631\u0645\u0627: ${p.employer}
`;
      if (p.amount) answer2 += `\u{1F4B0} \u0645\u0628\u0644\u063A \u0642\u0631\u0627\u0631\u062F\u0627\u062F: ${p.amount} \u0631\u06CC\u0627\u0644
`;
      if (p.progress !== null && p.progress !== void 0) {
        answer2 += `\u{1F4CA} \u062F\u0631\u0635\u062F \u067E\u06CC\u0634\u0631\u0641\u062A: ${p.progress}%
`;
      }
      if (p.status) answer2 += `\u{1F504} \u0648\u0636\u0639\u06CC\u062A: ${p.status === "active" ? "\u0641\u0639\u0627\u0644" : p.status}
`;
      return answer2;
    }
    let answer = `\u06CC\u0627\u0641\u062A \u0634\u062F ${results.length} \u067E\u0631\u0648\u0698\u0647:

`;
    results.forEach((p, index) => {
      answer += `${index + 1}. ${p.title}
`;
      answer += `   \u067E\u06CC\u0645\u0627\u0646\u06A9\u0627\u0631: ${p.contractor || "\u0646\u0627\u0645\u0634\u062E\u0635"} | `;
      answer += `\u067E\u06CC\u0634\u0631\u0641\u062A: ${p.progress || 0}%

`;
    });
    return answer;
  }
  async askGeneralQuestion(query) {
    if (this.openai) {
      try {
        const systemPrompt = `\u062A\u0648 \u06CC\u06A9 \u062F\u0633\u062A\u06CC\u0627\u0631 \u0647\u0648\u0634\u0645\u0646\u062F \u0628\u0631\u0627\u06CC \u0645\u062F\u06CC\u0631\u06CC\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u0633\u0627\u062E\u062A\u0645\u0627\u0646\u06CC \u0647\u0633\u062A\u06CC.
\u0628\u0647 \u0633\u0648\u0627\u0644\u0627\u062A \u06A9\u0627\u0631\u0628\u0631 \u0628\u0647 \u0632\u0628\u0627\u0646 \u0641\u0627\u0631\u0633\u06CC\u060C \u0648\u0627\u0636\u062D \u0648 \u06A9\u0627\u0631\u0628\u0631\u062F\u06CC \u067E\u0627\u0633\u062E \u0628\u062F\u0647.
\u067E\u0627\u0633\u062E\u200C\u0647\u0627\u06CC\u062A \u0628\u0627\u06CC\u062F:
- \u0645\u062E\u062A\u0635\u0631 \u0648 \u0645\u0641\u06CC\u062F \u0628\u0627\u0634\u0646\u062F (\u062D\u062F\u0627\u06A9\u062B\u0631 200 \u06A9\u0644\u0645\u0647)
- \u0645\u0633\u062A\u0642\u06CC\u0645\u0627\u064B \u0628\u0647 \u0633\u0648\u0627\u0644 \u067E\u0627\u0633\u062E \u062F\u0647\u0646\u062F
- \u062F\u0631 \u0635\u0648\u0631\u062A \u0644\u0632\u0648\u0645\u060C \u0645\u062B\u0627\u0644 \u0639\u0645\u0644\u06CC \u0627\u0631\u0627\u0626\u0647 \u06A9\u0646\u0646\u062F

\u0627\u06AF\u0631 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06A9\u0627\u0641\u06CC \u0646\u062F\u0627\u0631\u06CC\u060C \u0635\u0627\u062F\u0642\u0627\u0646\u0647 \u0627\u0639\u0644\u0627\u0645 \u06A9\u0646 \u06A9\u0647 \u0646\u0645\u06CC\u062F\u0627\u0646\u06CC.`;
        const completion = await this.openai.chat.completions.create({
          model: "grok-2-1212",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: query }
          ],
          temperature: 0.2,
          max_tokens: 500
        });
        const answer = completion.choices[0]?.message?.content || "";
        if (!answer || answer.includes("\u0646\u0645\u06CC\u200C\u062F\u0627\u0646\u0645") || answer.includes("\u0646\u0645\u06CC\u062F\u0627\u0646\u0645") || answer.includes("\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06A9\u0627\u0641\u06CC \u0646\u062F\u0627\u0631\u0645")) {
          console.log("\u{1F50D} AI doesn't have enough info, searching the web...");
          const webAnswer2 = await searchConstructionInfo(query);
          return {
            answer: `\u{1F916} \u067E\u0627\u0633\u062E \u0627\u0648\u0644\u06CC\u0647 \u062F\u0633\u062A\u06CC\u0627\u0631:
${answer}

${webAnswer2}`,
            references: [],
            source: "general-api"
          };
        }
        return {
          answer,
          references: [],
          source: "general-api"
        };
      } catch (error) {
        console.error("\u274C AI API error:", error);
        const errorMessage = error.message?.toLowerCase() || "";
        if (errorMessage.includes("abroad") || errorMessage.includes("geographic") || errorMessage.includes("region") || errorMessage.includes("403") || errorMessage.includes("forbidden")) {
          console.log("\u{1F30D} Geographic restriction detected, using web search fallback...");
          const webAnswer3 = await searchConstructionInfo(query);
          return {
            answer: `\u26A0\uFE0F \u062F\u0633\u062A\u06CC\u0627\u0631 \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC \u0628\u0647 \u062F\u0644\u06CC\u0644 \u0645\u062D\u062F\u0648\u062F\u06CC\u062A\u200C\u0647\u0627\u06CC \u062C\u063A\u0631\u0627\u0641\u06CC\u0627\u06CC\u06CC \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0646\u06CC\u0633\u062A.

${webAnswer3}`,
            references: [],
            source: "general-api"
          };
        }
        console.log("\u{1F50D} API error, trying web search fallback...");
        const webAnswer2 = await searchConstructionInfo(query);
        return {
          answer: `\u26A0\uFE0F \u062E\u0637\u0627 \u062F\u0631 \u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u062F\u0633\u062A\u06CC\u0627\u0631 \u0647\u0648\u0634 \u0645\u0635\u0646\u0648\u0639\u06CC.

${webAnswer2}`,
          references: [],
          source: "general-api"
        };
      }
    }
    console.log("\u{1F50D} No API key configured, using web search...");
    const webAnswer = await searchConstructionInfo(query);
    return {
      answer: webAnswer,
      references: [],
      source: "general-api"
    };
  }
  async ask(query) {
    const queryType = await this.classifyQuery(query);
    console.log(`\u{1F914} Query classified as: ${queryType}`);
    if (queryType === "database") {
      return await this.queryDatabase(query);
    }
    if (queryType === "legal") {
      const legalResult = await agentService.ask(query);
      return {
        answer: legalResult.answer,
        references: legalResult.references,
        source: legalResult.source === "api" ? "legal-api" : "legal-local"
      };
    }
    return await this.askGeneralQuestion(query);
  }
};
var multiSourceAgent = new MultiSourceAgentService();

// server/routes.ts
async function registerRoutes(app2) {
  app2.post("/api/agent/ask", async (req, res) => {
    try {
      const { query, projectId } = req.body;
      if (!query || typeof query !== "string") {
        return res.status(400).json({ message: "\u0633\u0624\u0627\u0644 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
      }
      const result = await multiSourceAgent.ask(query);
      res.json(result);
    } catch (error) {
      console.error("\u274C Agent ask error:", error);
      res.status(500).json({
        message: "\u062E\u0637\u0627 \u062F\u0631 \u067E\u0631\u062F\u0627\u0632\u0634 \u0633\u0624\u0627\u0644",
        error: error.message
      });
    }
  });
  app2.get("/api/agent/article/:id", async (req, res) => {
    try {
      const articleId = parseInt(req.params.id);
      if (isNaN(articleId)) {
        return res.status(400).json({ message: "\u0634\u0645\u0627\u0631\u0647 \u0645\u0627\u062F\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A" });
      }
      const article = agentService.getArticle(articleId);
      if (!article) {
        return res.status(404).json({ message: "\u0645\u0627\u062F\u0647 \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      res.json(article);
    } catch (error) {
      console.error("\u274C Agent article error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/agent/execute", async (req, res) => {
    try {
      const { action, data } = req.body;
      res.json({
        success: false,
        message: "\u0627\u06CC\u0646 \u0642\u0627\u0628\u0644\u06CC\u062A \u0628\u0647 \u0632\u0648\u062F\u06CC \u0627\u0636\u0627\u0641\u0647 \u0645\u06CC\u200C\u0634\u0648\u062F"
      });
    } catch (error) {
      console.error("\u274C Agent execute error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/agent/status", async (req, res) => {
    try {
      const isConfigured = agentService.isConfigured();
      res.json({
        connected: isConfigured,
        status: isConfigured ? "connected" : "disconnected"
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  const agentUploadDir = path2.join(process.cwd(), "uploads", "agent-documents");
  if (!fs2.existsSync(agentUploadDir)) {
    fs2.mkdirSync(agentUploadDir, { recursive: true });
  }
  const agentUpload = multer({
    dest: agentUploadDir,
    limits: { fileSize: 10 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
      const allowedExts = [".jsonl", ".json"];
      const ext = path2.extname(file.originalname).toLowerCase();
      if (allowedExts.includes(ext)) {
        cb(null, true);
      } else {
        cb(new Error("\u0641\u0642\u0637 \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC JSONL \u0648 JSON \u0645\u062C\u0627\u0632 \u0647\u0633\u062A\u0646\u062F"));
      }
    }
  });
  app2.post("/api/agent/upload-document", agentUpload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "\u0641\u0627\u06CC\u0644\u06CC \u0622\u067E\u0644\u0648\u062F \u0646\u0634\u062F\u0647 \u0627\u0633\u062A" });
      }
      const result = await agentService.loadFromFile(req.file.path);
      if (!result.success) {
        return res.status(400).json({ message: result.error || "\u062E\u0637\u0627 \u062F\u0631 \u067E\u0631\u062F\u0627\u0632\u0634 \u0641\u0627\u06CC\u0644" });
      }
      res.json({
        success: true,
        articlesCount: result.articlesCount,
        message: `${result.articlesCount} \u0645\u0627\u062F\u0647 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0628\u0627\u0631\u06AF\u0630\u0627\u0631\u06CC \u0634\u062F`
      });
    } catch (error) {
      console.error("\u274C Document upload error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/needs-action", async (req, res) => {
    try {
      const today = /* @__PURE__ */ new Date();
      const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      const endOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
      const allActionItems = await db.select().from(tasks).where(
        or2(
          and(
            sqlOperator2`${tasks.reminderDateTime}::date = CURRENT_DATE`,
            eq3(tasks.isCompleted, false)
          ),
          and(
            eq3(tasks.requiresConfirmation, true),
            eq3(tasks.isConfirmed, false)
          )
        )
      );
      const uniqueItems = Array.from(new Map(allActionItems.map((item) => [item.id, item])).values());
      res.json({ count: uniqueItems.length, items: uniqueItems });
    } catch (error) {
      res.status(500).json({ message: error.message, count: 0, items: [] });
    }
  });
  app2.get("/api/projects", async (req, res) => {
    try {
      const allProjects = await db.select().from(projects);
      res.json(allProjects);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/projects", async (req, res) => {
    try {
      const [project] = await db.insert(projects).values(req.body).returning();
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  const projectFilesUploadDir = path2.join(process.cwd(), "uploads", "project-files");
  if (!fs2.existsSync(projectFilesUploadDir)) {
    fs2.mkdirSync(projectFilesUploadDir, { recursive: true });
  }
  const projectFilesStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const projectId = req.body.projectId || req.params.projectId || "temp";
      const uploadPath = path2.join(projectFilesUploadDir, projectId);
      if (!fs2.existsSync(uploadPath)) {
        fs2.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
      const timestamp2 = Date.now();
      const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9._\u0600-\u06FF-]/g, "_");
      cb(null, `${timestamp2}_${sanitizedName}`);
    }
  });
  const projectFilesUpload = multer({
    storage: projectFilesStorage,
    limits: { fileSize: 50 * 1024 * 1024 }
  });
  app2.get("/api/projects/:projectId/files", async (req, res) => {
    try {
      const files = await db.select().from(projectFiles).where(eq3(projectFiles.projectId, req.params.projectId));
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/projects/:projectId/files", projectFilesUpload.single("file"), async (req, res) => {
    try {
      const file = req.file;
      if (!file) {
        return res.status(400).json({ message: "\u0641\u0627\u06CC\u0644 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A" });
      }
      const { title, uploadedBy } = req.body;
      const filePath = `/uploads/project-files/${req.params.projectId}/${file.filename}`;
      const [projectFile] = await db.insert(projectFiles).values({
        projectId: req.params.projectId,
        title: title || file.originalname,
        fileName: file.filename,
        filePath,
        fileType: file.mimetype,
        fileSize: file.size,
        uploadedBy: uploadedBy || null
      }).returning();
      res.json(projectFile);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/projects/:projectId/files/:fileId", async (req, res) => {
    try {
      const [fileData] = await db.select().from(projectFiles).where(eq3(projectFiles.id, req.params.fileId));
      if (fileData) {
        const fullPath = path2.join(projectFilesUploadDir, fileData.projectId, fileData.fileName);
        if (fs2.existsSync(fullPath)) {
          fs2.unlinkSync(fullPath);
        }
      }
      await db.delete(projectFiles).where(eq3(projectFiles.id, req.params.fileId));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/bitumen", async (req, res) => {
    try {
      const projectId = req.query.projectId;
      if (projectId) {
        const records = await db.select().from(bitumenRecords).where(eq3(bitumenRecords.projectId, projectId));
        res.json(records);
      } else {
        const records = await db.select().from(bitumenRecords);
        res.json(records);
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/bitumen", async (req, res) => {
    try {
      const [record] = await db.insert(bitumenRecords).values(req.body).returning();
      res.json(record);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/bitumen/:id", async (req, res) => {
    try {
      const [record] = await db.update(bitumenRecords).set({ ...req.body, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(bitumenRecords.id, req.params.id)).returning();
      res.json(record);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/bitumen/:id", async (req, res) => {
    try {
      await db.delete(bitumenRecords).where(eq3(bitumenRecords.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/tenders", async (req, res) => {
    try {
      const allTenders = await db.select().from(tenders);
      res.json(allTenders);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/tenders", async (req, res) => {
    try {
      const [tender] = await db.insert(tenders).values(req.body).returning();
      res.json(tender);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/tenders/:id", async (req, res) => {
    try {
      const [tender] = await db.update(tenders).set({ ...req.body, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(tenders.id, req.params.id)).returning();
      res.json(tender);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/tenders/:id", async (req, res) => {
    try {
      await db.delete(tenders).where(eq3(tenders.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/tenders/:id/approve", async (req, res) => {
    try {
      const { approvalStatus, approvalNotes, approvedBy } = req.body;
      const [tender] = await db.update(tenders).set({
        approvalStatus,
        approvalNotes,
        approvedBy,
        approvedAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq3(tenders.id, req.params.id)).returning();
      const tenderData = await db.select().from(tenders).where(eq3(tenders.id, req.params.id));
      if (tenderData.length > 0 && tenderData[0].createdBy) {
        const statusText = approvalStatus === "approved" ? "\u062A\u0627\u06CC\u06CC\u062F \u0634\u062F" : "\u0631\u062F \u0634\u062F";
        await db.insert(alerts).values({
          title: `\u0646\u062A\u06CC\u062C\u0647 \u0628\u0631\u0631\u0633\u06CC \u0645\u0646\u0627\u0642\u0635\u0647: ${tenderData[0].title}`,
          description: `\u0645\u0646\u0627\u0642\u0635\u0647 \u0634\u0645\u0627 ${statusText}. ${approvalNotes || ""}`,
          severity: approvalStatus === "approved" ? "low" : "medium",
          status: "open",
          assigneeId: tenderData[0].createdBy,
          createdBy: approvedBy,
          entityType: "tender",
          entityId: req.params.id
        });
      }
      res.json(tender);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/tenders/pending-approval/:userId", async (req, res) => {
    try {
      const pendingTenders = await db.select().from(tenders).where(
        and(
          eq3(tenders.assignedToId, req.params.userId),
          eq3(tenders.approvalStatus, "pending")
        )
      );
      res.json(pendingTenders);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/alerts", async (req, res) => {
    try {
      const { projectId, status, severity, entityType } = req.query;
      let query = db.select().from(alerts);
      const conditions = [];
      if (projectId) conditions.push(eq3(alerts.projectId, projectId));
      if (status) conditions.push(eq3(alerts.status, status));
      if (severity) conditions.push(eq3(alerts.severity, severity));
      if (entityType) conditions.push(eq3(alerts.entityType, entityType));
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
      const allAlerts = await query;
      res.json(allAlerts);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/alerts", async (req, res) => {
    try {
      const { recipientIds, ...alertData } = req.body;
      const [alert] = await db.insert(alerts).values(alertData).returning();
      if (recipientIds && Array.isArray(recipientIds) && recipientIds.length > 0) {
        const recipientRecords = recipientIds.map((userId) => ({
          alertId: alert.id,
          userId,
          isRead: false
        }));
        await db.insert(alertRecipients).values(recipientRecords);
      }
      res.json(alert);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/alerts/:id", async (req, res) => {
    try {
      const updateData = { ...req.body, updatedAt: /* @__PURE__ */ new Date() };
      if (req.body.status === "closed" && !req.body.closedAt) {
        updateData.closedAt = /* @__PURE__ */ new Date();
      }
      const [alert] = await db.update(alerts).set(updateData).where(eq3(alerts.id, req.params.id)).returning();
      res.json(alert);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/alerts/:id", async (req, res) => {
    try {
      await db.delete(alerts).where(eq3(alerts.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/alerts/csv", async (req, res) => {
    try {
      const allAlerts = await db.select().from(alerts);
      const csvHeader = "\u0634\u0646\u0627\u0633\u0647,\u067E\u0631\u0648\u0698\u0647,\u0646\u0648\u0639 \u0645\u0648\u062C\u0648\u062F\u06CC\u062A,\u0639\u0646\u0648\u0627\u0646,\u062A\u0648\u0636\u06CC\u062D\u0627\u062A,\u0634\u062F\u062A,\u0648\u0636\u0639\u06CC\u062A,\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u062C\u0627\u062F,\u062A\u0627\u0631\u06CC\u062E \u0628\u0633\u062A\u0647 \u0634\u062F\u0646\n";
      const csvRows = allAlerts.map((alert) => {
        const row = [
          alert.id,
          alert.projectId || "",
          alert.entityType || "",
          alert.title,
          alert.description || "",
          alert.severity,
          alert.status,
          alert.createdAt?.toISOString() || "",
          alert.closedAt?.toISOString() || ""
        ];
        return row.map((field) => `"${String(field).replace(/"/g, '""')}"`).join(",");
      }).join("\n");
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", 'attachment; filename="alerts.csv"');
      res.send("\uFEFF" + csvHeader + csvRows);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/alerts/:id/recipients", async (req, res) => {
    try {
      const recipients = await db.select({
        id: alertRecipients.id,
        alertId: alertRecipients.alertId,
        userId: alertRecipients.userId,
        isRead: alertRecipients.isRead,
        readAt: alertRecipients.readAt,
        firstName: users.firstName,
        lastName: users.lastName,
        username: users.username
      }).from(alertRecipients).leftJoin(users, eq3(alertRecipients.userId, users.id)).where(eq3(alertRecipients.alertId, req.params.id));
      res.json(recipients);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/alerts/:id/mark-read", async (req, res) => {
    try {
      const { userId } = req.body;
      await db.update(alertRecipients).set({ isRead: true, readAt: /* @__PURE__ */ new Date() }).where(
        and(
          eq3(alertRecipients.alertId, req.params.id),
          eq3(alertRecipients.userId, userId)
        )
      );
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/alerts/:id/recipients", async (req, res) => {
    try {
      const { recipientIds } = req.body;
      await db.delete(alertRecipients).where(eq3(alertRecipients.alertId, req.params.id));
      if (recipientIds && Array.isArray(recipientIds) && recipientIds.length > 0) {
        const recipientRecords = recipientIds.map((userId) => ({
          alertId: req.params.id,
          userId,
          isRead: false
        }));
        await db.insert(alertRecipients).values(recipientRecords);
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/alerts/:id/comments", async (req, res) => {
    try {
      const comments = await db.select({
        id: alertComments.id,
        alertId: alertComments.alertId,
        userId: alertComments.userId,
        content: alertComments.content,
        createdAt: alertComments.createdAt,
        updatedAt: alertComments.updatedAt,
        firstName: users.firstName,
        lastName: users.lastName,
        username: users.username,
        avatarPath: users.avatarPath
      }).from(alertComments).leftJoin(users, eq3(alertComments.userId, users.id)).where(eq3(alertComments.alertId, req.params.id)).orderBy(alertComments.createdAt);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/alerts/:id/comments", async (req, res) => {
    try {
      const { userId, content } = req.body;
      const [comment] = await db.insert(alertComments).values({
        alertId: req.params.id,
        userId,
        content
      }).returning();
      const commentWithUser = await db.select({
        id: alertComments.id,
        alertId: alertComments.alertId,
        userId: alertComments.userId,
        content: alertComments.content,
        createdAt: alertComments.createdAt,
        updatedAt: alertComments.updatedAt,
        firstName: users.firstName,
        lastName: users.lastName,
        username: users.username,
        avatarPath: users.avatarPath
      }).from(alertComments).leftJoin(users, eq3(alertComments.userId, users.id)).where(eq3(alertComments.id, comment.id));
      res.json(commentWithUser[0]);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  const sheetsUploadDir = path2.join(process.cwd(), "uploads", "sheets");
  if (!fs2.existsSync(sheetsUploadDir)) {
    fs2.mkdirSync(sheetsUploadDir, { recursive: true });
  }
  const sheetsStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const projectId = req.body.projectId || "temp";
      const sheetId = req.params.id || req.body.sheetId || "temp";
      const uploadPath = path2.join(sheetsUploadDir, projectId, sheetId);
      if (!fs2.existsSync(uploadPath)) {
        fs2.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
      const timestamp2 = Date.now();
      const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
      cb(null, `${timestamp2}_${sanitizedName}`);
    }
  });
  const sheetsUpload = multer({
    storage: sheetsStorage,
    limits: { fileSize: 15 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
      const allowedTypes = /jpeg|jpg|png|pdf|xlsx|xls|doc|docx/;
      const extname = allowedTypes.test(path2.extname(file.originalname).toLowerCase());
      const mimetype = allowedTypes.test(file.mimetype);
      if (extname && mimetype) {
        cb(null, true);
      } else {
        cb(new Error("\u0641\u0642\u0637 \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u062A\u0635\u0648\u06CC\u0631\u060C PDF \u0648 Excel \u0645\u062C\u0627\u0632 \u0647\u0633\u062A\u0646\u062F"));
      }
    }
  });
  app2.get("/api/sheets", async (req, res) => {
    try {
      const { projectId, sheetType, status, dateFrom, dateTo } = req.query;
      const conditions = [sqlOperator2`${sheets.deletedAt} IS NULL`];
      if (projectId) conditions.push(eq3(sheets.projectId, projectId));
      if (sheetType) conditions.push(eq3(sheets.sheetType, sheetType));
      if (status) conditions.push(eq3(sheets.status, status));
      if (dateFrom) conditions.push(sqlOperator2`${sheets.sampleDate} >= ${dateFrom}`);
      if (dateTo) conditions.push(sqlOperator2`${sheets.sampleDate} <= ${dateTo}`);
      const query = db.select().from(sheets).where(and(...conditions));
      const allSheets = await query;
      res.json(allSheets);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/sheets/:id", async (req, res) => {
    try {
      const [sheet] = await db.select().from(sheets).where(and(eq3(sheets.id, req.params.id), sqlOperator2`${sheets.deletedAt} IS NULL`));
      if (!sheet) {
        return res.status(404).json({ message: "\u0634\u06CC\u062A \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      const files = await db.select().from(sheetFiles).where(eq3(sheetFiles.sheetId, req.params.id));
      res.json({ ...sheet, files });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/sheets", sheetsUpload.array("files", 5), async (req, res) => {
    try {
      const files = req.files || [];
      const { projectId, sheetType, sampleDate, status, createdBy, ...otherData } = req.body;
      const [sheet] = await db.insert(sheets).values({
        projectId,
        sheetType,
        sampleDate,
        status: status || "pending",
        createdBy,
        ...otherData
      }).returning();
      if (files.length > 0) {
        const sheetId = sheet.id;
        const newPath = path2.join(sheetsUploadDir, projectId, sheetId);
        if (!fs2.existsSync(newPath)) {
          fs2.mkdirSync(newPath, { recursive: true });
        }
        for (const file of files) {
          const oldPath = file.path;
          const newFilePath = path2.join(newPath, file.filename);
          fs2.renameSync(oldPath, newFilePath);
          await db.insert(sheetFiles).values({
            sheetId: sheet.id,
            fileName: file.filename,
            filePath: newFilePath,
            fileType: file.mimetype,
            uploadedBy: createdBy
          });
        }
      }
      res.json(sheet);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/sheets/:id", async (req, res) => {
    try {
      const [sheet] = await db.update(sheets).set({ ...req.body, updatedAt: /* @__PURE__ */ new Date() }).where(and(eq3(sheets.id, req.params.id), sqlOperator2`${sheets.deletedAt} IS NULL`)).returning();
      res.json(sheet);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/sheets/:id", async (req, res) => {
    try {
      await db.update(sheets).set({ deletedAt: /* @__PURE__ */ new Date() }).where(eq3(sheets.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/sheets/csv", async (req, res) => {
    try {
      const allSheets = await db.select().from(sheets).where(sqlOperator2`${sheets.deletedAt} IS NULL`);
      const csvHeader = "\u0634\u0646\u0627\u0633\u0647,\u067E\u0631\u0648\u0698\u0647,\u06A9\u062F \u0634\u06CC\u062A,\u0646\u0648\u0639,\u062A\u0627\u0631\u06CC\u062E \u0646\u0645\u0648\u0646\u0647,\u062A\u0627\u0631\u06CC\u062E \u0622\u0632\u0645\u0627\u06CC\u0634,\u0645\u062D\u0644,\u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647,\u0648\u0636\u0639\u06CC\u062A,\u062A\u0648\u0636\u06CC\u062D\u0627\u062A\n";
      const csvRows = allSheets.map((sheet) => {
        const row = [
          sheet.id,
          sheet.projectId,
          sheet.sheetCode || "",
          sheet.sheetType,
          sheet.sampleDate,
          sheet.testDate || "",
          sheet.location || "",
          sheet.labName || "",
          sheet.status,
          sheet.notes || ""
        ];
        return row.map((field) => `"${String(field).replace(/"/g, '""')}"`).join(",");
      }).join("\n");
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", 'attachment; filename="sheets.csv"');
      res.send("\uFEFF" + csvHeader + csvRows);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/sheets/files/:fileId", async (req, res) => {
    try {
      const [file] = await db.select().from(sheetFiles).where(eq3(sheetFiles.id, req.params.fileId));
      if (!file) {
        return res.status(404).json({ message: "\u0641\u0627\u06CC\u0644 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      res.download(file.filePath, file.fileName);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/statements", async (req, res) => {
    try {
      const { projectId, status } = req.query;
      let query = db.select().from(statements);
      const conditions = [sqlOperator2`${statements.deletedAt} IS NULL`];
      if (projectId) conditions.push(eq3(statements.projectId, projectId));
      if (status) conditions.push(eq3(statements.status, status));
      query = query.where(and(...conditions));
      const allStatements = await query.orderBy(desc(statements.createdAt));
      res.json(allStatements);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/statements/:id", async (req, res) => {
    try {
      const [statement] = await db.select().from(statements).where(and(
        eq3(statements.id, req.params.id),
        sqlOperator2`${statements.deletedAt} IS NULL`
      ));
      if (!statement) {
        return res.status(404).json({ message: "\u0635\u0648\u0631\u062A\u200C\u0648\u0636\u0639\u06CC\u062A \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      res.json(statement);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/statements", async (req, res) => {
    try {
      const [statement] = await db.insert(statements).values(req.body).returning();
      res.json(statement);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/statements/:id", async (req, res) => {
    try {
      const [statement] = await db.update(statements).set({ ...req.body, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(statements.id, req.params.id)).returning();
      res.json(statement);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/statements/:id", async (req, res) => {
    try {
      await db.update(statements).set({ deletedAt: /* @__PURE__ */ new Date() }).where(eq3(statements.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/adjustments", async (req, res) => {
    try {
      const { projectId, status } = req.query;
      let query = db.select().from(adjustments);
      const conditions = [sqlOperator2`${adjustments.deletedAt} IS NULL`];
      if (projectId) conditions.push(eq3(adjustments.projectId, projectId));
      if (status) conditions.push(eq3(adjustments.status, status));
      query = query.where(and(...conditions));
      const allAdjustments = await query.orderBy(desc(adjustments.createdAt));
      res.json(allAdjustments);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/adjustments/:id", async (req, res) => {
    try {
      const [adjustment] = await db.select().from(adjustments).where(and(
        eq3(adjustments.id, req.params.id),
        sqlOperator2`${adjustments.deletedAt} IS NULL`
      ));
      if (!adjustment) {
        return res.status(404).json({ message: "\u062A\u0639\u062F\u06CC\u0644 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      res.json(adjustment);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/adjustments", async (req, res) => {
    try {
      const [adjustment] = await db.insert(adjustments).values(req.body).returning();
      res.json(adjustment);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/adjustments/:id", async (req, res) => {
    try {
      const [adjustment] = await db.update(adjustments).set({ ...req.body, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(adjustments.id, req.params.id)).returning();
      res.json(adjustment);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/adjustments/:id", async (req, res) => {
    try {
      await db.update(adjustments).set({ deletedAt: /* @__PURE__ */ new Date() }).where(eq3(adjustments.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/bitumen-diffs", async (req, res) => {
    try {
      const { projectId, status } = req.query;
      let query = db.select().from(bitumenDiffs);
      const conditions = [sqlOperator2`${bitumenDiffs.deletedAt} IS NULL`];
      if (projectId) conditions.push(eq3(bitumenDiffs.projectId, projectId));
      if (status) conditions.push(eq3(bitumenDiffs.status, status));
      query = query.where(and(...conditions));
      const allBitumenDiffs = await query.orderBy(desc(bitumenDiffs.createdAt));
      res.json(allBitumenDiffs);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/bitumen-diffs/:id", async (req, res) => {
    try {
      const [bitumenDiff] = await db.select().from(bitumenDiffs).where(and(
        eq3(bitumenDiffs.id, req.params.id),
        sqlOperator2`${bitumenDiffs.deletedAt} IS NULL`
      ));
      if (!bitumenDiff) {
        return res.status(404).json({ message: "\u0645\u0627\u0628\u0647\u200C\u0627\u0644\u062A\u0641\u0627\u0648\u062A \u0642\u06CC\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      res.json(bitumenDiff);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/bitumen-diffs", async (req, res) => {
    try {
      const [bitumenDiff] = await db.insert(bitumenDiffs).values(req.body).returning();
      res.json(bitumenDiff);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/bitumen-diffs/:id", async (req, res) => {
    try {
      const [bitumenDiff] = await db.update(bitumenDiffs).set({ ...req.body, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(bitumenDiffs.id, req.params.id)).returning();
      res.json(bitumenDiff);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/bitumen-diffs/:id", async (req, res) => {
    try {
      await db.update(bitumenDiffs).set({ deletedAt: /* @__PURE__ */ new Date() }).where(eq3(bitumenDiffs.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/projects/:projectId/financial-history", async (req, res) => {
    try {
      const { projectId } = req.params;
      const projectStatements = await db.select().from(statements).where(and(
        eq3(statements.projectId, projectId),
        sqlOperator2`${statements.deletedAt} IS NULL`
      )).orderBy(statements.createdAt);
      const projectAdjustments = await db.select().from(adjustments).where(and(
        eq3(adjustments.projectId, projectId),
        sqlOperator2`${adjustments.deletedAt} IS NULL`
      )).orderBy(adjustments.createdAt);
      const projectBitumenDiffs = await db.select().from(bitumenDiffs).where(and(
        eq3(bitumenDiffs.projectId, projectId),
        sqlOperator2`${bitumenDiffs.deletedAt} IS NULL`
      )).orderBy(bitumenDiffs.createdAt);
      res.json({
        statements: projectStatements,
        adjustments: projectAdjustments,
        bitumenDiffs: projectBitumenDiffs
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  function parsePersianNumber(str) {
    if (!str) return 0;
    const persianDigits = ["\u06F0", "\u06F1", "\u06F2", "\u06F3", "\u06F4", "\u06F5", "\u06F6", "\u06F7", "\u06F8", "\u06F9"];
    const arabicDigits = ["\u0660", "\u0661", "\u0662", "\u0663", "\u0664", "\u0665", "\u0666", "\u0667", "\u0668", "\u0669"];
    let result = str;
    persianDigits.forEach((digit, index) => {
      result = result.replace(new RegExp(digit, "g"), index.toString());
    });
    arabicDigits.forEach((digit, index) => {
      result = result.replace(new RegExp(digit, "g"), index.toString());
    });
    result = result.replace(/[,٬]/g, "");
    return parseFloat(result) || 0;
  }
  app2.get("/api/dashboard/financial-stats", async (req, res) => {
    try {
      const allProjects = await db.select().from(projects);
      const allStatements = await db.select().from(statements).where(and(
        eq3(statements.status, "\u062A\u0627\u06CC\u06CC\u062F \u0634\u062F\u0647"),
        sqlOperator2`${statements.deletedAt} IS NULL`
      ));
      const allAdjustments = await db.select().from(adjustments).where(and(
        eq3(adjustments.status, "\u062A\u0627\u06CC\u06CC\u062F \u0634\u062F\u0647"),
        sqlOperator2`${adjustments.deletedAt} IS NULL`
      ));
      const allBitumenDiffs = await db.select().from(bitumenDiffs).where(and(
        eq3(bitumenDiffs.status, "\u062A\u0627\u06CC\u06CC\u062F \u0634\u062F\u0647"),
        sqlOperator2`${bitumenDiffs.deletedAt} IS NULL`
      ));
      const totalContractAmount = allProjects.reduce((sum, p) => {
        return sum + parsePersianNumber(p.amount);
      }, 0);
      const totalStatements = allStatements.reduce((sum, s) => sum + parsePersianNumber(s.amount), 0);
      const totalAdjustments = allAdjustments.reduce((sum, a) => sum + parsePersianNumber(a.amount), 0);
      const totalBitumenDiffs = allBitumenDiffs.reduce((sum, b) => sum + parsePersianNumber(b.amount), 0);
      const totalFinancialProgress = totalStatements + totalAdjustments + totalBitumenDiffs;
      const financialProgressPercentage = totalContractAmount > 0 ? totalFinancialProgress / totalContractAmount * 100 : 0;
      const sixMonthsAgo = /* @__PURE__ */ new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
      const recentStatements = allStatements.filter((s) => s.createdAt && new Date(s.createdAt) >= sixMonthsAgo);
      const monthlyData = {};
      recentStatements.forEach((s) => {
        if (s.createdAt) {
          const month = new Date(s.createdAt).toISOString().slice(0, 7);
          monthlyData[month] = (monthlyData[month] || 0) + parsePersianNumber(s.amount);
        }
      });
      res.json({
        totalContractAmount,
        totalStatements,
        totalAdjustments,
        totalBitumenDiffs,
        totalFinancialProgress,
        financialProgressPercentage,
        monthlyProgress: Object.entries(monthlyData).map(([month, amount]) => ({
          month,
          amount
        })).sort((a, b) => a.month.localeCompare(b.month)),
        projectCount: allProjects.length,
        statementCount: allStatements.length,
        adjustmentCount: allAdjustments.length,
        bitumenDiffCount: allBitumenDiffs.length
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/weekly-reports", async (req, res) => {
    try {
      const { projectId, status } = req.query;
      let query = db.select().from(weeklyReports);
      const conditions = [];
      if (projectId) conditions.push(eq3(weeklyReports.projectId, projectId));
      if (status) conditions.push(eq3(weeklyReports.status, status));
      query = query.where(conditions.length > 0 ? and(...conditions) : void 0);
      const reports = await query.orderBy(desc(weeklyReports.createdAt));
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/weekly-reports/:id", async (req, res) => {
    try {
      const [report] = await db.select().from(weeklyReports).where(eq3(weeklyReports.id, req.params.id));
      if (!report) {
        return res.status(404).json({ message: "\u06AF\u0632\u0627\u0631\u0634 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/weekly-reports", async (req, res) => {
    try {
      const [report] = await db.insert(weeklyReports).values(req.body).returning();
      if (req.body.projectId) {
        const [project] = await db.select().from(projects).where(eq3(projects.id, req.body.projectId));
        if (project) {
          const projectManagers = await db.select().from(users).leftJoin(roles, eq3(users.roleId, roles.id)).where(eq3(roles.name, "project_manager"));
          for (const pm of projectManagers) {
            if (pm.users) {
              await db.insert(alerts).values({
                projectId: req.body.projectId,
                title: "\u06AF\u0632\u0627\u0631\u0634 \u0647\u0641\u062A\u06AF\u06CC \u062C\u062F\u06CC\u062F",
                description: `\u06AF\u0632\u0627\u0631\u0634 \u0647\u0641\u062A\u06AF\u06CC \u062C\u062F\u06CC\u062F \u0628\u0631\u0627\u06CC \u067E\u0631\u0648\u0698\u0647 ${project.title} \u062B\u0628\u062A \u0634\u062F`,
                severity: "low",
                status: "open",
                assigneeId: pm.users.id,
                createdBy: req.body.createdBy || null
              });
            }
          }
        }
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/weekly-reports/:id", async (req, res) => {
    try {
      const [report] = await db.update(weeklyReports).set({ ...req.body, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(weeklyReports.id, req.params.id)).returning();
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/weekly-reports/:id/refer", async (req, res) => {
    try {
      const { referredTo } = req.body;
      const [report] = await db.update(weeklyReports).set({
        referredTo,
        referredAt: /* @__PURE__ */ new Date(),
        status: "\u0627\u0631\u062C\u0627\u0639 \u0634\u062F\u0647",
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq3(weeklyReports.id, req.params.id)).returning();
      if (referredTo) {
        const [project] = await db.select().from(projects).where(eq3(projects.id, report.projectId));
        await db.insert(alerts).values({
          projectId: report.projectId,
          title: "\u06AF\u0632\u0627\u0631\u0634 \u0647\u0641\u062A\u06AF\u06CC \u0627\u0631\u062C\u0627\u0639 \u062F\u0627\u062F\u0647 \u0634\u062F",
          description: `\u06AF\u0632\u0627\u0631\u0634 \u0647\u0641\u062A\u06AF\u06CC \u067E\u0631\u0648\u0698\u0647 ${project?.title || ""} \u0628\u0647 \u0634\u0645\u0627 \u0627\u0631\u062C\u0627\u0639 \u062F\u0627\u062F\u0647 \u0634\u062F`,
          severity: "medium",
          status: "open",
          assigneeId: referredTo
        });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/weekly-reports/:id", async (req, res) => {
    try {
      await db.delete(weeklyReports).where(eq3(weeklyReports.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/users", async (req, res) => {
    try {
      const { search, roleId, isActive } = req.query;
      const conditions = [];
      if (search) {
        conditions.push(
          or2(
            like2(users.firstName, `%${search}%`),
            like2(users.lastName, `%${search}%`),
            like2(users.username, `%${search}%`),
            like2(users.email, `%${search}%`)
          )
        );
      }
      if (roleId) conditions.push(eq3(users.roleId, roleId));
      if (isActive !== void 0) conditions.push(eq3(users.isActive, isActive === "true"));
      const allUsers = await db.select({
        id: users.id,
        username: users.username,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        phone: users.phone,
        roleId: users.roleId,
        isActive: users.isActive,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        roleDisplayName: roles.displayName,
        roleName: roles.name
      }).from(users).leftJoin(roles, eq3(users.roleId, roles.id)).where(conditions.length > 0 ? and(...conditions) : void 0);
      res.json(allUsers);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/users/:id", async (req, res) => {
    try {
      const result = await db.select({
        id: users.id,
        username: users.username,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        phone: users.phone,
        roleId: users.roleId,
        isActive: users.isActive,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        roleDisplayName: roles.displayName,
        roleName: roles.name
      }).from(users).leftJoin(roles, eq3(users.roleId, roles.id)).where(eq3(users.id, req.params.id));
      if (!result || result.length === 0) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(result[0]);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/users", async (req, res) => {
    try {
      const { password, role, ...userData } = req.body;
      const hashedPassword = await bcrypt.hash(password, 10);
      const [user] = await db.insert(users).values({
        ...userData,
        password: hashedPassword
      }).returning({
        id: users.id,
        username: users.username,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        phone: users.phone,
        roleId: users.roleId,
        isActive: users.isActive,
        createdAt: users.createdAt
      });
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/users/:id", async (req, res) => {
    try {
      const { password, role, ...userData } = req.body;
      const updateData = {
        ...userData,
        updatedAt: /* @__PURE__ */ new Date()
      };
      if (password) {
        updateData.password = await bcrypt.hash(password, 10);
      }
      const [user] = await db.update(users).set(updateData).where(eq3(users.id, req.params.id)).returning({
        id: users.id,
        username: users.username,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        phone: users.phone,
        roleId: users.roleId,
        isActive: users.isActive,
        updatedAt: users.updatedAt
      });
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/users/:id", async (req, res) => {
    try {
      await db.delete(users).where(eq3(users.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/users/:id/projects", async (req, res) => {
    try {
      const assignments = await db.select({
        id: userProjects.id,
        userId: userProjects.userId,
        projectId: userProjects.projectId,
        assignedAt: userProjects.assignedAt,
        projectTitle: projects.title,
        projectLocation: projects.location,
        projectStatus: projects.status
      }).from(userProjects).leftJoin(projects, eq3(userProjects.projectId, projects.id)).where(eq3(userProjects.userId, req.params.id));
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/users/:id/projects", async (req, res) => {
    try {
      const { projectId } = req.body;
      const [assignment] = await db.insert(userProjects).values({
        userId: req.params.id,
        projectId
      }).returning();
      res.json(assignment);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/users/:userId/projects/:projectId", async (req, res) => {
    try {
      await db.delete(userProjects).where(
        and(
          eq3(userProjects.userId, req.params.userId),
          eq3(userProjects.projectId, req.params.projectId)
        )
      );
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const result = await db.select({
        id: users.id,
        username: users.username,
        password: users.password,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        roleId: users.roleId,
        isActive: users.isActive,
        forcePasswordReset: users.forcePasswordReset,
        roleDisplayName: roles.displayName,
        roleName: roles.name
      }).from(users).leftJoin(roles, eq3(users.roleId, roles.id)).where(eq3(users.username, username));
      if (!result || result.length === 0) {
        return res.status(401).json({ message: "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u06CC\u0627 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A" });
      }
      const user = result[0];
      if (!user.isActive) {
        return res.status(403).json({ message: "\u062D\u0633\u0627\u0628 \u06A9\u0627\u0631\u0628\u0631\u06CC \u063A\u06CC\u0631\u0641\u0639\u0627\u0644 \u0627\u0633\u062A" });
      }
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u06CC\u0627 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A" });
      }
      res.json({
        id: user.id,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        roleId: user.roleId,
        role: user.roleName || "user",
        roleDisplayName: user.roleDisplayName,
        forcePasswordReset: user.forcePasswordReset || false
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { username, email } = req.body;
      const [user] = await db.select().from(users).where(
        and(
          eq3(users.username, username),
          eq3(users.email, email)
        )
      );
      if (!user) {
        return res.status(404).json({ message: "\u06A9\u0627\u0631\u0628\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      const resetToken = Math.random().toString(36).substring(2, 15);
      const resetTokenExpiry = new Date(Date.now() + 36e5);
      await db.update(users).set({
        resetToken,
        resetTokenExpiry
      }).where(eq3(users.id, user.id));
      res.json({ resetToken, message: "\u062A\u0648\u06A9\u0646 \u0631\u06CC\u0633\u062A \u0631\u0645\u0632 \u0627\u06CC\u062C\u0627\u062F \u0634\u062F" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/auth/confirm-reset", async (req, res) => {
    try {
      const { resetToken, newPassword } = req.body;
      const [user] = await db.select().from(users).where(eq3(users.resetToken, resetToken));
      if (!user || !user.resetTokenExpiry || user.resetTokenExpiry < /* @__PURE__ */ new Date()) {
        return res.status(400).json({ message: "\u062A\u0648\u06A9\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u06CC\u0627 \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A" });
      }
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await db.update(users).set({
        password: hashedPassword,
        resetToken: null,
        resetTokenExpiry: null
      }).where(eq3(users.id, user.id));
      res.json({ message: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062A\u063A\u06CC\u06CC\u0631 \u06CC\u0627\u0641\u062A" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/auth/change-password", async (req, res) => {
    try {
      const { userId, currentPassword, newPassword } = req.body;
      const [user] = await db.select().from(users).where(eq3(users.id, userId));
      if (!user) {
        return res.status(404).json({ message: "\u06A9\u0627\u0631\u0628\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0641\u0639\u0644\u06CC \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A" });
      }
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await db.update(users).set({
        password: hashedPassword,
        forcePasswordReset: false
      }).where(eq3(users.id, user.id));
      res.json({ message: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062A\u063A\u06CC\u06CC\u0631 \u06CC\u0627\u0641\u062A" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  const uploadDir = path2.join(process.cwd(), "uploads", "messages");
  if (!fs2.existsSync(uploadDir)) {
    fs2.mkdirSync(uploadDir, { recursive: true });
  }
  const storageConfig = multer.diskStorage({
    destination: (req, file, cb) => {
      const conversationId = req.params.conversationId || "temp";
      const messageId = req.body.messageId || "temp";
      const uploadPath = path2.join(uploadDir, conversationId, messageId);
      if (!fs2.existsSync(uploadPath)) {
        fs2.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, uniqueSuffix + "-" + file.originalname);
    }
  });
  const upload = multer({ storage: storageConfig });
  app2.get("/api/conversations", async (req, res) => {
    try {
      const { userId, projectId, type } = req.query;
      const conditions = [];
      if (type) conditions.push(eq3(conversations.type, type));
      if (projectId) conditions.push(eq3(conversations.projectId, projectId));
      let query = db.select().from(conversations);
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
      let allConversations = await query;
      if (userId) {
        const memberConversations = await db.select({ conversationId: conversationMembers.conversationId }).from(conversationMembers).where(eq3(conversationMembers.userId, userId));
        const conversationIds = memberConversations.map((m) => m.conversationId);
        allConversations = allConversations.filter((c) => conversationIds.includes(c.id));
      }
      res.json(allConversations);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/conversations", async (req, res) => {
    try {
      const { type, title, projectId, createdBy, memberIds } = req.body;
      const [conversation] = await db.insert(conversations).values({ type, title, projectId, createdBy }).returning();
      if (memberIds && Array.isArray(memberIds)) {
        for (const memberId of memberIds) {
          await db.insert(conversationMembers).values({ conversationId: conversation.id, userId: memberId });
        }
      }
      res.json(conversation);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/conversations/:id", async (req, res) => {
    try {
      const [conversation] = await db.select().from(conversations).where(eq3(conversations.id, req.params.id));
      if (!conversation) {
        return res.status(404).json({ message: "\u06AF\u0641\u062A\u06AF\u0648 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      const members = await db.select().from(conversationMembers).where(eq3(conversationMembers.conversationId, req.params.id));
      res.json({ ...conversation, members });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/conversations/:id", async (req, res) => {
    try {
      await db.delete(conversations).where(eq3(conversations.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/conversations/:conversationId/messages", async (req, res) => {
    try {
      const conversationId = req.params.conversationId;
      const limit = req.query.limit ? parseInt(req.query.limit) : 50;
      const allMessages = await db.select().from(messages).where(eq3(messages.conversationId, conversationId)).orderBy(desc(messages.createdAt)).limit(limit);
      const messageIds = allMessages.map((m) => m.id);
      const files = messageIds.length > 0 ? await db.select().from(messageFiles).where(sqlOperator2`${messageFiles.messageId} = ANY(${messageIds})`) : [];
      const reads = messageIds.length > 0 ? await db.select().from(messageReads).where(sqlOperator2`${messageReads.messageId} = ANY(${messageIds})`) : [];
      const messagesWithFiles = allMessages.map((msg) => ({
        ...msg,
        files: files.filter((f) => f.messageId === msg.id),
        reads: reads.filter((r) => r.messageId === msg.id)
      }));
      res.json(messagesWithFiles.reverse());
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/conversations/:conversationId/messages", upload.array("files", 5), async (req, res) => {
    try {
      const { conversationId } = req.params;
      const { senderId, content } = req.body;
      const [message] = await db.insert(messages).values({ conversationId, senderId, content }).returning();
      if (req.files && Array.isArray(req.files)) {
        const messageId = message.id;
        const uploadPath = path2.join(uploadDir, conversationId, messageId);
        if (!fs2.existsSync(uploadPath)) {
          fs2.mkdirSync(uploadPath, { recursive: true });
        }
        for (const file of req.files) {
          const newPath = path2.join(uploadPath, file.filename);
          fs2.renameSync(file.path, newPath);
          await db.insert(messageFiles).values({
            messageId,
            filename: file.filename,
            originalName: file.originalname,
            mimeType: file.mimetype,
            size: file.size,
            path: `/uploads/messages/${conversationId}/${messageId}/${file.filename}`
          });
        }
      }
      const files = await db.select().from(messageFiles).where(eq3(messageFiles.messageId, message.id));
      res.json({ ...message, files, reads: [] });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/messages/:messageId/read", async (req, res) => {
    try {
      const { messageId } = req.params;
      const { userId } = req.body;
      const existing = await db.select().from(messageReads).where(and(
        eq3(messageReads.messageId, messageId),
        eq3(messageReads.userId, userId)
      ));
      if (existing.length === 0) {
        const [read] = await db.insert(messageReads).values({ messageId, userId }).returning();
        res.json(read);
      } else {
        res.json(existing[0]);
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/messages/search", async (req, res) => {
    try {
      const { userId, projectId, query: searchQuery } = req.query;
      let conversationIds = [];
      if (userId) {
        const userConversations = await db.select({ conversationId: conversationMembers.conversationId }).from(conversationMembers).where(eq3(conversationMembers.userId, userId));
        conversationIds = userConversations.map((c) => c.conversationId);
      }
      if (projectId) {
        const projectConversations = await db.select({ id: conversations.id }).from(conversations).where(eq3(conversations.projectId, projectId));
        const projectConvIds = projectConversations.map((c) => c.id);
        if (conversationIds.length > 0) {
          conversationIds = conversationIds.filter((id) => projectConvIds.includes(id));
        } else {
          conversationIds = projectConvIds;
        }
      }
      let query = db.select().from(messages);
      const conditions = [];
      if (conversationIds.length > 0) {
        conditions.push(sqlOperator2`${messages.conversationId} = ANY(${conversationIds})`);
      }
      if (searchQuery) {
        conditions.push(like2(messages.content, `%${searchQuery}%`));
      }
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
      const results = await query.orderBy(desc(messages.createdAt)).limit(50);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/roles", async (req, res) => {
    try {
      const allRoles = await db.select().from(roles);
      res.json(allRoles);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/roles/:id", async (req, res) => {
    try {
      const [role] = await db.select().from(roles).where(eq3(roles.id, req.params.id));
      if (!role) {
        return res.status(404).json({ message: "\u0646\u0642\u0634 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      const rolePerms = await db.select().from(rolePermissions).innerJoin(permissions, eq3(rolePermissions.permissionId, permissions.id)).where(eq3(rolePermissions.roleId, req.params.id));
      res.json({ ...role, permissions: rolePerms.map((rp) => rp.permissions) });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/roles", async (req, res) => {
    try {
      const { name, displayName, description, permissionIds } = req.body;
      const [role] = await db.insert(roles).values({ name, displayName, description }).returning();
      if (permissionIds && permissionIds.length > 0) {
        await db.insert(rolePermissions).values(
          permissionIds.map((permId) => ({ roleId: role.id, permissionId: permId }))
        );
      }
      res.json(role);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/roles/:id", async (req, res) => {
    try {
      const { name, displayName, description, permissionIds } = req.body;
      const [role] = await db.update(roles).set({ name, displayName, description, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(roles.id, req.params.id)).returning();
      if (permissionIds !== void 0) {
        await db.delete(rolePermissions).where(eq3(rolePermissions.roleId, req.params.id));
        if (permissionIds.length > 0) {
          await db.insert(rolePermissions).values(
            permissionIds.map((permId) => ({ roleId: req.params.id, permissionId: permId }))
          );
        }
      }
      res.json(role);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/roles/:id", async (req, res) => {
    try {
      const [role] = await db.select().from(roles).where(eq3(roles.id, req.params.id));
      if (role?.isSystem) {
        return res.status(400).json({ message: "\u0646\u0642\u0634 \u0633\u06CC\u0633\u062A\u0645\u06CC \u0642\u0627\u0628\u0644 \u062D\u0630\u0641 \u0646\u06CC\u0633\u062A" });
      }
      await db.delete(roles).where(eq3(roles.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/permissions", async (req, res) => {
    try {
      const allPermissions = await db.select().from(permissions);
      res.json(allPermissions);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/permissions", async (req, res) => {
    try {
      const [permission] = await db.insert(permissions).values(req.body).returning();
      res.json(permission);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/permissions/:id", async (req, res) => {
    try {
      const [permission] = await db.update(permissions).set(req.body).where(eq3(permissions.id, req.params.id)).returning();
      res.json(permission);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/permissions/:id", async (req, res) => {
    try {
      await db.delete(permissions).where(eq3(permissions.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  const avatarStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const avatarDir = path2.join(process.cwd(), "uploads", "avatars");
      if (!fs2.existsSync(avatarDir)) {
        fs2.mkdirSync(avatarDir, { recursive: true });
      }
      cb(null, avatarDir);
    },
    filename: (req, file, cb) => {
      const ext = path2.extname(file.originalname);
      const filename = `avatar-${Date.now()}${ext}`;
      cb(null, filename);
    }
  });
  const avatarUpload = multer({
    storage: avatarStorage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
      const allowedTypes = /jpeg|jpg|png|gif/;
      const extname = allowedTypes.test(path2.extname(file.originalname).toLowerCase());
      const mimetype = allowedTypes.test(file.mimetype);
      if (extname && mimetype) {
        cb(null, true);
      } else {
        cb(new Error("\u0641\u0642\u0637 \u0641\u0627\u06CC\u0644\u200C\u0647\u0627\u06CC \u062A\u0635\u0648\u06CC\u0631\u06CC \u0645\u062C\u0627\u0632 \u0647\u0633\u062A\u0646\u062F"));
      }
    }
  });
  app2.get("/api/profile/:userId", async (req, res) => {
    try {
      const [user] = await db.select({
        id: users.id,
        username: users.username,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        phone: users.phone,
        role: users.role,
        roleId: users.roleId,
        isActive: users.isActive,
        avatarPath: users.avatarPath,
        createdAt: users.createdAt
      }).from(users).where(eq3(users.id, req.params.userId));
      if (!user) {
        return res.status(404).json({ message: "\u06A9\u0627\u0631\u0628\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      const userProj = await db.select().from(userProjects).innerJoin(projects, eq3(userProjects.projectId, projects.id)).where(eq3(userProjects.userId, req.params.userId));
      const roleInfo = user.roleId ? await db.select().from(roles).where(eq3(roles.id, user.roleId)) : [];
      res.json({
        ...user,
        projects: userProj.map((up) => up.projects),
        roleInfo: roleInfo[0] || null
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/profile/:userId", async (req, res) => {
    try {
      const { firstName, lastName, email, phone } = req.body;
      const [updatedUser] = await db.update(users).set({ firstName, lastName, email, phone, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(users.id, req.params.userId)).returning();
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/profile/:userId/avatar", avatarUpload.single("avatar"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "\u0641\u0627\u06CC\u0644 \u062A\u0635\u0648\u06CC\u0631 \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A" });
      }
      const avatarPath = `/uploads/avatars/${req.file.filename}`;
      const [user] = await db.select().from(users).where(eq3(users.id, req.params.userId));
      if (user?.avatarPath) {
        const oldAvatarPath = path2.join(process.cwd(), user.avatarPath);
        if (fs2.existsSync(oldAvatarPath)) {
          fs2.unlinkSync(oldAvatarPath);
        }
      }
      const [updatedUser] = await db.update(users).set({ avatarPath, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(users.id, req.params.userId)).returning();
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/profile/:userId/change-password", async (req, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      const [user] = await db.select().from(users).where(eq3(users.id, req.params.userId));
      if (!user) {
        return res.status(404).json({ message: "\u06A9\u0627\u0631\u0628\u0631 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" });
      }
      const isValid = await bcrypt.compare(currentPassword, user.password);
      if (!isValid) {
        return res.status(400).json({ message: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0641\u0639\u0644\u06CC \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A" });
      }
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await db.update(users).set({ password: hashedPassword, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(users.id, req.params.userId));
      res.json({ success: true, message: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062A\u063A\u06CC\u06CC\u0631 \u06CC\u0627\u0641\u062A" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/users/:userId/permissions", async (req, res) => {
    try {
      const [user] = await db.select().from(users).where(eq3(users.id, req.params.userId));
      if (!user || !user.roleId) {
        return res.json([]);
      }
      const userPermissions = await db.select().from(rolePermissions).innerJoin(permissions, eq3(rolePermissions.permissionId, permissions.id)).where(eq3(rolePermissions.roleId, user.roleId));
      res.json(userPermissions.map((up) => up.permissions));
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/ai-assistant/chat", async (req, res) => {
    try {
      const { message, projectId } = req.body;
      if (!message) {
        return res.status(400).json({ message: "\u067E\u06CC\u0627\u0645 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A" });
      }
      const response = await chatWithAssistant(message, projectId);
      res.json({ response });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/tasks", async (req, res) => {
    try {
      const userId = req.query.userId;
      const category = req.query.category;
      let query = db.select().from(tasks);
      const conditions = [];
      if (userId) conditions.push(eq3(tasks.userId, userId));
      if (category) conditions.push(eq3(tasks.category, category));
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
      const allTasks = await query.orderBy(desc(tasks.createdAt));
      res.json(allTasks);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/tasks", async (req, res) => {
    try {
      const [task] = await db.insert(tasks).values(req.body).returning();
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/tasks/:id", async (req, res) => {
    try {
      const [task] = await db.update(tasks).set({ ...req.body, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(tasks.id, req.params.id)).returning();
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.patch("/api/tasks/:id", async (req, res) => {
    try {
      const updateData = { ...req.body, updatedAt: /* @__PURE__ */ new Date() };
      if (req.body.isCompleted === true) {
        updateData.completedAt = /* @__PURE__ */ new Date();
      } else if (req.body.isCompleted === false) {
        updateData.completedAt = null;
      }
      const [task] = await db.update(tasks).set(updateData).where(eq3(tasks.id, req.params.id)).returning();
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/tasks/:id", async (req, res) => {
    try {
      await db.delete(tasks).where(eq3(tasks.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/daily-notes", async (req, res) => {
    try {
      const userId = req.query.userId;
      const noteDate = req.query.noteDate;
      let query = db.select().from(dailyNotes);
      const conditions = [];
      if (userId) conditions.push(eq3(dailyNotes.userId, userId));
      if (noteDate) conditions.push(eq3(dailyNotes.noteDate, noteDate));
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
      const notes = await query.orderBy(desc(dailyNotes.createdAt));
      res.json(notes);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/daily-notes", async (req, res) => {
    try {
      const { userId, noteDate, content } = req.body;
      const [existing] = await db.select().from(dailyNotes).where(and(
        eq3(dailyNotes.userId, userId),
        eq3(dailyNotes.noteDate, noteDate)
      ));
      if (existing) {
        const [note2] = await db.update(dailyNotes).set({ content, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(dailyNotes.id, existing.id)).returning();
        return res.json(note2);
      }
      const [note] = await db.insert(dailyNotes).values(req.body).returning();
      res.json(note);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/daily-notes/:id", async (req, res) => {
    try {
      await db.delete(dailyNotes).where(eq3(dailyNotes.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/follow-up-tasks", async (req, res) => {
    try {
      const fromUserId = req.query.fromUserId;
      const toUserId = req.query.toUserId;
      let query = db.select({
        task: followUpTasks,
        fromUser: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName
        },
        toUser: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName
        }
      }).from(followUpTasks).leftJoin(users, eq3(followUpTasks.fromUserId, users.id));
      const conditions = [];
      if (fromUserId) conditions.push(eq3(followUpTasks.fromUserId, fromUserId));
      if (toUserId) conditions.push(eq3(followUpTasks.toUserId, toUserId));
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
      const followUpTasksList = await query.orderBy(desc(followUpTasks.createdAt));
      res.json(followUpTasksList);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/follow-up-tasks", async (req, res) => {
    try {
      const [task] = await db.insert(followUpTasks).values(req.body).returning();
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/follow-up-tasks/:id", async (req, res) => {
    try {
      const [task] = await db.update(followUpTasks).set({ ...req.body, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(followUpTasks.id, req.params.id)).returning();
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.patch("/api/follow-up-tasks/:id/confirm", async (req, res) => {
    try {
      const [task] = await db.update(followUpTasks).set({
        isConfirmed: true,
        confirmedAt: /* @__PURE__ */ new Date(),
        status: "completed",
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq3(followUpTasks.id, req.params.id)).returning();
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/follow-up-tasks/:id", async (req, res) => {
    try {
      await db.delete(followUpTasks).where(eq3(followUpTasks.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  const tasksUploadDir = path2.join(process.cwd(), "uploads", "tasks");
  if (!fs2.existsSync(tasksUploadDir)) {
    fs2.mkdirSync(tasksUploadDir, { recursive: true });
  }
  const tasksStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, tasksUploadDir);
    },
    filename: (req, file, cb) => {
      const timestamp2 = Date.now();
      const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
      cb(null, `${timestamp2}_${sanitizedName}`);
    }
  });
  const tasksUpload = multer({
    storage: tasksStorage,
    limits: { fileSize: 10 * 1024 * 1024 }
  });
  app2.post("/api/tasks/with-attachment", tasksUpload.single("file"), async (req, res) => {
    try {
      const file = req.file;
      const taskData = JSON.parse(req.body.taskData);
      const [task] = await db.insert(tasks).values(taskData).returning();
      if (file) {
        await db.insert(taskAttachments).values({
          taskId: task.id,
          fileName: file.filename,
          filePath: file.path,
          fileType: file.mimetype
        });
      }
      if (taskData.assigneeId && taskData.assigneeId !== taskData.userId) {
        await db.insert(letters).values({
          fromUserId: taskData.userId,
          subject: `\u0648\u0638\u06CC\u0641\u0647 \u062C\u062F\u06CC\u062F: ${taskData.title}`,
          content: `\u06CC\u06A9 \u0648\u0638\u06CC\u0641\u0647 \u062C\u062F\u06CC\u062F \u0628\u0647 \u0634\u0645\u0627 \u0627\u062E\u062A\u0635\u0627\u0635 \u062F\u0627\u062F\u0647 \u0634\u062F:

${taskData.description || ""}`,
          projectId: taskData.projectId || null
        }).returning().then(async ([letter]) => {
          await db.insert(letterRecipients).values({
            letterId: letter.id,
            userId: taskData.assigneeId
          });
        });
      }
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/tasks/:id/attachments", async (req, res) => {
    try {
      const attachments = await db.select().from(taskAttachments).where(eq3(taskAttachments.taskId, req.params.id));
      res.json(attachments);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.patch("/api/tasks/:id/confirm", async (req, res) => {
    try {
      const { confirmed } = req.body;
      const [task] = await db.update(tasks).set({
        isConfirmed: confirmed,
        confirmedAt: confirmed ? /* @__PURE__ */ new Date() : null,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq3(tasks.id, req.params.id)).returning();
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/tasks/by-project/:projectId", async (req, res) => {
    try {
      const projectTasks = await db.select().from(tasks).where(eq3(tasks.projectId, req.params.projectId));
      const total = projectTasks.length;
      const completed = projectTasks.filter((t) => t.isCompleted).length;
      const pending = total - completed;
      res.json({ tasks: projectTasks, stats: { total, completed, pending } });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/sticky-notes", async (req, res) => {
    try {
      const userId = req.query.userId;
      let query = db.select().from(stickyNotes);
      if (userId) {
        query = query.where(eq3(stickyNotes.userId, userId));
      }
      const notes = await query.orderBy(desc(stickyNotes.createdAt));
      res.json(notes);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/sticky-notes", async (req, res) => {
    try {
      const [note] = await db.insert(stickyNotes).values(req.body).returning();
      res.json(note);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/sticky-notes/:id", async (req, res) => {
    try {
      const [note] = await db.update(stickyNotes).set({ ...req.body, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(stickyNotes.id, req.params.id)).returning();
      res.json(note);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/sticky-notes/:id", async (req, res) => {
    try {
      await db.delete(stickyNotes).where(eq3(stickyNotes.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/sticky-notes/:id/items", async (req, res) => {
    try {
      const items = await db.select().from(stickyNoteItems).where(eq3(stickyNoteItems.noteId, req.params.id)).orderBy(stickyNoteItems.orderIndex);
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/sticky-notes/:id/items", async (req, res) => {
    try {
      const [item] = await db.insert(stickyNoteItems).values({
        noteId: req.params.id,
        ...req.body
      }).returning();
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.patch("/api/sticky-notes/items/:id", async (req, res) => {
    try {
      const [item] = await db.update(stickyNoteItems).set(req.body).where(eq3(stickyNoteItems.id, req.params.id)).returning();
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/sticky-notes/items/:id", async (req, res) => {
    try {
      await db.delete(stickyNoteItems).where(eq3(stickyNoteItems.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  const lettersUploadDir = path2.join(process.cwd(), "uploads", "letters");
  if (!fs2.existsSync(lettersUploadDir)) {
    fs2.mkdirSync(lettersUploadDir, { recursive: true });
  }
  const lettersStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, lettersUploadDir);
    },
    filename: (req, file, cb) => {
      const timestamp2 = Date.now();
      const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
      cb(null, `${timestamp2}_${sanitizedName}`);
    }
  });
  const lettersUpload = multer({
    storage: lettersStorage,
    limits: { fileSize: 10 * 1024 * 1024 }
  });
  app2.get("/api/letters/inbox/:userId", async (req, res) => {
    try {
      const inboxLetters = await db.select({
        letter: letters,
        sender: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName
        },
        recipient: letterRecipients
      }).from(letterRecipients).innerJoin(letters, eq3(letterRecipients.letterId, letters.id)).leftJoin(users, eq3(letters.fromUserId, users.id)).where(eq3(letterRecipients.userId, req.params.userId)).orderBy(desc(letters.createdAt));
      res.json(inboxLetters);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/letters/outbox/:userId", async (req, res) => {
    try {
      const outboxLetters = await db.select().from(letters).where(eq3(letters.fromUserId, req.params.userId)).orderBy(desc(letters.createdAt));
      res.json(outboxLetters);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/letters/project/:projectId", async (req, res) => {
    try {
      const projectLetters = await db.select().from(letters).where(eq3(letters.projectId, req.params.projectId)).orderBy(desc(letters.createdAt));
      res.json(projectLetters);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/letters", lettersUpload.array("files", 5), async (req, res) => {
    try {
      const files = req.files || [];
      const { fromUserId, recipientIds, subject, content, projectId } = req.body;
      const [letter] = await db.insert(letters).values({
        fromUserId,
        subject,
        content,
        projectId: projectId || null
      }).returning();
      const recipientList = JSON.parse(recipientIds);
      for (const recipientId of recipientList) {
        await db.insert(letterRecipients).values({
          letterId: letter.id,
          userId: recipientId
        });
      }
      if (files.length > 0) {
        for (const file of files) {
          await db.insert(letterAttachments).values({
            letterId: letter.id,
            fileName: file.filename,
            filePath: file.path,
            fileType: file.mimetype
          });
        }
      }
      res.json(letter);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.patch("/api/letters/:id/read", async (req, res) => {
    try {
      const { userId } = req.body;
      await db.update(letterRecipients).set({ isRead: true, readAt: /* @__PURE__ */ new Date() }).where(and(
        eq3(letterRecipients.letterId, req.params.id),
        eq3(letterRecipients.userId, userId)
      ));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/calendar-notes", async (req, res) => {
    try {
      const userId = req.query.userId;
      const date = req.query.date;
      let query = db.select().from(calendarNotes);
      const conditions = [];
      if (userId) conditions.push(eq3(calendarNotes.userId, userId));
      if (date) conditions.push(eq3(calendarNotes.date, date));
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
      const notes = await query.orderBy(desc(calendarNotes.createdAt));
      res.json(notes);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/calendar-notes", async (req, res) => {
    try {
      const { userId, date, content } = req.body;
      const [existing] = await db.select().from(calendarNotes).where(and(
        eq3(calendarNotes.userId, userId),
        eq3(calendarNotes.date, date)
      ));
      if (existing) {
        const [note2] = await db.update(calendarNotes).set({ content, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(calendarNotes.id, existing.id)).returning();
        return res.json(note2);
      }
      const [note] = await db.insert(calendarNotes).values(req.body).returning();
      res.json(note);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/calendar-notes/:id", async (req, res) => {
    try {
      await db.delete(calendarNotes).where(eq3(calendarNotes.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/admin/import-projects", async (req, res) => {
    try {
      if (process.env.NODE_ENV !== "development") {
        return res.status(403).json({ message: "\u0627\u06CC\u0646 \u0639\u0645\u0644\u06CC\u0627\u062A \u0641\u0642\u0637 \u062F\u0631 \u0645\u062D\u06CC\u0637 \u062A\u0648\u0633\u0639\u0647 \u0645\u062C\u0627\u0632 \u0627\u0633\u062A" });
      }
      console.log("\u{1F680} \u0634\u0631\u0648\u0639 import \u062E\u0648\u062F\u06A9\u0627\u0631 \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627...");
      const importModule = await import("./import-real-projects.js");
      await new Promise((resolve) => setTimeout(resolve, 1e3));
      const projectCount = await db.select().from(projects);
      res.json({
        success: true,
        message: "\u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0648\u0627\u0631\u062F \u0634\u062F\u0646\u062F",
        projectCount: projectCount.length
      });
    } catch (error) {
      console.error("\u274C \u062E\u0637\u0627 \u062F\u0631 import \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627:", error);
      res.status(500).json({ message: error.message });
    }
  });
  const staticUploadPath = path2.join(process.cwd(), "uploads");
  if (!fs2.existsSync(staticUploadPath)) {
    fs2.mkdirSync(staticUploadPath, { recursive: true });
  }
  app2.use("/uploads", express.static(staticUploadPath));
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express2 from "express";
import fs3 from "fs";
import path4 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path3 from "path";
var vite_config_default = defineConfig({
  plugins: [
    react()
  ],
  resolve: {
    alias: {
      "@": path3.resolve(import.meta.dirname, "client", "src"),
      "@shared": path3.resolve(import.meta.dirname, "shared"),
      "@assets": path3.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path3.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path3.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    strictPort: false,
    allowedHosts: true,
    hmr: {
      clientPort: 443,
      timeout: 12e4,
      overlay: false
    },
    fs: {
      strict: true,
      deny: ["**/.*"]
    },
    watch: {
      usePolling: true,
      interval: 500
    }
  }
});

// server/vite.ts
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: viteLogger,
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path4.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs3.promises.readFile(clientTemplate, "utf-8");
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path4.resolve(import.meta.dirname, "public");
  if (!fs3.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express2.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path4.resolve(distPath, "index.html"));
  });
}

// server/auto-alerts.ts
import { eq as eq4, and as and2 } from "drizzle-orm";
async function checkAndCreateAutoAlerts() {
  console.log("\u{1F50D} \u0628\u0631\u0631\u0633\u06CC \u0648 \u0627\u06CC\u062C\u0627\u062F \u0647\u0634\u062F\u0627\u0631\u0647\u0627\u06CC \u062E\u0648\u062F\u06A9\u0627\u0631...");
  try {
    await checkTenderDeadlines();
    await checkProjectProgress();
    console.log("\u2705 \u0628\u0631\u0631\u0633\u06CC \u0647\u0634\u062F\u0627\u0631\u0647\u0627\u06CC \u062E\u0648\u062F\u06A9\u0627\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0646\u062C\u0627\u0645 \u0634\u062F");
  } catch (error) {
    console.error("\u274C \u062E\u0637\u0627 \u062F\u0631 \u0627\u06CC\u062C\u0627\u062F \u0647\u0634\u062F\u0627\u0631\u0647\u0627\u06CC \u062E\u0648\u062F\u06A9\u0627\u0631:", error);
  }
}
async function checkTenderDeadlines() {
  const now = /* @__PURE__ */ new Date();
  const twoDaysFromNow = new Date(now.getTime() + 2 * 24 * 60 * 60 * 1e3);
  const allTenders = await db.select().from(tenders);
  for (const tender of allTenders) {
    if (!tender.deadlineDate || tender.status === "\u0628\u0633\u062A\u0647 \u0634\u062F\u0647") continue;
    const deadline = new Date(tender.deadlineDate);
    if (deadline < now && tender.status !== "\u0645\u0647\u0644\u062A \u06AF\u0630\u0634\u062A\u0647") {
      const existingAlert = await db.select().from(alerts).where(
        and2(
          eq4(alerts.entityType, "tender"),
          eq4(alerts.entityId, tender.id),
          eq4(alerts.status, "open")
        )
      ).limit(1);
      if (existingAlert.length === 0) {
        await db.insert(alerts).values({
          title: `\u0645\u0647\u0644\u062A \u0645\u0646\u0627\u0642\u0635\u0647 "${tender.title}" \u06AF\u0630\u0634\u062A\u0647 \u0627\u0633\u062A`,
          description: `\u0645\u0646\u0627\u0642\u0635\u0647 "${tender.title}" \u062F\u0631 \u062A\u0627\u0631\u06CC\u062E ${tender.deadlineDate} \u0628\u0647 \u067E\u0627\u06CC\u0627\u0646 \u0631\u0633\u06CC\u062F\u0647 \u0648 \u0646\u06CC\u0627\u0632 \u0628\u0647 \u0628\u0631\u0631\u0633\u06CC \u062F\u0627\u0631\u062F.`,
          severity: "high",
          status: "open",
          entityType: "tender",
          entityId: tender.id
        });
        console.log(`\u26A0\uFE0F  \u0647\u0634\u062F\u0627\u0631: \u0645\u0647\u0644\u062A \u0645\u0646\u0627\u0642\u0635\u0647 "${tender.title}" \u06AF\u0630\u0634\u062A\u0647 \u0627\u0633\u062A`);
      }
    } else if (deadline > now && deadline <= twoDaysFromNow && tender.status !== "\u0645\u0647\u0644\u062A \u0646\u0632\u062F\u06CC\u06A9") {
      const existingAlert = await db.select().from(alerts).where(
        and2(
          eq4(alerts.entityType, "tender"),
          eq4(alerts.entityId, tender.id),
          eq4(alerts.title, `\u0645\u0647\u0644\u062A \u0645\u0646\u0627\u0642\u0635\u0647 "${tender.title}" \u0646\u0632\u062F\u06CC\u06A9 \u0627\u0633\u062A`)
        )
      ).limit(1);
      if (existingAlert.length === 0) {
        const hoursLeft = Math.floor((deadline.getTime() - now.getTime()) / (1e3 * 60 * 60));
        await db.insert(alerts).values({
          title: `\u0645\u0647\u0644\u062A \u0645\u0646\u0627\u0642\u0635\u0647 "${tender.title}" \u0646\u0632\u062F\u06CC\u06A9 \u0627\u0633\u062A`,
          description: `${hoursLeft} \u0633\u0627\u0639\u062A \u062A\u0627 \u067E\u0627\u06CC\u0627\u0646 \u0645\u0647\u0644\u062A \u0645\u0646\u0627\u0642\u0635\u0647 "${tender.title}" \u0628\u0627\u0642\u06CC \u0645\u0627\u0646\u062F\u0647 \u0627\u0633\u062A.`,
          severity: "medium",
          status: "open",
          entityType: "tender",
          entityId: tender.id
        });
        console.log(`\u{1F514} \u0647\u0634\u062F\u0627\u0631: \u0645\u0647\u0644\u062A \u0645\u0646\u0627\u0642\u0635\u0647 "${tender.title}" \u0646\u0632\u062F\u06CC\u06A9 \u0627\u0633\u062A (${hoursLeft} \u0633\u0627\u0639\u062A)`);
      }
    }
  }
}
async function checkProjectProgress() {
  const allProjects = await db.select().from(projects);
  for (const project of allProjects) {
    if (project.status !== "active") continue;
    const progress = project.progress || 0;
    if (progress < 50) {
      const existingAlert = await db.select().from(alerts).where(
        and2(
          eq4(alerts.projectId, project.id),
          eq4(alerts.entityType, "project_progress"),
          eq4(alerts.status, "open")
        )
      ).limit(1);
      if (existingAlert.length === 0) {
        await db.insert(alerts).values({
          projectId: project.id,
          title: `\u067E\u06CC\u0634\u0631\u0641\u062A \u067E\u0631\u0648\u0698\u0647 "${project.title}" \u06A9\u0645\u062A\u0631 \u0627\u0632 \u06F5\u06F0\u066A \u0627\u0633\u062A`,
          description: `\u067E\u0631\u0648\u0698\u0647 "${project.title}" \u062F\u0627\u0631\u0627\u06CC ${progress}\u066A \u067E\u06CC\u0634\u0631\u0641\u062A \u0627\u0633\u062A \u0648 \u0646\u06CC\u0627\u0632 \u0628\u0647 \u0628\u0631\u0631\u0633\u06CC \u0648 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u062F\u0627\u0631\u062F.`,
          severity: "low",
          status: "open",
          entityType: "project_progress",
          entityId: project.id
        });
        console.log(`\u{1F4CA} \u0647\u0634\u062F\u0627\u0631: \u067E\u06CC\u0634\u0631\u0641\u062A \u067E\u0631\u0648\u0698\u0647 "${project.title}" \u06A9\u0645 \u0627\u0633\u062A (${progress}%)`);
      }
    }
  }
}
function startAutoAlertScheduler() {
  checkAndCreateAutoAlerts();
  const intervalMs = 60 * 60 * 1e3;
  setInterval(() => {
    checkAndCreateAutoAlerts();
  }, intervalMs);
  console.log(`\u23F0 \u0633\u06CC\u0633\u062A\u0645 \u0647\u0634\u062F\u0627\u0631\u0647\u0627\u06CC \u062E\u0648\u062F\u06A9\u0627\u0631 \u0631\u0627\u0647\u200C\u0627\u0646\u062F\u0627\u0632\u06CC \u0634\u062F (\u0647\u0631 ${intervalMs / 1e3 / 60} \u062F\u0642\u06CC\u0642\u0647)`);
}

// server/init-permissions.ts
import { eq as eq5 } from "drizzle-orm";
import bcrypt2 from "bcryptjs";
var defaultPermissions = [
  // Projects
  { key: "projects.view", displayName: "\u0645\u0634\u0627\u0647\u062F\u0647 \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627", description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u0645\u0634\u0627\u0647\u062F\u0647 \u0644\u06CC\u0633\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627", category: "projects" },
  { key: "projects.create", displayName: "\u0627\u06CC\u062C\u0627\u062F \u067E\u0631\u0648\u0698\u0647", description: "\u0627\u06CC\u062C\u0627\u062F \u067E\u0631\u0648\u0698\u0647 \u062C\u062F\u06CC\u062F", category: "projects" },
  { key: "projects.edit", displayName: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u067E\u0631\u0648\u0698\u0647", description: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u067E\u0631\u0648\u0698\u0647", category: "projects" },
  { key: "projects.delete", displayName: "\u062D\u0630\u0641 \u067E\u0631\u0648\u0698\u0647", description: "\u062D\u0630\u0641 \u067E\u0631\u0648\u0698\u0647", category: "projects" },
  // Reports
  { key: "reports.view", displayName: "\u0645\u0634\u0627\u0647\u062F\u0647 \u06AF\u0632\u0627\u0631\u0634\u200C\u0647\u0627", description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u0645\u0634\u0627\u0647\u062F\u0647 \u06AF\u0632\u0627\u0631\u0634\u200C\u0647\u0627", category: "reports" },
  { key: "reports.create", displayName: "\u062B\u0628\u062A \u06AF\u0632\u0627\u0631\u0634", description: "\u062B\u0628\u062A \u06AF\u0632\u0627\u0631\u0634 \u0631\u0648\u0632\u0627\u0646\u0647", category: "reports" },
  { key: "reports.edit", displayName: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u06AF\u0632\u0627\u0631\u0634", description: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u06AF\u0632\u0627\u0631\u0634\u200C\u0647\u0627", category: "reports" },
  // Bitumen
  { key: "bitumen.view", displayName: "\u0645\u0634\u0627\u0647\u062F\u0647 \u0642\u06CC\u0631", description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u0628\u062E\u0634 \u0642\u06CC\u0631", category: "bitumen" },
  { key: "bitumen.create", displayName: "\u062B\u0628\u062A \u0642\u06CC\u0631", description: "\u062B\u0628\u062A \u0631\u06A9\u0648\u0631\u062F \u0642\u06CC\u0631", category: "bitumen" },
  { key: "bitumen.edit", displayName: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0642\u06CC\u0631", description: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0631\u06A9\u0648\u0631\u062F\u0647\u0627\u06CC \u0642\u06CC\u0631", category: "bitumen" },
  { key: "bitumen.delete", displayName: "\u062D\u0630\u0641 \u0642\u06CC\u0631", description: "\u062D\u0630\u0641 \u0631\u06A9\u0648\u0631\u062F\u0647\u0627\u06CC \u0642\u06CC\u0631", category: "bitumen" },
  // Sheets (Lab Sheets)
  { key: "sheets.view", displayName: "\u0645\u0634\u0627\u0647\u062F\u0647 \u0628\u0631\u06AF\u0647\u200C\u0647\u0627\u06CC \u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647", description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u0628\u0631\u06AF\u0647\u200C\u0647\u0627\u06CC \u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647", category: "sheets" },
  { key: "sheets.create", displayName: "\u062B\u0628\u062A \u0628\u0631\u06AF\u0647 \u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647", description: "\u062B\u0628\u062A \u0628\u0631\u06AF\u0647 \u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647 \u062C\u062F\u06CC\u062F", category: "sheets" },
  { key: "sheets.edit", displayName: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0628\u0631\u06AF\u0647 \u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647", description: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0628\u0631\u06AF\u0647\u200C\u0647\u0627\u06CC \u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647", category: "sheets" },
  { key: "sheets.delete", displayName: "\u062D\u0630\u0641 \u0628\u0631\u06AF\u0647 \u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647", description: "\u062D\u0630\u0641 \u0628\u0631\u06AF\u0647\u200C\u0647\u0627\u06CC \u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647", category: "sheets" },
  // Tenders
  { key: "tenders.view", displayName: "\u0645\u0634\u0627\u0647\u062F\u0647 \u0645\u0646\u0627\u0642\u0635\u0627\u062A", description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u0645\u0646\u0627\u0642\u0635\u0627\u062A", category: "tenders" },
  { key: "tenders.create", displayName: "\u062B\u0628\u062A \u0645\u0646\u0627\u0642\u0635\u0647", description: "\u062B\u0628\u062A \u0645\u0646\u0627\u0642\u0635\u0647 \u062C\u062F\u06CC\u062F", category: "tenders" },
  { key: "tenders.edit", displayName: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0645\u0646\u0627\u0642\u0635\u0647", description: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0645\u0646\u0627\u0642\u0635\u0627\u062A", category: "tenders" },
  { key: "tenders.delete", displayName: "\u062D\u0630\u0641 \u0645\u0646\u0627\u0642\u0635\u0647", description: "\u062D\u0630\u0641 \u0645\u0646\u0627\u0642\u0635\u0627\u062A", category: "tenders" },
  // Alerts
  { key: "alerts.view", displayName: "\u0645\u0634\u0627\u0647\u062F\u0647 \u0647\u0634\u062F\u0627\u0631\u0647\u0627", description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u0647\u0634\u062F\u0627\u0631\u0647\u0627", category: "alerts" },
  { key: "alerts.create", displayName: "\u0627\u06CC\u062C\u0627\u062F \u0647\u0634\u062F\u0627\u0631", description: "\u0627\u06CC\u062C\u0627\u062F \u0647\u0634\u062F\u0627\u0631 \u062C\u062F\u06CC\u062F", category: "alerts" },
  { key: "alerts.edit", displayName: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0647\u0634\u062F\u0627\u0631", description: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0647\u0634\u062F\u0627\u0631\u0647\u0627", category: "alerts" },
  { key: "alerts.delete", displayName: "\u062D\u0630\u0641 \u0647\u0634\u062F\u0627\u0631", description: "\u062D\u0630\u0641 \u0647\u0634\u062F\u0627\u0631\u0647\u0627", category: "alerts" },
  // Users
  { key: "users.view", displayName: "\u0645\u0634\u0627\u0647\u062F\u0647 \u06A9\u0627\u0631\u0628\u0631\u0627\u0646", description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u0644\u06CC\u0633\u062A \u06A9\u0627\u0631\u0628\u0631\u0627\u0646", category: "users" },
  { key: "users.create", displayName: "\u0627\u06CC\u062C\u0627\u062F \u06A9\u0627\u0631\u0628\u0631", description: "\u0627\u06CC\u062C\u0627\u062F \u06A9\u0627\u0631\u0628\u0631 \u062C\u062F\u06CC\u062F", category: "users" },
  { key: "users.edit", displayName: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u06A9\u0627\u0631\u0628\u0631", description: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u06A9\u0627\u0631\u0628\u0631\u0627\u0646", category: "users" },
  { key: "users.delete", displayName: "\u062D\u0630\u0641 \u06A9\u0627\u0631\u0628\u0631", description: "\u062D\u0630\u0641 \u06A9\u0627\u0631\u0628\u0631\u0627\u0646", category: "users" },
  // Roles
  { key: "roles.view", displayName: "\u0645\u0634\u0627\u0647\u062F\u0647 \u0646\u0642\u0634\u200C\u0647\u0627", description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u0646\u0642\u0634\u200C\u0647\u0627 \u0648 \u0645\u062C\u0648\u0632\u0647\u0627", category: "roles" },
  { key: "roles.create", displayName: "\u0627\u06CC\u062C\u0627\u062F \u0646\u0642\u0634", description: "\u0627\u06CC\u062C\u0627\u062F \u0646\u0642\u0634 \u062C\u062F\u06CC\u062F", category: "roles" },
  { key: "roles.edit", displayName: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0646\u0642\u0634", description: "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u0646\u0642\u0634\u200C\u0647\u0627", category: "roles" },
  { key: "roles.delete", displayName: "\u062D\u0630\u0641 \u0646\u0642\u0634", description: "\u062D\u0630\u0641 \u0646\u0642\u0634\u200C\u0647\u0627", category: "roles" },
  // Messages
  { key: "messages.view", displayName: "\u0645\u0634\u0627\u0647\u062F\u0647 \u067E\u06CC\u0627\u0645\u200C\u0647\u0627", description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u067E\u06CC\u0627\u0645\u200C\u0647\u0627", category: "messages" },
  { key: "messages.send", displayName: "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645", description: "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645", category: "messages" },
  // Analysis
  { key: "analysis.view", displayName: "\u0645\u0634\u0627\u0647\u062F\u0647 \u062A\u062D\u0644\u06CC\u0644", description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u062A\u062D\u0644\u06CC\u0644\u200C\u0647\u0627", category: "analysis" }
];
var defaultRoles = [
  {
    name: "admin",
    displayName: "\u0645\u062F\u06CC\u0631 \u0633\u06CC\u0633\u062A\u0645",
    description: "\u062F\u0633\u062A\u0631\u0633\u06CC \u06A9\u0627\u0645\u0644 \u0628\u0647 \u062A\u0645\u0627\u0645 \u0628\u062E\u0634\u200C\u0647\u0627\u06CC \u0633\u06CC\u0633\u062A\u0645",
    isSystem: true,
    permissions: defaultPermissions.map((p) => p.key)
    // All permissions
  },
  {
    name: "manager",
    displayName: "\u0645\u062F\u06CC\u0631\u06CC\u062A",
    description: "\u0645\u062F\u06CC\u0631\u06CC\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627 \u0648 \u06A9\u0627\u0631\u0628\u0631\u0627\u0646",
    isSystem: true,
    permissions: defaultPermissions.map((p) => p.key)
    // All permissions
  },
  {
    name: "project_manager",
    displayName: "\u0645\u062F\u06CC\u0631 \u067E\u0631\u0648\u0698\u0647",
    description: "\u0645\u062F\u06CC\u0631\u06CC\u062A \u067E\u0631\u0648\u0698\u0647\u200C\u0647\u0627\u06CC \u062E\u0627\u0635",
    isSystem: false,
    permissions: [
      "projects.view",
      "projects.edit",
      "reports.view",
      "reports.create",
      "reports.edit",
      "bitumen.view",
      "bitumen.create",
      "bitumen.edit",
      "sheets.view",
      "sheets.create",
      "sheets.edit",
      "tenders.view",
      "alerts.view",
      "alerts.create",
      "alerts.edit",
      "messages.view",
      "messages.send",
      "analysis.view"
    ]
  },
  {
    name: "technical_office",
    displayName: "\u062F\u0641\u062A\u0631 \u0641\u0646\u06CC",
    description: "\u0628\u0631\u0631\u0633\u06CC \u0648 \u062A\u0627\u06CC\u06CC\u062F \u0628\u0631\u06AF\u0647\u200C\u0647\u0627\u06CC \u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647",
    isSystem: false,
    permissions: [
      "projects.view",
      "reports.view",
      "sheets.view",
      "sheets.create",
      "sheets.edit",
      "alerts.view",
      "messages.view",
      "messages.send"
    ]
  },
  {
    name: "supervisor",
    displayName: "\u0633\u0631\u067E\u0631\u0633\u062A",
    description: "\u0646\u0638\u0627\u0631\u062A \u0628\u0631 \u067E\u0631\u0648\u0698\u0647 \u0648 \u062B\u0628\u062A \u06AF\u0632\u0627\u0631\u0634",
    isSystem: false,
    permissions: [
      "projects.view",
      "reports.view",
      "reports.create",
      "bitumen.view",
      "sheets.view",
      "alerts.view",
      "messages.view",
      "messages.send"
    ]
  },
  {
    name: "viewer",
    displayName: "\u0628\u06CC\u0646\u0646\u062F\u0647",
    description: "\u0641\u0642\u0637 \u0645\u0634\u0627\u0647\u062F\u0647 \u0627\u0637\u0644\u0627\u0639\u0627\u062A",
    isSystem: false,
    permissions: [
      "projects.view",
      "reports.view",
      "bitumen.view",
      "sheets.view",
      "tenders.view",
      "alerts.view",
      "messages.view",
      "analysis.view"
    ]
  }
];
async function initializePermissionsAndRoles() {
  try {
    console.log("\u{1F510} Initializing permissions and roles...");
    const existingPerms = await db.select().from(permissions);
    if (existingPerms.length > 0) {
      console.log("\u2705 Permissions already initialized");
      return;
    }
    const insertedPermissions = await db.insert(permissions).values(defaultPermissions).returning();
    console.log(`\u2705 Inserted ${insertedPermissions.length} permissions`);
    const permissionMap = new Map(insertedPermissions.map((p) => [p.key, p.id]));
    for (const roleData of defaultRoles) {
      const { permissions: rolePerms, ...roleInfo } = roleData;
      const [role] = await db.insert(roles).values(roleInfo).returning();
      console.log(`\u2705 Created role: ${role.displayName}`);
      const rolePermissionValues = rolePerms.map((permKey) => {
        const permId = permissionMap.get(permKey);
        return permId ? { roleId: role.id, permissionId: permId } : null;
      }).filter(Boolean);
      if (rolePermissionValues.length > 0) {
        await db.insert(rolePermissions).values(rolePermissionValues);
        console.log(`   \u2192 Assigned ${rolePermissionValues.length} permissions`);
      }
    }
    console.log("\u2705 Permissions and roles initialized successfully!");
  } catch (error) {
    console.error("\u274C Error initializing permissions:", error);
    throw error;
  }
}
async function createDefaultAdminUser() {
  if (process.env.NODE_ENV !== "development") {
    return;
  }
  try {
    console.log("\u{1F464} Checking for default admin user...");
    const [existingAdmin] = await db.select().from(users).where(eq5(users.username, "admin"));
    if (existingAdmin) {
      console.log("\u2705 Default admin user already exists");
      return;
    }
    const [adminRole] = await db.select().from(roles).where(eq5(roles.name, "admin"));
    if (!adminRole) {
      console.log("\u26A0\uFE0F Admin role not found, cannot create default admin user");
      return;
    }
    const hashedPassword = await bcrypt2.hash("admin123", 10);
    await db.insert(users).values({
      username: "admin",
      password: hashedPassword,
      firstName: "\u0645\u062F\u06CC\u0631",
      lastName: "\u0633\u06CC\u0633\u062A\u0645",
      email: "admin@system.local",
      roleId: adminRole.id,
      role: "admin",
      isActive: true,
      forcePasswordReset: true
    });
    console.log("\u2705 Default admin user created (username: admin, password: admin123)");
    console.log("\u26A0\uFE0F Password must be changed on first login");
  } catch (error) {
    console.error("\u274C Error creating default admin user:", error);
  }
}
if (import.meta.url === `file://${process.argv[1]}`) {
initializePermissionsAndRoles().catch(console.error);
//  initializePermissionsAndRoles().then(() => process.exit(0)).catch(() => process.exit(1));
}

// server/cleanup-service.ts
import fs4 from "fs/promises";
import path5 from "path";
import { fileURLToPath as fileURLToPath2 } from "url";
var __filename2 = fileURLToPath2(import.meta.url);
var __dirname2 = path5.dirname(__filename2);
var CleanupService = class {
  tempDirectories = [
    path5.join(__dirname2, "..", "uploads", "temp"),
    path5.join(__dirname2, "..", "uploads", "processing")
  ];
  tempFilePatterns = [
    /^temp_.*\.txt$/,
    /^.*_temp\.pdf$/,
    /^processing_.*\.json$/
  ];
  async cleanupTempFiles(options = {}) {
    const { maxAge = 24 * 60 * 60 * 1e3, dryRun = false } = options;
    const deleted = [];
    const errors = [];
    const now = Date.now();
    for (const dir of this.tempDirectories) {
      try {
        await fs4.access(dir);
      } catch {
        continue;
      }
      try {
        const files = await fs4.readdir(dir);
        for (const file of files) {
          const filePath = path5.join(dir, file);
          try {
            const stats = await fs4.stat(filePath);
            if (stats.isFile()) {
              const age = now - stats.mtimeMs;
              const shouldDelete = age > maxAge || this.tempFilePatterns.some((pattern) => pattern.test(file));
              if (shouldDelete) {
                if (!dryRun) {
                  await fs4.unlink(filePath);
                }
                deleted.push(filePath);
              }
            }
          } catch (error) {
            errors.push(`Failed to process ${filePath}: ${error}`);
          }
        }
      } catch (error) {
        errors.push(`Failed to read directory ${dir}: ${error}`);
      }
    }
    if (deleted.length > 0) {
      console.log(`\u{1F5D1}\uFE0F  Cleaned up ${deleted.length} temporary file(s)`);
    }
    if (errors.length > 0) {
      console.error(`\u26A0\uFE0F  Cleanup errors: ${errors.length} issue(s)`);
      errors.forEach((err) => console.error(`  - ${err}`));
    }
    return { deleted, errors };
  }
  async cleanupEmptyDirectories() {
    const deleted = [];
    const errors = [];
    const uploadDirs = [
      "uploads/agent-documents",
      "uploads/letters",
      "uploads/messages",
      "uploads/project-files",
      "uploads/sheets",
      "uploads/tasks"
    ];
    for (const relDir of uploadDirs) {
      const dir = path5.join(__dirname2, "..", relDir);
      try {
        await fs4.access(dir);
        const files = await fs4.readdir(dir);
        if (files.length === 0) {
          console.log(`\u{1F4C1} Empty directory: ${relDir}`);
        }
      } catch (error) {
        if (error.code !== "ENOENT") {
          errors.push(`Failed to check ${dir}: ${error}`);
        }
      }
    }
    return { deleted, errors };
  }
  async cleanupProcessedFiles(filePath) {
    try {
      await fs4.access(filePath);
      await fs4.unlink(filePath);
      console.log(`\u{1F5D1}\uFE0F  Cleaned up processed file: ${filePath}`);
      return true;
    } catch (error) {
      if (error.code !== "ENOENT") {
        console.error(`\u274C Failed to cleanup ${filePath}:`, error);
      }
      return false;
    }
  }
  scheduleAutomaticCleanup(intervalHours = 24) {
    const intervalMs = intervalHours * 60 * 60 * 1e3;
    setInterval(async () => {
      console.log("\u{1F9F9} Running scheduled cleanup...");
      const result = await this.cleanupTempFiles({ maxAge: 24 * 60 * 60 * 1e3 });
      console.log(`\u2705 Cleanup completed: ${result.deleted.length} files deleted`);
      if (result.errors.length > 0) {
        console.error(`\u26A0\uFE0F  Cleanup errors: ${result.errors.length}`);
      }
    }, intervalMs);
    console.log(`\u{1F504} Automatic cleanup scheduled (every ${intervalHours} hours)`);
  }
};
var cleanupService = new CleanupService();

// server/index.ts
var app = express3();
app.use(express3.json());
app.use(express3.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path6 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path6.startsWith("/api")) {
      let logLine = `${req.method} ${path6} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, async () => {
    log(`serving on port ${port}`);
    await initializePermissionsAndRoles();
    await createDefaultAdminUser();
    await agentService.initialize();
    const contractLawPath = "uploads/agent-documents/contract_law.jsonl";
    try {
      const fs5 = await import("fs");
      if (fs5.existsSync(contractLawPath)) {
        const result = await agentService.loadFromFile(contractLawPath);
        if (result.success) {
          console.log(`\u{1F4DA} \u0634\u0631\u0627\u06CC\u0637 \u0639\u0645\u0648\u0645\u06CC \u067E\u06CC\u0645\u0627\u0646 \u0628\u0627\u0631\u06AF\u0630\u0627\u0631\u06CC \u0634\u062F (${result.articlesCount} \u0645\u0627\u062F\u0647)`);
        }
      }
    } catch (error) {
      console.log("\u26A0\uFE0F \u0641\u0627\u06CC\u0644 \u0634\u0631\u0627\u06CC\u0637 \u0639\u0645\u0648\u0645\u06CC \u067E\u06CC\u0645\u0627\u0646 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F");
    }
    startAutoAlertScheduler();
    const initialCleanup = await cleanupService.cleanupTempFiles();
    if (initialCleanup.deleted.length > 0) {
      log(`\u{1F9F9} Initial cleanup: ${initialCleanup.deleted.length} files removed`);
    }
    cleanupService.scheduleAutomaticCleanup(24);
  });
})();
