export function toPersianDigits(str: string | number): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(str).replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
}

export function toEnglishDigits(str: string): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return str.replace(/[۰-۹]/g, (digit) => String(persianDigits.indexOf(digit)));
}

export function parsePersianNumber(str: string | null | undefined): number {
  if (!str) return 0;
  // Convert Persian/Arabic digits to English
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  let result = str;
  
  // Replace Persian digits
  persianDigits.forEach((digit, index) => {
    result = result.replace(new RegExp(digit, 'g'), index.toString());
  });
  
  // Replace Arabic digits
  arabicDigits.forEach((digit, index) => {
    result = result.replace(new RegExp(digit, 'g'), index.toString());
  });
  
  // Remove both Persian comma (٬) and ASCII comma (,)
  result = result.replace(/[,٬]/g, '');
  
  return parseFloat(result) || 0;
}

export function formatCurrency(amount: string | number): string {
  const numStr = String(amount).replace(/,/g, '');
  const parts = numStr.split('.');
  const integerPart = parts[0];
  const decimalPart = parts[1];
  
  const withSeparator = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  
  const formatted = decimalPart ? `${withSeparator}.${decimalPart}` : withSeparator;
  return toPersianDigits(formatted);
}
