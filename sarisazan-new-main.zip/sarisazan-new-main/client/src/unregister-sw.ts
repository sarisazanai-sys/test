// Unregister Service Worker to clear old cache
// This should be called once to clear cached bundles

export function unregisterServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations().then((registrations) => {
      for (const registration of registrations) {
        registration.unregister().then((success) => {
          if (success) {
            console.log('✅ Service Worker unregistered successfully');
            // Clear all caches
            if ('caches' in window) {
              caches.keys().then((cacheNames) => {
                return Promise.all(
                  cacheNames.map((cacheName) => {
                    console.log('🗑️ Deleting cache:', cacheName);
                    return caches.delete(cacheName);
                  })
                );
              }).then(() => {
                console.log('✅ All caches cleared');
                // Reload page to get fresh bundle
                window.location.reload();
              });
            } else {
              window.location.reload();
            }
          }
        });
      }
    });
  }
}

// Auto-unregister on development or if old bundle detected
if (import.meta.env.DEV || window.location.search.includes('clear-cache=true')) {
  // Only unregister in dev mode or if explicitly requested
  // unregisterServiceWorker();
}

