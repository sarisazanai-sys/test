import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ExecutionReportForm } from "@/components/ExecutionReportForm";
import { ExecutionReportList } from "@/components/ExecutionReportList";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function ExecutionReportsPage() {
  const [activeTab, setActiveTab] = useState("list");
  const currentUser = {
    id: "87140069-9ef7-4f84-9531-f065f793a4f9",
    name: "علی احمدی",
  };

  return (
    <div className="container mx-auto py-6" dir="rtl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">گزارش روزانه اجرا</h1>
        {activeTab === "list" && (
          <Button onClick={() => setActiveTab("form")} className="gap-2">
            <Plus className="w-4 h-4" />
            ایجاد گزارش جدید
          </Button>
        )}
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="form">ثبت گزارش جدید</TabsTrigger>
          <TabsTrigger value="list">لیست گزارش‌ها</TabsTrigger>
        </TabsList>
        
        <TabsContent value="form" className="mt-6">
          <ExecutionReportForm 
            supervisorId={currentUser.id} 
            supervisorName={currentUser.name}
            onSuccess={() => setActiveTab("list")}
          />
        </TabsContent>
        
        <TabsContent value="list" className="mt-6">
          <ExecutionReportList />
        </TabsContent>
      </Tabs>
    </div>
  );
}
