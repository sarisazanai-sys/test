import { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send, Loader2, Book, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { ScrollArea } from './ui/scroll-area';
import { useToast } from '@/hooks/use-toast';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  references?: string[];
  source?: 'local' | 'api';
  timestamp: number;
}

interface Article {
  chapter: string | null;
  article_number: number;
  article_title: string;
  text: string;
}

export function AIChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [showArticleDialog, setShowArticleDialog] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    const saved = localStorage.getItem('ai_chat_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setMessages(parsed);
        }
      } catch (e) {
        console.error('Failed to parse chat history:', e);
      }
    }
  }, []);

  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem('ai_chat_history', JSON.stringify(messages));
    }
  }, [messages]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const handleSend = async () => {
    const query = input.trim();
    if (!query || isLoading) return;

    const cachedResponse = getCachedResponse(query);
    if (cachedResponse) {
      setMessages(prev => [...prev, 
        { id: Date.now().toString(), role: 'user', content: query, timestamp: Date.now() },
        cachedResponse
      ]);
      setInput('');
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: query,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/agent/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
      });

      if (!response.ok) {
        throw new Error('خطا در ارتباط با سرویس');
      }

      const data = await response.json();
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.answer,
        references: data.references || [],
        source: data.source,
        timestamp: Date.now()
      };

      setMessages(prev => [...prev, assistantMessage]);
      cacheResponse(query, assistantMessage);

    } catch (error: any) {
      toast({
        title: '❌ خطا',
        description: error.message || 'خطا در دریافت پاسخ',
        variant: 'destructive'
      });
      
      setMessages(prev => prev.filter(m => m.id !== userMessage.id));
    } finally {
      setIsLoading(false);
    }
  };

  const normalizeQuery = (query: string): string => {
    return query
      .replace(/[؟،؛]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  };

  const getCachedResponse = (query: string): Message | null => {
    const normalizedQuery = normalizeQuery(query);
    const cacheKey = `ai_cache_${normalizedQuery}`;
    
    try {
      const cached = localStorage.getItem(cacheKey);
      if (!cached) return null;

      const cacheEntry = JSON.parse(cached);
      const age = Date.now() - cacheEntry.timestamp;
      const CACHE_DURATION = 7 * 24 * 60 * 60 * 1000;

      if (age > CACHE_DURATION) {
        localStorage.removeItem(cacheKey);
        return null;
      }

      return { 
        ...cacheEntry.response, 
        id: `cached-${Date.now()}`, 
        timestamp: Date.now() 
      };
    } catch (e) {
      return null;
    }
  };

  const cacheResponse = (query: string, response: Message) => {
    const normalizedQuery = normalizeQuery(query);
    const cacheKey = `ai_cache_${normalizedQuery}`;
    const cacheEntry = {
      query: normalizedQuery,
      response: {
        ...response,
        id: response.id,
        timestamp: response.timestamp
      },
      timestamp: Date.now()
    };
    localStorage.setItem(cacheKey, JSON.stringify(cacheEntry));
  };

  const handleArticleClick = async (articleNum: string) => {
    const num = parseInt(articleNum.replace('ماده ', ''));
    if (isNaN(num)) return;

    try {
      const response = await fetch(`/api/agent/article/${num}`);
      if (!response.ok) throw new Error('ماده یافت نشد');
      
      const article = await response.json();
      setSelectedArticle(article);
      setShowArticleDialog(true);
    } catch (error) {
      toast({
        title: '❌ خطا',
        description: 'ماده مورد نظر یافت نشد',
        variant: 'destructive'
      });
    }
  };

  const renderMessage = (message: Message) => {
    const isUser = message.role === 'user';
    
    return (
      <div
        key={message.id}
        className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}
      >
        <div
          className={`max-w-[80%] rounded-lg p-3 ${
            isUser
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted text-foreground'
          }`}
        >
          <div className="whitespace-pre-wrap text-sm leading-relaxed">
            {message.content}
          </div>
          
          {message.references && message.references.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2 pt-2 border-t border-border/50">
              {message.references.map((ref, idx) => (
                <Button
                  key={idx}
                  variant="ghost"
                  size="sm"
                  className="h-6 text-xs gap-1 hover:bg-background/20"
                  onClick={() => handleArticleClick(ref)}
                >
                  <Book className="w-3 h-3" />
                  {ref}
                  <ExternalLink className="w-2 h-2" />
                </Button>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearHistory = () => {
    setMessages([]);
    localStorage.removeItem('ai_chat_history');
    toast({
      title: '✅ تاریخچه پاک شد',
      description: 'تاریخچه چت با موفقیت حذف شد'
    });
  };

  return (
    <>
      {!isOpen && (
        <Button
          onClick={() => setIsOpen(true)}
          size="lg"
          className="fixed bottom-6 right-6 rounded-full shadow-lg w-14 h-14 z-50"
        >
          <MessageCircle className="w-6 h-6" />
        </Button>
      )}

      {isOpen && (
        <Card className="fixed bottom-6 right-6 w-96 h-[600px] shadow-2xl z-50 flex flex-col">
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">مشاور هوش مصنوعی</h3>
            </div>
            <div className="flex items-center gap-1">
              {messages.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearHistory}
                  className="h-8 text-xs"
                >
                  پاک کردن
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(false)}
                className="h-8 w-8"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <ScrollArea className="flex-1 p-4" ref={scrollRef}>
            {messages.length === 0 && (
              <div className="text-center text-muted-foreground text-sm py-8">
                <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p className="mt-2 text-xs">سؤال خود را بپرسید...</p>
              </div>
            )}
            
            {messages.map(renderMessage)}
            
            {isLoading && (
              <div className="flex justify-start mb-4">
                <div className="bg-muted rounded-lg p-3">
                  <Loader2 className="w-4 h-4 animate-spin" />
                </div>
              </div>
            )}
          </ScrollArea>

          <div className="p-4 border-t">
            <div className="flex gap-2">
              <Textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="سؤال خود را بپرسید..."
                className="resize-none min-h-[60px]"
                disabled={isLoading}
              />
              <Button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                size="icon"
                className="h-[60px] w-[60px]"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </Button>
            </div>
          </div>
        </Card>
      )}

      <Dialog open={showArticleDialog} onOpenChange={setShowArticleDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>
              ماده {selectedArticle?.article_number} - {selectedArticle?.article_title}
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh]">
            <div className="p-4 text-sm leading-relaxed whitespace-pre-wrap">
              {selectedArticle?.text}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </>
  );
}
