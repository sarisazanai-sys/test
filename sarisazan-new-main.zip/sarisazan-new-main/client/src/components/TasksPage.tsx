import { PageHeader } from "./PageHeader";
import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Checkbox } from "./ui/checkbox";
import { Plus, Bell, Check, X, Upload, FileText, User, Calendar as CalendarIcon } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { format } from "date-fns-jalali";
import { toPersianDigits } from "@/lib/persian-utils";
import { useToast } from "@/hooks/use-toast";

interface Task {
  id: string;
  userId: string;
  title: string;
  description?: string;
  isCompleted: boolean;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  reminderDateTime?: string;
  assigneeId?: string;
  projectId?: string;
  requiresConfirmation?: boolean;
  isConfirmed?: boolean;
  createdAt: string;
  completedAt?: string;
}

interface User {
  id: string;
  firstName?: string;
  lastName?: string;
  username: string;
}

interface Project {
  id: string;
  title: string;
}

const priorityColors = {
  low: 'border-gray-300',
  medium: 'border-gray-300',
  high: 'border-gray-300',
  urgent: 'border-gray-300',
};

const priorityLabels = {
  low: 'کم',
  medium: 'متوسط',
  high: 'زیاد',
  urgent: 'فوری',
};

export default function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed' | 'completedToday'>('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 'medium',
    reminderDateTime: '',
    assigneeId: '',
    projectId: '',
    requiresConfirmation: false,
  });

  // Get user ID from localStorage for headers
  const getUserId = (): string | null => {
    try {
      // Try currentUser first (used in auth context)
      const currentUserStored = localStorage.getItem("currentUser");
      if (currentUserStored) {
        const user = JSON.parse(currentUserStored);
        if (user?.id) return user.id;
      }
      // Fallback to user (legacy)
      const userStored = localStorage.getItem("user");
      if (userStored) {
        const user = JSON.parse(userStored);
        if (user?.id) return user.id;
      }
    } catch (error) {
      console.error("Failed to get user ID from localStorage:", error);
    }
    return null;
  };

  // Get headers with user ID
  const getHeaders = (includeContentType: boolean = false): HeadersInit => {
    const headers: HeadersInit = {};
    if (includeContentType) {
      headers["Content-Type"] = "application/json";
    }
    const userId = getUserId();
    if (userId) {
      headers["x-user-id"] = userId;
    }
    return headers;
  };

  useEffect(() => {
    fetchTasks();
    fetchUsers();
    fetchProjects();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await fetch('/api/tasks', {
        headers: getHeaders(),
      });
      if (response.ok) {
        const data = await response.json();
        setTasks(data);
      }
    } catch (error) {
      console.error('Error fetching tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/users', {
        headers: getHeaders(),
      });
      if (response.ok) {
        const data = await response.json();
        setUsers(data);
      }
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const fetchProjects = async () => {
    try {
      const response = await fetch('/api/projects', {
        headers: getHeaders(),
      });
      if (response.ok) {
        const data = await response.json();
        setProjects(data);
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
    }
  };

  const handleCreateTask = async () => {
    try {
      const userId = getUserId() || "1";

      if (selectedFile) {
        const formDataObj = new FormData();
        formDataObj.append('file', selectedFile);
        formDataObj.append('taskData', JSON.stringify({
          userId,
          ...formData,
        }));

        const headers = getHeaders();
        const response = await fetch('/api/tasks/with-attachment', {
          method: 'POST',
          headers: headers,
          body: formDataObj,
        });

        if (response.ok) {
          const newTask = await response.json();
          setTasks([newTask, ...tasks]);
          toast({
            title: "✅ وظیفه ایجاد شد",
            description: "وظیفه جدید با موفقیت ایجاد شد",
          });
          resetForm();
        } else {
          const errorData = await response.json().catch(() => ({ message: 'خطای نامشخص' }));
          console.error('Error creating task:', response.status, errorData);
          toast({
            title: "❌ خطا",
            description: errorData.message || "ایجاد وظیفه با خطا مواجه شد",
            variant: "destructive",
          });
        }
      } else {
        const response = await fetch('/api/tasks', {
          method: 'POST',
          headers: getHeaders(true),
          body: JSON.stringify({ userId, ...formData }),
        });

        if (response.ok) {
          const newTask = await response.json();
          setTasks([newTask, ...tasks]);
          toast({
            title: "✅ وظیفه ایجاد شد",
            description: "وظیفه جدید با موفقیت ایجاد شد",
          });
          resetForm();
        } else {
          const errorData = await response.json().catch(() => ({ message: 'خطای نامشخص' }));
          console.error('Error creating task:', response.status, errorData);
          toast({
            title: "❌ خطا",
            description: errorData.message || "ایجاد وظیفه با خطا مواجه شد",
            variant: "destructive",
          });
        }
      }
    } catch (error) {
      console.error('Error creating task:', error);
      toast({
        title: "❌ خطا",
        description: "ایجاد وظیفه با خطا مواجه شد",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      priority: 'medium',
      reminderDateTime: '',
      assigneeId: '',
      projectId: '',
      requiresConfirmation: false,
    });
    setSelectedFile(null);
    setDialogOpen(false);
  };

  const toggleTaskComplete = async (taskId: string) => {
    try {
      const task = tasks.find(t => t.id === taskId);
      if (!task) return;

      const response = await fetch(`/api/tasks/${taskId}`, {
        method: 'PATCH',
        headers: getHeaders(true),
        body: JSON.stringify({ isCompleted: !task.isCompleted }),
      });

      if (response.ok) {
        const updatedTask = await response.json();
        setTasks(tasks.map(t => 
          t.id === taskId ? updatedTask : t
        ));

        if (updatedTask.isCompleted) {
          toast({
            title: "🎉 وظیفه انجام شد",
            description: "وظیفه با موفقیت تکمیل شد",
          });
        }
      }
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  const handleConfirmTask = async (taskId: string, confirmed: boolean) => {
    try {
      const response = await fetch(`/api/tasks/${taskId}/confirm`, {
        method: 'PATCH',
        headers: getHeaders(true),
        body: JSON.stringify({ confirmed }),
      });

      if (response.ok) {
        const updatedTask = await response.json();
        setTasks(tasks.map(t => 
          t.id === taskId ? updatedTask : t
        ));

        toast({
          title: confirmed ? "✅ وظیفه تأیید شد" : "❌ وظیفه رد شد",
          description: confirmed ? "وظیفه با موفقیت تأیید شد" : "وظیفه رد شد",
        });
      }
    } catch (error) {
      console.error('Error confirming task:', error);
    }
  };

  const filteredTasks = tasks.filter(task => {
    const today = new Date().toISOString().split('T')[0];
    
    switch (filter) {
      case 'pending':
        return !task.isCompleted;
      case 'completed':
        return task.isCompleted;
      case 'completedToday':
        return task.isCompleted && task.completedAt && 
               new Date(task.completedAt).toDateString() === new Date().toDateString();
      default:
        return true;
    }
  });

  const completedTodayCount = tasks.filter(t => 
    t.isCompleted && 
    t.completedAt &&
    new Date(t.completedAt).toDateString() === new Date().toDateString()
  ).length;

  return (
    <div className="min-h-screen bg-background">
      <PageHeader 
        title="وظایف" 
        subtitle="مدیریت و پیگیری وظایف" 
        theme="tasks"
        actions={
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                وظیفه جدید
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>ایجاد وظیفه جدید</DialogTitle>
                <DialogDescription>
                  اطلاعات وظیفه جدید را وارد کنید
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان وظیفه *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="عنوان وظیفه را وارد کنید"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">توضیحات</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="توضیحات وظیفه را وارد کنید"
                    rows={4}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="priority">اولویت</Label>
                    <Select
                      value={formData.priority}
                      onValueChange={(value) => setFormData({ ...formData, priority: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">کم</SelectItem>
                        <SelectItem value="medium">متوسط</SelectItem>
                        <SelectItem value="high">زیاد</SelectItem>
                        <SelectItem value="urgent">فوری</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reminder">یادآوری (تاریخ و ساعت)</Label>
                    <Input
                      id="reminder"
                      type="text"
                      value={formData.reminderDateTime}
                      onChange={(e) => setFormData({ ...formData, reminderDateTime: e.target.value })}
                      placeholder="1403/07/15 14:30"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="assignee">اختصاص به</Label>
                    <Select
                      value={formData.assigneeId}
                      onValueChange={(value) => setFormData({ ...formData, assigneeId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب کاربر" />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map(user => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.firstName && user.lastName 
                              ? `${user.firstName} ${user.lastName}`
                              : user.username}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="project">پروژه</Label>
                    <Select
                      value={formData.projectId}
                      onValueChange={(value) => setFormData({ ...formData, projectId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب پروژه (اختیاری)" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects.map(project => (
                          <SelectItem key={project.id} value={project.id}>
                            {project.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="attachment">پیوست فایل</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="attachment"
                      type="file"
                      onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                      className="flex-1"
                    />
                    {selectedFile && (
                      <Badge variant="outline" className="gap-1">
                        <FileText className="h-3 w-3" />
                        {selectedFile.name}
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Checkbox
                    id="confirmation"
                    checked={formData.requiresConfirmation}
                    onCheckedChange={(checked) => 
                      setFormData({ ...formData, requiresConfirmation: checked as boolean })
                    }
                  />
                  <Label htmlFor="confirmation" className="cursor-pointer">
                    نیاز به تأیید دارد
                  </Label>
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    لغو
                  </Button>
                  <Button onClick={handleCreateTask} disabled={!formData.title}>
                    ایجاد وظیفه
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        }
      />
      
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex gap-2 flex-wrap">
          <Button 
            variant={filter === 'all' ? 'default' : 'outline'}
            onClick={() => setFilter('all')}
          >
            همه
          </Button>
          <Button 
            variant={filter === 'pending' ? 'default' : 'outline'}
            onClick={() => setFilter('pending')}
          >
            در انتظار
          </Button>
          <Button 
            variant={filter === 'completed' ? 'default' : 'outline'}
            onClick={() => setFilter('completed')}
          >
            انجام شده
          </Button>
          <Button 
            variant={filter === 'completedToday' ? 'default' : 'outline'}
            onClick={() => setFilter('completedToday')}
          >
            انجام شده امروز
          </Button>
        </div>

        {completedTodayCount > 0 && (
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center font-bold">
                  {toPersianDigits(completedTodayCount)}
                </div>
                <div>
                  <p className="font-semibold">وظایف انجام شده امروز</p>
                  <p className="text-sm text-muted-foreground">آفرین! به کارتان ادامه دهید</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="space-y-3">
          {loading ? (
            <div className="text-center py-12 text-muted-foreground">
              در حال بارگذاری...
            </div>
          ) : filteredTasks.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              وظیفه‌ای یافت نشد
            </div>
          ) : (
            filteredTasks.map(task => (
              <Card key={task.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Checkbox 
                      checked={task.isCompleted}
                      onCheckedChange={() => toggleTaskComplete(task.id)}
                      className="mt-1"
                    />
                    
                    <div className="flex-1 space-y-2">
                      <div className={`font-medium ${task.isCompleted ? 'line-through text-muted-foreground' : ''}`}>
                        {task.title}
                      </div>
                      
                      {task.description && (
                        <p className={`text-sm ${task.isCompleted ? 'line-through text-muted-foreground' : 'text-muted-foreground'}`}>
                          {task.description}
                        </p>
                      )}
                      
                      <div className="flex flex-wrap gap-2 items-center">
                        <Badge variant="outline" className={priorityColors[task.priority]}>
                          {priorityLabels[task.priority]}
                        </Badge>
                        
                        {task.reminderDateTime && (
                          <Badge variant="outline" className="gap-1">
                            <Bell className="h-3 w-3" />
                            {toPersianDigits(format(new Date(task.reminderDateTime), 'yyyy/MM/dd'))}
                          </Badge>
                        )}
                        
                        {task.requiresConfirmation && !task.isConfirmed && (
                          <>
                            <Badge variant="outline">
                              نیاز به تأیید
                            </Badge>
                            <div className="flex gap-1">
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="h-7 gap-1"
                                onClick={() => handleConfirmTask(task.id, true)}
                              >
                                <Check className="h-3 w-3" />
                                تأیید
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="h-7 gap-1"
                                onClick={() => handleConfirmTask(task.id, false)}
                              >
                                <X className="h-3 w-3" />
                                رد
                              </Button>
                            </div>
                          </>
                        )}

                        {task.isConfirmed && (
                          <Badge variant="outline" className="gap-1">
                            <Check className="h-3 w-3" />
                            تأیید شده
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
