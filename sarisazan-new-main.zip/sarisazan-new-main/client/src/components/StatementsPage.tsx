import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, TrendingUp, Calculator, Search, X } from "lucide-react";
import { format } from "date-fns-jalali";
import { toPersianDigits, formatCurrency } from "@/lib/persian-utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";

type Statement = {
  id: string;
  projectId: string;
  statementNumber: string;
  amount: string;
  status: string;
  startDate?: string | null;
  endDate?: string | null;
  notes?: string | null;
  createdAt: string;
  updatedAt?: string | null;
};

type Adjustment = {
  id: string;
  projectId: string;
  modificationNumber: string;
  amount?: string | null;
  status: string;
  startDate?: string | null;
  endDate?: string | null;
  notes?: string | null;
  createdAt: string;
  updatedAt?: string | null;
};

type BitumenDiff = {
  id: string;
  projectId: string;
  differenceNumber: string;
  amount: string;
  status: string;
  notes?: string | null;
  createdAt: string;
  updatedAt?: string | null;
};

type Project = {
  id: string;
  title: string;
  contractNumber?: string | null;
  contractDate?: string | null;
  employer?: string | null;
  contractor?: string | null;
  amount?: string | null;
};

type ProjectSummary = {
  project: Project;
  latestStatement: Statement | null;
  latestAdjustment: Adjustment | null;
  latestBitumenDiff: BitumenDiff | null;
};

export default function StatementsPage() {
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);

  // Get user ID from localStorage for headers
  const getUserId = (): string | null => {
    try {
      const currentUserStored = localStorage.getItem("currentUser");
      if (currentUserStored) {
        const user = JSON.parse(currentUserStored);
        if (user?.id) return user.id;
      }
      const userStored = localStorage.getItem("user");
      if (userStored) {
        const user = JSON.parse(userStored);
        if (user?.id) return user.id;
      }
    } catch (error) {
      console.error("Failed to get user ID from localStorage:", error);
    }
    return null;
  };

  const getHeaders = (): HeadersInit => {
    const headers: Record<string, string> = {};
    const userId = getUserId();
    if (userId) {
      headers["x-user-id"] = userId;
    }
    return headers as HeadersInit;
  };

  // Check if user is authenticated before making requests
  const userId = getUserId();
  
  // Fetch all projects
  const { data: projects = [], isLoading: isLoadingProjects, error: projectsError } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const headers = getHeaders();
      const headerRecord = headers as Record<string, string>;
      if (!headerRecord["x-user-id"]) {
        throw new Error("احراز هویت لازم است. لطفاً دوباره وارد سیستم شوید.");
      }
      const response = await fetch("/api/projects", { headers });
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("احراز هویت لازم است. لطفاً دوباره وارد سیستم شوید.");
        }
        throw new Error("خطا در دریافت پروژه‌ها");
      }
      return response.json();
    },
    enabled: !!userId, // Only fetch if user ID exists
    retry: false,
  });

  // Fetch all statements
  const { data: allStatements = [], isLoading: isLoadingStatements, error: statementsError } = useQuery<Statement[]>({
    queryKey: ["/api/statements"],
    queryFn: async () => {
      const headers = getHeaders();
      if (!headers["x-user-id"]) {
        return []; // Return empty if not authenticated
      }
      const response = await fetch("/api/statements", { headers });
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          // Permission denied, return empty array silently
          return [];
        }
        throw new Error("خطا در دریافت صورت‌وضعیت‌ها");
      }
      return response.json();
    },
    enabled: !!userId, // Only fetch if user ID exists
    retry: false,
  });

  // Fetch all adjustments
  const { data: allAdjustments = [], isLoading: isLoadingAdjustments, error: adjustmentsError } = useQuery<Adjustment[]>({
    queryKey: ["/api/adjustments"],
    queryFn: async () => {
      const headers = getHeaders();
      if (!headers["x-user-id"]) {
        return []; // Return empty if not authenticated
      }
      const response = await fetch("/api/adjustments", { headers });
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          // Permission denied, return empty array silently
          return [];
        }
        throw new Error("خطا در دریافت تعدیل‌ها");
      }
      return response.json();
    },
    enabled: !!userId, // Only fetch if user ID exists
    retry: false,
  });

  // Fetch all bitumen diffs
  const { data: allBitumenDiffs = [], isLoading: isLoadingBitumenDiffs, error: bitumenDiffsError } = useQuery<BitumenDiff[]>({
    queryKey: ["/api/bitumen-diffs"],
    queryFn: async () => {
      const headers = getHeaders();
      if (!headers["x-user-id"]) {
        return []; // Return empty if not authenticated
      }
      const response = await fetch("/api/bitumen-diffs", { headers });
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          // Permission denied, return empty array silently
          return [];
        }
        throw new Error("خطا در دریافت مابه‌التفاوت‌ها");
      }
      return response.json();
    },
    enabled: !!userId, // Only fetch if user ID exists
    retry: false,
  });

  // Fetch detailed data for selected project
  const { data: projectDetails, isLoading: isLoadingDetails } = useQuery<{
    statements: Statement[];
    adjustments: Adjustment[];
    bitumenDiffs: BitumenDiff[];
  }>({
    queryKey: ["/api/projects", selectedProjectId, "financial-history"],
    enabled: !!selectedProjectId,
    queryFn: async () => {
      const response = await fetch(`/api/projects/${selectedProjectId}/financial-history`, {
        headers: getHeaders(),
      });
      if (!response.ok) throw new Error("خطا در دریافت جزئیات پروژه");
      return response.json();
    },
  });

  // Create project summaries with latest approved items
  const projectSummaries = useMemo<ProjectSummary[]>(() => {
    if (!projects || projects.length === 0) return [];
    
    return projects.map((project) => {
      // Get latest approved statement
      // Check for various approved status values
      const approvedStatuses = ["تأیید شده", "confirmed", "تایید شده", "تأییدشده", "تاییدشده"];
      const projectStatements = (allStatements || []).filter(
        (s) => {
          if (s.projectId !== project.id) return false;
          const status = s.status || "";
          return approvedStatuses.some(approved => 
            status === approved || status.toLowerCase() === approved.toLowerCase()
          );
        }
      );
      const latestStatement = projectStatements.length > 0
        ? projectStatements.sort((a, b) => {
            // Try to sort by announcedDate or submissionDate first, then createdAt
            const dateA = a.announcedDate || a.submissionDate || a.createdAt || "";
            const dateB = b.announcedDate || b.submissionDate || b.createdAt || "";
            return new Date(dateB).getTime() - new Date(dateA).getTime();
          })[0]
        : null;

      // Get latest approved adjustment
      const projectAdjustments = (allAdjustments || []).filter(
        (a) => {
          if (a.projectId !== project.id) return false;
          const status = a.status || "";
          return approvedStatuses.some(approved => 
            status === approved || status.toLowerCase() === approved.toLowerCase()
          );
        }
      );
      const latestAdjustment = projectAdjustments.length > 0
        ? projectAdjustments.sort((a, b) => {
            // Try to sort by endDate or startDate first, then createdAt
            const dateA = a.endDate || a.startDate || a.createdAt || "";
            const dateB = b.endDate || b.startDate || b.createdAt || "";
            return new Date(dateB).getTime() - new Date(dateA).getTime();
          })[0]
        : null;

      // Get latest approved bitumen diff
      const projectBitumenDiffs = (allBitumenDiffs || []).filter(
        (b) => {
          if (b.projectId !== project.id) return false;
          const status = b.status || "";
          return approvedStatuses.some(approved => 
            status === approved || status.toLowerCase() === approved.toLowerCase()
          );
        }
      );
      const latestBitumenDiff = projectBitumenDiffs.length > 0
        ? projectBitumenDiffs.sort((a, b) => {
            // Sort by updatedAt or createdAt
            const dateA = a.updatedAt || a.createdAt || "";
            const dateB = b.updatedAt || b.createdAt || "";
            return new Date(dateB).getTime() - new Date(dateA).getTime();
          })[0]
        : null;

      return {
        project,
        latestStatement,
        latestAdjustment,
        latestBitumenDiff,
      };
    });
  }, [projects, allStatements, allAdjustments, allBitumenDiffs]);

  // Filter projects based on search query
  const filteredSummaries = useMemo(() => {
    if (!searchQuery.trim()) return projectSummaries;
    const query = searchQuery.toLowerCase();
    return projectSummaries.filter(
      (summary) =>
        summary.project.title?.toLowerCase().includes(query) ||
        summary.project.contractNumber?.toLowerCase().includes(query) ||
        summary.latestStatement?.statementNumber?.toLowerCase().includes(query) ||
        summary.latestAdjustment?.modificationNumber?.toLowerCase().includes(query) ||
        summary.latestBitumenDiff?.differenceNumber?.toLowerCase().includes(query)
    );
  }, [projectSummaries, searchQuery]);

  const selectedProject = useMemo(() => {
    if (!selectedProjectId) return null;
    return projectSummaries.find((s) => s.project.id === selectedProjectId);
  }, [selectedProjectId, projectSummaries]);

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
      "تأیید شده": { label: "تأیید شده", variant: "default" },
      confirmed: { label: "تأیید شده", variant: "default" },
      "تایید شده": { label: "تأیید شده", variant: "default" },
      "تأییدشده": { label: "تأیید شده", variant: "default" },
      "تاییدشده": { label: "تأیید شده", variant: "default" },
      "ابلاغ شده": { label: "ابلاغ شده", variant: "secondary" },
      announced: { label: "ابلاغ شده", variant: "secondary" },
      "در انتظار": { label: "در انتظار", variant: "outline" },
      pending: { label: "در انتظار", variant: "outline" },
      temporary: { label: "موقت", variant: "secondary" },
      "موقت": { label: "موقت", variant: "secondary" },
    };
    const statusInfo = statusMap[status] || { label: status, variant: "outline" as const };
    return (
      <Badge variant={statusInfo.variant} className="text-xs">
        {statusInfo.label}
      </Badge>
    );
  };

  const handleRowClick = (projectId: string) => {
    setSelectedProjectId(projectId);
    setDetailsDialogOpen(true);
  };

  const isLoading = isLoadingProjects || isLoadingStatements || isLoadingAdjustments || isLoadingBitumenDiffs;

  return (
    <div className="container mx-auto p-3 sm:p-4 md:p-6 space-y-4 md:space-y-6" dir="rtl">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
        <h1 className="text-xl sm:text-2xl md:text-3xl font-bold">صورت‌وضعیت‌ها</h1>
        <div className="w-full sm:w-auto">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
              placeholder="جستجوی پروژه، شماره قرارداد..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 w-full sm:w-[280px] md:w-[320px]"
              />
            </div>
            </div>
          </div>

      {/* Main Table Card */}
      <Card className="shadow-sm">
        <CardHeader className="pb-3 sm:pb-4">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <FileText className="h-4 w-4 sm:h-5 sm:w-5" />
            لیست پروژه‌ها و آخرین صورت‌وضعیت‌ها
            </CardTitle>
          </CardHeader>
        <CardContent className="p-0 sm:p-6">
          {projectsError && (
            <div className="text-center py-6 px-4 text-red-600 bg-red-50 dark:bg-red-950 rounded-lg m-4">
              <p className="font-semibold mb-1">خطا در بارگذاری پروژه‌ها</p>
              <p className="text-sm">{projectsError.message}</p>
              </div>
          )}
          {/* Only show warning if there's a real permission error */}
          {((statementsError && statementsError.message && (statementsError.message.includes("مجوز") || statementsError.message.includes("Permission"))) ||
            (adjustmentsError && adjustmentsError.message && (adjustmentsError.message.includes("مجوز") || adjustmentsError.message.includes("Permission"))) ||
            (bitumenDiffsError && bitumenDiffsError.message && (bitumenDiffsError.message.includes("مجوز") || bitumenDiffsError.message.includes("Permission")))) && (
            <div className="text-center py-3 px-4 text-amber-600 bg-amber-50 dark:bg-amber-950 rounded-lg m-4 text-sm">
              <p>توجه: برخی اطلاعات به دلیل محدودیت دسترسی بارگذاری نشدند.</p>
              </div>
          )}
          {isLoading ? (
            <div className="text-center py-12 text-muted-foreground">در حال بارگذاری...</div>
          ) : (
            <div className="overflow-x-auto -mx-4 sm:mx-0">
              <div className="inline-block min-w-full align-middle">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right w-12 sm:w-16">ردیف</TableHead>
                      <TableHead className="text-right min-w-[140px] sm:min-w-[200px]">نام پروژه</TableHead>
                      <TableHead className="text-right min-w-[120px] sm:min-w-[150px] hidden md:table-cell">شماره قرارداد</TableHead>
                      <TableHead className="text-right min-w-[160px] sm:min-w-[180px]">آخرین صورت‌وضعیت</TableHead>
                      <TableHead className="text-right min-w-[160px] sm:min-w-[180px] hidden lg:table-cell">آخرین تعدیل</TableHead>
                      <TableHead className="text-right min-w-[160px] sm:min-w-[180px] hidden lg:table-cell">آخرین مابه‌التفاوت</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredSummaries.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                          {searchQuery ? "نتیجه‌ای یافت نشد" : "هیچ پروژه‌ای وجود ندارد"}
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredSummaries.map((summary, index) => (
                        <TableRow
                          key={summary.project.id}
                          className="cursor-pointer hover:bg-muted/50 transition-colors"
                          onClick={() => handleRowClick(summary.project.id)}
                        >
                          <TableCell className="font-medium">{toPersianDigits((index + 1).toString())}</TableCell>
                          <TableCell className="font-medium">
                            <div className="flex flex-col gap-1">
                              <span className="text-sm sm:text-base">{summary.project.title}</span>
                              <span className="text-xs text-muted-foreground md:hidden">
                                {summary.project.contractNumber || "—"}
                              </span>
              </div>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">{summary.project.contractNumber || "—"}</TableCell>
                          <TableCell>
                            {summary.latestStatement ? (
                              <div className="flex flex-col gap-1">
                                <div className="font-medium text-green-600 dark:text-green-400 text-sm">
                                  {formatCurrency(summary.latestStatement.amount)} ریال
              </div>
                                <div className="text-xs text-muted-foreground">
                                  #{summary.latestStatement.statementNumber}
              </div>
                                <div className="text-xs text-muted-foreground">
                                  {toPersianDigits(format(new Date(summary.latestStatement.createdAt), "yyyy/MM/dd"))}
              </div>
            </div>
                            ) : (
                              <span className="text-muted-foreground text-sm">—</span>
                            )}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            {summary.latestAdjustment ? (
                              <div className="flex flex-col gap-1">
                                <div className="font-medium text-blue-600 dark:text-blue-400 text-sm">
                                  {formatCurrency(summary.latestAdjustment.amount || "0")} ریال
                          </div>
                            <div className="text-xs text-muted-foreground">
                                  #{summary.latestAdjustment.modificationNumber}
                            </div>
                                <div className="text-xs text-muted-foreground">
                                  {toPersianDigits(format(new Date(summary.latestAdjustment.createdAt), "yyyy/MM/dd"))}
                          </div>
                        </div>
                            ) : (
                              <span className="text-muted-foreground text-sm">—</span>
                            )}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            {summary.latestBitumenDiff ? (
                              <div className="flex flex-col gap-1">
                                <div
                                  className={`font-medium text-sm ${
                                    parseFloat(summary.latestBitumenDiff.amount) < 0
                                      ? "text-red-600 dark:text-red-400"
                                      : "text-purple-600 dark:text-purple-400"
                                  }`}
                                >
                                  {formatCurrency(summary.latestBitumenDiff.amount)} ریال
                  </div>
                                <div className="text-xs text-muted-foreground">
                                  #{summary.latestBitumenDiff.differenceNumber}
                            </div>
                              <div className="text-xs text-muted-foreground">
                                  {toPersianDigits(format(new Date(summary.latestBitumenDiff.createdAt), "yyyy/MM/dd"))}
                              </div>
                            </div>
                            ) : (
                              <span className="text-muted-foreground text-sm">—</span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
                            </div>
                              </div>
          )}
          </CardContent>
        </Card>

      {/* Details Dialog */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent className="max-w-[95vw] sm:max-w-4xl lg:max-w-6xl max-h-[95vh] overflow-hidden flex flex-col p-0" dir="rtl">
          <DialogHeader className="px-4 sm:px-6 pt-4 sm:pt-6 pb-3 border-b">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <DialogTitle className="flex items-center gap-2 text-lg sm:text-xl">
                  <FileText className="h-5 w-5" />
                  جزئیات مالی پروژه
                </DialogTitle>
                <div className="mt-2 text-sm">
                  <div className="flex flex-col sm:flex-row gap-2 sm:gap-4">
                    <span className="font-medium">{selectedProject?.project.title}</span>
                    {selectedProject?.project.contractNumber && (
                      <span className="text-muted-foreground">
                        شماره قرارداد: {selectedProject.project.contractNumber}
                      </span>
                    )}
                  </div>
                </div>
                  </div>
                            <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setDetailsDialogOpen(false)}
              >
                <X className="h-4 w-4" />
                            </Button>
                          </div>
          </DialogHeader>

          {isLoadingDetails ? (
            <div className="text-center py-12 text-muted-foreground">در حال بارگذاری جزئیات...</div>
          ) : projectDetails ? (
            <ScrollArea className="flex-1 px-4 sm:px-6">
              <Tabs defaultValue="statements" className="w-full py-4" dir="rtl">
                <TabsList className="grid w-full grid-cols-3 mb-4">
                  <TabsTrigger value="statements" className="flex items-center gap-2 text-xs sm:text-sm">
                    <FileText className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden sm:inline">صورت‌وضعیت‌ها</span>
                    <span className="sm:hidden">صورت</span>
                    <Badge variant="secondary" className="mr-1 text-xs">
                      {projectDetails.statements.length}
                    </Badge>
                  </TabsTrigger>
                  <TabsTrigger value="adjustments" className="flex items-center gap-2 text-xs sm:text-sm">
                    <Calculator className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden sm:inline">تعدیل‌ها</span>
                    <span className="sm:hidden">تعدیل</span>
                    <Badge variant="secondary" className="mr-1 text-xs">
                      {projectDetails.adjustments.length}
                    </Badge>
                  </TabsTrigger>
                  <TabsTrigger value="bitumen-diffs" className="flex items-center gap-2 text-xs sm:text-sm">
                    <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden sm:inline">مابه‌التفاوت‌ها</span>
                    <span className="sm:hidden">مابه‌التفاوت</span>
                    <Badge variant="secondary" className="mr-1 text-xs">
                      {projectDetails.bitumenDiffs.length}
                    </Badge>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="statements" className="space-y-3 mt-0">
                  {projectDetails.statements.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">
                      هیچ صورت‌وضعیتی ثبت نشده است
                </div>
                  ) : (
                    projectDetails.statements
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .map((statement) => (
                        <Card key={statement.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex flex-col gap-4">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <h3 className="font-semibold text-base sm:text-lg">
                                    صورت‌وضعیت شماره {statement.statementNumber}
                                  </h3>
                                  {getStatusBadge(statement.status)}
                                </div>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">مبلغ:</span>
                                  <span className="font-medium text-green-600 dark:text-green-400">
                                    {formatCurrency(statement.amount)} ریال
                                  </span>
                                </div>
                                {statement.startDate && statement.endDate && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground min-w-[80px]">دوره:</span>
                                    <span>
                                      {toPersianDigits(statement.startDate)} تا {toPersianDigits(statement.endDate)}
                                    </span>
                  </div>
                )}
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">تاریخ ثبت:</span>
                                  <span>
                                    {toPersianDigits(format(new Date(statement.createdAt), "yyyy/MM/dd HH:mm"))}
                                  </span>
                          </div>
                                {statement.updatedAt && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground min-w-[80px]">آخرین به‌روزرسانی:</span>
                                    <span>
                                      {toPersianDigits(format(new Date(statement.updatedAt), "yyyy/MM/dd HH:mm"))}
                                    </span>
                </div>
                                )}
                              </div>
                              {statement.notes && (
                                <div className="pt-3 border-t">
                                  <p className="text-sm">
                                    <span className="font-medium text-muted-foreground">توضیحات: </span>
                                    <span className="text-foreground">{statement.notes}</span>
                                  </p>
                  </div>
                )}
                          </div>
              </CardContent>
            </Card>
                      ))
                  )}
                </TabsContent>

                <TabsContent value="adjustments" className="space-y-3 mt-0">
                  {projectDetails.adjustments.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">هیچ تعدیلی ثبت نشده است</div>
                  ) : (
                    projectDetails.adjustments
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .map((adjustment) => (
                        <Card key={adjustment.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex flex-col gap-4">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <h3 className="font-semibold text-base sm:text-lg">
                                    تعدیل شماره {adjustment.modificationNumber}
                                  </h3>
                                  {getStatusBadge(adjustment.status)}
            </div>
            </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">مبلغ:</span>
                                  <span className="font-medium text-blue-600 dark:text-blue-400">
                                    {formatCurrency(adjustment.amount || "0")} ریال
                                  </span>
            </div>
                                {adjustment.startDate && adjustment.endDate && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground min-w-[80px]">دوره:</span>
                                    <span>
                                      {toPersianDigits(adjustment.startDate)} تا {toPersianDigits(adjustment.endDate)}
                                    </span>
            </div>
                                )}
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">تاریخ ثبت:</span>
                                  <span>
                                    {toPersianDigits(format(new Date(adjustment.createdAt), "yyyy/MM/dd HH:mm"))}
                                  </span>
            </div>
                                {adjustment.updatedAt && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground min-w-[80px]">آخرین به‌روزرسانی:</span>
                                    <span>
                                      {toPersianDigits(format(new Date(adjustment.updatedAt), "yyyy/MM/dd HH:mm"))}
                                    </span>
            </div>
                                )}
            </div>
                              {adjustment.notes && (
                                <div className="pt-3 border-t">
                                  <p className="text-sm">
                                    <span className="font-medium text-muted-foreground">توضیحات: </span>
                                    <span className="text-foreground">{adjustment.notes}</span>
                                  </p>
            </div>
                              )}
            </div>
                          </CardContent>
                        </Card>
                      ))
                  )}
                </TabsContent>

                <TabsContent value="bitumen-diffs" className="space-y-3 mt-0">
                  {projectDetails.bitumenDiffs.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">
                      هیچ مابه‌التفاوتی ثبت نشده است
            </div>
                  ) : (
                    projectDetails.bitumenDiffs
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .map((bitumenDiff) => (
                        <Card key={bitumenDiff.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex flex-col gap-4">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <h3 className="font-semibold text-base sm:text-lg">
                                    مابه‌التفاوت شماره {bitumenDiff.differenceNumber}
                                  </h3>
                                  {getStatusBadge(bitumenDiff.status)}
            </div>
            </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">مبلغ:</span>
                                  <span
                                    className={`font-medium ${
                                      parseFloat(bitumenDiff.amount) < 0
                                        ? "text-red-600 dark:text-red-400"
                                        : "text-purple-600 dark:text-purple-400"
                                    }`}
                                  >
                                    {formatCurrency(bitumenDiff.amount)} ریال
                                  </span>
            </div>
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">تاریخ ثبت:</span>
                                  <span>
                                    {toPersianDigits(format(new Date(bitumenDiff.createdAt), "yyyy/MM/dd HH:mm"))}
                                  </span>
            </div>
                                {bitumenDiff.updatedAt && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground min-w-[80px]">آخرین به‌روزرسانی:</span>
                                    <span>
                                      {toPersianDigits(format(new Date(bitumenDiff.updatedAt), "yyyy/MM/dd HH:mm"))}
                                    </span>
            </div>
                                )}
            </div>
                              {bitumenDiff.notes && (
                                <div className="pt-3 border-t">
                                  <p className="text-sm">
                                    <span className="font-medium text-muted-foreground">توضیحات: </span>
                                    <span className="text-foreground">{bitumenDiff.notes}</span>
                                  </p>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))
                  )}
                </TabsContent>
              </Tabs>
            </ScrollArea>
          ) : (
            <div className="text-center py-12 text-muted-foreground px-4">خطا در بارگذاری جزئیات</div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
