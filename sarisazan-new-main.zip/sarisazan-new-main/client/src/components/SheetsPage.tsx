import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Edit, Trash2, Download, FileText, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { toPersianDigits } from "@/lib/persian-utils";
import { format } from "date-fns-jalali";
import type { Sheet, InsertSheet, Project } from "@shared/schema";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";

const sheetTypes = [
  { value: "quality_control", label: "کنترل کیفیت" },
  { value: "material_test", label: "آزمایش مصالح" },
  { value: "soil_test", label: "آزمایش خاک" },
  { value: "concrete_test", label: "آزمایش بتن" },
  { value: "asphalt_test", label: "آزمایش آسفالت" },
  { value: "other", label: "سایر" },
];

const statuses = [
  { value: "pending", label: "در انتظار", variant: "secondary" as const },
  { value: "approved", label: "تایید شده", variant: "default" as const },
  { value: "rejected", label: "رد شده", variant: "destructive" as const },
];

export default function SheetsPage() {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [projectFilter, setProjectFilter] = useState("all");
  const [sheetTypeFilter, setSheetTypeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [editingSheet, setEditingSheet] = useState<Sheet | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [sampleDate, setSampleDate] = useState<Date | undefined>(undefined);
  const [testDate, setTestDate] = useState<Date | undefined>(undefined);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState<Partial<InsertSheet>>({
    projectId: "",
    sheetCode: "",
    sheetType: "",
    sampleDate: "",
    testDate: "",
    location: "",
    labName: "",
    specRef: "",
    resultsJson: "",
    status: "pending",
    notes: "",
    createdBy: "",
  });

  const { data: sheets = [], isLoading } = useQuery<Sheet[]>({
    queryKey: ["/api/sheets", projectFilter, sheetTypeFilter, statusFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (projectFilter !== "all") params.append("projectId", projectFilter);
      if (sheetTypeFilter !== "all") params.append("sheetType", sheetTypeFilter);
      if (statusFilter !== "all") params.append("status", statusFilter);
      
      const response = await fetch(`/api/sheets?${params.toString()}`);
      if (!response.ok) throw new Error("خطا در دریافت شیت‌ها");
      return response.json();
    },
  });

  // Get user ID from localStorage for headers
  const getUserId = (): string | null => {
    try {
      const stored = localStorage.getItem("currentUser");
      if (stored) {
        const user = JSON.parse(stored);
        return user?.id || null;
      }
    } catch (error) {
      console.error("Failed to get user ID from localStorage:", error);
    }
    return null;
  };

  const getHeaders = (): HeadersInit => {
    const headers: Record<string, string> = {};
    const userId = getUserId();
    if (userId) {
      headers["x-user-id"] = userId;
    }
    return headers as HeadersInit;
  };

  const userId = getUserId();

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const headers = getHeaders();
      const response = await fetch("/api/projects", { headers });
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("احراز هویت لازم است");
        }
        throw new Error("خطا در دریافت پروژه‌ها");
      }
      return response.json();
    },
    enabled: !!userId,
    retry: false,
  });

  const createSheetMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await fetch("/api/sheets", {
        method: "POST",
        body: data,
      });
      if (!response.ok) throw new Error("خطا در ایجاد شیت");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sheets"] });
      setOpen(false);
      resetForm();
      toast({
        title: "موفقیت",
        description: "شیت جدید با موفقیت ایجاد شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const updateSheetMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertSheet> }) => {
      const response = await fetch(`/api/sheets/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در ویرایش شیت");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sheets"] });
      setOpen(false);
      resetForm();
      toast({
        title: "موفقیت",
        description: "شیت با موفقیت ویرایش شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const deleteSheetMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/sheets/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("خطا در حذف شیت");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sheets"] });
      toast({
        title: "موفقیت",
        description: "شیت با موفقیت حذف شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const currentUser = JSON.parse(localStorage.getItem("user") || "{}");
    
    if (editingSheet) {
      updateSheetMutation.mutate({ id: editingSheet.id, data: formData });
    } else {
      const formDataToSend = new FormData();
      formDataToSend.append("projectId", formData.projectId || "");
      formDataToSend.append("sheetCode", formData.sheetCode || "");
      formDataToSend.append("sheetType", formData.sheetType || "");
      formDataToSend.append("sampleDate", formData.sampleDate || "");
      formDataToSend.append("testDate", formData.testDate || "");
      formDataToSend.append("location", formData.location || "");
      formDataToSend.append("labName", formData.labName || "");
      formDataToSend.append("specRef", formData.specRef || "");
      formDataToSend.append("resultsJson", formData.resultsJson || "");
      formDataToSend.append("status", formData.status || "pending");
      formDataToSend.append("notes", formData.notes || "");
      formDataToSend.append("createdBy", currentUser.id || "");
      
      if (selectedFiles) {
        Array.from(selectedFiles).forEach((file) => {
          formDataToSend.append("files", file);
        });
      }
      
      createSheetMutation.mutate(formDataToSend);
    }
  };

  const resetForm = () => {
    setFormData({
      projectId: "",
      sheetCode: "",
      sheetType: "",
      sampleDate: "",
      testDate: "",
      location: "",
      labName: "",
      specRef: "",
      resultsJson: "",
      status: "pending",
      notes: "",
      createdBy: "",
    });
    setSelectedFiles(null);
    setSampleDate(undefined);
    setTestDate(undefined);
    setEditingSheet(null);
  };

  const handleEdit = (sheet: Sheet) => {
    setEditingSheet(sheet);
    setFormData({
      projectId: sheet.projectId,
      sheetCode: sheet.sheetCode || "",
      sheetType: sheet.sheetType,
      sampleDate: sheet.sampleDate,
      testDate: sheet.testDate || "",
      location: sheet.location || "",
      labName: sheet.labName || "",
      specRef: sheet.specRef || "",
      resultsJson: sheet.resultsJson || "",
      status: sheet.status,
      notes: sheet.notes || "",
      createdBy: sheet.createdBy,
    });
    if (sheet.sampleDate) {
      const [year, month, day] = sheet.sampleDate.split("-").map(Number);
      setSampleDate(new Date(year, month - 1, day));
    }
    if (sheet.testDate) {
      const [year, month, day] = sheet.testDate.split("-").map(Number);
      setTestDate(new Date(year, month - 1, day));
    }
    setOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("آیا از حذف این شیت اطمینان دارید؟")) {
      deleteSheetMutation.mutate(id);
    }
  };

  const handleDownloadCSV = async () => {
    try {
      const response = await fetch("/api/sheets/csv");
      if (!response.ok) throw new Error("خطا در دریافت فایل CSV");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `sheets_${format(new Date(), "yyyy-MM-dd")}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "موفقیت",
        description: "فایل CSV با موفقیت دانلود شد",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "خطا",
        description: "خطا در دانلود فایل CSV",
      });
    }
  };

  const getSheetTypeLabel = (type: string) => {
    return sheetTypes.find(t => t.value === type)?.label || type;
  };

  const getStatusLabel = (status: string) => {
    return statuses.find(s => s.value === status)?.label || status;
  };

  const getStatusVariant = (status: string) => {
    return statuses.find(s => s.value === status)?.variant || "default";
  };

  const filteredSheets = useMemo(
    () => sheets.filter((sheet) => {
      const matchesSearch = 
        sheet.sheetCode?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sheet.location?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sheet.labName?.toLowerCase().includes(searchQuery.toLowerCase());
      
      return matchesSearch;
    }),
    [sheets, searchQuery]
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">مدیریت شیت‌های آزمایشگاهی</h1>
        <div className="flex gap-2">
          <Button onClick={handleDownloadCSV} variant="outline">
            <Download className="ml-2 h-4 w-4" />
            خروجی CSV
          </Button>
          <Dialog open={open} onOpenChange={(isOpen) => {
            setOpen(isOpen);
            if (!isOpen) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="ml-2 h-4 w-4" />
                شیت جدید
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingSheet ? "ویرایش شیت" : "ایجاد شیت جدید"}
                </DialogTitle>
                <DialogDescription>
                  {editingSheet ? "اطلاعات شیت را ویرایش کنید" : "اطلاعات شیت جدید را وارد کنید"}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="projectId">پروژه *</Label>
                    <Select
                      value={formData.projectId}
                      onValueChange={(value) => setFormData({ ...formData, projectId: value })}
                      disabled={!!editingSheet}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب پروژه" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects.map((project) => (
                          <SelectItem key={project.id} value={project.id}>
                            {project.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="sheetCode">کد شیت</Label>
                    <Input
                      id="sheetCode"
                      value={formData.sheetCode || ""}
                      onChange={(e) => setFormData({ ...formData, sheetCode: e.target.value })}
                      placeholder="مثلاً: QC-001"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="sheetType">نوع شیت *</Label>
                    <Select
                      value={formData.sheetType}
                      onValueChange={(value) => setFormData({ ...formData, sheetType: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب نوع" />
                      </SelectTrigger>
                      <SelectContent>
                        {sheetTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="status">وضعیت</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => setFormData({ ...formData, status: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب وضعیت" />
                      </SelectTrigger>
                      <SelectContent>
                        {statuses.map((status) => (
                          <SelectItem key={status.value} value={status.value}>
                            {status.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>تاریخ نمونه‌برداری *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-right font-normal",
                            !sampleDate && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {sampleDate ? (
                            toPersianDigits(format(sampleDate, "yyyy/MM/dd"))
                          ) : (
                            <span>انتخاب تاریخ</span>
                          )}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={sampleDate}
                          onSelect={(date) => {
                            setSampleDate(date);
                            if (date) {
                              setFormData({
                                ...formData,
                                sampleDate: format(date, "yyyy-MM-dd"),
                              });
                            }
                          }}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label>تاریخ آزمایش</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-right font-normal",
                            !testDate && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {testDate ? (
                            toPersianDigits(format(testDate, "yyyy/MM/dd"))
                          ) : (
                            <span>انتخاب تاریخ</span>
                          )}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={testDate}
                          onSelect={(date) => {
                            setTestDate(date);
                            if (date) {
                              setFormData({
                                ...formData,
                                testDate: format(date, "yyyy-MM-dd"),
                              });
                            }
                          }}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">محل نمونه‌برداری</Label>
                    <Input
                      id="location"
                      value={formData.location || ""}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="محل نمونه‌برداری"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="labName">نام آزمایشگاه</Label>
                    <Input
                      id="labName"
                      value={formData.labName || ""}
                      onChange={(e) => setFormData({ ...formData, labName: e.target.value })}
                      placeholder="نام آزمایشگاه"
                    />
                  </div>

                  <div className="space-y-2 col-span-2">
                    <Label htmlFor="specRef">مرجع استاندارد</Label>
                    <Input
                      id="specRef"
                      value={formData.specRef || ""}
                      onChange={(e) => setFormData({ ...formData, specRef: e.target.value })}
                      placeholder="مثلاً: ASTM D5, AASHTO T315"
                    />
                  </div>

                  <div className="space-y-2 col-span-2">
                    <Label htmlFor="notes">توضیحات</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes || ""}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      placeholder="توضیحات اضافی"
                      rows={3}
                    />
                  </div>

                  {!editingSheet && (
                    <div className="space-y-2 col-span-2">
                      <Label htmlFor="files">فایل‌های پیوست (حداکثر 5 فایل)</Label>
                      <Input
                        id="files"
                        type="file"
                        multiple
                        accept=".jpg,.jpeg,.png,.pdf,.xlsx,.xls,.doc,.docx"
                        onChange={(e) => setSelectedFiles(e.target.files)}
                      />
                      <p className="text-xs text-muted-foreground">
                        فرمت‌های مجاز: JPG, PNG, PDF, Excel, Word (حداکثر ۱۵ مگابایت)
                      </p>
                    </div>
                  )}
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => {
                    setOpen(false);
                    resetForm();
                  }}>
                    انصراف
                  </Button>
                  <Button type="submit" disabled={!formData.projectId || !formData.sheetType || !formData.sampleDate}>
                    {editingSheet ? "ویرایش" : "ایجاد"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative">
          <Search className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="جستجو در شیت‌ها..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
          />
        </div>

        <Select value={projectFilter} onValueChange={setProjectFilter}>
          <SelectTrigger>
            <SelectValue placeholder="همه پروژه‌ها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه پروژه‌ها</SelectItem>
            {projects.map((project) => (
              <SelectItem key={project.id} value={project.id}>
                {project.title}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={sheetTypeFilter} onValueChange={setSheetTypeFilter}>
          <SelectTrigger>
            <SelectValue placeholder="همه انواع" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه انواع</SelectItem>
            {sheetTypes.map((type) => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger>
            <SelectValue placeholder="همه وضعیت‌ها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            {statuses.map((status) => (
              <SelectItem key={status.value} value={status.value}>
                {status.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>کد شیت</TableHead>
              <TableHead>نوع</TableHead>
              <TableHead>پروژه</TableHead>
              <TableHead>تاریخ نمونه</TableHead>
              <TableHead>محل</TableHead>
              <TableHead>آزمایشگاه</TableHead>
              <TableHead>وضعیت</TableHead>
              <TableHead>عملیات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center">
                  در حال بارگذاری...
                </TableCell>
              </TableRow>
            ) : filteredSheets.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center">
                  شیتی یافت نشد
                </TableCell>
              </TableRow>
            ) : (
              filteredSheets.map((sheet) => (
                <TableRow key={sheet.id}>
                  <TableCell className="font-medium">
                    {sheet.sheetCode ? toPersianDigits(sheet.sheetCode) : "-"}
                  </TableCell>
                  <TableCell>{getSheetTypeLabel(sheet.sheetType)}</TableCell>
                  <TableCell>
                    {projects.find(p => p.id === sheet.projectId)?.title || "-"}
                  </TableCell>
                  <TableCell>
                    {sheet.sampleDate ? toPersianDigits(sheet.sampleDate) : "-"}
                  </TableCell>
                  <TableCell>{sheet.location || "-"}</TableCell>
                  <TableCell>{sheet.labName || "-"}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusVariant(sheet.status)}>
                      {getStatusLabel(sheet.status)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEdit(sheet)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(sheet.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
