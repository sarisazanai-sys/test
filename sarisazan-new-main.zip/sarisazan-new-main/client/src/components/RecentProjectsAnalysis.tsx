import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toPersianDigits } from "@/lib/persian-utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { ArrowUpRight, TrendingUp, TrendingDown, Calendar, Users } from "lucide-react";
import type { Project } from "@shared/schema";

interface RecentProjectsAnalysisProps {
  projects: Project[];
}

export default function RecentProjectsAnalysis({ projects }: RecentProjectsAnalysisProps) {
  const recentProjects = projects.slice(0, 6);
  
  const progressRanges = {
    low: projects.filter(p => (p.progress || 0) < 30).length,
    medium: projects.filter(p => (p.progress || 0) >= 30 && (p.progress || 0) < 70).length,
    high: projects.filter(p => (p.progress || 0) >= 70).length,
  };

  const contractorDistribution = projects.reduce((acc, p) => {
    const contractor = p.contractor || 'نامشخص';
    acc[contractor] = (acc[contractor] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const contractorData = Object.entries(contractorDistribution).map(([name, count]) => ({
    name: name.substring(0, 20),
    count
  }));

  const monthlyProgress = projects.slice(0, 8).map((p, i) => ({
    name: p.title?.substring(0, 15) + '...',
    progress: p.progress || 0,
    target: 80
  }));

  const avgProgress = projects.length > 0 
    ? Math.round(projects.reduce((sum, p) => sum + (p.progress || 0), 0) / projects.length)
    : 0;

  const activeProjects = projects.filter(p => p.status === 'active').length;
  const completedProjects = projects.filter(p => p.status === 'completed').length;

  const COLORS = {
    primary: '#3b82f6',
    success: '#10b981',
    warning: '#f59e0b',
    danger: '#ef4444',
    purple: '#8b5cf6',
    cyan: '#06b6d4'
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 border-green-200 dark:border-green-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-green-500/10 rounded-lg">
                <TrendingUp className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
              <Badge variant="outline" className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 border-green-300">
                میانگین کلی
              </Badge>
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-green-700 dark:text-green-400">
                {toPersianDigits(`${avgProgress}٪`)}
              </h3>
              <p className="text-sm text-muted-foreground">پیشرفت پروژه‌ها</p>
              <div className="relative pt-2">
                <div className="flex items-center justify-center">
                  <div className="relative w-24 h-24">
                    <svg className="w-full h-full transform -rotate-90">
                      <circle
                        cx="48"
                        cy="48"
                        r="40"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        className="text-green-200 dark:text-green-900"
                      />
                      <circle
                        cx="48"
                        cy="48"
                        r="40"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        strokeDasharray={`${2 * Math.PI * 40}`}
                        strokeDashoffset={`${2 * Math.PI * 40 * (1 - avgProgress / 100)}`}
                        className="text-green-600 dark:text-green-400 transition-all duration-1000"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-lg font-bold text-green-700 dark:text-green-400">
                        {toPersianDigits(`${avgProgress}٪`)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-950/20 dark:to-amber-950/20 border-orange-200 dark:border-orange-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-orange-500/10 rounded-lg">
                <Calendar className="w-6 h-6 text-orange-600 dark:text-orange-400" />
              </div>
              <Badge variant="outline" className="bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400 border-orange-300">
                آخرین ماه
              </Badge>
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-orange-700 dark:text-orange-400">
                {toPersianDigits(activeProjects.toString())}
              </h3>
              <p className="text-sm text-muted-foreground">پروژه فعال</p>
              <ResponsiveContainer width="100%" height={60}>
                <LineChart data={monthlyProgress.slice(0, 6)}>
                  <Line 
                    type="monotone" 
                    dataKey="progress" 
                    stroke={COLORS.warning} 
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-pink-50 dark:from-red-950/20 dark:to-pink-950/20 border-red-200 dark:border-red-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-red-500/10 rounded-lg">
                <TrendingDown className="w-6 h-6 text-red-600 dark:text-red-400" />
              </div>
              <Badge variant="outline" className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 border-red-300">
                نیاز به توجه
              </Badge>
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-red-700 dark:text-red-400">
                {toPersianDigits(progressRanges.low.toString())}
              </h3>
              <p className="text-sm text-muted-foreground">پروژه با پیشرفت کمتر از ۳۰٪</p>
              <ResponsiveContainer width="100%" height={60}>
                <LineChart data={[
                  { value: progressRanges.low },
                  { value: progressRanges.medium },
                  { value: progressRanges.high }
                ]}>
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke={COLORS.danger} 
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20 border-blue-200 dark:border-blue-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-blue-500/10 rounded-lg">
                <Users className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <Badge variant="outline" className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 border-blue-300">
                تکمیل شده
              </Badge>
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-blue-700 dark:text-blue-400">
                {toPersianDigits(`${completedProjects > 0 ? Math.round((completedProjects / projects.length) * 100) : 0}٪`)}
              </h3>
              <p className="text-sm text-muted-foreground">نرخ تکمیل</p>
              <Progress 
                value={completedProjects > 0 ? (completedProjects / projects.length) * 100 : 0} 
                className="h-2 bg-blue-200 dark:bg-blue-900"
              />
              <p className="text-xs text-muted-foreground mt-2">
                {toPersianDigits(completedProjects.toString())} از {toPersianDigits(projects.length.toString())} پروژه
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-blue-500"></div>
              پیشرفت پروژه‌ها
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {progressRanges.high > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">بالای ۷۰٪</span>
                    <span className="font-bold text-green-600">{toPersianDigits(progressRanges.high.toString())}</span>
                  </div>
                  <Progress value={(progressRanges.high / projects.length) * 100} className="h-2 bg-green-100" />
                </div>
              )}
              {progressRanges.medium > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">۳۰٪ تا ۷۰٪</span>
                    <span className="font-bold text-blue-600">{toPersianDigits(progressRanges.medium.toString())}</span>
                  </div>
                  <Progress value={(progressRanges.medium / projects.length) * 100} className="h-2 bg-blue-100" />
                </div>
              )}
              {progressRanges.low > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">زیر ۳۰٪</span>
                    <span className="font-bold text-orange-600">{toPersianDigits(progressRanges.low.toString())}</span>
                  </div>
                  <Progress value={(progressRanges.low / projects.length) * 100} className="h-2 bg-orange-100" />
                </div>
              )}
            </div>
            <div className="mt-6 pt-6 border-t">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">مجموع پروژه‌ها</span>
                <span className="text-lg font-bold">{toPersianDigits(projects.length.toString())}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-purple-500"></div>
              توزیع پیمانکاران
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={contractorData.slice(0, 5)}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="count"
                  label={({ name, count }) => count > 0 ? toPersianDigits(count.toString()) : ''}
                >
                  {contractorData.slice(0, 5).map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={[COLORS.primary, COLORS.success, COLORS.warning, COLORS.purple, COLORS.cyan][index % 5]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2">
              {contractorData.slice(0, 3).map((item, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: [COLORS.primary, COLORS.success, COLORS.warning][index] }}
                    ></div>
                    <span className="text-muted-foreground">{item.name}</span>
                  </div>
                  <span className="font-medium">{toPersianDigits(item.count.toString())}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              عملکرد اخیر
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyProgress}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis 
                  dataKey="name" 
                  tick={{ fontSize: 10, textAnchor: 'end' }}
                  angle={-45}
                  height={80}
                  interval={0}
                />
                <YAxis 
                  domain={[0, 100]}
                  tick={{ fontSize: 12 }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="progress" fill={COLORS.success} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
            پروژه‌های اخیر
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentProjects.map((project, index) => (
              <div 
                key={project.id}
                className="flex items-center gap-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-all hover:shadow-md"
              >
                <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
                  {toPersianDigits((index + 1).toString())}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold truncate">{project.title}</h4>
                  <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                    <span>{project.contractor || 'نامشخص'}</span>
                    <span>•</span>
                    <span>{project.contractNumber ? toPersianDigits(project.contractNumber) : '-'}</span>
                  </div>
                </div>
                <div className="flex-shrink-0 text-right space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{toPersianDigits(`${project.progress || 0}٪`)}</span>
                    {(project.progress || 0) >= 100 ? (
                      <Badge className="bg-green-500 hover:bg-green-600">تکمیل</Badge>
                    ) : (project.progress || 0) >= 70 ? (
                      <Badge className="bg-blue-500 hover:bg-blue-600">در حال اجرا</Badge>
                    ) : (
                      <Badge className="bg-orange-500 hover:bg-orange-600">نیاز به توجه</Badge>
                    )}
                  </div>
                  <Progress value={project.progress || 0} className="h-1 w-24" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
