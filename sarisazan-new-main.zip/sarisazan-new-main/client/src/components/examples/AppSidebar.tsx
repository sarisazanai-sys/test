import { AppSidebar } from '../app-sidebar';

export default function AppSidebarExample() {
  const currentUser = {
    name: "علی احمدی",
    role: "مدیر پروژه",
  };
  
  return <AppSidebar currentUser={currentUser} />;
}
