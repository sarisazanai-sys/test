import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger } from "@/components/ui/context-menu";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MessageSquare, Plus, Send, Paperclip, Search, Users, User, FolderOpen, File, X, Check, CheckCheck, Edit, Trash2, Reply, Forward, Pin, Archive, MoreVertical, Image, Video, Mic, MapPin, Clock, Smile } from "lucide-react";
import { format } from "date-fns-jalali";
import { useAuth } from "@/lib/auth-context";
import type { Conversation, Message, User as UserType, Project } from "@shared/schema";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

export default function MessagesPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messageContent, setMessageContent] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [chatSearchQuery, setChatSearchQuery] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingMessage, setEditingMessage] = useState<string | null>(null);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [selectedMessages, setSelectedMessages] = useState<Set<string>>(new Set());
  const [showMessageMenu, setShowMessageMenu] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const [newConversation, setNewConversation] = useState({
    type: "direct",
    title: "",
    memberIds: [] as string[],
    projectId: "",
    selectedUserId: "",
  });
  const [showArchived, setShowArchived] = useState(false);
  const [forwardingMessage, setForwardingMessage] = useState<Message | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Get user ID from localStorage for headers
  const getUserId = (): string | null => {
    try {
      const stored = localStorage.getItem("currentUser");
      if (stored) {
        const user = JSON.parse(stored);
        return user?.id || null;
      }
    } catch (error) {
      console.error("Failed to get user ID from localStorage:", error);
    }
    return null;
  };

  // Get headers with user ID
  const getHeaders = (includeContentType: boolean = false): HeadersInit => {
    const headers: HeadersInit = {};
    if (includeContentType) {
      headers["Content-Type"] = "application/json";
    }
    const userId = getUserId();
    if (userId) {
      headers["x-user-id"] = userId;
    }
    return headers;
  };

  const { data: users = [] } = useQuery<UserType[]>({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users", {
        headers: getHeaders(),
      });
      if (!response.ok) throw new Error("خطا در دریافت کاربران");
      return response.json();
    },
  });

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects", {
        headers: getHeaders(),
      });
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌ها");
      return response.json();
    },
  });

  const { data: conversations = [] } = useQuery<(Conversation & { unreadCount?: number })[]>({
    queryKey: ["/api/conversations", showArchived],
    queryFn: async () => {
      const response = await fetch(`/api/conversations?showArchived=${showArchived}`, {
        headers: getHeaders(),
      });
      if (!response.ok) throw new Error("خطا در دریافت مکالمات");
      return response.json();
    },
    refetchInterval: 5000, // Auto-refresh every 5 seconds to get updated unread counts
  });

  const { data: messages = [] } = useQuery<(Message & { sender?: UserType; files?: any[]; reads?: any[] })[]>({
    queryKey: [`/api/conversations/${selectedConversation}/messages`],
    queryFn: async () => {
      const response = await fetch(`/api/conversations/${selectedConversation}/messages`, {
        headers: getHeaders(),
      });
      if (!response.ok) throw new Error("خطا در دریافت پیام‌ها");
      return response.json();
    },
    enabled: !!selectedConversation,
    refetchInterval: 5000, // Auto-refresh every 5 seconds
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Request notification permission on mount
  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  // Track last message count to detect new messages
  const lastMessageCountRef = useRef<number>(0);
  const lastMessageIdsRef = useRef<Set<string>>(new Set());

  // Show notification for new messages
  useEffect(() => {
    if (!user?.id || messages.length === 0) return;
    
    // Check for new messages
    const currentMessageIds = new Set(messages.map(m => m.id));
    const newMessages = messages.filter(
      (msg) => 
        msg.senderId !== user.id && 
        !lastMessageIdsRef.current.has(msg.id) &&
        (!msg.reads || !msg.reads.some((r: any) => r.userId === user.id))
    );

    if (newMessages.length > 0) {
      const lastNewMessage = newMessages[newMessages.length - 1];
      const conversation = conversations.find(c => c.id === lastNewMessage.conversationId);
      const senderName = lastNewMessage.sender 
        ? `${lastNewMessage.sender.firstName || ""} ${lastNewMessage.sender.lastName || ""}`.trim() || "کاربر"
        : "کاربر";
      
      const conversationTitle = conversation?.title || senderName;
      
      // Show browser notification (only if page is hidden or message is from different conversation)
      if (("Notification" in window && Notification.permission === "granted") && 
          (document.hidden || lastNewMessage.conversationId !== selectedConversation)) {
        new Notification(conversationTitle, {
          body: `${senderName}: ${lastNewMessage.content || "🎤 پیام صوتی"}`,
          icon: "/favicon.ico",
          tag: `message-${lastNewMessage.id}`,
          requireInteraction: false,
        });
      }
      
      // Show toast notification (only if message is from different conversation or page is visible)
      if (lastNewMessage.conversationId !== selectedConversation || !document.hidden) {
        toast({
          title: "پیام جدید",
          description: `${conversationTitle}: ${lastNewMessage.content || "🎤 پیام صوتی"}`,
        });
      }
    }

    // Update refs
    lastMessageCountRef.current = messages.length;
    messages.forEach(msg => lastMessageIdsRef.current.add(msg.id));
  }, [messages, selectedConversation, user?.id, conversations]);

  // Mark messages as read when conversation is opened
  useEffect(() => {
    if (!selectedConversation || !user?.id) return;
    
    // Mark all unread messages in this conversation as read
    const unreadMessages = messages.filter(
      (msg) => msg.senderId !== user.id && (!msg.reads || !msg.reads.some((r: any) => r.userId === user.id))
    );

    if (unreadMessages.length > 0) {
      unreadMessages.forEach(async (msg) => {
        try {
          await fetch(`/api/messages/${msg.id}/read`, {
            method: "POST",
            headers: getHeaders(true),
            body: JSON.stringify({ userId: user.id }),
          });
        } catch (error) {
          console.error("Error marking message as read:", error);
        }
      });
      
      // Invalidate queries to refresh message status
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: [`/api/conversations/${selectedConversation}/messages`] });
        queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      }, 500);
    }
  }, [selectedConversation, messages, user?.id]);

  const createConversationMutation = useMutation({
    mutationFn: async (data: typeof newConversation) => {
      if (!user?.id) {
        throw new Error("کاربر احراز هویت نشده است");
      }
      
      // Prepare data for backend
      const { selectedUserId, ...conversationData } = data;
      
      // برای گفتگوهای مستقیم، memberIds را از selectedUserId بساز
      let memberIds = conversationData.memberIds || [];
      if (data.type === "direct" && selectedUserId) {
        memberIds = [selectedUserId]; // فقط کاربر انتخاب شده
      }
      
      const payload = {
        ...conversationData,
        memberIds, // ارسال memberIds به backend
        createdBy: user.id,
        // Convert empty projectId to null to avoid foreign key constraint violation
        projectId: conversationData.projectId && conversationData.projectId.trim() !== "" 
          ? conversationData.projectId 
          : null,
      };
      
      const res = await fetch("/api/conversations", {
        method: "POST",
        headers: getHeaders(true),
        body: JSON.stringify(payload),
      });
      
      if (!res.ok) {
        const errorText = await res.text();
        let errorMessage = "خطا در ایجاد گفتگو";
        try {
          const errorJson = JSON.parse(errorText);
          errorMessage = errorJson.message || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        throw new Error(errorMessage);
      }
      
      return res.json();
    },
    onSuccess: (newConv) => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setNewConversation({ type: "direct", title: "", memberIds: [], projectId: "", selectedUserId: "" });
      setIsCreateDialogOpen(false);
      setSelectedConversation(newConv.id);
    },
    onError: (error: Error) => {
      console.error("Error creating conversation:", error);
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message || "خطا در ایجاد گفتگو",
      });
    },
  });

  const editMessageMutation = useMutation({
    mutationFn: async ({ messageId, content }: { messageId: string; content: string }) => {
      const res = await fetch(`/api/messages/${messageId}`, {
        method: "PUT",
        headers: getHeaders(true),
        body: JSON.stringify({ content }),
      });
      if (!res.ok) {
        const errorText = await res.text();
        let errorMessage = "خطا در ویرایش پیام";
        try {
          const errorJson = JSON.parse(errorText);
          errorMessage = errorJson.message || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        throw new Error(errorMessage);
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${selectedConversation}/messages`] });
      setEditingMessage(null);
      toast({ title: "موفق", description: "پیام ویرایش شد" });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message || "خطا در ویرایش پیام",
      });
    },
  });

  const pinConversationMutation = useMutation({
    mutationFn: async ({ conversationId, isPinned }: { conversationId: string; isPinned: boolean }) => {
      const res = await fetch(`/api/conversations/${conversationId}/pin`, {
        method: "PUT",
        headers: getHeaders(true),
        body: JSON.stringify({ isPinned }),
      });
      if (!res.ok) throw new Error("خطا در pin/unpin گفتگو");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
  });

  const archiveConversationMutation = useMutation({
    mutationFn: async ({ conversationId, isArchived }: { conversationId: string; isArchived: boolean }) => {
      const res = await fetch(`/api/conversations/${conversationId}/archive`, {
        method: "PUT",
        headers: getHeaders(true),
        body: JSON.stringify({ isArchived }),
      });
      if (!res.ok) throw new Error("خطا در archive/unarchive گفتگو");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
  });

  const muteConversationMutation = useMutation({
    mutationFn: async ({ conversationId, isMuted }: { conversationId: string; isMuted: boolean }) => {
      const res = await fetch(`/api/conversations/${conversationId}/mute`, {
        method: "PUT",
        headers: getHeaders(true),
        body: JSON.stringify({ isMuted }),
      });
      if (!res.ok) throw new Error("خطا در mute/unmute گفتگو");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
  });

  const forwardMessageMutation = useMutation({
    mutationFn: async ({ messageId, conversationId }: { messageId: string; conversationId: string }) => {
      if (!user?.id) throw new Error("کاربر احراز هویت نشده است");
      const res = await fetch(`/api/messages/${messageId}/forward`, {
        method: "POST",
        headers: getHeaders(true),
        body: JSON.stringify({ conversationId, senderId: user.id }),
      });
      if (!res.ok) throw new Error("خطا در فوروارد پیام");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${selectedConversation}/messages`] });
      setForwardingMessage(null);
      toast({
        title: "✅ موفق",
        description: "پیام با موفقیت فوروارد شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "❌ خطا",
        description: error.message || "خطا در فوروارد پیام",
      });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: async ({ conversationId, content, files }: { conversationId: string; content: string; files?: File[] }) => {
      if (!user?.id) {
        throw new Error("کاربر احراز هویت نشده است");
      }
      
      const formData = new FormData();
      formData.append("senderId", user.id);
      formData.append("content", content || "");
      
      console.log("FormData prepared:", { senderId: user.id, content: content || "", filesCount: files?.length || 0 });
      
      if (files && files.length > 0) {
        files.forEach((file) => {
          formData.append("files", file);
        });
      }

      // Don't set Content-Type header for FormData - let browser set it with boundary
      const headers = getHeaders(false);
      // Remove Content-Type if it exists, browser will set it automatically for FormData
      delete (headers as any)["Content-Type"];
      
      console.log("Sending request to:", `/api/conversations/${conversationId}/messages`);
      const res = await fetch(`/api/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: headers,
        body: formData,
      });
      
      console.log("Response status:", res.status, res.statusText);
      
      if (!res.ok) {
        const errorText = await res.text();
        let errorMessage = "خطا در ارسال پیام";
        try {
          const errorJson = JSON.parse(errorText);
          errorMessage = errorJson.message || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        throw new Error(errorMessage);
      }
      
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${selectedConversation}/messages`] });
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setMessageContent("");
      setSelectedFiles([]);
      setReplyingTo(null);
    },
    onError: (error: Error) => {
      console.error("Error sending message:", error);
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message || "خطا در ارسال پیام",
      });
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(Array.from(e.target.files));
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const streamRef = useRef<MediaStream | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setAudioBlob(audioBlob);
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
          streamRef.current = null;
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error("Error starting recording:", error);
      toast({
        variant: "destructive",
        title: "خطا",
        description: "دسترسی به میکروفون امکان‌پذیر نیست",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setAudioBlob(null);
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }
    setAudioUrl(null);
    audioChunksRef.current = [];
  };

  const sendVoiceMessage = () => {
    if (!selectedConversation || !audioBlob) return;

    const audioFile = new File([audioBlob], `voice-${Date.now()}.webm`, { type: 'audio/webm' });
    sendMessageMutation.mutate({
      conversationId: selectedConversation,
      content: "🎤 پیام صوتی",
      files: [audioFile],
    });

    // Cleanup
    setAudioBlob(null);
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
      setAudioUrl(null);
    }
    audioChunksRef.current = [];
  };

  const handleSendMessage = () => {
    if (!selectedConversation || (!messageContent.trim() && selectedFiles.length === 0)) {
      console.log("Cannot send: no conversation or empty content", { selectedConversation, messageContent, selectedFiles });
      return;
    }
    
    console.log("Sending message:", { conversationId: selectedConversation, content: messageContent, files: selectedFiles.length });
    sendMessageMutation.mutate({
      conversationId: selectedConversation,
      content: messageContent,
      files: selectedFiles.length > 0 ? selectedFiles : undefined,
    });
  };

  const getConversationIcon = (type: string) => {
    switch (type) {
      case "direct": return <User className="h-4 w-4" />;
      case "group": return <Users className="h-4 w-4" />;
      case "project": return <FolderOpen className="h-4 w-4" />;
      default: return <MessageSquare className="h-4 w-4" />;
    }
  };

  const getConversationTypeLabel = (type: string) => {
    switch (type) {
      case "direct": return "مستقیم";
      case "group": return "گروهی";
      case "project": return "پروژه‌ای";
      default: return type;
    }
  };

  const getConversationTypeColor = (type: string) => {
    switch (type) {
      case "direct": return "bg-blue-500";
      case "group": return "bg-green-500";
      case "project": return "bg-purple-500";
      default: return "bg-gray-500";
    }
  };

  const selectedConversationData = conversations.find(c => c.id === selectedConversation);

  return (
    <div className="h-[calc(100vh-12rem)] max-w-full" dir="rtl">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-3xl font-bold">پیام‌ها و گفتگوها</h1>
            <p className="text-sm text-muted-foreground mt-1">
              مدیریت ارتباطات داخلی تیم
            </p>
          </div>
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="shadow-md">
                <Plus className="h-4 w-4 ml-2" />
                گفتگوی جدید
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>ایجاد گفتگوی جدید</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label>نوع گفتگو</Label>
                  <Select 
                    value={newConversation.type} 
                    onValueChange={(value) => setNewConversation({ ...newConversation, type: value, title: "", memberIds: [], selectedUserId: "", projectId: "" })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="direct">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4" />
                          <span>مستقیم (کاربر به کاربر)</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="group">
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          <span>گروهی</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="project">
                        <div className="flex items-center gap-2">
                          <FolderOpen className="h-4 w-4" />
                          <span>پروژه‌ای</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {newConversation.type === "direct" ? (
                  <div className="space-y-2">
                    <Label>انتخاب کاربر</Label>
                    <Select 
                      value={newConversation.selectedUserId} 
                      onValueChange={(value) => {
                        const selectedUser = users.find(u => u.id === value);
                        const userName = selectedUser 
                          ? `${selectedUser.firstName || ""} ${selectedUser.lastName || ""}`.trim() || selectedUser.username || "کاربر"
                          : "";
                        setNewConversation({ 
                          ...newConversation, 
                          selectedUserId: value,
                          memberIds: [value],
                          title: userName
                        });
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="کاربر را انتخاب کنید" />
                      </SelectTrigger>
                      <SelectContent>
                        {users
                          .filter(u => u.id !== user?.id)
                          .map((userItem) => (
                            <SelectItem key={userItem.id} value={userItem.id}>
                              {`${userItem.firstName || ""} ${userItem.lastName || ""}`.trim() || userItem.username || "کاربر"}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label>عنوان گفتگو</Label>
                    <Input
                      value={newConversation.title}
                      onChange={(e) => setNewConversation({ ...newConversation, title: e.target.value })}
                      placeholder="عنوان گفتگو را وارد کنید"
                    />
                  </div>
                )}

                {newConversation.type === "project" && (
                  <div className="space-y-2">
                    <Label>انتخاب پروژه</Label>
                    <Select 
                      value={newConversation.projectId} 
                      onValueChange={(value) => setNewConversation({ ...newConversation, projectId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب پروژه" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects.map((project) => (
                          <SelectItem key={project.id} value={project.id}>
                            {project.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <Button 
                  onClick={() => {
                    const conversationData = { ...newConversation };
                    // For direct conversations, ensure title is set from selected user
                    if (conversationData.type === "direct" && conversationData.selectedUserId) {
                      const selectedUser = users.find(u => u.id === conversationData.selectedUserId);
                      conversationData.title = selectedUser 
                        ? `${selectedUser.firstName || ""} ${selectedUser.lastName || ""}`.trim() || selectedUser.username || "کاربر"
                        : "گفتگوی مستقیم";
                    }
                    createConversationMutation.mutate(conversationData);
                  }} 
                  className="w-full"
                  disabled={
                    (newConversation.type === "direct" && !newConversation.selectedUserId) ||
                    (newConversation.type !== "direct" && !newConversation.title.trim()) ||
                    (newConversation.type === "project" && !newConversation.projectId)
                  }
                >
                  ایجاد گفتگو
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-12 gap-4 h-[calc(100vh-200px)] overflow-hidden">
          {/* Conversations List */}
          <Card className="col-span-12 md:col-span-4 lg:col-span-3 flex flex-col h-full overflow-hidden">
            <div className="p-4 border-b flex-shrink-0 space-y-2">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="جستجو در گفتگوها..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => setShowArchived(!showArchived)}
              >
                <Archive className="h-4 w-4 ml-2" />
                {showArchived ? "مخفی کردن آرشیو" : "نمایش آرشیو"}
              </Button>
            </div>
            <ScrollArea className="flex-1 min-h-0">
              {conversations.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <MessageSquare className="h-12 w-12 text-muted-foreground mb-3" />
                  <p className="text-sm text-muted-foreground">
                    هنوز گفتگویی وجود ندارد
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    برای شروع، گفتگوی جدیدی ایجاد کنید
                  </p>
                </div>
              ) : (
                conversations
                  .filter((conv) => 
                    !searchQuery || 
                    conv.title?.toLowerCase().includes(searchQuery.toLowerCase())
                  )
                  .map((conversation) => {
                    // Use unreadCount from conversation if available, otherwise calculate from messages
                    const unreadCount = (conversation as any).unreadCount ?? 
                      (conversation.id === selectedConversation 
                        ? messages.filter(
                            (msg) => msg.senderId !== user?.id && 
                            (!msg.reads || !msg.reads.some((r: any) => r.userId === user?.id))
                          ).length
                        : 0);
                    
                    return (
                      <div
                        key={conversation.id}
                        className={cn(
                          "p-4 border-b hover:bg-accent/50 transition-all duration-200 relative group",
                          selectedConversation === conversation.id && "bg-accent border-r-4 border-r-primary",
                          unreadCount > 0 && "bg-primary/5",
                          (conversation as any).isPinned && "bg-yellow-50 dark:bg-yellow-900/10"
                        )}
                      >
                        <div 
                          className="flex items-start gap-3 cursor-pointer"
                          onClick={() => setSelectedConversation(conversation.id)}
                        >
                          <div className={cn(
                            "p-2 rounded-lg relative",
                            getConversationTypeColor(conversation.type),
                            "bg-opacity-10"
                          )}>
                            {getConversationIcon(conversation.type)}
                            {unreadCount > 0 && (
                              <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold">
                                {unreadCount > 9 ? "9+" : unreadCount}
                              </span>
                            )}
                            {(conversation as any).isPinned && (
                              <Pin className="absolute -bottom-1 -left-1 h-3 w-3 text-yellow-600 fill-yellow-600" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <span className={cn(
                                "font-medium truncate",
                                unreadCount > 0 && "font-semibold"
                              )}>
                                {conversation.title || "بدون عنوان"}
                              </span>
                              <div className="flex items-center gap-2">
                                {unreadCount > 0 && (
                                  <Badge variant="default" className="text-xs h-5 min-w-5 px-1.5 flex items-center justify-center">
                                    {unreadCount > 9 ? "9+" : unreadCount}
                                  </Badge>
                                )}
                                <Badge variant="secondary" className="text-xs">
                                  {getConversationTypeLabel(conversation.type)}
                                </Badge>
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              {conversation.updatedAt && (
                                <span className="text-xs text-muted-foreground">
                                  {format(conversation.updatedAt, "yyyy/MM/dd HH:mm")}
                                </span>
                              )}
                              {(conversation as any).isMuted && (
                                <Mic className="h-3 w-3 text-muted-foreground" />
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="absolute left-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <MoreVertical className="h-3 w-3" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={(e) => {
                                  e.stopPropagation();
                                  pinConversationMutation.mutate({
                                    conversationId: conversation.id,
                                    isPinned: !(conversation as any).isPinned,
                                  });
                                }}
                              >
                                <Pin className="h-4 w-4 ml-2" />
                                {(conversation as any).isPinned ? "Unpin" : "Pin"}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={(e) => {
                                  e.stopPropagation();
                                  archiveConversationMutation.mutate({
                                    conversationId: conversation.id,
                                    isArchived: !(conversation as any).isArchived,
                                  });
                                }}
                              >
                                <Archive className="h-4 w-4 ml-2" />
                                {(conversation as any).isArchived ? "Unarchive" : "Archive"}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={(e) => {
                                  e.stopPropagation();
                                  muteConversationMutation.mutate({
                                    conversationId: conversation.id,
                                    isMuted: !(conversation as any).isMuted,
                                  });
                                }}
                              >
                                <Mic className="h-4 w-4 ml-2" />
                                {(conversation as any).isMuted ? "Unmute" : "Mute"}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    );
                  })
              )}
            </ScrollArea>
          </Card>

          {/* Messages Area */}
          <Card className="col-span-12 md:col-span-8 lg:col-span-9 flex flex-col h-full overflow-hidden">
            {!selectedConversation ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageSquare className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">گفتگوی خود را انتخاب کنید</h3>
                  <p className="text-sm text-muted-foreground">
                    برای مشاهده پیام‌ها، یک گفتگو از لیست سمت راست انتخاب کنید
                  </p>
                </div>
              </div>
            ) : (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b flex-shrink-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "p-2 rounded-lg",
                        getConversationTypeColor(selectedConversationData?.type || ""),
                        "bg-opacity-10"
                      )}>
                        {getConversationIcon(selectedConversationData?.type || "")}
                      </div>
                      <div>
                        <h3 className="font-semibold">
                          {selectedConversationData?.title || "بدون عنوان"}
                        </h3>
                        <p className="text-xs text-muted-foreground">
                          {getConversationTypeLabel(selectedConversationData?.type || "")}
                        </p>
                      </div>
                    </div>
                    <div className="relative">
                      <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="جستجو در چت..."
                        value={chatSearchQuery}
                        onChange={(e) => setChatSearchQuery(e.target.value)}
                        className="pr-10 w-48"
                      />
                    </div>
                  </div>
                </div>

                {/* Messages */}
                <ScrollArea className="flex-1 min-h-0 p-4">
                  {messages.length === 0 ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center">
                        <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                        <p className="text-sm text-muted-foreground">
                          هنوز پیامی ارسال نشده است
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          اولین پیام را ارسال کنید
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {messages
                        .filter((msg) => {
                          if (!chatSearchQuery) return !msg.deletedAt;
                          const searchLower = chatSearchQuery.toLowerCase();
                          return (
                            !msg.deletedAt &&
                            (msg.content?.toLowerCase().includes(searchLower) ||
                            msg.sender?.firstName?.toLowerCase().includes(searchLower) ||
                            msg.sender?.lastName?.toLowerCase().includes(searchLower))
                          );
                        })
                        .map((message) => {
                        const isMyMessage = message.senderId === user?.id;
                        const isEditing = editingMessage === message.id;
                        const messageStatus = message.status || "pending";
                        const hasReads = message.reads && message.reads.length > 0;
                        // Status logic: pending -> sent (یک تیک) -> read (دو تیک آبی)
                        const isRead = messageStatus === "read" || hasReads;
                        const isSent = messageStatus === "sent";
                        
                        return (
                          <ContextMenu key={message.id}>
                            <ContextMenuTrigger asChild>
                              <div
                                className={cn(
                                  "flex gap-3 group hover:bg-accent/50 p-2 rounded-lg transition-colors",
                                  isMyMessage ? "flex-row-reverse" : "flex-row"
                                )}
                              >
                                <Avatar className="h-8 w-8 mt-1">
                                  <AvatarFallback className={isMyMessage ? "bg-primary text-primary-foreground" : "bg-secondary"}>
                                    {message.sender?.firstName?.[0] || "U"}
                                  </AvatarFallback>
                                </Avatar>
                                <div className={cn("flex flex-col gap-1 max-w-[70%]", isMyMessage && "items-end")}>
                                  {message.replyToId && (
                                    <div className={cn(
                                      "text-xs p-2 rounded border-r-2 border-primary/50 bg-accent/50 mb-1",
                                      isMyMessage ? "text-right" : "text-left"
                                    )}>
                                      <div className="font-medium">پاسخ به:</div>
                                      <div className="text-muted-foreground truncate">
                                        {messages.find(m => m.id === message.replyToId)?.content || "پیام حذف شده"}
                                      </div>
                                    </div>
                                  )}
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-medium">
                                      {isMyMessage ? "شما" : `${message.sender?.firstName || ""} ${message.sender?.lastName || ""}`}
                                    </span>
                                    <span className="text-xs text-muted-foreground">
                                      {message.createdAt ? format(new Date(message.createdAt), "HH:mm") : ""}
                                    </span>
                                    {message.editedAt && (
                                      <span className="text-xs text-muted-foreground" title="ویرایش شده">
                                        (ویرایش شده)
                                      </span>
                                    )}
                                  </div>
                                  {isEditing ? (
                                    <div className="flex gap-2 items-end">
                                      <Textarea
                                        defaultValue={message.content || ""}
                                        className="min-h-[60px]"
                                        autoFocus
                                        onKeyDown={(e) => {
                                          if (e.key === "Escape") {
                                            setEditingMessage(null);
                                          } else if (e.key === "Enter" && !e.shiftKey) {
                                            e.preventDefault();
                                            const textarea = e.target as HTMLTextAreaElement;
                                            if (textarea.value.trim()) {
                                              editMessageMutation.mutate({
                                                messageId: message.id,
                                                content: textarea.value,
                                              });
                                            }
                                          }
                                        }}
                                      />
                                      <Button size="sm" onClick={() => setEditingMessage(null)}>
                                        <X className="h-4 w-4" />
                                      </Button>
                                    </div>
                                  ) : (
                                    <div className={cn(
                                      "rounded-2xl px-4 py-2 shadow-sm relative",
                                      isMyMessage 
                                        ? "bg-primary text-primary-foreground rounded-tr-sm" 
                                        : "bg-accent rounded-tl-sm"
                                    )}>
                                      {message.deletedAt ? (
                                        <p className="text-sm italic text-muted-foreground">این پیام حذف شده است</p>
                                      ) : (
                                        <>
                                          <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>
                                          {message.files && message.files.length > 0 && (
                                            <div className="mt-2 space-y-2">
                                              {message.files.map((file: any, index: number) => {
                                                const isAudio = file.mimeType?.startsWith('audio/') || file.originalName?.endsWith('.webm') || file.originalName?.endsWith('.mp3') || file.originalName?.endsWith('.wav');
                                                return (
                                                  <div key={index} className="flex items-center gap-2">
                                                    {isAudio ? (
                                                      <div className="flex flex-col gap-1 w-full">
                                                        <audio 
                                                          src={file.path} 
                                                          controls 
                                                          className="w-full h-8"
                                                          preload="metadata"
                                                        />
                                                        <span className="text-xs text-muted-foreground">{file.originalName}</span>
                                                      </div>
                                                    ) : (
                                                      <div className="flex items-center gap-2 text-xs">
                                                        <File className="h-3 w-3" />
                                                        <span>{file.originalName}</span>
                                                      </div>
                                                    )}
                                                  </div>
                                                );
                                              })}
                                            </div>
                                          )}
                                        </>
                                      )}
                                    </div>
                                  )}
                                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                    {isMyMessage && (
                                      <>
                                        {messageStatus === "pending" ? (
                                          <Clock className="h-3 w-3" />
                                        ) : isRead ? (
                                          <CheckCheck className="h-3 w-3 text-blue-500" />
                                        ) : isSent ? (
                                          <Check className="h-3 w-3" />
                                        ) : (
                                          <Check className="h-3 w-3" />
                                        )}
                                      </>
                                    )}
                                  </div>
                                </div>
                                {isMyMessage && !isEditing && (
                                  <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                      <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <MoreVertical className="h-4 w-4" />
                                      </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align={isMyMessage ? "end" : "start"}>
                                      <DropdownMenuItem onClick={() => setReplyingTo(message)}>
                                        <Reply className="h-4 w-4 ml-2" />
                                        پاسخ
                                      </DropdownMenuItem>
                                      <DropdownMenuItem onClick={() => setEditingMessage(message.id)}>
                                        <Edit className="h-4 w-4 ml-2" />
                                        ویرایش
                                      </DropdownMenuItem>
                                      <DropdownMenuItem 
                                        onClick={async () => {
                                          if (confirm("آیا مطمئن هستید که می‌خواهید این پیام را حذف کنید؟")) {
                                            try {
                                              const res = await fetch(`/api/messages/${message.id}`, {
                                                method: "DELETE",
                                                headers: getHeaders(),
                                              });
                                              if (res.ok) {
                                                queryClient.invalidateQueries({ queryKey: [`/api/conversations/${selectedConversation}/messages`] });
                                                toast({ title: "موفق", description: "پیام حذف شد" });
                                              }
                                            } catch (error) {
                                              toast({ variant: "destructive", title: "خطا", description: "خطا در حذف پیام" });
                                            }
                                          }
                                        }}
                                        className="text-destructive"
                                      >
                                        <Trash2 className="h-4 w-4 ml-2" />
                                        حذف
                                      </DropdownMenuItem>
                                    </DropdownMenuContent>
                                  </DropdownMenu>
                                )}
                              </div>
                            </ContextMenuTrigger>
                            <ContextMenuContent>
                              <ContextMenuItem onClick={() => setReplyingTo(message)}>
                                <Reply className="h-4 w-4 ml-2" />
                                پاسخ
                              </ContextMenuItem>
                              <ContextMenuItem onClick={() => setForwardingMessage(message)}>
                                <Forward className="h-4 w-4 ml-2" />
                                فوروارد
                              </ContextMenuItem>
                              {isMyMessage && (
                                <>
                                  <ContextMenuItem onClick={() => setEditingMessage(message.id)}>
                                    <Edit className="h-4 w-4 ml-2" />
                                    ویرایش
                                  </ContextMenuItem>
                                  <ContextMenuItem 
                                    onClick={async () => {
                                      if (confirm("آیا مطمئن هستید که می‌خواهید این پیام را حذف کنید؟")) {
                                        try {
                                          const res = await fetch(`/api/messages/${message.id}`, {
                                            method: "DELETE",
                                            headers: getHeaders(),
                                          });
                                          if (res.ok) {
                                            queryClient.invalidateQueries({ queryKey: [`/api/conversations/${selectedConversation}/messages`] });
                                            toast({ title: "موفق", description: "پیام حذف شد" });
                                          }
                                        } catch (error) {
                                          toast({ variant: "destructive", title: "خطا", description: "خطا در حذف پیام" });
                                        }
                                      }
                                    }}
                                    className="text-destructive"
                                  >
                                    <Trash2 className="h-4 w-4 ml-2" />
                                    حذف
                                  </ContextMenuItem>
                                </>
                              )}
                            </ContextMenuContent>
                          </ContextMenu>
                        );
                      })}
                      <div ref={messagesEndRef} />
                    </div>
                  )}
                </ScrollArea>

                {/* Message Input */}
                <div className="p-4 border-t flex-shrink-0">
                  {replyingTo && (
                    <div className="mb-2 p-2 bg-accent rounded-lg flex items-center justify-between">
                      <div className="flex-1">
                        <div className="text-xs font-medium mb-1">پاسخ به:</div>
                        <div className="text-xs text-muted-foreground truncate">
                          {replyingTo.content || "پیام"}
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => setReplyingTo(null)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                  {audioUrl && audioBlob && (
                    <div className="mb-2 p-3 bg-accent rounded-lg flex items-center justify-between">
                      <div className="flex items-center gap-3 flex-1">
                        <audio src={audioUrl} controls className="h-8 flex-1" />
                        <span className="text-xs text-muted-foreground">
                          {(audioBlob.size / 1024).toFixed(1)} KB
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" onClick={sendVoiceMessage}>
                          <Send className="h-4 w-4 ml-1" />
                          ارسال
                        </Button>
                        <Button size="sm" variant="ghost" onClick={cancelRecording}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                  {selectedFiles.length > 0 && (
                    <div className="mb-2 flex flex-wrap gap-2">
                      {selectedFiles.map((file, index) => (
                        <div key={index} className="flex items-center gap-2 bg-accent px-3 py-1 rounded-lg text-sm">
                          <File className="h-4 w-4" />
                          <span className="max-w-[150px] truncate">{file.name}</span>
                          <button onClick={() => removeFile(index)} className="hover:text-destructive">
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="flex gap-2">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileSelect}
                      multiple
                      className="hidden"
                    />
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => fileInputRef.current?.click()}
                      title="پیوست فایل"
                    >
                      <Paperclip className="h-4 w-4" />
                    </Button>
                    {isRecording ? (
                      <Button
                        variant="destructive"
                        size="icon"
                        onClick={stopRecording}
                        title="توقف ضبط"
                        className="animate-pulse"
                      >
                        <Mic className="h-4 w-4" />
                      </Button>
                    ) : (
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={startRecording}
                        title="ضبط صدا"
                        disabled={!!audioUrl}
                      >
                        <Mic className="h-4 w-4" />
                      </Button>
                    )}
                    <Textarea
                      value={messageContent}
                      onChange={(e) => setMessageContent(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      placeholder={replyingTo ? "پاسخ خود را بنویسید..." : "پیام خود را بنویسید... (Enter برای ارسال، Shift+Enter برای خط جدید)"}
                      className="min-h-[60px] resize-none"
                      disabled={isRecording}
                    />
                    <Button 
                      onClick={handleSendMessage}
                      disabled={(!messageContent.trim() && selectedFiles.length === 0) || isRecording}
                      size="icon"
                      className="h-[60px]"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            )}
          </Card>
        </div>
      </div>

      {/* Forward Message Dialog */}
      <Dialog open={!!forwardingMessage} onOpenChange={(open) => !open && setForwardingMessage(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>فوروارد پیام</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="p-3 bg-accent rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">پیام:</p>
              <p className="text-sm">{forwardingMessage?.content}</p>
            </div>
            <div className="space-y-2">
              <Label>انتخاب گفتگوی مقصد</Label>
              <Select
                onValueChange={(conversationId) => {
                  if (forwardingMessage) {
                    forwardMessageMutation.mutate({
                      messageId: forwardingMessage.id,
                      conversationId,
                    });
                  }
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="گفتگو را انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  {conversations
                    .filter(c => c.id !== selectedConversation)
                    .map((conv) => (
                      <SelectItem key={conv.id} value={conv.id}>
                        {conv.title || "بدون عنوان"}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
