import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toPersianDigits, formatCurrency, parsePersianNumber } from "@/lib/persian-utils";
import { 
  DollarSign, 
  TrendingUp, 
  FolderKanban, 
  AlertTriangle, 
  AlertCircle,
  CheckCircle, 
  FileText,
  Calculator,
  Wallet,
  Users,
  Download,
  Gavel,
  ClipboardList,
  TrendingDown,
  Activity,
  Target,
  Calendar,
  Shield,
  Droplet,
  Search,
  Clock,
} from "lucide-react";
import type { Project, Alert, Task } from "@shared/schema";
import { 
  BarChart, 
  Bar, 
  LineChart,
  Line,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Area,
  AreaChart,
  ScatterChart,
  Scatter,
  ComposedChart
} from "recharts";

type FinancialStats = {
  totalContractAmount: number;
  totalStatements: number;
  totalAdjustments: number;
  totalBitumenDiffs: number;
  totalFinancialProgress: number;
  financialProgressPercentage: number;
  monthlyProgress: { month: string; amount: number }[];
  projectCount: number;
  statementCount: number;
  adjustmentCount: number;
  bitumenDiffCount: number;
};

type ProjectComparison = {
  id: string;
  title: string;
  contractNumber: string | null;
  contractAmount: number;
  lastStatementAmount: number;
  physicalProgress: number;
  financialProgress: number;
  progressDiff: number;
  status: string;
  isAtRisk: boolean;
};

type AtRiskProject = {
  id: string;
  title: string;
  contractNumber: string | null;
  physicalProgress: number;
  financialProgress: number;
  status: string;
  riskLevel: "high" | "medium" | "low";
  reason: string;
};

type UserStats = {
  totalUsers: number;
  activeUsers: number;
  totalTasks: number;
  completedTasks: number;
  openAlerts: number;
  userActivity: Array<{
    id: string;
    name: string;
    tasksCount: number;
    completedTasksCount: number;
  }>;
};

type TendersStats = {
  total: number;
  open: number;
  closed: number;
  expired: number;
  nearDeadline: number;
};

type SheetsStats = {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
  byType: Record<string, number>;
};

type SCurveData = {
  month: string;
  planned: number;
  actual: number;
};

type BudgetVariance = {
  id: string;
  title: string;
  contractNumber: string | null;
  contractAmount: number;
  spentAmount: number;
  budgetVariance: number;
  budgetVariancePercent: number;
  physicalProgress: number;
  financialProgress: number;
  progressVariance: number;
  status: string;
};

type CashFlowData = {
  month: string;
  actual: number;
  projected: number;
};

type Milestone = {
  date: string;
  title: string;
  type: string;
  projectId: string;
  projectTitle: string;
};

type RiskSummary = {
  total: number;
  high: number;
  medium: number;
  low: number;
  risks: Array<{
    id: string;
    title: string;
    description: string | null;
    severity: string;
    status: string;
    projectId: string | null;
    projectTitle: string;
    createdAt: string | null;
    impact: string;
    probability: string;
  }>;
};

// Helper function to map status from DB to Persian
const getStatusLabel = (status: string | null | undefined): string => {
  if (!status) return "نامشخص";
  const statusMap: Record<string, string> = {
    "active": "در حال اجرا",
    "completed": "تکمیل شده",
    "pending": "در انتظار",
    "suspended": "متوقف شده",
    "در حال اجرا": "در حال اجرا", // Support both formats
    "تکمیل شده": "تکمیل شده",
  };
  return statusMap[status] || status;
};

// Helper function to check if status is active
const isActiveStatus = (status: string | null | undefined): boolean => {
  return status === "active" || status === "در حال اجرا";
};

// Helper function to check if status is completed
const isCompletedStatus = (status: string | null | undefined): boolean => {
  return status === "completed" || status === "تکمیل شده";
};

// Helper function to calculate financial progress for a project
const calculateProjectFinancialProgress = (project: Project): number => {
  try {
    if (!project.amount || !project.lastStatementAmount) return 0;
    const amountStr = String(project.amount || "0");
    const contractAmount = parsePersianNumber(amountStr);
    if (contractAmount === 0 || isNaN(contractAmount)) return 0;

    const lastStatementAmountStr = String(project.lastStatementAmount || "0");
    const lastStatementAmount = parsePersianNumber(lastStatementAmountStr);
    
    if (lastStatementAmount === 0 || isNaN(lastStatementAmount)) return 0;
    if (contractAmount === 0) return 0;
    
    return parseFloat(((lastStatementAmount / contractAmount) * 100).toFixed(2));
  } catch (error) {
    console.error("Error calculating financial progress:", error);
    return 0;
  }
};

// Empty State Component
const EmptyState = ({ 
  icon: Icon, 
  title, 
  description, 
  action 
}: { 
  icon: any; 
  title: string; 
  description?: string; 
  action?: React.ReactNode;
}) => (
  <div className="h-[320px] flex flex-col items-center justify-center text-center p-6">
    <Icon className="h-16 w-16 text-muted-foreground/50 mb-4" />
    <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
    {description && (
      <p className="text-sm text-muted-foreground max-w-md mb-4">{description}</p>
    )}
    {action && <div className="mt-2">{action}</div>}
  </div>
);

// Format currency helper - unified
const formatCurrencyUnified = (value: number, showUnit: boolean = true): string => {
  if (value === 0 || isNaN(value)) return "۰";
  const billions = value / 1000000000;
  if (billions >= 1) {
    return `${formatCurrency(billions.toFixed(1))}${showUnit ? " میلیارد ریال" : ""}`;
  }
  const millions = value / 1000000;
  if (millions >= 1) {
    return `${formatCurrency(millions.toFixed(1))}${showUnit ? " میلیون ریال" : ""}`;
  }
  return `${formatCurrency(value.toFixed(0))}${showUnit ? " ریال" : ""}`;
};

export default function ManagementDashboard() {
  const [timeFilter, setTimeFilter] = useState<"all" | "month" | "quarter" | "year">("all");
  const [projectFilter, setProjectFilter] = useState<"all" | "active" | "at-risk" | "completed">("all");
  const [searchQuery, setSearchQuery] = useState("");
  
  const getUserId = (): string | null => {
    try {
      const stored = localStorage.getItem("currentUser");
      if (stored) {
        const user = JSON.parse(stored);
        return user?.id || null;
      }
    } catch (error) {
      console.error("Failed to get user ID from localStorage:", error);
    }
    return null;
  };

  const getHeaders = (): HeadersInit => {
    const headers: Record<string, string> = {};
    const userId = getUserId();
    if (userId) {
      headers["x-user-id"] = userId;
    }
    return headers as HeadersInit;
  };

  // Check if user is authenticated
  const userId = getUserId();

  const { data: projects = [], isLoading: isLoadingProjects } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const headers = getHeaders();
      const headerRecord = headers as Record<string, string>;
      if (!headerRecord["x-user-id"]) {
        throw new Error("احراز هویت لازم است. لطفاً دوباره وارد سیستم شوید.");
      }
      const response = await fetch("/api/projects", { headers });
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("احراز هویت لازم است. لطفاً دوباره وارد سیستم شوید.");
        }
        throw new Error("خطا در دریافت پروژه‌ها");
      }
      return response.json();
    },
    enabled: !!userId, // Only fetch if user ID exists
    retry: false,
  });

  const { data: alerts = [], isLoading: isLoadingAlerts } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
    queryFn: async () => {
      const headers = getHeaders();
      const headerRecord = headers as Record<string, string>;
      if (!headerRecord["x-user-id"]) {
        return []; // Return empty if not authenticated
      }
      const response = await fetch("/api/alerts", { headers });
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          return []; // Return empty for permission errors
        }
        throw new Error("خطا در دریافت هشدارها");
      }
      return response.json();
    },
    enabled: !!userId, // Only fetch if user ID exists
    retry: false,
  });

  const { data: tasks = [], isLoading: isLoadingTasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    queryFn: async () => {
      const response = await fetch("/api/tasks", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت وظایف");
      return response.json();
    },
  });

  const { data: financialStats, isLoading: isLoadingFinancialStats } = useQuery<FinancialStats>({
    queryKey: ["/api/dashboard/financial-stats"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/financial-stats", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت آمار مالی");
      return response.json();
    },
  });

  const { data: projectsComparison = [], isLoading: isLoadingComparison } = useQuery<ProjectComparison[]>({
    queryKey: ["/api/dashboard/projects-comparison"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/projects-comparison", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت مقایسه پروژه‌ها");
      return response.json();
    },
  });

  const { data: atRiskProjects = [], isLoading: isLoadingAtRisk } = useQuery<AtRiskProject[]>({
    queryKey: ["/api/dashboard/at-risk-projects"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/at-risk-projects", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت پروژه‌های در معرض خطر");
      return response.json();
    },
  });

  const { data: userStats, isLoading: isLoadingUserStats } = useQuery<UserStats>({
    queryKey: ["/api/dashboard/user-stats"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/user-stats", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت آمار کاربران");
      return response.json();
    },
  });

  const { data: tendersStats, isLoading: isLoadingTendersStats } = useQuery<TendersStats>({
    queryKey: ["/api/dashboard/tenders-stats"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/tenders-stats", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت آمار مناقصات");
      return response.json();
    },
  });

  const { data: sheetsStats, isLoading: isLoadingSheetsStats } = useQuery<SheetsStats>({
    queryKey: ["/api/dashboard/sheets-stats"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/sheets-stats", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت آمار شیت‌ها");
      return response.json();
    },
  });

  const { data: sCurveData = [], isLoading: isLoadingSCurve } = useQuery<SCurveData[]>({
    queryKey: ["/api/dashboard/s-curve"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/s-curve", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت داده‌های S-Curve");
      return response.json();
    },
  });

  const { data: budgetVariance = [], isLoading: isLoadingBudgetVariance } = useQuery<BudgetVariance[]>({
    queryKey: ["/api/dashboard/budget-variance"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/budget-variance", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت تحلیل انحرافات");
      return response.json();
    },
  });

  const { data: cashFlowData = [], isLoading: isLoadingCashFlow } = useQuery<CashFlowData[]>({
    queryKey: ["/api/dashboard/cash-flow"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/cash-flow", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت جریان نقدی");
      return response.json();
    },
  });

  const { data: milestones = [], isLoading: isLoadingMilestones } = useQuery<Milestone[]>({
    queryKey: ["/api/dashboard/milestones"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/milestones", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت Milestones");
      return response.json();
    },
  });

  const { data: riskSummary, isLoading: isLoadingRisks } = useQuery<RiskSummary>({
    queryKey: ["/api/dashboard/risks"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard/risks", { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت مدیریت ریسک");
      return response.json();
    },
  });

  const isLoading = isLoadingProjects || isLoadingAlerts || isLoadingTasks || isLoadingFinancialStats || 
                    isLoadingComparison || isLoadingAtRisk || isLoadingUserStats || isLoadingTendersStats || isLoadingSheetsStats ||
                    isLoadingSCurve || isLoadingBudgetVariance || isLoadingCashFlow || isLoadingMilestones || isLoadingRisks;

  // Calculate project statistics with correct status mapping
  const activeProjects = projects.filter(p => isActiveStatus(p.status)).length;
  const completedProjects = projects.filter(p => isCompletedStatus(p.status)).length;
  const suspendedProjects = projects.filter(p => p.status === "suspended" || p.status === "متوقف شده").length;
  const pendingProjects = projects.filter(p => p.status === "pending" || p.status === "در انتظار").length;
  
  // Calculate average progress (using financial progress if available, otherwise physical)
  const averageProgress = useMemo(() => {
    if (projects.length === 0) return 0;
    const totalProgress = projects.reduce((sum, p) => {
      const financialProgress = calculateProjectFinancialProgress(p);
      const physicalProgress = p.progress || 0;
      // Use financial progress if available, otherwise physical
      return sum + (financialProgress > 0 ? financialProgress : physicalProgress);
    }, 0);
    return Math.round(totalProgress / projects.length);
  }, [projects]);

  // Calculate average financial progress
  const averageFinancialProgress = useMemo(() => {
    if (projects.length === 0) return 0;
    const totalFinancialProgress = projects.reduce((sum, p) => {
      return sum + calculateProjectFinancialProgress(p);
    }, 0);
    return parseFloat((totalFinancialProgress / projects.length).toFixed(2));
  }, [projects]);

  const openAlerts = alerts.filter(a => a.status === "open" || a.status === "باز").length;
  const completedTasks = tasks.filter(t => t.isCompleted).length;
  const totalTasks = tasks.length;

  // Filter projects based on filters - MUST BE DEFINED BEFORE USE
  const filteredProjects = useMemo(() => {
    let filtered = projects;
    
    // Status filter
    if (projectFilter === "active") {
      filtered = filtered.filter(p => isActiveStatus(p.status));
    } else if (projectFilter === "completed") {
      filtered = filtered.filter(p => isCompletedStatus(p.status));
    } else if (projectFilter === "at-risk") {
      filtered = filtered.filter(p => {
        const financialProgress = calculateProjectFinancialProgress(p);
        const physicalProgress = p.progress || 0;
        return physicalProgress < 50 || financialProgress < 30 || financialProgress > 110;
      });
    }
    
    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(p => 
        p.title?.toLowerCase().includes(query) ||
        p.contractNumber?.toLowerCase().includes(query) ||
        p.employer?.toLowerCase().includes(query) ||
        p.contractor?.toLowerCase().includes(query)
      );
    }
    
    return filtered;
  }, [projects, projectFilter, searchQuery]);

  // Calculate insights and trends
  const criticalProjectsCount = useMemo(() => {
    return filteredProjects.filter(p => {
      const financialProgress = calculateProjectFinancialProgress(p);
      const physicalProgress = p.progress || 0;
      return physicalProgress < 30 || financialProgress < 20 || financialProgress > 110;
    }).length;
  }, [filteredProjects]);

  // Calculate at-risk projects (medium risk)
  const atRiskProjectsCount = useMemo(() => {
    return filteredProjects.filter(p => {
      const financialProgress = calculateProjectFinancialProgress(p);
      const physicalProgress = p.progress || 0;
      return (physicalProgress < 50 && physicalProgress >= 30) || (financialProgress < 30 && financialProgress >= 20);
    }).length;
  }, [filteredProjects]);

  // Calculate burn rate (spending rate)
  const burnRate = useMemo(() => {
    if (!financialStats || !financialStats.totalContractAmount) return 0;
    const spent = financialStats.totalFinancialProgress;
    const total = financialStats.totalContractAmount;
    if (total === 0) return 0;
    return parseFloat(((spent / total) * 100).toFixed(2));
  }, [financialStats]);

  // Calculate delay risk (projects with low progress)
  const delayRisk = useMemo(() => {
    return filteredProjects.filter(p => {
      const financialProgress = calculateProjectFinancialProgress(p);
      const physicalProgress = p.progress || 0;
      return financialProgress < 30 && physicalProgress < 30;
    }).length;
  }, [filteredProjects]);

  const projectProgressData = filteredProjects
    .slice(0, 8)
    .map(p => {
      const financialProgress = calculateProjectFinancialProgress(p);
      return {
        name: p.title.length > 25 ? p.title.substring(0, 25) + "..." : p.title,
        progress: p.progress || 0,
        financial: financialProgress
      };
    });

  const statusDistribution = [
    { name: "در حال اجرا", value: activeProjects, color: "#10b981" },
    { name: "تکمیل شده", value: completedProjects, color: "#3b82f6" },
    { name: "متوقف شده", value: suspendedProjects, color: "#f59e0b" },
    { name: "در انتظار", value: pendingProjects, color: "#6b7280" },
  ].filter(s => s.value > 0);

  const financialBreakdown = financialStats ? [
    { name: "صورت‌وضعیت‌ها", value: financialStats.totalStatements, color: "#10b981" },
    { name: "تعدیل‌ها", value: financialStats.totalAdjustments, color: "#3b82f6" },
    { name: "مابه‌التفاوت قیر", value: Math.abs(financialStats.totalBitumenDiffs), color: "#a855f7" },
  ].filter(s => s.value > 0) : [];

  const monthlyProgressData = useMemo(() => {
    try {
      if (!financialStats?.monthlyProgress || !Array.isArray(financialStats.monthlyProgress)) {
        return [];
      }
      return financialStats.monthlyProgress.map(mp => {
        if (!mp || !mp.month) return null;
        const monthStr = String(mp.month);
        const month = monthStr.length >= 7 ? monthStr.substring(5, 7) : monthStr;
        const amount = (mp.amount || 0) / 1000000000;
        return { month, amount };
      }).filter(Boolean) as { month: string; amount: number }[];
    } catch (error) {
      console.error("Error processing monthlyProgressData:", error);
      return [];
    }
  }, [financialStats?.monthlyProgress]);

  // فیلتر داده‌ها بر اساس زمان
  const filteredMonthlyData = useMemo(() => {
    if (!financialStats?.monthlyProgress) return [];
    
    const now = new Date();
    let filterDate = new Date();
    
    switch (timeFilter) {
      case "month":
        filterDate.setMonth(now.getMonth() - 1);
        break;
      case "quarter":
        filterDate.setMonth(now.getMonth() - 3);
        break;
      case "year":
        filterDate.setFullYear(now.getFullYear() - 1);
        break;
      default:
        return financialStats.monthlyProgress;
    }
    
    return financialStats.monthlyProgress.filter(mp => {
      try {
        if (!mp || !mp.month) return false;
        const monthDate = new Date(String(mp.month) + "-01");
        return monthDate >= filterDate;
      } catch (error) {
        console.error("Error filtering monthly progress:", error);
        return false;
      }
    });
  }, [financialStats, timeFilter]);

  // داده‌های نمودار پیشرفت مالی vs فیزیکی
  const progressComparisonData = useMemo(() => {
    try {
      if (!projectsComparison || !Array.isArray(projectsComparison)) {
        return [];
      }
      return projectsComparison.slice(0, 10).map(p => ({
        name: (p.title || "").length > 20 ? (p.title || "").substring(0, 20) + "..." : (p.title || ""),
        physical: p.physicalProgress || 0,
        financial: p.financialProgress || 0,
      }));
    } catch (error) {
      console.error("Error processing progressComparisonData:", error);
      return [];
    }
  }, [projectsComparison]);

  // Export به PDF
  const handleExportPDF = () => {
    window.print();
  };

  if (isLoading) {
      return (
        <div className="container mx-auto p-6 space-y-6" dir="rtl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">داشبورد مدیریتی</h1>
            <p className="text-muted-foreground mt-1">نمای کامل وضعیت پروژه‌ها و عملکرد مالی</p>
          </div>
        </div>

        {/* Financial KPIs Skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="border-r-4 border-r-gray-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-5 w-5 rounded" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-24 mb-1" />
                <Skeleton className="h-3 w-20" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Project KPIs Skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="border-r-4 border-r-gray-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-28" />
                <Skeleton className="h-4 w-4 rounded" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-20 mb-1" />
                <Skeleton className="h-3 w-24" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts Skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(2)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-48 mb-2" />
                <Skeleton className="h-4 w-64" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-[300px] w-full" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* More Charts Skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(2)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-40 mb-2" />
                <Skeleton className="h-4 w-56" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-[300px] w-full" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Table Skeleton */}
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-44 mb-2" />
            <Skeleton className="h-4 w-64" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center gap-4">
                  <Skeleton className="h-4 flex-1" />
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-4 w-16" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold">داشبورد مدیریتی</h1>
          <p className="text-muted-foreground mt-1">نمای کامل وضعیت پروژه‌ها و عملکرد مالی</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={timeFilter} onValueChange={(value: any) => setTimeFilter(value)}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="فیلتر زمانی" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">همه زمان‌ها</SelectItem>
              <SelectItem value="month">ماه جاری</SelectItem>
              <SelectItem value="quarter">سه ماهه</SelectItem>
              <SelectItem value="year">سال جاری</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleExportPDF} variant="outline" size="sm">
            <Download className="h-4 w-4 ml-2" />
            خروجی PDF
          </Button>
        </div>
      </div>

      {/* Financial KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="border-r-4 border-r-emerald-500 bg-gradient-to-br from-emerald-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">مبلغ کل قراردادها</CardTitle>
            <DollarSign className="h-5 w-5 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">
              {financialStats ? formatCurrency((financialStats.totalContractAmount / 1000000000).toFixed(1)) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">میلیارد ریال</p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-blue-500 bg-gradient-to-br from-blue-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">پیشرفت ریالی</CardTitle>
            <Wallet className="h-5 w-5 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {financialStats ? formatCurrency((financialStats.totalFinancialProgress / 1000000000).toFixed(1)) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {financialStats ? `${toPersianDigits(financialStats.financialProgressPercentage.toFixed(1))}٪ از کل` : "میلیارد ریال"}
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-purple-500 bg-gradient-to-br from-purple-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">صورت‌وضعیت‌ها</CardTitle>
            <FileText className="h-5 w-5 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {financialStats ? toPersianDigits(financialStats.statementCount.toString()) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {financialStats ? `${formatCurrency((financialStats.totalStatements / 1000000000).toFixed(1))} میلیارد` : "تایید شده"}
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-orange-500 bg-gradient-to-br from-orange-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">تعدیل‌ها</CardTitle>
            <Calculator className="h-5 w-5 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {financialStats ? toPersianDigits(financialStats.adjustmentCount.toString()) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {financialStats ? `${formatCurrency((financialStats.totalAdjustments / 1000000000).toFixed(1))} میلیارد` : "تایید شده"}
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-pink-500 bg-gradient-to-br from-pink-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">مابه‌التفاوت قیر</CardTitle>
            <TrendingUp className="h-5 w-5 text-pink-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-pink-600">
              {financialStats ? toPersianDigits(financialStats.bitumenDiffCount.toString()) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {financialStats ? `${formatCurrency((financialStats.totalBitumenDiffs / 1000000000).toFixed(1))} میلیارد` : "تایید شده"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Critical KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-r-4 border-r-red-500 bg-gradient-to-br from-red-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">پروژه‌های بحرانی</CardTitle>
            <AlertTriangle className="h-5 w-5 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {toPersianDigits(criticalProjectsCount.toString())}
            </div>
            <p className="text-xs text-muted-foreground mt-1">نیاز به بررسی فوری</p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-orange-500 bg-gradient-to-br from-orange-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">پروژه‌های در معرض خطر</CardTitle>
            <AlertCircle className="h-5 w-5 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {toPersianDigits(atRiskProjectsCount.toString())}
            </div>
            <p className="text-xs text-muted-foreground mt-1">نیاز به نظارت</p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-amber-500 bg-gradient-to-br from-amber-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">نرخ مصرف بودجه</CardTitle>
            <TrendingDown className="h-5 w-5 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">
              {toPersianDigits(burnRate.toFixed(1))}%
            </div>
            <p className="text-xs text-muted-foreground mt-1">از کل بودجه مصرف شده</p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-yellow-500 bg-gradient-to-br from-yellow-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ریسک تأخیر</CardTitle>
            <Clock className="h-5 w-5 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {toPersianDigits(delayRisk.toString())}
            </div>
            <p className="text-xs text-muted-foreground mt-1">پروژه با پیشرفت پایین</p>
          </CardContent>
        </Card>
      </div>

      {/* Additional Stats Cards - Moved here for better visibility */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-r-4 border-r-indigo-500 bg-gradient-to-br from-indigo-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">کاربران فعال</CardTitle>
            <Users className="h-4 w-4 text-indigo-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">
              {userStats ? toPersianDigits(userStats.activeUsers.toString()) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              از {userStats ? toPersianDigits(userStats.totalUsers.toString()) : "۰"} کاربر
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-amber-500 bg-gradient-to-br from-amber-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">مناقصات</CardTitle>
            <Gavel className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">
              {tendersStats ? toPersianDigits(tendersStats.open.toString()) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {tendersStats ? `${toPersianDigits(tendersStats.nearDeadline.toString())} با مهلت نزدیک` : "باز"}
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-teal-500 bg-gradient-to-br from-teal-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">شیت‌های آزمایشگاه</CardTitle>
            <ClipboardList className="h-4 w-4 text-teal-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-teal-600">
              {sheetsStats ? toPersianDigits(sheetsStats.total.toString()) : "۰"}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {sheetsStats ? `${toPersianDigits(sheetsStats.approved.toString())} تایید شده` : "ثبت شده"}
            </p>
          </CardContent>
        </Card>

        <Card className="border-r-4 border-r-red-500 bg-gradient-to-br from-red-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">پروژه‌های در معرض خطر</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {toPersianDigits(atRiskProjects.length.toString())}
            </div>
            <p className="text-xs text-muted-foreground mt-1">نیاز به بررسی فوری</p>
          </CardContent>
        </Card>
      </div>

      <Separator className="my-6" />

      {/* Tabs for Advanced Reports */}
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <FileText className="h-5 w-5 text-primary" />
          گزارش‌های تفصیلی
        </h2>
        <Tabs defaultValue="comparison" className="w-full" dir="rtl">
          <TabsList className="flex flex-row-reverse flex-wrap w-full gap-2" dir="rtl">
          <TabsTrigger value="comparison" dir="rtl">مقایسه پروژه‌ها</TabsTrigger>
          <TabsTrigger value="s-curve" dir="rtl">نمودار S-Curve</TabsTrigger>
          <TabsTrigger value="variance" dir="rtl">تحلیل انحرافات</TabsTrigger>
          <TabsTrigger value="cash-flow" dir="rtl">جریان نقدی</TabsTrigger>
          <TabsTrigger value="milestones" dir="rtl">Milestones</TabsTrigger>
          <TabsTrigger value="risks" dir="rtl">مدیریت ریسک</TabsTrigger>
          <TabsTrigger value="at-risk" dir="rtl">پروژه‌های در معرض خطر</TabsTrigger>
          <TabsTrigger value="progress" dir="rtl">پیشرفت مالی vs فیزیکی</TabsTrigger>
          <TabsTrigger value="users" dir="rtl">آمار کاربران</TabsTrigger>
        </TabsList>

        {/* Projects Comparison Table */}
        <TabsContent value="comparison" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>جدول مقایسه‌ای پروژه‌ها</CardTitle>
              <p className="text-sm text-muted-foreground">مقایسه پیشرفت فیزیکی و مالی پروژه‌ها</p>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto" dir="rtl">
                <table className="w-full" dir="rtl">
                  <thead dir="rtl">
                    <tr className="border-b">
                      <th className="text-right p-3 font-semibold" dir="rtl">نام پروژه</th>
                      <th className="text-right p-3 font-semibold" dir="rtl">شماره قرارداد</th>
                      <th className="text-right p-3 font-semibold" dir="rtl">پیشرفت فیزیکی</th>
                      <th className="text-right p-3 font-semibold" dir="rtl">پیشرفت مالی</th>
                      <th className="text-right p-3 font-semibold" dir="rtl">تفاوت</th>
                      <th className="text-right p-3 font-semibold" dir="rtl">وضعیت</th>
                    </tr>
                  </thead>
                  <tbody>
                    {projectsComparison.slice(0, 15).map((project) => (
                      <tr key={project.id} className="border-b hover:bg-muted/50 transition-colors">
                        <td className="p-3 text-right">{project.title}</td>
                        <td className="p-3 text-right">{project.contractNumber || "—"}</td>
                        <td className="p-3">
                          <div className="flex items-center gap-2 flex-row-reverse">
                            <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[100px]">
                              <div 
                                className="bg-blue-500 h-2 rounded-full" 
                                style={{ width: `${project.physicalProgress}%` }}
                              />
                            </div>
                            <span className="text-sm font-medium min-w-[40px] text-right">{toPersianDigits(project.physicalProgress.toFixed(1))}%</span>
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-2 flex-row-reverse">
                            <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[100px]">
                              <div 
                                className="bg-green-500 h-2 rounded-full" 
                                style={{ width: `${project.financialProgress}%` }}
                              />
                            </div>
                            <span className="text-sm font-medium min-w-[40px] text-right">{toPersianDigits(project.financialProgress.toFixed(1))}%</span>
                          </div>
                        </td>
                        <td className="p-3 text-right">
                          <span className={`text-sm font-medium ${project.progressDiff > 0 ? "text-green-600" : project.progressDiff < 0 ? "text-red-600" : "text-gray-600"}`}>
                            {project.progressDiff > 0 ? "+" : ""}{toPersianDigits(project.progressDiff.toFixed(1))}%
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          {project.isAtRisk ? (
                            <Badge variant="destructive">در معرض خطر</Badge>
                          ) : (
                            <Badge variant="default">عادی</Badge>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* At Risk Projects */}
        <TabsContent value="at-risk" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>پروژه‌های در معرض خطر</CardTitle>
              <p className="text-sm text-muted-foreground">پروژه‌هایی که نیاز به بررسی و پیگیری فوری دارند</p>
            </CardHeader>
            <CardContent>
              {atRiskProjects.length > 0 ? (
                <div className="overflow-x-auto" dir="rtl">
                  <table className="w-full" dir="rtl">
                    <thead dir="rtl">
                      <tr className="border-b">
                        <th className="text-right p-3 font-semibold" dir="rtl">نام پروژه</th>
                        <th className="text-right p-3 font-semibold" dir="rtl">شماره قرارداد</th>
                        <th className="text-right p-3 font-semibold" dir="rtl">پیشرفت فیزیکی</th>
                        <th className="text-right p-3 font-semibold" dir="rtl">پیشرفت مالی</th>
                        <th className="text-right p-3 font-semibold" dir="rtl">سطح خطر</th>
                        <th className="text-right p-3 font-semibold" dir="rtl">دلیل</th>
                      </tr>
                    </thead>
                    <tbody>
                      {atRiskProjects.map((project) => (
                        <tr key={project.id} className="border-b hover:bg-muted/50 transition-colors">
                          <td className="p-3 font-medium text-right">{project.title}</td>
                          <td className="p-3 text-right">{project.contractNumber || "—"}</td>
                          <td className="p-3">
                            <div className="flex items-center gap-2 flex-row-reverse">
                              <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[100px]">
                                <div 
                                  className="bg-orange-500 h-2 rounded-full" 
                                  style={{ width: `${project.physicalProgress}%` }}
                                />
                              </div>
                              <span className="text-sm font-medium text-right">{toPersianDigits(project.physicalProgress.toFixed(1))}%</span>
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center gap-2 flex-row-reverse">
                              <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[100px]">
                                <div 
                                  className="bg-red-500 h-2 rounded-full" 
                                  style={{ width: `${project.financialProgress}%` }}
                                />
                              </div>
                              <span className="text-sm font-medium text-right">{toPersianDigits(project.financialProgress.toFixed(1))}%</span>
                            </div>
                          </td>
                          <td className="p-3 text-right">
                            <Badge 
                              variant={project.riskLevel === "high" ? "destructive" : project.riskLevel === "medium" ? "default" : "secondary"}
                            >
                              {project.riskLevel === "high" ? "بالا" : project.riskLevel === "medium" ? "متوسط" : "پایین"}
                            </Badge>
                          </td>
                          <td className="p-3 text-sm text-muted-foreground text-right">{project.reason}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                  ) : (
                    <EmptyState
                      icon={Shield}
                      title="هیچ پروژه‌ای در معرض خطر یافت نشد"
                      description="عالی! در حال حاضر همه پروژه‌ها در وضعیت مطلوبی قرار دارند. برای حفظ این وضعیت، پیشرفت پروژه‌ها را به‌طور منظم بررسی کنید."
                    />
                  )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Financial vs Physical Progress Chart */}
        <TabsContent value="progress" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>مقایسه پیشرفت مالی و فیزیکی</CardTitle>
              <p className="text-sm text-muted-foreground">نمودار مقایسه‌ای پیشرفت فیزیکی و مالی پروژه‌ها</p>
            </CardHeader>
            <CardContent>
              {progressComparisonData.length > 0 ? (
                <ResponsiveContainer width="100%" height={400}>
                  <ComposedChart data={progressComparisonData} margin={{ top: 10, right: 10, left: 0, bottom: 60 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                    <XAxis 
                      dataKey="name" 
                      angle={-20}
                      textAnchor="end"
                      height={80}
                      interval={0}
                      tick={{ fill: '#6b7280', fontSize: 10, fontFamily: 'Vazirmatn' }}
                      axisLine={{ stroke: '#d1d5db' }}
                      tickLine={{ stroke: '#d1d5db' }}
                    />
                    <YAxis 
                      domain={[0, 100]}
                      tick={{ fill: '#6b7280', fontSize: 12 }}
                      axisLine={{ stroke: '#d1d5db' }}
                      tickLine={{ stroke: '#d1d5db' }}
                      width={40}
                    />
                    <Tooltip 
                      formatter={(value: number, name: string) => [
                        toPersianDigits(value.toFixed(1)) + "%", 
                        name === "physical" ? "پیشرفت فیزیکی" : "پیشرفت مالی"
                      ]}
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        borderRadius: '8px', 
                        border: '1px solid #e5e7eb',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                        fontFamily: 'Vazirmatn',
                        padding: '8px 12px'
                      }}
                    />
                    <Legend 
                      formatter={(value) => value === "physical" ? "پیشرفت فیزیکی" : "پیشرفت مالی"}
                      wrapperStyle={{ fontFamily: 'Vazirmatn' }}
                    />
                    <Bar dataKey="physical" name="physical" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="financial" name="financial" fill="#10b981" radius={[6, 6, 0, 0]} />
                  </ComposedChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[400px] flex items-center justify-center text-muted-foreground">
                  داده‌ای برای نمایش وجود ندارد
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* User Statistics */}
        <TabsContent value="users" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>آمار کاربران</CardTitle>
                <p className="text-sm text-muted-foreground">وضعیت کاربران و فعالیت‌های آنها</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <span className="text-sm font-medium">کل کاربران</span>
                    <span className="text-lg font-bold">{userStats ? toPersianDigits(userStats.totalUsers.toString()) : "۰"}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <span className="text-sm font-medium">کاربران فعال</span>
                    <span className="text-lg font-bold text-green-600">{userStats ? toPersianDigits(userStats.activeUsers.toString()) : "۰"}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <span className="text-sm font-medium">کل وظایف</span>
                    <span className="text-lg font-bold">{userStats ? toPersianDigits(userStats.totalTasks.toString()) : "۰"}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <span className="text-sm font-medium">وظایف انجام شده</span>
                    <span className="text-lg font-bold text-blue-600">{userStats ? toPersianDigits(userStats.completedTasks.toString()) : "۰"}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>فعالیت کاربران</CardTitle>
                <p className="text-sm text-muted-foreground">تعداد وظایف هر کاربر</p>
              </CardHeader>
              <CardContent>
                {userStats && userStats.userActivity.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={userStats.userActivity.slice(0, 10)} layout="vertical" margin={{ left: 20, right: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis type="number" tick={{ fill: '#6b7280', fontSize: 12 }} />
                      <YAxis 
                        type="category" 
                        dataKey="name" 
                        width={150}
                        tick={{ fill: '#6b7280', fontSize: 11, fontFamily: 'Vazirmatn' }}
                      />
                      <Tooltip 
                        formatter={(value: number) => [toPersianDigits(value.toString()), "تعداد"]}
                        contentStyle={{ 
                          backgroundColor: 'white', 
                          borderRadius: '8px', 
                          border: '1px solid #e5e7eb',
                          fontFamily: 'Vazirmatn'
                        }}
                      />
                      <Legend 
                        formatter={(value) => value === "tasksCount" ? "کل وظایف" : "انجام شده"}
                        wrapperStyle={{ fontFamily: 'Vazirmatn' }}
                      />
                      <Bar dataKey="tasksCount" name="tasksCount" fill="#3b82f6" radius={[0, 6, 6, 0]} />
                      <Bar dataKey="completedTasksCount" name="completedTasksCount" fill="#10b981" radius={[0, 6, 6, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                    داده‌ای برای نمایش وجود ندارد
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* S-Curve Chart */}
        <TabsContent value="s-curve" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>نمودار S-Curve پیشرفت پروژه‌ها</CardTitle>
              <p className="text-sm text-muted-foreground">مقایسه پیشرفت برنامه‌ریزی‌شده و واقعی</p>
            </CardHeader>
            <CardContent>
              {sCurveData.length > 0 ? (
                <ResponsiveContainer width="100%" height={400}>
                  <AreaChart data={sCurveData.map(d => ({
                    month: d.month.substring(5, 7),
                    planned: d.planned / 1000000000,
                    actual: d.actual / 1000000000,
                  }))} margin={{ top: 10, right: 10, left: 0, bottom: 30 }}>
                    <defs>
                      <linearGradient id="colorPlanned" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                    <XAxis 
                      dataKey="month" 
                      tick={{ fill: '#6b7280', fontSize: 12, fontFamily: 'Vazirmatn' }}
                      axisLine={{ stroke: '#d1d5db' }}
                      tickLine={{ stroke: '#d1d5db' }}
                    />
                    <YAxis 
                      tick={{ fill: '#6b7280', fontSize: 12 }}
                      axisLine={{ stroke: '#d1d5db' }}
                      tickLine={{ stroke: '#d1d5db' }}
                      width={60}
                    />
                    <Tooltip 
                      formatter={(value: number) => [formatCurrency(value.toFixed(1)) + " میلیارد", ""]}
                      labelFormatter={(label) => `ماه ${toPersianDigits(label)}`}
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        borderRadius: '8px', 
                        border: '1px solid #e5e7eb',
                        fontFamily: 'Vazirmatn'
                      }}
                    />
                    <Legend 
                      formatter={(value) => value === "planned" ? "برنامه‌ریزی شده" : "واقعی"}
                      wrapperStyle={{ fontFamily: 'Vazirmatn' }}
                    />
                    <Area type="monotone" dataKey="planned" stroke="#3b82f6" fillOpacity={1} fill="url(#colorPlanned)" name="planned" />
                    <Area type="monotone" dataKey="actual" stroke="#10b981" fillOpacity={1} fill="url(#colorActual)" name="actual" />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[400px] flex items-center justify-center text-muted-foreground">
                  داده‌ای برای نمایش وجود ندارد
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Budget Variance Analysis */}
        <TabsContent value="variance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>تحلیل انحرافات بودجه</CardTitle>
              <p className="text-sm text-muted-foreground">مقایسه بودجه تخصیص‌یافته با هزینه‌های واقعی</p>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto" dir="rtl">
                <table className="w-full" dir="rtl">
                  <thead dir="rtl">
                    <tr className="border-b">
                      <th className="text-right p-3 font-semibold" dir="rtl">نام پروژه</th>
                      <th className="text-right p-3 font-semibold" dir="rtl">بودجه (میلیارد)</th>
                      <th className="text-right p-3 font-semibold" dir="rtl">هزینه شده</th>
                      <th className="text-right p-3 font-semibold" dir="rtl">انحراف</th>
                      <th className="text-right p-3 font-semibold" dir="rtl">درصد انحراف</th>
                      <th className="text-right p-3 font-semibold" dir="rtl">وضعیت</th>
                    </tr>
                  </thead>
                  <tbody>
                    {budgetVariance.slice(0, 20).map((project) => (
                      <tr key={project.id} className="border-b hover:bg-muted/50 transition-colors">
                        <td className="p-3 text-right">{project.title}</td>
                        <td className="p-3 text-right">{formatCurrency((project.contractAmount / 1000000000).toFixed(1))}</td>
                        <td className="p-3 text-right">{formatCurrency((project.spentAmount / 1000000000).toFixed(1))}</td>
                        <td className="p-3 text-right">
                          <span className={project.budgetVariance > 0 ? "text-green-600" : "text-red-600"}>
                            {formatCurrency((Math.abs(project.budgetVariance) / 1000000000).toFixed(1))}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          <Badge variant={project.budgetVariancePercent > 10 ? "destructive" : project.budgetVariancePercent > 5 ? "default" : "secondary"}>
                            {toPersianDigits(project.budgetVariancePercent.toFixed(1))}%
                          </Badge>
                        </td>
                        <td className="p-3 text-right">
                          {project.budgetVariancePercent > 10 ? (
                            <Badge variant="destructive">انحراف بالا</Badge>
                          ) : project.budgetVariancePercent > 5 ? (
                            <Badge variant="default">انحراف متوسط</Badge>
                          ) : (
                            <Badge variant="secondary">عادی</Badge>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cash Flow Projection */}
        <TabsContent value="cash-flow" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>پیش‌بینی جریان نقدی</CardTitle>
              <p className="text-sm text-muted-foreground">جریان نقدی ۶ ماه گذشته و پیش‌بینی ۶ ماه آینده</p>
            </CardHeader>
            <CardContent>
              {cashFlowData.length > 0 ? (
                <ResponsiveContainer width="100%" height={400}>
                  <ComposedChart data={cashFlowData.map(d => ({
                    month: d.month.substring(5, 7),
                    actual: d.actual / 1000000000,
                    projected: d.projected / 1000000000,
                  }))} margin={{ top: 10, right: 10, left: 0, bottom: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                    <XAxis 
                      dataKey="month" 
                      tick={{ fill: '#6b7280', fontSize: 12, fontFamily: 'Vazirmatn' }}
                      axisLine={{ stroke: '#d1d5db' }}
                      tickLine={{ stroke: '#d1d5db' }}
                    />
                    <YAxis 
                      tick={{ fill: '#6b7280', fontSize: 12 }}
                      axisLine={{ stroke: '#d1d5db' }}
                      tickLine={{ stroke: '#d1d5db' }}
                      width={60}
                    />
                    <Tooltip 
                      formatter={(value: number) => [formatCurrency(value.toFixed(1)) + " میلیارد", ""]}
                      labelFormatter={(label) => `ماه ${toPersianDigits(label)}`}
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        borderRadius: '8px', 
                        border: '1px solid #e5e7eb',
                        fontFamily: 'Vazirmatn'
                      }}
                    />
                    <Legend 
                      formatter={(value) => value === "actual" ? "واقعی" : "پیش‌بینی"}
                      wrapperStyle={{ fontFamily: 'Vazirmatn' }}
                    />
                    <Bar dataKey="actual" name="actual" fill="#10b981" radius={[6, 6, 0, 0]} />
                    <Line type="monotone" dataKey="projected" name="projected" stroke="#f59e0b" strokeWidth={2} strokeDasharray="5 5" />
                  </ComposedChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[400px] flex items-center justify-center text-muted-foreground">
                  داده‌ای برای نمایش وجود ندارد
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Milestones Timeline */}
        <TabsContent value="milestones" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Milestones پروژه‌ها</CardTitle>
              <p className="text-sm text-muted-foreground">رویدادهای مهم و نقاط عطف پروژه‌ها</p>
            </CardHeader>
            <CardContent>
              {milestones.length > 0 ? (
                <div className="space-y-4">
                  {milestones.slice(0, 30).map((milestone, index) => (
                    <div key={`${milestone.projectId}-${index}`} className="flex items-start gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                      <div className={`p-2 rounded-full ${
                        milestone.type === "start" ? "bg-blue-100 text-blue-600" :
                        milestone.type === "end" ? "bg-green-100 text-green-600" :
                        "bg-red-100 text-red-600"
                      }`}>
                        {milestone.type === "start" ? <Target className="h-4 w-4" /> :
                         milestone.type === "end" ? <CheckCircle className="h-4 w-4" /> :
                         <AlertTriangle className="h-4 w-4" />}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold">{milestone.title}</h4>
                          <span className="text-sm text-muted-foreground">
                            {toPersianDigits(new Date(milestone.date).toLocaleDateString('fa-IR'))}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">{milestone.projectTitle}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState
                  icon={Calendar}
                  title="هیچ Milestone‌ای یافت نشد"
                  description="در حال حاضر Milestone‌ای برای نمایش وجود ندارد. با تعریف تاریخ شروع و پایان برای پروژه‌ها، Milestone‌ها به‌طور خودکار ایجاد می‌شوند."
                />
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Risk Management */}
        <TabsContent value="risks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>مدیریت ریسک</CardTitle>
              <p className="text-sm text-muted-foreground">ریسک‌های شناسایی شده و وضعیت آنها</p>
            </CardHeader>
            <CardContent>
              {riskSummary ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <Card className="border-r-4 border-r-red-500">
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold text-red-600">
                          {toPersianDigits(riskSummary.high.toString())}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">ریسک‌های بالا</p>
                      </CardContent>
                    </Card>
                    <Card className="border-r-4 border-r-orange-500">
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold text-orange-600">
                          {toPersianDigits(riskSummary.medium.toString())}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">ریسک‌های متوسط</p>
                      </CardContent>
                    </Card>
                    <Card className="border-r-4 border-r-yellow-500">
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold text-yellow-600">
                          {toPersianDigits(riskSummary.low.toString())}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">ریسک‌های پایین</p>
                      </CardContent>
                    </Card>
                    <Card className="border-r-4 border-r-gray-500">
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold">
                          {toPersianDigits(riskSummary.total.toString())}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">کل ریسک‌ها</p>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="overflow-x-auto" dir="rtl">
                    <table className="w-full" dir="rtl">
                      <thead dir="rtl">
                        <tr className="border-b">
                          <th className="text-right p-3 font-semibold" dir="rtl">عنوان ریسک</th>
                          <th className="text-right p-3 font-semibold" dir="rtl">پروژه</th>
                          <th className="text-right p-3 font-semibold" dir="rtl">شدت</th>
                          <th className="text-right p-3 font-semibold" dir="rtl">تأثیر</th>
                          <th className="text-right p-3 font-semibold" dir="rtl">احتمال</th>
                          <th className="text-right p-3 font-semibold" dir="rtl">وضعیت</th>
                        </tr>
                      </thead>
                      <tbody>
                        {riskSummary.risks.slice(0, 20).map((risk) => (
                          <tr key={risk.id} className="border-b hover:bg-muted/50 transition-colors">
                            <td className="p-3 text-right">
                              <div>
                                <div className="font-medium">{risk.title}</div>
                                {risk.description && (
                                  <div className="text-sm text-muted-foreground mt-1">{risk.description.substring(0, 100)}...</div>
                                )}
                              </div>
                            </td>
                            <td className="p-3 text-right">{risk.projectTitle}</td>
                            <td className="p-3 text-right">
                              <Badge 
                                variant={risk.severity === "high" ? "destructive" : risk.severity === "medium" ? "default" : "secondary"}
                              >
                                {risk.severity === "high" ? "بالا" : risk.severity === "medium" ? "متوسط" : "پایین"}
                              </Badge>
                            </td>
                            <td className="p-3 text-right">{risk.impact}</td>
                            <td className="p-3 text-right">{risk.probability}</td>
                            <td className="p-3 text-right">
                              <Badge variant={risk.status === "open" ? "destructive" : "default"}>
                                {risk.status === "open" ? "باز" : "بسته"}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  داده‌ای برای نمایش وجود ندارد
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
