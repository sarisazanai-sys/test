import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { 
  User, 
  Mail, 
  Phone, 
  Lock, 
  Upload, 
  Save, 
  Calendar,
  Clock,
  FolderKanban,
  CheckCircle,
  MessageSquare,
  Shield,
  Settings,
  Activity,
  FileText,
  AlertCircle
} from "lucide-react";
import type { User as UserType, Project } from "@shared/schema";

type UserProfile = UserType & {
  projects?: Project[];
  roleInfo?: { displayName: string; description: string } | null;
  createdAt?: string;
  lastLogin?: string;
};

// Get user ID helper
const getUserId = (): string | null => {
  try {
    const currentUserStored = localStorage.getItem("currentUser");
    if (currentUserStored) {
      const user = JSON.parse(currentUserStored);
      if (user?.id) return user.id;
    }
    const userStored = localStorage.getItem("user");
    if (userStored) {
      const user = JSON.parse(userStored);
      if (user?.id) return user.id;
    }
  } catch (error) {
    console.error("Failed to get user ID:", error);
  }
  return null;
};

// Get headers helper
const getHeaders = (includeContentType: boolean = false): HeadersInit => {
  const headers: HeadersInit = {};
  if (includeContentType) {
    headers["Content-Type"] = "application/json";
  }
  const userId = getUserId();
  if (userId) {
    headers["x-user-id"] = userId;
  }
  return headers;
};

// Password strength checker
const getPasswordStrength = (password: string): { strength: "weak" | "medium" | "strong"; label: string; color: string } => {
  if (password.length === 0) return { strength: "weak", label: "", color: "" };
  if (password.length < 6) return { strength: "weak", label: "ضعیف", color: "text-red-500" };
  if (password.length < 10) return { strength: "medium", label: "متوسط", color: "text-yellow-500" };
  return { strength: "strong", label: "قوی", color: "text-green-500" };
};

// Empty State Component
const EmptyState = ({ 
  icon: Icon, 
  title, 
  description, 
  action 
}: { 
  icon: any; 
  title: string; 
  description?: string; 
  action?: React.ReactNode;
}) => (
  <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
    <Icon className="h-16 w-16 text-muted-foreground/50 mb-4" />
    <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
    {description && (
      <p className="text-sm text-muted-foreground max-w-md mb-4">{description}</p>
    )}
    {action && <div className="mt-2">{action}</div>}
  </div>
);

export default function ProfilePage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const currentUser = JSON.parse(localStorage.getItem("user") || "{}");
  const userId = currentUser.id || getUserId();

  const [profileData, setProfileData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const { data: profile, isLoading } = useQuery<UserProfile>({
    queryKey: [`/api/profile/${userId}`],
    enabled: !!userId,
    queryFn: async () => {
      const response = await fetch(`/api/profile/${userId}`, { headers: getHeaders() });
      if (!response.ok) throw new Error("خطا در دریافت پروفایل");
      return response.json();
    },
  });

  // Fetch stats
  const { data: stats } = useQuery({
    queryKey: [`/api/profile/${userId}/stats`],
    enabled: !!userId,
    queryFn: async () => {
      try {
        const response = await fetch(`/api/profile/${userId}/stats`, { headers: getHeaders() });
        if (response.ok) {
          return response.json();
        }
      } catch (error) {
        console.error("Error fetching stats:", error);
      }
      return { projects: 0, tasks: 0, messages: 0 };
    },
  });

  useEffect(() => {
    if (profile) {
      setProfileData({
        firstName: profile.firstName || "",
        lastName: profile.lastName || "",
        email: profile.email || "",
        phone: profile.phone || "",
      });
    }
  }, [profile]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof profileData) => {
      const response = await fetch(`/api/profile/${userId}`, {
        method: "PUT",
        headers: getHeaders(true),
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در بروزرسانی پروفایل");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/profile/${userId}`] });
      toast({ title: "پروفایل با موفقیت بروزرسانی شد" });
    },
    onError: () => {
      toast({ title: "خطا در بروزرسانی پروفایل", variant: "destructive" });
    },
  });

  const changePasswordMutation = useMutation({
    mutationFn: async (data: typeof passwordData) => {
      const response = await fetch(`/api/profile/${userId}/change-password`, {
        method: "POST",
        headers: getHeaders(true),
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "خطا در تغییر رمز عبور");
      }
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "رمز عبور با موفقیت تغییر یافت" });
      setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" });
    },
    onError: (error: Error) => {
      toast({ title: error.message, variant: "destructive" });
    },
  });

  const uploadAvatarMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("avatar", file);

      const response = await fetch(`/api/profile/${userId}/avatar`, {
        method: "POST",
        headers: getHeaders(),
        body: formData,
      });
      if (!response.ok) throw new Error("خطا در آپلود تصویر");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/profile/${userId}`] });
      toast({ title: "تصویر پروفایل با موفقیت بروزرسانی شد" });
    },
    onError: () => {
      toast({ title: "خطا در آپلود تصویر", variant: "destructive" });
    },
  });

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({ title: "حجم فایل باید کمتر از 5 مگابایت باشد", variant: "destructive" });
        return;
      }
      uploadAvatarMutation.mutate(file);
    }
  };

  const handleProfileUpdate = () => {
    if (!profileData.firstName.trim() || !profileData.lastName.trim()) {
      toast({ title: "نام و نام خانوادگی الزامی است", variant: "destructive" });
      return;
    }
    updateProfileMutation.mutate(profileData);
  };

  const handlePasswordChange = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({ title: "رمز عبور جدید و تکرار آن مطابقت ندارند", variant: "destructive" });
      return;
    }
    if (passwordData.newPassword.length < 6) {
      toast({ title: "رمز عبور باید حداقل 6 کاراکتر باشد", variant: "destructive" });
      return;
    }
    changePasswordMutation.mutate(passwordData);
  };

  // Get emoji for role
  const getRoleEmoji = (roleName?: string): string => {
    if (!roleName) return "👤";
    
    // Normalize role name
    const normalizedRole = roleName.toLowerCase().trim();
    
    const roleEmojiMap: Record<string, string> = {
      admin: "🛠️",
      "مدیر سیستم": "🛠️",
      manager: "🏢",
      "مدیریت": "🏢",
      project_manager: "📊",
      "مدیر پروژه": "📊",
      technical_office: "📐",
      "دفتر فنی": "📐",
      supervisor: "👷‍♂️",
      "سرپرست": "👷‍♂️",
      viewer: "👁️",
      "بیننده": "👁️",
    };
    
    return roleEmojiMap[normalizedRole] || roleEmojiMap[normalizedRole.replace(/\s+/g, "_")] || "👤";
  };

  const getInitials = () => {
    // If no avatar, show role emoji first
    if (!profile?.avatarPath) {
      // Try roleInfo.name first (e.g., "admin", "manager"), then role, then displayName
      const roleName = profile?.roleInfo?.name || profile?.role || profile?.roleInfo?.displayName;
      const emoji = getRoleEmoji(roleName);
      if (emoji !== "👤") return emoji;
    }
    
    // Otherwise show initials
    if (profile?.firstName && profile?.lastName) {
      return `${profile.firstName.charAt(0)}${profile.lastName.charAt(0)}`;
    }
    if (profile?.username) {
      return profile.username.charAt(0).toUpperCase();
    }
    return "👤";
  };

  const passwordStrength = useMemo(() => getPasswordStrength(passwordData.newPassword), [passwordData.newPassword]);

  const formatDate = (dateString?: string) => {
    if (!dateString) return "—";
    try {
      const date = new Date(dateString);
      return new Intl.DateTimeFormat("fa-IR", {
        year: "numeric",
        month: "long",
        day: "numeric",
      }).format(date);
    } catch {
      return dateString;
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6" dir="rtl">
        <div className="h-8 bg-muted animate-pulse rounded w-64" />
        <div className="grid gap-6 md:grid-cols-3">
          <div className="h-96 bg-muted animate-pulse rounded-lg" />
          <div className="md:col-span-2 h-96 bg-muted animate-pulse rounded-lg" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header with Gradient and Stats */}
      <div className="relative overflow-hidden rounded-lg bg-gradient-to-br from-[#1e40af] via-[#2563eb] to-[#3b82f6] text-white p-6 shadow-lg" dir="rtl">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-4 flex-row-reverse">
            <Avatar className="w-20 h-20 border-4 border-white/20 shadow-lg">
              <AvatarImage src={profile?.avatarPath || undefined} />
              <AvatarFallback className="text-3xl bg-white/20 text-white">
                {getInitials()}
              </AvatarFallback>
            </Avatar>
            <div className="text-right">
              <h1 className="text-3xl font-bold">
                {profile?.firstName && profile?.lastName
                  ? `${profile.firstName} ${profile.lastName}`
                  : profile?.username || "کاربر"}
              </h1>
              <p className="text-white/80 mt-1">
                {profile?.roleInfo?.displayName || profile?.role || "کاربر"}
              </p>
            </div>
          </div>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-3 gap-4 w-full md:w-auto" dir="rtl">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20 text-right">
              <div className="flex items-center gap-2 mb-1 flex-row-reverse">
                <FolderKanban className="w-4 h-4" />
                <span className="text-xs text-white/80">پروژه‌ها</span>
              </div>
              <p className="text-2xl font-bold text-right">{stats?.projects || profile?.projects?.length || 0}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20 text-right">
              <div className="flex items-center gap-2 mb-1 flex-row-reverse">
                <CheckCircle className="w-4 h-4" />
                <span className="text-xs text-white/80">وظایف</span>
              </div>
              <p className="text-2xl font-bold text-right">{stats?.tasks || 0}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20 text-right">
              <div className="flex items-center gap-2 mb-1 flex-row-reverse">
                <MessageSquare className="w-4 h-4" />
                <span className="text-xs text-white/80">پیام‌ها</span>
              </div>
              <p className="text-2xl font-bold text-right">{stats?.messages || 0}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs for Organization */}
      <Tabs defaultValue="personal" className="w-full" dir="rtl">
        <TabsList className="flex flex-row-reverse flex-wrap w-full gap-2" dir="rtl">
          <TabsTrigger value="personal" dir="rtl" className="flex items-center gap-2 flex-row-reverse">
            <User className="w-4 h-4" />
            اطلاعات شخصی
          </TabsTrigger>
          <TabsTrigger value="security" dir="rtl" className="flex items-center gap-2 flex-row-reverse">
            <Shield className="w-4 h-4" />
            امنیت
          </TabsTrigger>
          <TabsTrigger value="activity" dir="rtl" className="flex items-center gap-2 flex-row-reverse">
            <Activity className="w-4 h-4" />
            فعالیت‌ها
          </TabsTrigger>
          <TabsTrigger value="settings" dir="rtl" className="flex items-center gap-2 flex-row-reverse">
            <Settings className="w-4 h-4" />
            تنظیمات
          </TabsTrigger>
        </TabsList>

        {/* Personal Information Tab */}
        <TabsContent value="personal" className="space-y-6 mt-6">
          <div className="grid gap-6 md:grid-cols-3">
            {/* Avatar Card */}
            <Card className="md:col-span-1 shadow-md hover:shadow-lg transition-shadow border-r-4 border-r-[#1e40af]">
              <CardHeader>
                <CardTitle className="text-lg">تصویر پروفایل</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col items-center space-y-4">
                <Avatar className="w-32 h-32 border-4 border-[#1e40af]/20 shadow-lg">
                  <AvatarImage src={profile?.avatarPath || undefined} />
                  <AvatarFallback className="text-4xl bg-gradient-to-br from-[#1e40af] to-[#3b82f6] text-white">
                    {getInitials()}
                  </AvatarFallback>
                </Avatar>
                
                <div className="w-full">
                  <Label htmlFor="avatar-upload" className="cursor-pointer">
                    <div className="flex items-center justify-center gap-2 p-3 border-2 border-dashed border-[#1e40af]/30 rounded-lg hover:bg-[#1e40af]/5 hover:border-[#1e40af]/50 transition-all flex-row-reverse">
                      <Upload className="w-4 h-4 text-[#1e40af]" />
                      <span className="text-sm font-medium text-[#1e40af]">آپلود تصویر جدید</span>
                    </div>
                    <Input
                      id="avatar-upload"
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleAvatarChange}
                    />
                  </Label>
                  <p className="text-xs text-muted-foreground text-center mt-2">
                    حداکثر 5 مگابایت (JPG, PNG)
                  </p>
                </div>

                <Separator />

                <div className="w-full space-y-3 pt-2" dir="rtl">
                  <div className="flex items-center justify-between p-2 bg-muted/50 rounded-lg">
                    <span className="text-sm text-muted-foreground text-right">نام کاربری</span>
                    <span className="font-medium text-sm text-right">{profile?.username}</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-muted/50 rounded-lg">
                    <span className="text-sm text-muted-foreground text-right">نقش</span>
                    <Badge variant="secondary" className="bg-[#1e40af]/10 text-[#1e40af] border-[#1e40af]/20">
                      {profile?.roleInfo?.displayName || profile?.role || "کاربر"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-muted/50 rounded-lg">
                    <span className="text-sm text-muted-foreground text-right">وضعیت</span>
                    <Badge variant={profile?.isActive ? "default" : "destructive"}>
                      {profile?.isActive ? "فعال" : "غیرفعال"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Personal Information Form */}
            <Card className="md:col-span-2 shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle>اطلاعات شخصی</CardTitle>
                <CardDescription>
                  اطلاعات شخصی خود را ویرایش کنید
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">نام *</Label>
                    <div className="relative">
                      <User className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="firstName"
                        value={profileData.firstName}
                        onChange={(e) =>
                          setProfileData({ ...profileData, firstName: e.target.value })
                        }
                        className="pr-10 rounded-lg"
                        placeholder="نام خود را وارد کنید"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">نام خانوادگی *</Label>
                    <div className="relative">
                      <User className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="lastName"
                        value={profileData.lastName}
                        onChange={(e) =>
                          setProfileData({ ...profileData, lastName: e.target.value })
                        }
                        className="pr-10 rounded-lg"
                        placeholder="نام خانوادگی خود را وارد کنید"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">ایمیل</Label>
                  <div className="relative">
                    <Mail className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      value={profileData.email}
                      onChange={(e) =>
                        setProfileData({ ...profileData, email: e.target.value })
                      }
                      className="pr-10 rounded-lg"
                      placeholder="example@domain.com"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">شماره تماس</Label>
                  <div className="relative">
                    <Phone className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="phone"
                      value={profileData.phone}
                      onChange={(e) =>
                        setProfileData({ ...profileData, phone: e.target.value })
                      }
                      className="pr-10 rounded-lg"
                      dir="ltr"
                      placeholder="09123456789"
                    />
                  </div>
                </div>

                <Button 
                  onClick={handleProfileUpdate} 
                  className="w-full bg-[#1e40af] hover:bg-[#1e3a8a] text-white rounded-lg"
                  disabled={updateProfileMutation.isPending}
                >
                  <Save className="w-4 h-4 ml-2" />
                  {updateProfileMutation.isPending ? "در حال ذخیره..." : "ذخیره تغییرات"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6 mt-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Change Password */}
            <Card className="shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 flex-row-reverse">
                  <Lock className="w-5 h-5 text-[#1e40af]" />
                  تغییر رمز عبور
                </CardTitle>
                <CardDescription>
                  رمز عبور خود را تغییر دهید
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">رمز عبور فعلی</Label>
                  <div className="relative">
                    <Lock className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="currentPassword"
                      type="password"
                      value={passwordData.currentPassword}
                      onChange={(e) =>
                        setPasswordData({ ...passwordData, currentPassword: e.target.value })
                      }
                      className="pr-10 rounded-lg"
                      placeholder="رمز عبور فعلی"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="newPassword">رمز عبور جدید</Label>
                  <div className="relative">
                    <Lock className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="newPassword"
                      type="password"
                      value={passwordData.newPassword}
                      onChange={(e) =>
                        setPasswordData({ ...passwordData, newPassword: e.target.value })
                      }
                      className="pr-10 rounded-lg"
                      placeholder="رمز عبور جدید"
                    />
                  </div>
                  {passwordData.newPassword && (
                    <div className="flex items-center gap-2 mt-1 flex-row-reverse">
                      <span className={`text-xs ${passwordStrength.color} text-right`}>
                        قدرت رمز: {passwordStrength.label}
                      </span>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">تکرار رمز عبور جدید</Label>
                  <div className="relative">
                    <Lock className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="confirmPassword"
                      type="password"
                      value={passwordData.confirmPassword}
                      onChange={(e) =>
                        setPasswordData({ ...passwordData, confirmPassword: e.target.value })
                      }
                      className="pr-10 rounded-lg"
                      placeholder="تکرار رمز عبور جدید"
                    />
                  </div>
                  {passwordData.confirmPassword && passwordData.newPassword !== passwordData.confirmPassword && (
                    <p className="text-xs text-red-500 mt-1">رمز عبورها مطابقت ندارند</p>
                  )}
                </div>

                <Button 
                  onClick={handlePasswordChange} 
                  className="w-full bg-[#1e40af] hover:bg-[#1e3a8a] text-white rounded-lg"
                  disabled={changePasswordMutation.isPending}
                >
                  <Lock className="w-4 h-4 ml-2" />
                  {changePasswordMutation.isPending ? "در حال تغییر..." : "تغییر رمز عبور"}
                </Button>
              </CardContent>
            </Card>

            {/* Account Information */}
            <Card className="shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 flex-row-reverse">
                  <FileText className="w-5 h-5 text-[#1e40af]" />
                  اطلاعات حساب
                </CardTitle>
                <CardDescription>
                  جزئیات حساب کاربری شما
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3" dir="rtl">
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-2 flex-row-reverse">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground text-right">تاریخ عضویت</span>
                    </div>
                    <span className="font-medium text-sm text-right">{formatDate(profile?.createdAt)}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-2 flex-row-reverse">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground text-right">آخرین ورود</span>
                    </div>
                    <span className="font-medium text-sm text-right">{formatDate(profile?.lastLogin) || "—"}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-2 flex-row-reverse">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground text-right">نام کاربری</span>
                    </div>
                    <span className="font-medium text-sm text-right">{profile?.username}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Activity Tab */}
        <TabsContent value="activity" className="space-y-6 mt-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Projects */}
            <Card className="shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 flex-row-reverse">
                  <FolderKanban className="w-5 h-5 text-[#1e40af]" />
                  پروژه‌های تخصیص یافته
                </CardTitle>
                <CardDescription>
                  پروژه‌هایی که به شما اختصاص داده شده است
                </CardDescription>
              </CardHeader>
              <CardContent>
                {profile?.projects && profile.projects.length > 0 ? (
                  <div className="space-y-3">
                    {profile.projects.map((project) => (
                      <div
                        key={project.id}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                        dir="rtl"
                      >
                        <div className="flex-1 text-right">
                          <p className="font-medium">{project.title}</p>
                          {project.location && (
                            <p className="text-sm text-muted-foreground mt-1">{project.location}</p>
                          )}
                        </div>
                        <Badge 
                          variant="outline" 
                          className="ml-3 border-[#1e40af]/20 text-[#1e40af]"
                        >
                          {project.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    icon={FolderKanban}
                    title="هیچ پروژه‌ای یافت نشد"
                    description="در حال حاضر پروژه‌ای به شما اختصاص داده نشده است. برای اختصاص پروژه با مدیر سیستم تماس بگیرید."
                    action={
                      <Button variant="outline" size="sm" className="border-[#1e40af] text-[#1e40af]">
                        ارتباط با مدیر
                      </Button>
                    }
                  />
                )}
              </CardContent>
            </Card>

            {/* Activity Stats */}
            <Card className="shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 flex-row-reverse">
                  <Activity className="w-5 h-5 text-[#1e40af]" />
                  آمار فعالیت
                </CardTitle>
                <CardDescription>
                  خلاصه فعالیت‌های شما
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-[#1e40af]/5 to-transparent rounded-lg border border-[#1e40af]/10" dir="rtl">
                    <div className="flex items-center gap-3 flex-row-reverse">
                      <div className="p-2 bg-[#1e40af]/10 rounded-lg">
                        <FolderKanban className="w-5 h-5 text-[#1e40af]" />
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">پروژه‌های فعال</p>
                        <p className="text-2xl font-bold text-[#1e40af]">
                          {stats?.projects || profile?.projects?.length || 0}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-500/5 to-transparent rounded-lg border border-green-500/10" dir="rtl">
                    <div className="flex items-center gap-3 flex-row-reverse">
                      <div className="p-2 bg-green-500/10 rounded-lg">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">وظایف انجام شده</p>
                        <p className="text-2xl font-bold text-green-600">
                          {stats?.tasks || 0}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-500/5 to-transparent rounded-lg border border-blue-500/10" dir="rtl">
                    <div className="flex items-center gap-3 flex-row-reverse">
                      <div className="p-2 bg-blue-500/10 rounded-lg">
                        <MessageSquare className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">پیام‌های خوانده نشده</p>
                        <p className="text-2xl font-bold text-blue-600">
                          {stats?.messages || 0}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6 mt-6">
          <Card className="shadow-md hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 flex-row-reverse">
                <Settings className="w-5 h-5 text-[#1e40af]" />
                تنظیمات
              </CardTitle>
              <CardDescription>
                تنظیمات حساب کاربری
              </CardDescription>
            </CardHeader>
            <CardContent>
              <EmptyState
                icon={Settings}
                title="به زودی"
                description="تنظیمات اضافی به زودی اضافه خواهد شد."
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
