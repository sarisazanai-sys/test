import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search } from "lucide-react";
import ProjectCard from "./ProjectCard";
import { useToast } from "@/hooks/use-toast";
import { useProject } from "@/lib/project-context";
import { useLocation } from "wouter";
import type { Project, InsertProject } from "@shared/schema";

export default function ProjectsPage() {
  const [open, setOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { setSelectedProject } = useProject();
  const [, setLocation] = useLocation();

  const [formData, setFormData] = useState<InsertProject>({
    title: "",
    contractNumber: "",
    contractDate: "",
    location: "",
    employer: "",
    contractor: "",
    amount: "",
    amount25Percent: "",
    link: "",
    projectNumber: "",
    progress: 0,
    status: "active",
    startDate: "",
    lastStatementNumber: "",
    lastStatementAmount: "",
    lastModificationNumber: "",
    lastModificationAmount: "",
    lastBitumenDifferenceNumber: "",
    lastBitumenDifferenceAmount: "",
    financialProgress: "",
  });

  // Get user ID from localStorage for headers
  const getUserId = (): string | null => {
    try {
      // Try currentUser first (used in auth context)
      const currentUserStored = localStorage.getItem("currentUser");
      if (currentUserStored) {
        const user = JSON.parse(currentUserStored);
        if (user?.id) return user.id;
      }
      // Fallback to user (legacy)
      const userStored = localStorage.getItem("user");
      if (userStored) {
        const user = JSON.parse(userStored);
        if (user?.id) return user.id;
      }
    } catch (error) {
      console.error("Failed to get user ID from localStorage:", error);
    }
    return null;
  };

  // Get headers with user ID
  const getHeaders = (includeContentType: boolean = false): HeadersInit => {
    const headers: HeadersInit = {};
    if (includeContentType) {
      headers["Content-Type"] = "application/json";
    }
    const userId = getUserId();
    if (userId) {
      headers["x-user-id"] = userId;
    } else {
      console.warn("ProjectsPage: No user ID found in localStorage. Authentication may fail.");
    }
    return headers;
  };

  const { data: projects = [], isLoading, error: projectsError } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const headers = getHeaders();
      console.log("ProjectsPage: Fetching projects with headers:", headers);
      const response = await fetch("/api/projects", {
        headers,
      });
      if (!response.ok) {
        const errorText = await response.text();
        console.error("ProjectsPage: Error fetching projects:", response.status, errorText);
        if (response.status === 401) {
          throw new Error("احراز هویت لازم است. لطفاً دوباره وارد سیستم شوید.");
        }
        throw new Error("خطا در دریافت پروژه‌ها");
      }
      const data = await response.json();
      console.log("ProjectsPage: Projects loaded:", data.length);
      return data;
    },
    retry: false,
  });

  const createProjectMutation = useMutation({
    mutationFn: async (data: InsertProject) => {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: getHeaders(true),
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("خطا در ایجاد پروژه");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setOpen(false);
      setFormData({
        title: "",
        contractNumber: "",
        location: "",
        employer: "",
        amount: "",
        progress: 0,
        status: "active",
        startDate: "",
      });
      toast({
        title: "موفقیت",
        description: "پروژه جدید با موفقیت ایجاد شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createProjectMutation.mutate(formData);
  };

  const handleViewDetails = (id: string) => {
    setLocation(`/projects/${id}`);
  };

  const handleEdit = (id: string) => {
    const project = projects.find(p => p.id === id);
    if (project) {
      setEditingProject(project);
      setFormData({
        title: project.title || "",
        contractNumber: project.contractNumber || "",
        contractDate: project.contractDate || "",
        location: project.location || "",
        employer: project.employer || "",
        contractor: project.contractor || "",
        amount: project.amount || "",
        amount25Percent: project.amount25Percent || "",
        link: project.link || "",
        projectNumber: project.projectNumber || "",
        progress: project.progress || 0,
        status: (project.status as "active" | "completed" | "pending" | "suspended") || "active",
        startDate: project.startDate || "",
        lastStatementNumber: project.lastStatementNumber || "",
        lastStatementAmount: project.lastStatementAmount || "",
        lastModificationNumber: project.lastModificationNumber || "",
        lastModificationAmount: project.lastModificationAmount || "",
        lastBitumenDifferenceNumber: project.lastBitumenDifferenceNumber || "",
        lastBitumenDifferenceAmount: project.lastBitumenDifferenceAmount || "",
        financialProgress: project.financialProgress || "",
      });
      setEditOpen(true);
    }
  };

  const handleDelete = (id: string) => {
    if (window.confirm("آیا از حذف این پروژه مطمئن هستید؟ این عمل قابل بازگشت نیست.")) {
      deleteProjectMutation.mutate(id);
    }
  };

  const editProjectMutation = useMutation({
    mutationFn: async (data: { id: string; data: InsertProject }) => {
      const response = await fetch(`/api/projects/${data.id}`, {
        method: "PUT",
        headers: getHeaders(true),
        body: JSON.stringify(data.data),
      });
      if (!response.ok) throw new Error("خطا در ویرایش پروژه");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setEditOpen(false);
      setEditingProject(null);
      setFormData({
        title: "",
        contractNumber: "",
        contractDate: "",
        location: "",
        employer: "",
        contractor: "",
        amount: "",
        amount25Percent: "",
        link: "",
        projectNumber: "",
        progress: 0,
        status: "active",
        startDate: "",
        lastStatementNumber: "",
        lastStatementAmount: "",
        lastModificationNumber: "",
        lastModificationAmount: "",
        lastBitumenDifferenceNumber: "",
        lastBitumenDifferenceAmount: "",
        financialProgress: "",
      });
      toast({
        title: "موفقیت",
        description: "پروژه با موفقیت ویرایش شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const deleteProjectMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`/api/projects/${id}`, {
        method: "DELETE",
        headers: getHeaders(),
      });
      if (!response.ok) throw new Error("خطا در حذف پروژه");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "موفقیت",
        description: "پروژه با موفقیت حذف شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProject) {
      editProjectMutation.mutate({
        id: editingProject.id,
        data: formData,
      });
    }
  };

  // تابع محاسبه درصد پیشرفت بر اساس مبلغ آخرین صورت وضعیت
  const calculateFinancialProgress = (project: Project): number => {
    try {
      if (!project.amount || !project.lastStatementAmount) return 0;
      
      const amountStr = String(project.amount || "0");
      const contractAmount = parseFloat(amountStr.replace(/,/g, "").replace(/[^\d.-]/g, "") || "0");
      if (contractAmount === 0 || isNaN(contractAmount)) return 0;

      const lastStatementAmountStr = String(project.lastStatementAmount || "0");
      const lastStatementAmount = parseFloat(lastStatementAmountStr.replace(/,/g, "").replace(/[^\d.-]/g, "") || "0");
      
      if (lastStatementAmount === 0 || isNaN(lastStatementAmount)) return 0;
      if (contractAmount === 0) return 0;
      
      return parseFloat(((lastStatementAmount / contractAmount) * 100).toFixed(2));
    } catch (error) {
      console.error("Error calculating financial progress:", error);
      return 0;
    }
  };

  const filteredProjects = projects.filter((project) => {
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.contractNumber?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || project.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2">پروژه‌ها</h1>
          <p className="text-muted-foreground">مدیریت و پیگیری پروژه‌های در حال اجرا</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-new-project">
              <Plus className="w-4 h-4 ml-2" />
              پروژه جدید
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>ایجاد پروژه جدید</DialogTitle>
              <DialogDescription>
                اطلاعات پروژه جدید را وارد کنید
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان پروژه *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="عنوان پروژه را وارد کنید"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contractNumber">شماره قرارداد</Label>
                  <Input
                    id="contractNumber"
                    value={formData.contractNumber || ""}
                    onChange={(e) => setFormData({ ...formData, contractNumber: e.target.value })}
                    placeholder="شماره قرارداد"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">محل اجرا</Label>
                  <Input
                    id="location"
                    value={formData.location || ""}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="محل اجرای پروژه"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="employer">کارفرما</Label>
                  <Input
                    id="employer"
                    value={formData.employer || ""}
                    onChange={(e) => setFormData({ ...formData, employer: e.target.value })}
                    placeholder="نام کارفرما"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">مبلغ قرارداد (ریال)</Label>
                  <Input
                    id="amount"
                    value={formData.amount || ""}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="مبلغ قرارداد"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="startDate">تاریخ شروع</Label>
                  <Input
                    id="startDate"
                    value={formData.startDate || ""}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    placeholder="1402/01/01"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="progress">پیشرفت (%)</Label>
                  <Input
                    id="progress"
                    type="number"
                    min="0"
                    max="100"
                    value={formData.progress || 0}
                    onChange={(e) => setFormData({ ...formData, progress: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">وضعیت</Label>
                  <Select
                    value={formData.status || "active"}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger id="status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">در حال اجرا</SelectItem>
                      <SelectItem value="completed">تکمیل شده</SelectItem>
                      <SelectItem value="pending">در انتظار</SelectItem>
                      <SelectItem value="suspended">متوقف شده</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">اطلاعات مالی</h3>
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="projectNumber">شماره پروژه</Label>
                    <Input
                      id="projectNumber"
                      value={formData.projectNumber || ""}
                      onChange={(e) => setFormData({ ...formData, projectNumber: e.target.value })}
                      placeholder="شماره پروژه"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contractDate">تاریخ قرارداد</Label>
                    <Input
                      id="contractDate"
                      value={formData.contractDate || ""}
                      onChange={(e) => setFormData({ ...formData, contractDate: e.target.value })}
                      placeholder="1400/02/04"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contractor">پیمانکار</Label>
                    <Input
                      id="contractor"
                      value={formData.contractor || ""}
                      onChange={(e) => setFormData({ ...formData, contractor: e.target.value })}
                      placeholder="نام پیمانکار"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="amount25Percent">مبلغ 25% قرارداد (ریال)</Label>
                    <Input
                      id="amount25Percent"
                      value={formData.amount25Percent || ""}
                      onChange={(e) => setFormData({ ...formData, amount25Percent: e.target.value })}
                      placeholder="مبلغ 25% قرارداد"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="link">لینک</Label>
                    <Input
                      id="link"
                      value={formData.link || ""}
                      onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                      placeholder="لینک پروژه"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="financialProgress">درصد پیشرفت ریالی</Label>
                    <Input
                      id="financialProgress"
                      value={formData.financialProgress || ""}
                      onChange={(e) => setFormData({ ...formData, financialProgress: e.target.value })}
                      placeholder="58.54%"
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">آخرین اطلاعات مالی</h3>
                <div className="grid gap-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="lastStatementNumber">شماره آخرین صورت وضعیت</Label>
                      <Input
                        id="lastStatementNumber"
                        value={formData.lastStatementNumber || ""}
                        onChange={(e) => setFormData({ ...formData, lastStatementNumber: e.target.value })}
                        placeholder="2"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastStatementAmount">مبلغ آخرین صورت وضعیت (ریال)</Label>
                      <Input
                        id="lastStatementAmount"
                        value={formData.lastStatementAmount || ""}
                        onChange={(e) => setFormData({ ...formData, lastStatementAmount: e.target.value })}
                        placeholder="35,902,628,577"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="lastModificationNumber">شماره آخرین تعدیل</Label>
                      <Input
                        id="lastModificationNumber"
                        value={formData.lastModificationNumber || ""}
                        onChange={(e) => setFormData({ ...formData, lastModificationNumber: e.target.value })}
                        placeholder="2"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastModificationAmount">مبلغ آخرین تعدیل (ریال)</Label>
                      <Input
                        id="lastModificationAmount"
                        value={formData.lastModificationAmount || ""}
                        onChange={(e) => setFormData({ ...formData, lastModificationAmount: e.target.value })}
                        placeholder="14,948,065,358"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="lastBitumenDifferenceNumber">شماره آخرین مابه‌التفاوت قیر</Label>
                      <Input
                        id="lastBitumenDifferenceNumber"
                        value={formData.lastBitumenDifferenceNumber || ""}
                        onChange={(e) => setFormData({ ...formData, lastBitumenDifferenceNumber: e.target.value })}
                        placeholder="-"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastBitumenDifferenceAmount">مبلغ آخرین مابه‌التفاوت قیر (ریال)</Label>
                      <Input
                        id="lastBitumenDifferenceAmount"
                        value={formData.lastBitumenDifferenceAmount || ""}
                        onChange={(e) => setFormData({ ...formData, lastBitumenDifferenceAmount: e.target.value })}
                        placeholder="-"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                  انصراف
                </Button>
                <Button type="submit" disabled={createProjectMutation.isPending}>
                  {createProjectMutation.isPending ? "در حال ذخیره..." : "ذخیره پروژه"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Edit Project Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>ویرایش پروژه</DialogTitle>
            <DialogDescription>
              اطلاعات پروژه را ویرایش کنید
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-title">عنوان پروژه *</Label>
                <Input
                  id="edit-title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="عنوان پروژه را وارد کنید"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-contractNumber">شماره قرارداد</Label>
                <Input
                  id="edit-contractNumber"
                  value={formData.contractNumber || ""}
                  onChange={(e) => setFormData({ ...formData, contractNumber: e.target.value })}
                  placeholder="شماره قرارداد"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-location">محل اجرا</Label>
                <Input
                  id="edit-location"
                  value={formData.location || ""}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="محل اجرای پروژه"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-employer">کارفرما</Label>
                <Input
                  id="edit-employer"
                  value={formData.employer || ""}
                  onChange={(e) => setFormData({ ...formData, employer: e.target.value })}
                  placeholder="نام کارفرما"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-amount">مبلغ قرارداد (ریال)</Label>
                <Input
                  id="edit-amount"
                  value={formData.amount || ""}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  placeholder="مبلغ قرارداد"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-startDate">تاریخ شروع</Label>
                <Input
                  id="edit-startDate"
                  value={formData.startDate || ""}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  placeholder="1402/01/01"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-progress">پیشرفت (%)</Label>
                <Input
                  id="edit-progress"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.progress || 0}
                  onChange={(e) => setFormData({ ...formData, progress: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-status">وضعیت</Label>
                <Select
                  value={formData.status || "active"}
                  onValueChange={(value) => setFormData({ ...formData, status: value })}
                >
                  <SelectTrigger id="edit-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">در حال اجرا</SelectItem>
                    <SelectItem value="completed">تکمیل شده</SelectItem>
                    <SelectItem value="pending">در انتظار</SelectItem>
                    <SelectItem value="suspended">متوقف شده</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">اطلاعات مالی</h3>
              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-projectNumber">شماره پروژه</Label>
                  <Input
                    id="edit-projectNumber"
                    value={formData.projectNumber || ""}
                    onChange={(e) => setFormData({ ...formData, projectNumber: e.target.value })}
                    placeholder="شماره پروژه"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-contractDate">تاریخ قرارداد</Label>
                  <Input
                    id="edit-contractDate"
                    value={formData.contractDate || ""}
                    onChange={(e) => setFormData({ ...formData, contractDate: e.target.value })}
                    placeholder="1400/02/04"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-contractor">پیمانکار</Label>
                  <Input
                    id="edit-contractor"
                    value={formData.contractor || ""}
                    onChange={(e) => setFormData({ ...formData, contractor: e.target.value })}
                    placeholder="نام پیمانکار"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-amount25Percent">مبلغ 25% قرارداد (ریال)</Label>
                  <Input
                    id="edit-amount25Percent"
                    value={formData.amount25Percent || ""}
                    onChange={(e) => setFormData({ ...formData, amount25Percent: e.target.value })}
                    placeholder="مبلغ 25% قرارداد"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-link">لینک</Label>
                  <Input
                    id="edit-link"
                    value={formData.link || ""}
                    onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                    placeholder="لینک پروژه"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-financialProgress">درصد پیشرفت ریالی</Label>
                  <Input
                    id="edit-financialProgress"
                    value={formData.financialProgress || ""}
                    onChange={(e) => setFormData({ ...formData, financialProgress: e.target.value })}
                    placeholder="58.54%"
                  />
                </div>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">آخرین اطلاعات مالی</h3>
              <div className="grid gap-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-lastStatementNumber">شماره آخرین صورت وضعیت</Label>
                    <Input
                      id="edit-lastStatementNumber"
                      value={formData.lastStatementNumber || ""}
                      onChange={(e) => setFormData({ ...formData, lastStatementNumber: e.target.value })}
                      placeholder="2"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-lastStatementAmount">مبلغ آخرین صورت وضعیت (ریال)</Label>
                    <Input
                      id="edit-lastStatementAmount"
                      value={formData.lastStatementAmount || ""}
                      onChange={(e) => setFormData({ ...formData, lastStatementAmount: e.target.value })}
                      placeholder="35,902,628,577"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-lastModificationNumber">شماره آخرین تعدیل</Label>
                    <Input
                      id="edit-lastModificationNumber"
                      value={formData.lastModificationNumber || ""}
                      onChange={(e) => setFormData({ ...formData, lastModificationNumber: e.target.value })}
                      placeholder="2"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-lastModificationAmount">مبلغ آخرین تعدیل (ریال)</Label>
                    <Input
                      id="edit-lastModificationAmount"
                      value={formData.lastModificationAmount || ""}
                      onChange={(e) => setFormData({ ...formData, lastModificationAmount: e.target.value })}
                      placeholder="14,948,065,358"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-lastBitumenDifferenceNumber">شماره آخرین مابه‌التفاوت قیر</Label>
                    <Input
                      id="edit-lastBitumenDifferenceNumber"
                      value={formData.lastBitumenDifferenceNumber || ""}
                      onChange={(e) => setFormData({ ...formData, lastBitumenDifferenceNumber: e.target.value })}
                      placeholder="-"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-lastBitumenDifferenceAmount">مبلغ آخرین مابه‌التفاوت قیر (ریال)</Label>
                    <Input
                      id="edit-lastBitumenDifferenceAmount"
                      value={formData.lastBitumenDifferenceAmount || ""}
                      onChange={(e) => setFormData({ ...formData, lastBitumenDifferenceAmount: e.target.value })}
                      placeholder="-"
                    />
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditOpen(false)}>
                انصراف
              </Button>
              <Button type="submit" disabled={editProjectMutation.isPending}>
                {editProjectMutation.isPending ? "در حال ذخیره..." : "ذخیره تغییرات"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="جستجو در پروژه‌ها..."
            className="pr-10"
            data-testid="input-search-projects"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full md:w-48" data-testid="select-filter">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه پروژه‌ها</SelectItem>
            <SelectItem value="active">در حال اجرا</SelectItem>
            <SelectItem value="completed">تکمیل شده</SelectItem>
            <SelectItem value="pending">در انتظار</SelectItem>
            <SelectItem value="suspended">متوقف شده</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {projectsError && (
        <div className="text-center py-8 text-red-600 bg-red-50 dark:bg-red-950 rounded-lg p-4 mb-4">
          <p className="font-semibold">خطا در بارگذاری پروژه‌ها</p>
          <p className="text-sm">{projectsError.message}</p>
          <p className="text-xs mt-2 text-muted-foreground">
            لطفاً مطمئن شوید که وارد سیستم شده‌اید و دوباره تلاش کنید.
          </p>
          <Button 
            onClick={() => window.location.reload()} 
            className="mt-4"
            variant="outline"
          >
            بارگذاری مجدد
          </Button>
        </div>
      )}
      {isLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                  <Skeleton className="h-6 w-16" />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-5/6" />
                  <Skeleton className="h-4 w-4/6" />
                </div>
                <div className="space-y-2">
                  <Skeleton className="h-2 w-full rounded-full" />
                  <Skeleton className="h-4 w-20" />
                </div>
                <div className="flex gap-2 pt-2">
                  <Skeleton className="h-9 flex-1" />
                  <Skeleton className="h-9 w-9" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          <p className="text-sm text-muted-foreground">
            {filteredProjects.length} پروژه
          </p>
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredProjects.map((project) => {
              // محاسبه درصد پیشرفت بر اساس مبلغ آخرین صورت وضعیت
              const financialProgress = calculateFinancialProgress(project);
              
              return (
                <ProjectCard
                  key={project.id}
                  id={project.id}
                  title={project.title}
                  contractNumber={project.contractNumber || ""}
                  location={project.location || ""}
                  employer={project.employer || ""}
                  amount={project.amount || "0"}
                  progress={financialProgress}
                  status={(project.status as "active" | "completed" | "pending" | "suspended") || "active"}
                  startDate={project.startDate || ""}
                  onViewDetails={handleViewDetails}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
