# راهنمای استقرار سریع‌سازان البرز روی سرور مجازی (VPS)

این راهنمای گام‌به‌گام برای استقرار برنامه سریع‌سازان البرز روی سرور مجازی شما است.

## پیش‌نیازها

- سرور مجازی (VPS) با Ubuntu 20.04 یا بالاتر
- دسترسی SSH به سرور
- حداقل 2GB RAM
- حداقل 20GB فضای ذخیره‌سازی

## مرحله 1: اتصال به سرور

```bash
ssh root@IP_ADDRESS_SERVER
```

جایگزین کنید `IP_ADDRESS_SERVER` را با آدرس IP سرور خودتان.

## مرحله 2: نصب Node.js

```bash
# بروزرسانی سیستم
sudo apt update && sudo apt upgrade -y

# نصب Node.js 20 (نسخه توصیه شده)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# بررسی نصب
node --version  # باید 20.x.x را نشان دهد
npm --version
```

## مرحله 3: نصب و راه‌اندازی PostgreSQL

```bash
# نصب PostgreSQL
sudo apt install postgresql postgresql-contrib -y

# راه‌اندازی PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# ایجاد کاربر و دیتابیس
sudo -u postgres psql << EOF
CREATE DATABASE sarisazan_db;
CREATE USER sarisazan_user WITH PASSWORD 'YOUR_SECURE_PASSWORD_HERE';
GRANT ALL PRIVILEGES ON DATABASE sarisazan_db TO sarisazan_user;
\q
EOF
```

**⚠️ مهم**: `YOUR_SECURE_PASSWORD_HERE` را با یک رمز عبور قوی جایگزین کنید.

## مرحله 4: نصب NGINX (وب سرور)

```bash
# نصب NGINX
sudo apt install nginx -y

# راه‌اندازی NGINX
sudo systemctl start nginx
sudo systemctl enable nginx
```

## مرحله 5: آپلود فایل‌های برنامه

### روش 1: با استفاده از Git (توصیه می‌شود)

```bash
# نصب Git
sudo apt install git -y

# کلون کردن مخزن
cd /var/www
sudo git clone YOUR_REPOSITORY_URL sarisazan
cd sarisazan

# اگر مخزن private است، از توکن استفاده کنید
# git clone https://USERNAME:TOKEN@github.com/username/repo.git
```

### روش 2: با استفاده از SCP

در کامپیوتر محلی خودتان:

```bash
# فشرده‌سازی پروژه
cd /path/to/your/project
tar -czf sarisazan.tar.gz .

# آپلود به سرور
scp sarisazan.tar.gz root@IP_ADDRESS_SERVER:/var/www/

# در سرور:
cd /var/www
tar -xzf sarisazan.tar.gz
mkdir -p sarisazan
mv * sarisazan/ 2>/dev/null || true
cd sarisazan
```

## مرحله 6: تنظیم متغیرهای محیطی

```bash
# ایجاد فایل .env
cd /var/www/sarisazan
sudo nano .env
```

محتوای زیر را در فایل قرار دهید:

```env
# اطلاعات دیتابیس
DATABASE_URL=postgresql://sarisazan_user:YOUR_SECURE_PASSWORD_HERE@localhost:5432/sarisazan_db

# اطلاعات سرور
NODE_ENV=production
PORT=5000

# کلید AI (اختیاری - اگر دارید)
XAI_API_KEY=your_xai_api_key_if_you_have_one

# امنیت
SESSION_SECRET=$(openssl rand -hex 32)
```

ذخیره کنید با `Ctrl+X`, سپس `Y`, سپس `Enter`.

## مرحله 7: نصب dependencies و build برنامه

```bash
cd /var/www/sarisazan

# نصب dependencies
npm install

# Build برنامه برای production
npm run build

# اجرای migration دیتابیس
npm run db:push
```

## مرحله 8: نصب PM2 (Process Manager)

```bash
# نصب PM2 به صورت global
sudo npm install -g pm2

# راه‌اندازی برنامه با PM2
pm2 start npm --name "sarisazan" -- start

# ذخیره‌سازی تنظیمات PM2
pm2 save

# راه‌اندازی خودکار PM2 هنگام بوت سیستم
pm2 startup systemd
# دستور خروجی را کپی و اجرا کنید
```

## مرحله 9: تنظیم NGINX به عنوان Reverse Proxy

```bash
# ایجاد فایل تنظیمات NGINX
sudo nano /etc/nginx/sites-available/sarisazan
```

محتوای زیر را قرار دهید:

```nginx
server {
    listen 80;
    server_name YOUR_DOMAIN_OR_IP;

    # افزایش حجم آپلود فایل
    client_max_body_size 100M;

    location / {
        proxy_pass http://localhost:60000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # افزایش timeout برای عملیات طولانی
        proxy_connect_timeout 6000;
        proxy_send_timeout 6000;
        proxy_read_timeout 6000;
        send_timeout 6000;
    }
}
```

فعال‌سازی تنظیمات:

```bash
# ایجاد لینک symbolic
sudo ln -s /etc/nginx/sites-available/sarisazan /etc/nginx/sites-enabled/

# حذف تنظیمات پیش‌فرض
sudo rm /etc/nginx/sites-enabled/default

# بررسی صحت تنظیمات
sudo nginx -t

# راه‌اندازی مجدد NGINX
sudo systemctl restart nginx
```

## مرحله 10: تنظیم Firewall

```bash
# فعال‌سازی UFW
sudo ufw enable

# باز کردن پورت‌های لازم
sudo ufw allow 22    # SSH
sudo ufw allow 80    # HTTP
sudo ufw allow 443   # HTTPS (برای آینده)

# بررسی وضعیت
sudo ufw status
```

## مرحله 11: نصب SSL (اختیاری اما توصیه می‌شود)

اگر دامنه دارید (مثل sarisazan.ir):

```bash
# نصب Certbot
sudo apt install certbot python3-certbot-nginx -y

# دریافت گواهی SSL
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# تست تمدید خودکار
sudo certbot renew --dry-run
```

## مرحله 12: ایجاد کاربر Admin اولیه

برنامه به صورت خودکار کاربر admin می‌سازد:
- **نام کاربری**: `admin`
- **رمز عبور**: `admin123`

⚠️ **مهم**: بعد از اولین ورود، حتماً رمز عبور را تغییر دهید!

## مرحله 13: بررسی و مانیتورینگ

```bash
# مشاهده لاگ‌های برنامه
pm2 logs sarisazan

# مشاهده وضعیت برنامه
pm2 status

# مشاهده استفاده از منابع
pm2 monit

# راه‌اندازی مجدد برنامه (در صورت نیاز)
pm2 restart sarisazan

# توقف برنامه
pm2 stop sarisazan

# شروع برنامه
pm2 start sarisazan
```

## پشتیبان‌گیری خودکار از دیتابیس

```bash
# ایجاد پوشه backup
sudo mkdir -p /var/backups/sarisazan

# ایجاد اسکریپت backup
sudo nano /usr/local/bin/backup-sarisazan.sh
```

محتوای اسکریپت:

```bash
#!/bin/bash
BACKUP_DIR="/var/backups/sarisazan"
DATE=$(date +%Y%m%d_%H%M%S)
FILENAME="sarisazan_backup_$DATE.sql"

# Backup دیتابیس
sudo -u postgres pg_dump sarisazan_db > $BACKUP_DIR/$FILENAME

# فشرده‌سازی
gzip $BACKUP_DIR/$FILENAME

# حذف فایل‌های قدیمی‌تر از 30 روز
find $BACKUP_DIR -name "*.gz" -mtime +30 -delete

echo "Backup completed: $FILENAME.gz"
```

اجرای خودکار روزانه:

```bash
# اجازه اجرا
sudo chmod +x /usr/local/bin/backup-sarisazan.sh

# افزودن به crontab (هر شب ساعت 2 بامداد)
sudo crontab -e
# اضافه کنید:
0 2 * * * /usr/local/bin/backup-sarisazan.sh >> /var/log/sarisazan-backup.log 2>&1
```

## بروزرسانی برنامه

```bash
cd /var/www/sarisazan

# دریافت آخرین تغییرات
sudo git pull

# نصب dependencies جدید
npm install

# Build مجدد
npm run build

# اجرای migration (در صورت نیاز)
npm run db:push

# راه‌اندازی مجدد برنامه
pm2 restart sarisazan
```

## عیب‌یابی مشکلات رایج

### برنامه راه‌اندازی نمی‌شود

```bash
# بررسی لاگ‌ها
pm2 logs sarisazan

# بررسی دیتابیس
sudo -u postgres psql -c "\l"

# بررسی اتصال دیتابیس
sudo -u postgres psql -d sarisazan_db
```

### خطای دسترسی به دیتابیس

```bash
# بررسی تنظیمات PostgreSQL
sudo nano /etc/postgresql/*/main/pg_hba.conf

# اطمینان از وجود این خط:
# local   all             all                                     md5

# راه‌اندازی مجدد PostgreSQL
sudo systemctl restart postgresql
```

### NGINX خطا می‌دهد

```bash
# بررسی تنظیمات
sudo nginx -t

# مشاهده لاگ‌های خطا
sudo tail -f /var/log/nginx/error.log
```

## امنیت بیشتر

### تغییر پورت SSH (توصیه می‌شود)

```bash
sudo nano /etc/ssh/sshd_config
# تغییر دهید:
Port 2222  # به جای 22

sudo systemctl restart sshd

# به‌روزرسانی firewall
sudo ufw allow 2222
sudo ufw delete allow 22
```

### نصب Fail2Ban (محافظت در برابر حملات brute-force)

```bash
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

## پشتیبانی و کمک

- مستندات رسمی: `/path/to/your/docs`
- Issues: GitHub repository issues
- تیم پشتیبانی: support@example.com

---

## خلاصه دستورات سریع

```bash
# مشاهده وضعیت
pm2 status

# مشاهده لاگ‌ها
pm2 logs sarisazan

# راه‌اندازی مجدد
pm2 restart sarisazan

# Backup دستی دیتابیس
sudo -u postgres pg_dump sarisazan_db > backup.sql

# بررسی استفاده از منابع
htop

# مانیتورینگ دیسک
df -h
```

---

🎉 **تبریک! برنامه شما با موفقیت روی سرور مجازی مستقر شد!**

حالا می‌توانید با مراجعه به `http://YOUR_SERVER_IP` از برنامه استفاده کنید.
