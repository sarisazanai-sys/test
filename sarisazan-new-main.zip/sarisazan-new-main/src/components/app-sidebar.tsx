import { Home, FolderKanban, FileText, Droplet, ClipboardList, Gavel, Bell, Users, Shield, User as UserIcon, Inbox, ChevronDown, Receipt, Sparkles, CheckSquare, Calendar, StickyNote, Mail, Fuel } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link, useLocation } from "wouter";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useSidebar } from "@/components/ui/sidebar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useState, useEffect } from "react";

type MenuItem = {
  title: string;
  url?: string;
  icon: any;
  id: string;
  emoji?: string;
  iconColor?: string;
  subItems?: Array<{
    title: string;
    url: string;
    id: string;
    emoji?: string;
  }>;
};

// Icon color mapping - vibrant, distinct colors for each menu item
const iconColorMap: Record<string, string> = {
  dashboard: "text-blue-600",
  projects: "text-emerald-600",
  tasks: "text-green-600",
  reports: "text-violet-600",
  statements: "text-cyan-600",
  "bitumen-diffs": "text-purple-600",
  bitumen: "text-gray-700",
  sheets: "text-teal-600",
  tenders: "text-amber-600",
  alerts: "text-red-600",
  users: "text-indigo-600",
  roles: "text-slate-600",
  "ai-assistant": "text-purple-600",
  profile: "text-sky-600",
  messages: "text-orange-500",
  calendar: "text-blue-500",
  notes: "text-yellow-600",
  letters: "text-orange-600",
};

// Hover background color mapping
const hoverColorMap: Record<string, string> = {
  dashboard: "hover:bg-blue-50 dark:hover:bg-blue-950/20",
  projects: "hover:bg-emerald-50 dark:hover:bg-emerald-950/20",
  tasks: "hover:bg-green-50 dark:hover:bg-green-950/20",
  reports: "hover:bg-violet-50 dark:hover:bg-violet-950/20",
  statements: "hover:bg-cyan-50 dark:hover:bg-cyan-950/20",
  "bitumen-diffs": "hover:bg-purple-50 dark:hover:bg-purple-950/20",
  bitumen: "hover:bg-gray-50 dark:hover:bg-gray-950/20",
  sheets: "hover:bg-teal-50 dark:hover:bg-teal-950/20",
  tenders: "hover:bg-amber-50 dark:hover:bg-amber-950/20",
  alerts: "hover:bg-red-50 dark:hover:bg-red-950/20",
  users: "hover:bg-indigo-50 dark:hover:bg-indigo-950/20",
  roles: "hover:bg-slate-50 dark:hover:bg-slate-950/20",
  "ai-assistant": "hover:bg-purple-50 dark:hover:bg-purple-950/20",
  profile: "hover:bg-sky-50 dark:hover:bg-sky-950/20",
  messages: "hover:bg-orange-50 dark:hover:bg-orange-950/20",
  calendar: "hover:bg-blue-50 dark:hover:bg-blue-950/20",
  notes: "hover:bg-yellow-50 dark:hover:bg-yellow-950/20",
  letters: "hover:bg-orange-50 dark:hover:bg-orange-950/20",
};

// Border color mapping for hover effect (right border for RTL layout)
const borderColorMap: Record<string, string> = {
  dashboard: "hover:border-r-blue-600",
  projects: "hover:border-r-emerald-600",
  tasks: "hover:border-r-green-600",
  reports: "hover:border-r-violet-600",
  statements: "hover:border-r-cyan-600",
  "bitumen-diffs": "hover:border-r-purple-600",
  bitumen: "hover:border-r-gray-700",
  sheets: "hover:border-r-teal-600",
  tenders: "hover:border-r-amber-600",
  alerts: "hover:border-r-red-600",
  users: "hover:border-r-indigo-600",
  roles: "hover:border-r-slate-600",
  "ai-assistant": "hover:border-r-purple-600",
  profile: "hover:border-r-sky-600",
  messages: "hover:border-r-orange-500",
  calendar: "hover:border-r-blue-500",
  notes: "hover:border-r-yellow-600",
  letters: "hover:border-r-orange-600",
};

// Mapping between menu items and required permissions
const menuItemPermissions: Record<string, string | null> = {
  "dashboard": null, // Always visible
  "tasks": "tasks.view",
  "projects": "projects.view",
  "calendar": "calendar.view",
  "notes": "notes.view",
  "reports": "reports.view",
  "statements": "statements.view",
  "bitumen-diffs": "bitumen.view",
  "bitumen": "bitumen.view",
  "sheets": "sheets.view",
  "tenders": "tenders.view",
  "alerts": "alerts.view",
  "users": "users.view",
  "roles": "roles.view",
  "messages": "messages.view",
  "ai-assistant": "analysis.view",
  "profile": null, // Always visible
};

const menuItems: MenuItem[] = [
  { title: "داشبورد", url: "/", icon: Home, id: "dashboard" },
  { title: "وظایف", url: "/tasks", icon: CheckSquare, id: "tasks" },
  { title: "پروژه‌ها", url: "/projects", icon: FolderKanban, id: "projects" },
  { title: "تقویم", url: "/calendar", icon: Calendar, id: "calendar" },
  { title: "یادداشت‌ها", url: "/notes", icon: StickyNote, id: "notes" },
  { 
    title: "گزارش روزانه", 
    icon: FileText, 
    id: "reports",
    subItems: [
      { title: "📑 دفتر فنی", url: "/reports/technical", id: "technical-report" },
      { title: "📋 اجرا", url: "/reports/execution", id: "execution-report" },
    ]
  },
  { title: "صورت‌وضعیت‌ها", url: "/statements", icon: Receipt, id: "statements" },
  { title: "مابه‌التفاوت قیر", url: "/bitumen-diffs", icon: Fuel, id: "bitumen-diffs" },
  { title: "قیر", url: "/bitumen", icon: Droplet, id: "bitumen" },
  { title: "شیت‌ها", url: "/sheets", icon: ClipboardList, id: "sheets" },
  { title: "مناقصات", url: "/tenders", icon: Gavel, id: "tenders" },
  { title: "هشدارها", url: "/alerts", icon: Bell, id: "alerts" },
];

const adminItems: MenuItem[] = [
  { title: "کاربران", url: "/users", icon: Users, id: "users" },
  { title: "نقش‌ها و مجوزها", url: "/roles", icon: Shield, id: "roles" },
];

const userItems: MenuItem[] = [
  { title: "دستیار هوش مصنوعی", url: "/ai-assistant", icon: Sparkles, id: "ai-assistant" },
  { title: "پروفایل من", url: "/profile", icon: UserIcon, id: "profile" },
  { title: "پیام‌ها", url: "/messages", icon: Inbox, id: "messages" },
];

/**
 * AppSidebar Component - ULTRA STABLE VERSION
 * 
 * IMPORTANT: This component is designed to NEVER lose menu items, regardless of:
 * - API failures
 * - Rate limiting
 * - Changes in other files
 * - Hot reloads
 * - State changes
 * 
 * Design principles:
 * 1. NO API calls - completely independent
 * 2. NO permission checking - shows all items always
 * 3. NO useMemo/useEffect with dependencies - prevents re-computation
 * 4. Direct constant assignment - menuItems, adminItems, userItems are always used
 * 5. Fallback rendering - if filtered arrays are empty, show original arrays
 * 
 * DO NOT ADD:
 * - API calls (useQuery, fetch, etc.)
 * - Permission checking logic
 * - useMemo with dependencies
 * - useEffect with dependencies (except empty array for one-time logging)
 * - Any conditional logic that might hide menu items
 */
export function AppSidebar({ currentUser }: { currentUser?: { name: string; role: string; avatar?: string } }) {
  const [location] = useLocation();
  const { state } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [openSubMenus, setOpenSubMenus] = useState<Set<string>>(new Set(["reports"]));
  
  // ULTRA SIMPLE & STABLE: Always show all items - NO CONDITIONS, NO API, NO STATE, NO DEPENDENCIES
  // This ensures sidebar NEVER disappears, regardless of any changes in other files
  // Direct assignment - no useMemo, no useEffect with dependencies, no re-computation
  // These are CONSTANT values that NEVER change
  const filteredMenuItems = menuItems;
  const filteredAdminItems = adminItems;
  const filteredUserItems = userItems;
  
  // Minimal debug logging (only once on mount - empty dependency array)
  // DO NOT add dependencies to this useEffect - it should only run once
  useEffect(() => {
    console.log("✅✅✅ AppSidebar - STABLE VERSION - ALL ITEMS ALWAYS VISIBLE:", {
      menuItems: menuItems.length,
      adminItems: adminItems.length,
      userItems: userItems.length,
      total: menuItems.length + adminItems.length + userItems.length,
      currentUserRole: currentUser?.role,
      filteredMenuItemsLength: filteredMenuItems.length,
      filteredAdminItemsLength: filteredAdminItems.length,
      filteredUserItemsLength: filteredUserItems.length,
      note: "NO API CALLS - NO PERMISSIONS - ALWAYS SHOWS ALL ITEMS",
    });
    console.log("✅✅✅ AppSidebar - Menu Items:", menuItems.map(i => i.title));
    console.log("✅✅✅ AppSidebar - Admin Items:", adminItems.map(i => i.title));
    console.log("✅✅✅ AppSidebar - User Items:", userItems.map(i => i.title));
  }, []); // Empty dependency array - only log once on mount, never re-run

  const toggleSubMenu = (id: string) => {
    setOpenSubMenus(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const renderMenuItem = (item: MenuItem) => {
    const iconColor = iconColorMap[item.id] || "text-gray-600";
    const hoverColor = hoverColorMap[item.id] || "hover:bg-gray-100";
    const borderColor = borderColorMap[item.id] || "hover:border-r-gray-600";
    
    if (item.subItems) {
      const hasActiveSubItem = item.subItems.some(subItem => location === subItem.url);
      const isOpen = openSubMenus.has(item.id);
      
      if (isCollapsed) {
        return (
          <Tooltip>
            <TooltipTrigger asChild>
              <Link href={item.subItems[0].url}>
                <SidebarMenuButton 
                  data-testid={`nav-${item.id}`}
                  className={`border-r-2 border-r-transparent ${borderColor} transition-all duration-200`}
                >
                  <item.icon className={`w-5 h-5 ${iconColor}`} />
                </SidebarMenuButton>
              </Link>
            </TooltipTrigger>
            <TooltipContent side="right">
              <p>{item.title}</p>
            </TooltipContent>
          </Tooltip>
        );
      }

      return (
        <Collapsible open={isOpen} onOpenChange={() => toggleSubMenu(item.id)}>
          <CollapsibleTrigger asChild>
            <SidebarMenuButton 
              data-testid={`nav-${item.id}`} 
              isActive={hasActiveSubItem} 
              className={`border-r-2 border-r-transparent ${borderColor} ${hoverColor} transition-all duration-200`}
            >
              <item.icon className={`w-5 h-5 ${iconColor}`} />
              <span>{item.title}</span>
              <ChevronDown className={`mr-auto w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </SidebarMenuButton>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <SidebarMenuSub>
              {item.subItems.map((subItem) => {
                const isActive = location === subItem.url;
                return (
                  <SidebarMenuSubItem key={subItem.id}>
                    <SidebarMenuSubButton asChild isActive={isActive}>
                      <Link href={subItem.url}>
                        <span>{subItem.title}</span>
                      </Link>
                    </SidebarMenuSubButton>
                  </SidebarMenuSubItem>
                );
              })}
            </SidebarMenuSub>
          </CollapsibleContent>
        </Collapsible>
      );
    }

    const isActive = location === item.url || (item.url !== "/" && location.startsWith(item.url!));
    
    const button = (
      <SidebarMenuButton 
        asChild 
        data-testid={`nav-${item.id}`} 
        isActive={isActive} 
        className={`border-r-2 border-r-transparent ${borderColor} ${hoverColor} transition-all duration-200`}
      >
        <Link href={item.url!} className="flex items-center gap-3">
          <item.icon className={`w-5 h-5 ${iconColor}`} />
          {!isCollapsed && <span>{item.title}</span>}
        </Link>
      </SidebarMenuButton>
    );

    if (isCollapsed) {
      return (
        <Tooltip>
          <TooltipTrigger asChild>
            {button}
          </TooltipTrigger>
          <TooltipContent side="right">
            <p>{item.title}</p>
          </TooltipContent>
        </Tooltip>
      );
    }

    return button;
  };


  return (
    <Sidebar side="right" collapsible="icon" className="relative">
      <SidebarHeader className="p-4 border-b">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl">
            س
          </div>
          {!isCollapsed && (
            <div className="flex-1">
              <h2 className="font-bold text-lg">سیستم مدیریت پروژه</h2>
              <p className="text-xs text-muted-foreground">سریع‌سازان البرز</p>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          {!isCollapsed && <SidebarGroupLabel>منوی اصلی</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              {/* ALWAYS RENDER ALL MENU ITEMS - NO CONDITIONS */}
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  {renderMenuItem(item)}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Always show admin menu - no conditions */}
        <SidebarGroup>
          {!isCollapsed && <SidebarGroupLabel>مدیریت</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              {/* ALWAYS RENDER ALL ADMIN ITEMS - NO CONDITIONS */}
              {adminItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  {renderMenuItem(item)}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {!isCollapsed && <SidebarGroupLabel>کاربری</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              {/* ALWAYS RENDER ALL USER ITEMS - NO CONDITIONS */}
              {userItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  {renderMenuItem(item)}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4 border-t">
        {!isCollapsed ? (
          <div className="flex items-center gap-3 p-2 rounded-md">
            <Avatar className="w-8 h-8">
              <AvatarImage src={currentUser?.avatar} />
              <AvatarFallback>
                <UserIcon className="w-4 h-4" />
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{currentUser?.name || "کاربر"}</p>
              <p className="text-xs text-muted-foreground truncate">{currentUser?.role || "نقش"}</p>
            </div>
          </div>
        ) : (
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center justify-center p-2">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={currentUser?.avatar} />
                  <AvatarFallback>
                    <UserIcon className="w-4 h-4" />
                  </AvatarFallback>
                </Avatar>
              </div>
            </TooltipTrigger>
            <TooltipContent side="right">
              <p>{currentUser?.name || "کاربر"}</p>
              <p className="text-xs text-muted-foreground">{currentUser?.role || "نقش"}</p>
            </TooltipContent>
          </Tooltip>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}
