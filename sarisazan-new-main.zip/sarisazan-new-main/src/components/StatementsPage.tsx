import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, TrendingUp, Calculator, Search, X, Plus } from "lucide-react";
import { format } from "date-fns-jalali";
import { toPersianDigits, formatCurrency } from "@/lib/persian-utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

type Statement = {
  id: string;
  projectId: string;
  statementNumber: string;
  amount: string;
  status: string;
  startDate?: string | null;
  endDate?: string | null;
  announcedDate?: string | null;
  submissionDate?: string | null;
  notes?: string | null;
  createdAt: string;
  updatedAt?: string | null;
};

type Adjustment = {
  id: string;
  projectId: string;
  modificationNumber: string;
  amount?: string | null;
  status: string;
  startDate?: string | null;
  endDate?: string | null;
  notes?: string | null;
  createdAt: string;
  updatedAt?: string | null;
};

type BitumenDiff = {
  id: string;
  projectId: string;
  differenceNumber: string;
  amount: string;
  status: string;
  notes?: string | null;
  createdAt: string;
  updatedAt?: string | null;
};

type Project = {
  id: string;
  title: string;
  contractNumber?: string | null;
  contractDate?: string | null;
  employer?: string | null;
  contractor?: string | null;
  amount?: string | null;
};

type ProjectSummary = {
  project: Project;
  latestStatement: Statement | null;
  latestAdjustment: Adjustment | null;
  latestBitumenDiff: BitumenDiff | null;
};

// Helper function to check if status is approved
const isApprovedStatus = (status: string | null | undefined): boolean => {
  if (!status) return false;
  const statusLower = status.toLowerCase().trim();
  const approvedStatuses = [
    "تأیید شده", "تایید شده", "تأییدشده", "تاییدشده",
    "confirmed", "approve", "approved", "تایید", "تأیید"
  ];
  return approvedStatuses.some(approved => statusLower === approved.toLowerCase());
};

// Helper function to parse date safely
const parseDate = (dateStr: string | null | undefined): Date => {
  if (!dateStr) return new Date(0);
  try {
    const parsed = new Date(dateStr);
    return isNaN(parsed.getTime()) ? new Date(0) : parsed;
  } catch {
    return new Date(0);
  }
};

// Helper function to get latest item (regardless of status)
// Changed: Show latest item even if status is "موقت" (temporary) or not approved
const getLatestItem = <T extends { status?: string | null; createdAt?: string | null; updatedAt?: string | null }>(
  items: T[],
  getDate: (item: T) => string | null | undefined
): T | null => {
  if (items.length === 0) return null;
  
  // Sort by date (newest first) and return the latest one
  // No filtering by status - show the most recent item regardless of status
  return items.sort((a, b) => {
    const dateA = parseDate(getDate(a));
    const dateB = parseDate(getDate(b));
    return dateB.getTime() - dateA.getTime(); // Descending order (newest first)
  })[0];
};

export default function StatementsPage() {
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [createStatementDialogOpen, setCreateStatementDialogOpen] = useState(false);
  const [createAdjustmentDialogOpen, setCreateAdjustmentDialogOpen] = useState(false);
  const [createBitumenDiffDialogOpen, setCreateBitumenDiffDialogOpen] = useState(false);
  const [selectedProjectForCreate, setSelectedProjectForCreate] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get user ID from localStorage for headers
  const getUserId = (): string | null => {
    try {
      const currentUserStored = localStorage.getItem("currentUser");
      if (currentUserStored) {
        const user = JSON.parse(currentUserStored);
        if (user?.id) return user.id;
      }
      const userStored = localStorage.getItem("user");
      if (userStored) {
        const user = JSON.parse(userStored);
        if (user?.id) return user.id;
      }
    } catch (error) {
      console.error("Failed to get user ID from localStorage:", error);
    }
    return null;
  };

  const getHeaders = (): HeadersInit => {
    const headers: Record<string, string> = {};
    const userId = getUserId();
    if (userId) {
      headers["x-user-id"] = userId;
    }
    return headers as HeadersInit;
  };

  // Check if user is authenticated before making requests
  const userId = getUserId();
  
  // Fetch all projects
  const { data: projects = [], isLoading: isLoadingProjects, error: projectsError } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    queryFn: async () => {
      const headers = getHeaders();
      const headerRecord = headers as Record<string, string>;
      if (!headerRecord["x-user-id"]) {
        throw new Error("احراز هویت لازم است. لطفاً دوباره وارد سیستم شوید.");
      }
      const response = await fetch("/api/projects", { headers });
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("احراز هویت لازم است. لطفاً دوباره وارد سیستم شوید.");
        }
        throw new Error("خطا در دریافت پروژه‌ها");
      }
      return response.json();
    },
    enabled: !!userId, // Only fetch if user ID exists
    retry: false,
  });

  // Fetch all statements - with better error handling for rate limiting
  const { data: allStatements = [], isLoading: isLoadingStatements, error: statementsError } = useQuery<Statement[]>({
    queryKey: ["/api/statements"],
    queryFn: async () => {
      const headers = getHeaders();
      if (!headers["x-user-id"]) {
        return []; // Return empty if not authenticated
      }
      const response = await fetch("/api/statements", { headers });
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          // Permission denied, return empty array silently
          return [];
        }
        if (response.status === 429) {
          // Rate limited - return empty array instead of throwing
          console.warn("Rate limited for /api/statements, returning empty array");
          return [];
        }
        throw new Error("خطا در دریافت صورت‌وضعیت‌ها");
      }
      return response.json();
    },
    enabled: !!userId, // Only fetch if user ID exists
    retry: false, // Don't retry to avoid more rate limiting
    staleTime: 300000, // Consider data fresh for 5 minutes
  });

  // Fetch all adjustments - with better error handling for rate limiting
  const { data: allAdjustments = [], isLoading: isLoadingAdjustments, error: adjustmentsError } = useQuery<Adjustment[]>({
    queryKey: ["/api/adjustments"],
    queryFn: async () => {
      const headers = getHeaders();
      if (!headers["x-user-id"]) {
        return []; // Return empty if not authenticated
      }
      const response = await fetch("/api/adjustments", { headers });
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          // Permission denied, return empty array silently
          return [];
        }
        if (response.status === 429) {
          // Rate limited - return empty array instead of throwing
          console.warn("Rate limited for /api/adjustments, returning empty array");
          return [];
        }
        throw new Error("خطا در دریافت تعدیل‌ها");
      }
      return response.json();
    },
    enabled: !!userId, // Only fetch if user ID exists
    retry: false, // Don't retry to avoid more rate limiting
    staleTime: 300000, // Consider data fresh for 5 minutes
  });

  // Fetch all bitumen diffs - with better error handling for rate limiting
  const { data: allBitumenDiffs = [], isLoading: isLoadingBitumenDiffs, error: bitumenDiffsError } = useQuery<BitumenDiff[]>({
    queryKey: ["/api/bitumen-diffs"],
    queryFn: async () => {
      const headers = getHeaders();
      if (!headers["x-user-id"]) {
        return []; // Return empty if not authenticated
      }
      const response = await fetch("/api/bitumen-diffs", { headers });
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          // Permission denied, return empty array silently
          return [];
        }
        if (response.status === 429) {
          // Rate limited - return empty array instead of throwing
          console.warn("Rate limited for /api/bitumen-diffs, returning empty array");
          return [];
        }
        throw new Error("خطا در دریافت مابه‌التفاوت‌ها");
      }
      return response.json();
    },
    enabled: !!userId, // Only fetch if user ID exists
    retry: false, // Don't retry to avoid more rate limiting
    staleTime: 300000, // Consider data fresh for 5 minutes
  });

  // Fetch detailed data for selected project
  const { data: projectDetails, isLoading: isLoadingDetails, error: projectDetailsError } = useQuery<{
    statements: Statement[];
    adjustments: Adjustment[];
    bitumenDiffs: BitumenDiff[];
  }>({
    queryKey: ["/api/projects", selectedProjectId, "financial-history"],
    enabled: !!selectedProjectId,
    queryFn: async () => {
      const response = await fetch(`/api/projects/${selectedProjectId}/financial-history`, {
        headers: getHeaders(),
      });
      if (!response.ok) {
        if (response.status === 429) {
          // Return empty data structure instead of throwing error
          console.warn(`Rate limited for project ${selectedProjectId} financial-history`);
          return { statements: [], adjustments: [], bitumenDiffs: [] };
        }
        if (response.status === 401 || response.status === 403) {
          throw new Error("دسترسی غیرمجاز");
        }
        throw new Error("خطا در دریافت جزئیات پروژه");
      }
      return response.json();
    },
    retry: false, // Don't retry to avoid more rate limiting
    staleTime: 300000, // Consider data fresh for 5 minutes
  });

  // Create project summaries with latest approved items
  const projectSummaries = useMemo<ProjectSummary[]>(() => {
    if (!projects || projects.length === 0) return [];
    
    return projects.map((project) => {
      // Get all statements for this project
      const projectStatements = (allStatements || []).filter(
        (s) => s.projectId === project.id
      );
      
      // Get latest statement (regardless of status - show most recent)
      const latestStatement = getLatestItem(projectStatements, (s) => 
        s.announcedDate || s.submissionDate || s.createdAt || null
      );

      // Get all adjustments for this project
      const projectAdjustments = (allAdjustments || []).filter(
        (a) => a.projectId === project.id
      );
      
      // Get latest adjustment (regardless of status - show most recent)
      const latestAdjustment = getLatestItem(projectAdjustments, (a) => 
        a.endDate || a.startDate || a.createdAt || null
      );

      // Get all bitumen diffs for this project
      const projectBitumenDiffs = (allBitumenDiffs || []).filter(
        (b) => b.projectId === project.id
      );
      
      // Get latest bitumen diff (regardless of status - show most recent)
      const latestBitumenDiff = getLatestItem(projectBitumenDiffs, (b) => 
        b.updatedAt || b.createdAt || null
      );

      // Debug logging for first project
      if (project.id === projects[0]?.id) {
        console.log("StatementsPage Debug - Project:", project.title, {
          totalStatements: projectStatements.length,
          statements: projectStatements.map(s => ({ id: s.id, status: s.status, createdAt: s.createdAt })),
          latestStatement: latestStatement ? { id: latestStatement.id, status: latestStatement.status, amount: latestStatement.amount } : null,
          totalAdjustments: projectAdjustments.length,
          adjustments: projectAdjustments.map(a => ({ id: a.id, status: a.status, createdAt: a.createdAt })),
          latestAdjustment: latestAdjustment ? { id: latestAdjustment.id, status: latestAdjustment.status, amount: latestAdjustment.amount } : null,
          totalBitumenDiffs: projectBitumenDiffs.length,
          bitumenDiffs: projectBitumenDiffs.map(b => ({ id: b.id, status: b.status, createdAt: b.createdAt })),
          latestBitumenDiff: latestBitumenDiff ? { id: latestBitumenDiff.id, status: latestBitumenDiff.status, amount: latestBitumenDiff.amount } : null,
        });
      }

      return {
        project,
        latestStatement,
        latestAdjustment,
        latestBitumenDiff,
      };
    });
  }, [projects, allStatements, allAdjustments, allBitumenDiffs]);

  // Filter projects based on search query
  const filteredSummaries = useMemo(() => {
    if (!searchQuery.trim()) return projectSummaries;
    const query = searchQuery.toLowerCase();
    return projectSummaries.filter(
      (summary) =>
        summary.project.title?.toLowerCase().includes(query) ||
        summary.project.contractNumber?.toLowerCase().includes(query) ||
        summary.latestStatement?.statementNumber?.toLowerCase().includes(query) ||
        summary.latestAdjustment?.modificationNumber?.toLowerCase().includes(query) ||
        summary.latestBitumenDiff?.differenceNumber?.toLowerCase().includes(query)
    );
  }, [projectSummaries, searchQuery]);

  const selectedProject = useMemo(() => {
    if (!selectedProjectId) return null;
    return projectSummaries.find((s) => s.project.id === selectedProjectId);
  }, [selectedProjectId, projectSummaries]);

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
      "تأیید شده": { label: "تأیید شده", variant: "default" },
      confirmed: { label: "تأیید شده", variant: "default" },
      "تایید شده": { label: "تأیید شده", variant: "default" },
      "تأییدشده": { label: "تأیید شده", variant: "default" },
      "تاییدشده": { label: "تأیید شده", variant: "default" },
      "ابلاغ شده": { label: "ابلاغ شده", variant: "secondary" },
      announced: { label: "ابلاغ شده", variant: "secondary" },
      "در انتظار": { label: "در انتظار", variant: "outline" },
      pending: { label: "در انتظار", variant: "outline" },
      temporary: { label: "موقت", variant: "secondary" },
      "موقت": { label: "موقت", variant: "secondary" },
    };
    const statusInfo = statusMap[status] || { label: status, variant: "outline" as const };
    return (
      <Badge variant={statusInfo.variant} className="text-xs">
        {statusInfo.label}
      </Badge>
    );
  };

  const handleRowClick = (projectId: string) => {
    setSelectedProjectId(projectId);
    setDetailsDialogOpen(true);
  };

  // Form states for creating new items
  const [statementForm, setStatementForm] = useState({
    projectId: "",
    statementNumber: "",
    amount: "",
    status: "موقت",
    startDate: "",
    endDate: "",
    notes: "",
  });

  const [adjustmentForm, setAdjustmentForm] = useState({
    projectId: "",
    modificationNumber: "",
    amount: "",
    status: "موقت",
    startDate: "",
    endDate: "",
    notes: "",
  });

  const [bitumenDiffForm, setBitumenDiffForm] = useState({
    projectId: "",
    differenceNumber: "",
    amount: "",
    status: "موقت",
    notes: "",
  });

  // Mutation for creating statement
  const createStatementMutation = useMutation({
    mutationFn: async (data: typeof statementForm) => {
      const headers = getHeaders();
      const response = await fetch("/api/statements", {
        method: "POST",
        headers,
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        if (response.status === 429) {
          throw new Error("درخواست‌های زیادی ارسال شده است. لطفاً چند لحظه صبر کنید.");
        }
        throw new Error("خطا در ایجاد صورت‌وضعیت");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/statements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", selectedProjectForCreate, "financial-history"] });
      setCreateStatementDialogOpen(false);
      setStatementForm({
        projectId: "",
        statementNumber: "",
        amount: "",
        status: "موقت",
        startDate: "",
        endDate: "",
        notes: "",
      });
      toast({
        title: "موفقیت",
        description: "صورت‌وضعیت با موفقیت ایجاد شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  // Mutation for creating adjustment
  const createAdjustmentMutation = useMutation({
    mutationFn: async (data: typeof adjustmentForm) => {
      const headers = getHeaders();
      const response = await fetch("/api/adjustments", {
        method: "POST",
        headers,
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        if (response.status === 429) {
          throw new Error("درخواست‌های زیادی ارسال شده است. لطفاً چند لحظه صبر کنید.");
        }
        throw new Error("خطا در ایجاد تعدیل");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/adjustments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", selectedProjectForCreate, "financial-history"] });
      setCreateAdjustmentDialogOpen(false);
      setAdjustmentForm({
        projectId: "",
        modificationNumber: "",
        amount: "",
        status: "موقت",
        startDate: "",
        endDate: "",
        notes: "",
      });
      toast({
        title: "موفقیت",
        description: "تعدیل با موفقیت ایجاد شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  // Mutation for creating bitumen diff
  const createBitumenDiffMutation = useMutation({
    mutationFn: async (data: typeof bitumenDiffForm) => {
      const headers = getHeaders();
      const response = await fetch("/api/bitumen-diffs", {
        method: "POST",
        headers,
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        if (response.status === 429) {
          throw new Error("درخواست‌های زیادی ارسال شده است. لطفاً چند لحظه صبر کنید.");
        }
        throw new Error("خطا در ایجاد مابه‌التفاوت");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bitumen-diffs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", selectedProjectForCreate, "financial-history"] });
      setCreateBitumenDiffDialogOpen(false);
      setBitumenDiffForm({
        projectId: "",
        differenceNumber: "",
        amount: "",
        status: "موقت",
        notes: "",
      });
      toast({
        title: "موفقیت",
        description: "مابه‌التفاوت با موفقیت ایجاد شد",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "خطا",
        description: error.message,
      });
    },
  });

  const isLoading = isLoadingProjects || isLoadingStatements || isLoadingAdjustments || isLoadingBitumenDiffs;

  return (
    <div className="container mx-auto p-3 sm:p-4 md:p-6 space-y-4 md:space-y-6" dir="rtl">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
        <h1 className="text-xl sm:text-2xl md:text-3xl font-bold">صورت‌وضعیت‌ها</h1>
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:flex-initial">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="جستجوی پروژه، شماره قرارداد..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 w-full sm:w-[280px] md:w-[320px]"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSelectedProjectForCreate(null);
                setCreateStatementDialogOpen(true);
              }}
              className="text-xs sm:text-sm"
            >
              <Plus className="w-3 h-3 sm:w-4 sm:h-4 ml-1 sm:ml-2" />
              <span className="hidden sm:inline">ایجاد صورت‌وضعیت</span>
              <span className="sm:hidden">صورت‌وضعیت</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSelectedProjectForCreate(null);
                setCreateAdjustmentDialogOpen(true);
              }}
              className="text-xs sm:text-sm"
            >
              <Plus className="w-3 h-3 sm:w-4 sm:h-4 ml-1 sm:ml-2" />
              <span className="hidden sm:inline">ایجاد تعدیل</span>
              <span className="sm:hidden">تعدیل</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSelectedProjectForCreate(null);
                setCreateBitumenDiffDialogOpen(true);
              }}
              className="text-xs sm:text-sm"
            >
              <Plus className="w-3 h-3 sm:w-4 sm:h-4 ml-1 sm:ml-2" />
              <span className="hidden sm:inline">ایجاد مابه‌التفاوت</span>
              <span className="sm:hidden">مابه‌التفاوت</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Main Table Card */}
      <Card className="shadow-sm">
        <CardHeader className="pb-3 sm:pb-4">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <FileText className="h-4 w-4 sm:h-5 sm:w-5" />
            لیست پروژه‌ها و آخرین صورت‌وضعیت‌ها
            </CardTitle>
          </CardHeader>
        <CardContent className="p-0 sm:p-6">
          {projectsError && (
            <div className="text-center py-6 px-4 text-red-600 bg-red-50 dark:bg-red-950 rounded-lg m-4">
              <p className="font-semibold mb-1">خطا در بارگذاری پروژه‌ها</p>
              <p className="text-sm">{projectsError.message}</p>
              </div>
          )}
          {/* Only show warning if there's a real permission error */}
          {((statementsError && statementsError.message && (statementsError.message.includes("مجوز") || statementsError.message.includes("Permission"))) ||
            (adjustmentsError && adjustmentsError.message && (adjustmentsError.message.includes("مجوز") || adjustmentsError.message.includes("Permission"))) ||
            (bitumenDiffsError && bitumenDiffsError.message && (bitumenDiffsError.message.includes("مجوز") || bitumenDiffsError.message.includes("Permission")))) && (
            <div className="text-center py-3 px-4 text-amber-600 bg-amber-50 dark:bg-amber-950 rounded-lg m-4 text-sm">
              <p>توجه: برخی اطلاعات به دلیل محدودیت دسترسی بارگذاری نشدند.</p>
              </div>
          )}
          {isLoading ? (
            <div className="text-center py-12 text-muted-foreground">در حال بارگذاری...</div>
          ) : (
            <div className="overflow-x-auto -mx-4 sm:mx-0">
              <div className="inline-block min-w-full align-middle">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right w-12 sm:w-16">ردیف</TableHead>
                      <TableHead className="text-right min-w-[140px] sm:min-w-[200px]">نام پروژه</TableHead>
                      <TableHead className="text-right min-w-[120px] sm:min-w-[150px] hidden md:table-cell">شماره قرارداد</TableHead>
                      <TableHead className="text-right min-w-[160px] sm:min-w-[180px]">آخرین صورت‌وضعیت</TableHead>
                      <TableHead className="text-right min-w-[160px] sm:min-w-[180px] hidden lg:table-cell">آخرین تعدیل</TableHead>
                      <TableHead className="text-right min-w-[160px] sm:min-w-[180px] hidden lg:table-cell">آخرین مابه‌التفاوت</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredSummaries.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                          {searchQuery ? "نتیجه‌ای یافت نشد" : "هیچ پروژه‌ای وجود ندارد"}
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredSummaries.map((summary, index) => (
                        <TableRow
                          key={summary.project.id}
                          className="cursor-pointer hover:bg-muted/50 transition-colors"
                          onClick={() => handleRowClick(summary.project.id)}
                        >
                          <TableCell className="font-medium">{toPersianDigits((index + 1).toString())}</TableCell>
                          <TableCell className="font-medium">
                            <div className="flex flex-col gap-1">
                              <span className="text-sm sm:text-base">{summary.project.title}</span>
                              <span className="text-xs text-muted-foreground md:hidden">
                                {summary.project.contractNumber || "—"}
                              </span>
              </div>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">{summary.project.contractNumber || "—"}</TableCell>
                          <TableCell>
                            {summary.latestStatement ? (
                              <div className="flex flex-col gap-1">
                                <div className="font-medium text-green-600 dark:text-green-400 text-sm">
                                  {formatCurrency(summary.latestStatement.amount)} ریال
              </div>
                                <div className="text-xs text-muted-foreground">
                                  #{summary.latestStatement.statementNumber}
              </div>
                                <div className="text-xs text-muted-foreground">
                                  {toPersianDigits(format(new Date(summary.latestStatement.createdAt), "yyyy/MM/dd"))}
              </div>
            </div>
                            ) : (
                              <span className="text-muted-foreground text-sm">—</span>
                            )}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            {summary.latestAdjustment ? (
                              <div className="flex flex-col gap-1">
                                <div className="font-medium text-blue-600 dark:text-blue-400 text-sm">
                                  {formatCurrency(summary.latestAdjustment.amount || "0")} ریال
                          </div>
                            <div className="text-xs text-muted-foreground">
                                  #{summary.latestAdjustment.modificationNumber}
                            </div>
                                <div className="text-xs text-muted-foreground">
                                  {toPersianDigits(format(new Date(summary.latestAdjustment.createdAt), "yyyy/MM/dd"))}
                          </div>
                        </div>
                            ) : (
                              <span className="text-muted-foreground text-sm">—</span>
                            )}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell">
                            {summary.latestBitumenDiff ? (
                              <div className="flex flex-col gap-1">
                                <div
                                  className={`font-medium text-sm ${
                                    parseFloat(summary.latestBitumenDiff.amount) < 0
                                      ? "text-red-600 dark:text-red-400"
                                      : "text-purple-600 dark:text-purple-400"
                                  }`}
                                >
                                  {formatCurrency(summary.latestBitumenDiff.amount)} ریال
                  </div>
                                <div className="text-xs text-muted-foreground">
                                  #{summary.latestBitumenDiff.differenceNumber}
                            </div>
                              <div className="text-xs text-muted-foreground">
                                  {toPersianDigits(format(new Date(summary.latestBitumenDiff.createdAt), "yyyy/MM/dd"))}
                              </div>
                            </div>
                            ) : (
                              <span className="text-muted-foreground text-sm">—</span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
                            </div>
                              </div>
          )}
          </CardContent>
        </Card>

      {/* Details Dialog */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent className="max-w-[95vw] sm:max-w-4xl lg:max-w-6xl max-h-[95vh] overflow-hidden flex flex-col p-0" dir="rtl">
          <DialogHeader className="px-4 sm:px-6 pt-4 sm:pt-6 pb-3 border-b">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <DialogTitle className="flex items-center gap-2 text-lg sm:text-xl">
                  <FileText className="h-5 w-5" />
                  جزئیات مالی پروژه
                </DialogTitle>
                <div className="mt-2 text-sm">
                  <div className="flex flex-col sm:flex-row gap-2 sm:gap-4">
                    <span className="font-medium">{selectedProject?.project.title}</span>
                    {selectedProject?.project.contractNumber && (
                      <span className="text-muted-foreground">
                        شماره قرارداد: {selectedProject.project.contractNumber}
                      </span>
                    )}
                  </div>
                </div>
                  </div>
                            <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setDetailsDialogOpen(false)}
              >
                <X className="h-4 w-4" />
                            </Button>
                          </div>
          </DialogHeader>

          {isLoadingDetails ? (
            <div className="text-center py-12 text-muted-foreground">در حال بارگذاری جزئیات...</div>
          ) : projectDetailsError && projectDetailsError.message && !projectDetailsError.message.includes("429") ? (
            // Only show error if it's NOT a 429 (rate limit) - 429 errors return empty data silently
            <div className="text-center py-12 px-4">
              <div className="text-red-600 dark:text-red-400 mb-2 font-semibold">خطا در بارگذاری جزئیات</div>
              <div className="text-sm text-muted-foreground mb-4">
                {projectDetailsError.message || "خطای نامشخص"}
              </div>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => {
                  setDetailsDialogOpen(false);
                  setTimeout(() => {
                    setDetailsDialogOpen(true);
                  }, 2000); // Wait 2 seconds before retry
                }}
              >
                تلاش مجدد
              </Button>
            </div>
          ) : projectDetails || (projectDetailsError && projectDetailsError.message?.includes("429")) ? (
            // Show content even if 429 (rate limit) - data will be empty arrays
            <ScrollArea className="flex-1 px-4 sm:px-6">
              {projectDetailsError && projectDetailsError.message?.includes("429") && (
                <div className="mb-4 p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg text-sm text-amber-800 dark:text-amber-200">
                  <p className="font-semibold mb-1">⚠️ محدودیت درخواست</p>
                  <p>به دلیل تعداد زیاد درخواست‌ها، داده‌ها در حال حاضر بارگذاری نشدند. لطفاً چند لحظه صبر کنید.</p>
                </div>
              )}
              <Tabs defaultValue="statements" className="w-full py-4" dir="rtl">
                <TabsList className="grid w-full grid-cols-3 mb-4">
                  <TabsTrigger value="statements" className="flex items-center gap-2 text-xs sm:text-sm">
                    <FileText className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden sm:inline">صورت‌وضعیت‌ها</span>
                    <span className="sm:hidden">صورت</span>
                    <Badge variant="secondary" className="mr-1 text-xs">
                      {projectDetails?.statements.length || 0}
                    </Badge>
                  </TabsTrigger>
                  <TabsTrigger value="adjustments" className="flex items-center gap-2 text-xs sm:text-sm">
                    <Calculator className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden sm:inline">تعدیل‌ها</span>
                    <span className="sm:hidden">تعدیل</span>
                    <Badge variant="secondary" className="mr-1 text-xs">
                      {projectDetails?.adjustments.length || 0}
                    </Badge>
                  </TabsTrigger>
                  <TabsTrigger value="bitumen-diffs" className="flex items-center gap-2 text-xs sm:text-sm">
                    <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden sm:inline">مابه‌التفاوت‌ها</span>
                    <span className="sm:hidden">مابه‌التفاوت</span>
                    <Badge variant="secondary" className="mr-1 text-xs">
                      {projectDetails?.bitumenDiffs.length || 0}
                    </Badge>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="statements" className="space-y-3 mt-0">
                  {!projectDetails || projectDetails.statements.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">
                      {projectDetailsError && projectDetailsError.message?.includes("429") 
                        ? "داده‌ها به دلیل محدودیت درخواست بارگذاری نشدند" 
                        : "هیچ صورت‌وضعیتی ثبت نشده است"}
                </div>
                  ) : (
                    projectDetails.statements
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .map((statement) => (
                        <Card key={statement.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex flex-col gap-4">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <h3 className="font-semibold text-base sm:text-lg">
                                    صورت‌وضعیت شماره {statement.statementNumber}
                                  </h3>
                                  {getStatusBadge(statement.status)}
                                </div>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">مبلغ:</span>
                                  <span className="font-medium text-green-600 dark:text-green-400">
                                    {formatCurrency(statement.amount)} ریال
                                  </span>
                                </div>
                                {statement.startDate && statement.endDate && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground min-w-[80px]">دوره:</span>
                                    <span>
                                      {toPersianDigits(statement.startDate)} تا {toPersianDigits(statement.endDate)}
                                    </span>
                  </div>
                )}
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">تاریخ ثبت:</span>
                                  <span>
                                    {toPersianDigits(format(new Date(statement.createdAt), "yyyy/MM/dd HH:mm"))}
                                  </span>
                          </div>
                                {statement.updatedAt && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground min-w-[80px]">آخرین به‌روزرسانی:</span>
                                    <span>
                                      {toPersianDigits(format(new Date(statement.updatedAt), "yyyy/MM/dd HH:mm"))}
                                    </span>
                </div>
                                )}
                              </div>
                              {statement.notes && (
                                <div className="pt-3 border-t">
                                  <p className="text-sm">
                                    <span className="font-medium text-muted-foreground">توضیحات: </span>
                                    <span className="text-foreground">{statement.notes}</span>
                                  </p>
                  </div>
                )}
                          </div>
              </CardContent>
            </Card>
                      ))
                  )}
                </TabsContent>

                <TabsContent value="adjustments" className="space-y-3 mt-0">
                  {!projectDetails || projectDetails.adjustments.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">
                      {projectDetailsError && projectDetailsError.message?.includes("429") 
                        ? "داده‌ها به دلیل محدودیت درخواست بارگذاری نشدند" 
                        : "هیچ تعدیلی ثبت نشده است"}
                    </div>
                  ) : (
                    projectDetails.adjustments
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .map((adjustment) => (
                        <Card key={adjustment.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex flex-col gap-4">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <h3 className="font-semibold text-base sm:text-lg">
                                    تعدیل شماره {adjustment.modificationNumber}
                                  </h3>
                                  {getStatusBadge(adjustment.status)}
            </div>
            </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">مبلغ:</span>
                                  <span className="font-medium text-blue-600 dark:text-blue-400">
                                    {formatCurrency(adjustment.amount || "0")} ریال
                                  </span>
            </div>
                                {adjustment.startDate && adjustment.endDate && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground min-w-[80px]">دوره:</span>
                                    <span>
                                      {toPersianDigits(adjustment.startDate)} تا {toPersianDigits(adjustment.endDate)}
                                    </span>
            </div>
                                )}
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">تاریخ ثبت:</span>
                                  <span>
                                    {toPersianDigits(format(new Date(adjustment.createdAt), "yyyy/MM/dd HH:mm"))}
                                  </span>
            </div>
                                {adjustment.updatedAt && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground min-w-[80px]">آخرین به‌روزرسانی:</span>
                                    <span>
                                      {toPersianDigits(format(new Date(adjustment.updatedAt), "yyyy/MM/dd HH:mm"))}
                                    </span>
            </div>
                                )}
            </div>
                              {adjustment.notes && (
                                <div className="pt-3 border-t">
                                  <p className="text-sm">
                                    <span className="font-medium text-muted-foreground">توضیحات: </span>
                                    <span className="text-foreground">{adjustment.notes}</span>
                                  </p>
            </div>
                              )}
            </div>
                          </CardContent>
                        </Card>
                      ))
                  )}
                </TabsContent>

                <TabsContent value="bitumen-diffs" className="space-y-3 mt-0">
                  {!projectDetails || projectDetails.bitumenDiffs.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">
                      {projectDetailsError && projectDetailsError.message?.includes("429") 
                        ? "داده‌ها به دلیل محدودیت درخواست بارگذاری نشدند" 
                        : "هیچ مابه‌التفاوتی ثبت نشده است"}
            </div>
                  ) : (
                    projectDetails.bitumenDiffs
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .map((bitumenDiff) => (
                        <Card key={bitumenDiff.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex flex-col gap-4">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <h3 className="font-semibold text-base sm:text-lg">
                                    مابه‌التفاوت شماره {bitumenDiff.differenceNumber}
                                  </h3>
                                  {getStatusBadge(bitumenDiff.status)}
            </div>
            </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">مبلغ:</span>
                                  <span
                                    className={`font-medium ${
                                      parseFloat(bitumenDiff.amount) < 0
                                        ? "text-red-600 dark:text-red-400"
                                        : "text-purple-600 dark:text-purple-400"
                                    }`}
                                  >
                                    {formatCurrency(bitumenDiff.amount)} ریال
                                  </span>
            </div>
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground min-w-[80px]">تاریخ ثبت:</span>
                                  <span>
                                    {toPersianDigits(format(new Date(bitumenDiff.createdAt), "yyyy/MM/dd HH:mm"))}
                                  </span>
            </div>
                                {bitumenDiff.updatedAt && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-muted-foreground min-w-[80px]">آخرین به‌روزرسانی:</span>
                                    <span>
                                      {toPersianDigits(format(new Date(bitumenDiff.updatedAt), "yyyy/MM/dd HH:mm"))}
                                    </span>
            </div>
                                )}
            </div>
                              {bitumenDiff.notes && (
                                <div className="pt-3 border-t">
                                  <p className="text-sm">
                                    <span className="font-medium text-muted-foreground">توضیحات: </span>
                                    <span className="text-foreground">{bitumenDiff.notes}</span>
                                  </p>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))
                  )}
                </TabsContent>
              </Tabs>
            </ScrollArea>
          ) : (
            <div className="text-center py-12 text-muted-foreground px-4">خطا در بارگذاری جزئیات</div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Statement Dialog */}
      <Dialog open={createStatementDialogOpen} onOpenChange={setCreateStatementDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>ایجاد صورت‌وضعیت جدید</DialogTitle>
            <DialogDescription>اطلاعات صورت‌وضعیت را وارد کنید</DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!statementForm.projectId || !statementForm.statementNumber || !statementForm.amount) {
                toast({
                  variant: "destructive",
                  title: "خطا",
                  description: "لطفاً تمام فیلدهای الزامی را پر کنید",
                });
                return;
              }
              createStatementMutation.mutate(statementForm);
            }}
            className="space-y-4"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <Label htmlFor="statement-project">پروژه *</Label>
                <Select
                  value={statementForm.projectId}
                  onValueChange={(value) => setStatementForm({ ...statementForm, projectId: value })}
                  required
                >
                  <SelectTrigger id="statement-project">
                    <SelectValue placeholder="انتخاب پروژه" />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.title} ({project.contractNumber || "بدون شماره"})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="statement-number">شماره صورت‌وضعیت *</Label>
                <Input
                  id="statement-number"
                  value={statementForm.statementNumber}
                  onChange={(e) => setStatementForm({ ...statementForm, statementNumber: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="statement-amount">مبلغ (ریال) *</Label>
                <Input
                  id="statement-amount"
                  type="number"
                  value={statementForm.amount}
                  onChange={(e) => setStatementForm({ ...statementForm, amount: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="statement-status">وضعیت</Label>
                <Select
                  value={statementForm.status}
                  onValueChange={(value) => setStatementForm({ ...statementForm, status: value })}
                >
                  <SelectTrigger id="statement-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="موقت">موقت</SelectItem>
                    <SelectItem value="تأیید شده">تأیید شده</SelectItem>
                    <SelectItem value="confirmed">Confirmed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="statement-start-date">تاریخ شروع</Label>
                <Input
                  id="statement-start-date"
                  type="text"
                  value={statementForm.startDate}
                  onChange={(e) => setStatementForm({ ...statementForm, startDate: e.target.value })}
                  placeholder="1403/07/15"
                />
              </div>
              <div>
                <Label htmlFor="statement-end-date">تاریخ پایان</Label>
                <Input
                  id="statement-end-date"
                  type="text"
                  value={statementForm.endDate}
                  onChange={(e) => setStatementForm({ ...statementForm, endDate: e.target.value })}
                  placeholder="1403/08/15"
                />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="statement-notes">یادداشت‌ها</Label>
                <Textarea
                  id="statement-notes"
                  value={statementForm.notes}
                  onChange={(e) => setStatementForm({ ...statementForm, notes: e.target.value })}
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setCreateStatementDialogOpen(false)}
              >
                انصراف
              </Button>
              <Button
                type="submit"
                disabled={createStatementMutation.isPending}
              >
                {createStatementMutation.isPending ? "در حال ایجاد..." : "ایجاد"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Create Adjustment Dialog */}
      <Dialog open={createAdjustmentDialogOpen} onOpenChange={setCreateAdjustmentDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>ایجاد تعدیل جدید</DialogTitle>
            <DialogDescription>اطلاعات تعدیل را وارد کنید</DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!adjustmentForm.projectId || !adjustmentForm.modificationNumber) {
                toast({
                  variant: "destructive",
                  title: "خطا",
                  description: "لطفاً تمام فیلدهای الزامی را پر کنید",
                });
                return;
              }
              createAdjustmentMutation.mutate(adjustmentForm);
            }}
            className="space-y-4"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <Label htmlFor="adjustment-project">پروژه *</Label>
                <Select
                  value={adjustmentForm.projectId}
                  onValueChange={(value) => setAdjustmentForm({ ...adjustmentForm, projectId: value })}
                  required
                >
                  <SelectTrigger id="adjustment-project">
                    <SelectValue placeholder="انتخاب پروژه" />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.title} ({project.contractNumber || "بدون شماره"})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="adjustment-number">شماره تعدیل *</Label>
                <Input
                  id="adjustment-number"
                  value={adjustmentForm.modificationNumber}
                  onChange={(e) => setAdjustmentForm({ ...adjustmentForm, modificationNumber: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="adjustment-amount">مبلغ (ریال)</Label>
                <Input
                  id="adjustment-amount"
                  type="number"
                  value={adjustmentForm.amount}
                  onChange={(e) => setAdjustmentForm({ ...adjustmentForm, amount: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="adjustment-status">وضعیت</Label>
                <Select
                  value={adjustmentForm.status}
                  onValueChange={(value) => setAdjustmentForm({ ...adjustmentForm, status: value })}
                >
                  <SelectTrigger id="adjustment-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="موقت">موقت</SelectItem>
                    <SelectItem value="تأیید شده">تأیید شده</SelectItem>
                    <SelectItem value="confirmed">Confirmed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="adjustment-start-date">تاریخ شروع</Label>
                <Input
                  id="adjustment-start-date"
                  type="text"
                  value={adjustmentForm.startDate}
                  onChange={(e) => setAdjustmentForm({ ...adjustmentForm, startDate: e.target.value })}
                  placeholder="1403/07/15"
                />
              </div>
              <div>
                <Label htmlFor="adjustment-end-date">تاریخ پایان</Label>
                <Input
                  id="adjustment-end-date"
                  type="text"
                  value={adjustmentForm.endDate}
                  onChange={(e) => setAdjustmentForm({ ...adjustmentForm, endDate: e.target.value })}
                  placeholder="1403/08/15"
                />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="adjustment-notes">یادداشت‌ها</Label>
                <Textarea
                  id="adjustment-notes"
                  value={adjustmentForm.notes}
                  onChange={(e) => setAdjustmentForm({ ...adjustmentForm, notes: e.target.value })}
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setCreateAdjustmentDialogOpen(false)}
              >
                انصراف
              </Button>
              <Button
                type="submit"
                disabled={createAdjustmentMutation.isPending}
              >
                {createAdjustmentMutation.isPending ? "در حال ایجاد..." : "ایجاد"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Create Bitumen Diff Dialog */}
      <Dialog open={createBitumenDiffDialogOpen} onOpenChange={setCreateBitumenDiffDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>ایجاد مابه‌التفاوت قیر جدید</DialogTitle>
            <DialogDescription>اطلاعات مابه‌التفاوت را وارد کنید</DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!bitumenDiffForm.projectId || !bitumenDiffForm.differenceNumber || !bitumenDiffForm.amount) {
                toast({
                  variant: "destructive",
                  title: "خطا",
                  description: "لطفاً تمام فیلدهای الزامی را پر کنید",
                });
                return;
              }
              createBitumenDiffMutation.mutate(bitumenDiffForm);
            }}
            className="space-y-4"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <Label htmlFor="bitumen-project">پروژه *</Label>
                <Select
                  value={bitumenDiffForm.projectId}
                  onValueChange={(value) => setBitumenDiffForm({ ...bitumenDiffForm, projectId: value })}
                  required
                >
                  <SelectTrigger id="bitumen-project">
                    <SelectValue placeholder="انتخاب پروژه" />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.title} ({project.contractNumber || "بدون شماره"})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="bitumen-number">شماره مابه‌التفاوت *</Label>
                <Input
                  id="bitumen-number"
                  value={bitumenDiffForm.differenceNumber}
                  onChange={(e) => setBitumenDiffForm({ ...bitumenDiffForm, differenceNumber: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="bitumen-amount">مبلغ (ریال) *</Label>
                <Input
                  id="bitumen-amount"
                  type="number"
                  value={bitumenDiffForm.amount}
                  onChange={(e) => setBitumenDiffForm({ ...bitumenDiffForm, amount: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="bitumen-status">وضعیت</Label>
                <Select
                  value={bitumenDiffForm.status}
                  onValueChange={(value) => setBitumenDiffForm({ ...bitumenDiffForm, status: value })}
                >
                  <SelectTrigger id="bitumen-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="موقت">موقت</SelectItem>
                    <SelectItem value="تأیید شده">تأیید شده</SelectItem>
                    <SelectItem value="confirmed">Confirmed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="bitumen-notes">یادداشت‌ها</Label>
                <Textarea
                  id="bitumen-notes"
                  value={bitumenDiffForm.notes}
                  onChange={(e) => setBitumenDiffForm({ ...bitumenDiffForm, notes: e.target.value })}
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setCreateBitumenDiffDialogOpen(false)}
              >
                انصراف
              </Button>
              <Button
                type="submit"
                disabled={createBitumenDiffMutation.isPending}
              >
                {createBitumenDiffMutation.isPending ? "در حال ایجاد..." : "ایجاد"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
