import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import ThemeToggle from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { LogOut, Calendar, User } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import PersonalDashboard from "@/components/PersonalDashboard";
import ManagementDashboard from "@/components/ManagementDashboard";
import ProjectsPage from "@/components/ProjectsPage";
import ProjectDetailsPage from "@/pages/ProjectDetailsPage";
import WeeklyReportsPage from "@/components/WeeklyReportsPage";
import ExecutionReportsPage from "@/pages/ExecutionReportsPage";
import BitumenPage from "@/components/BitumenPage";
import TendersPage from "@/components/TendersPage";
import AlertsPage from "@/components/AlertsPage";
import UsersPage from "@/components/UsersPage";
import MessagesPage from "@/components/MessagesPage";
import SheetsPage from "@/components/SheetsPage";
import StatementsPage from "@/components/StatementsPage";
import BitumenDiffsPage from "@/components/BitumenDiffsPage";
import RolesPage from "@/components/RolesPage";
import ProfilePage from "@/components/ProfilePage";
import AIAssistantPage from "@/components/AIAssistantPage";
import TasksPage from "@/components/TasksPage";
import CalendarPage from "@/components/CalendarPage";
import NotesPage from "@/components/NotesPage";
import LettersPage from "@/components/LettersPage";
import LoginForm from "@/components/LoginForm";
import NotFound from "@/pages/not-found";
import { GlobalSearch } from "@/components/GlobalSearch";
import { StatusBar } from "@/components/StatusBar";
import { useState, useEffect, Component, ReactNode } from "react";
import { format } from "date-fns-jalali";
import { toPersianDigits } from "@/lib/persian-utils";
import { ProjectProvider } from "@/lib/project-context";
import { AuthProvider, useAuth } from "@/lib/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

function PersianDate() {
  const [currentDate, setCurrentDate] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDate(new Date());
    }, 60000); // Update every minute

    return () => clearInterval(timer);
  }, []);

  const persianWeekDays = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه'];
  const dayName = persianWeekDays[currentDate.getDay()];
  const formattedDate = toPersianDigits(format(currentDate, 'yyyy/MM/dd'));

  return (
    <div className="flex items-center gap-2 text-sm text-muted-foreground">
      <Calendar className="w-4 h-4" />
      <span className="hidden sm:inline">{dayName}</span>
      <span>{formattedDate}</span>
    </div>
  );
}

// Error Boundary Component
class ErrorBoundary extends Component<
  { children: ReactNode },
  { hasError: boolean; error: Error | null }
> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: any) {
    console.error("Error caught by boundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="container mx-auto p-6" dir="rtl">
          <Card>
            <CardHeader>
              <CardTitle className="text-red-600">خطا در بارگذاری صفحه</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                متأسفانه خطایی در بارگذاری صفحه رخ داده است. لطفاً صفحه را refresh کنید.
              </p>
              <p className="text-sm text-muted-foreground mb-4">
                جزئیات خطا: {this.state.error?.message || "خطای نامشخص"}
              </p>
              <Button onClick={() => window.location.reload()}>
                بارگذاری مجدد
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

function AuthenticatedRoutes() {
  return (
    <ErrorBoundary>
      <Switch>
        <Route path="/" component={ManagementDashboard} />
      <Route path="/dashboard" component={ManagementDashboard} />
      <Route path="/tasks" component={TasksPage} />
      <Route path="/calendar" component={CalendarPage} />
      <Route path="/notes" component={NotesPage} />
      <Route path="/letters" component={LettersPage} />
      <Route path="/projects" component={ProjectsPage} />
      <Route path="/projects/:id" component={ProjectDetailsPage} />
      <Route path="/reports/execution" component={ExecutionReportsPage} />
      <Route path="/reports/technical" component={WeeklyReportsPage} />
      <Route path="/reports" component={WeeklyReportsPage} />
      <Route path="/statements" component={StatementsPage} />
      <Route path="/bitumen-diffs" component={BitumenDiffsPage} />
      <Route path="/bitumen" component={BitumenPage} />
      <Route path="/sheets" component={SheetsPage} />
      <Route path="/tenders" component={TendersPage} />
      <Route path="/alerts" component={AlertsPage} />
      <Route path="/ai-assistant" component={AIAssistantPage} />
      <Route path="/analysis">
        <div className="p-6">
          <h1 className="text-3xl font-bold mb-4">تحلیل پروژه</h1>
          <p className="text-muted-foreground">نمودارها و تحلیل‌های مالی</p>
        </div>
      </Route>
      <Route path="/users" component={UsersPage} />
      <Route path="/roles" component={RolesPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/messages" component={MessagesPage} />
        <Route component={NotFound} />
      </Switch>
    </ErrorBoundary>
  );
}

function AppContent() {
  const { user, setUser, logout, isAuthenticated } = useAuth();
  
  const style = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  const handleLogin = async (username: string, password: string) => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (!response.ok) {
        // Check content type before parsing
        const contentType = response.headers.get("content-type");
        let errorMessage = "خطا در ورود";
        
        try {
          if (contentType && contentType.includes("application/json")) {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
          } else {
            // Response is not JSON, read as text
            const text = await response.text();
            errorMessage = text || errorMessage;
            
            // Handle common error messages
            if (text.toLowerCase().includes("too many")) {
              errorMessage = "درخواست‌های زیادی ارسال شده است. لطفاً چند لحظه صبر کنید و دوباره تلاش کنید.";
            }
          }
        } catch (parseError) {
          // If parsing fails completely, use status-based message
          if (response.status === 429) {
            errorMessage = "درخواست‌های زیادی ارسال شده است. لطفاً چند لحظه صبر کنید و دوباره تلاش کنید.";
          } else if (response.status === 401) {
            errorMessage = "نام کاربری یا رمز عبور اشتباه است";
          } else if (response.status === 403) {
            errorMessage = "دسترسی غیرمجاز";
          } else {
            errorMessage = `خطا در ورود (کد خطا: ${response.status})`;
          }
        }
        
        alert(errorMessage);
        return;
      }

      const userData = await response.json();
      
      // Log user role for debugging
      console.log("User logged in - Full data:", userData);
      console.log("User logged in - Role check:", {
        id: userData.id,
        username: userData.username,
        role: userData.role,
        roleName: userData.roleName,
        roleDisplayName: userData.roleDisplayName,
        roleId: userData.roleId
      });
      
      // Ensure role is set correctly
      if (!userData.role && userData.roleName) {
        userData.role = userData.roleName;
      }
      if (!userData.role) {
        userData.role = "viewer";
      }
      
      // Store user in localStorage immediately (synchronously) before setUser
      localStorage.setItem("currentUser", JSON.stringify(userData));
      
      setUser(userData);
    } catch (error: any) {
      console.error("Login error:", error);
      // Handle JSON parsing errors specifically
      if (error instanceof SyntaxError && error.message.includes("JSON")) {
        alert("خطا در دریافت پاسخ از سرور. لطفاً دوباره تلاش کنید.");
      } else {
        alert(error?.message || "خطا در ارتباط با سرور");
      }
    }
  };

  const displayName = user?.firstName && user?.lastName 
    ? `${user.firstName} ${user.lastName}` 
    : user?.username || "کاربر";
  const userRole = user?.roleDisplayName || "کاربر سیستم";

  return (
    <TooltipProvider>
      {!isAuthenticated ? (
        <LoginForm onLogin={handleLogin} />
      ) : (
        <SidebarProvider style={style as React.CSSProperties} defaultOpen={true}>
          <div className="flex h-screen w-full">
            <AppSidebar currentUser={user ? {
              name: `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.username,
              role: (user.role || user.roleName || "viewer").toLowerCase(), // Use role name, not display name, and normalize to lowercase
            } : undefined} />
            <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
              <header className="flex items-center justify-between p-2 sm:p-4 border-b gap-2 sm:gap-4 bg-white dark:bg-card flex-wrap sm:flex-nowrap" dir="rtl">
                {/* سمت راست: ایکون باز و بسته شدن sidebar */}
                <div className="flex items-center flex-shrink-0">
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                </div>
                
                {/* وسط: جستجو */}
                <div className="flex-1 flex justify-center px-2 sm:px-4 min-w-0 max-w-full sm:max-w-2xl mx-auto order-3 sm:order-2 w-full sm:w-auto">
                  <GlobalSearch />
                </div>
                
                {/* سمت چپ: Avatar، تاریخ، Theme و Logout */}
                <div className="flex items-center gap-1 sm:gap-3 flex-shrink-0 order-2 sm:order-3">
                  <Avatar className="w-7 h-7 sm:w-9 sm:h-9">
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      <User className="w-3 h-3 sm:w-4 sm:h-4" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden md:block">
                    <p className="text-sm font-medium">{displayName}</p>
                    <p className="text-xs text-muted-foreground">{userRole}</p>
                  </div>
                  <div className="hidden lg:block h-6 w-px bg-border"></div>
                  <div className="hidden lg:block">
                    <PersianDate />
                  </div>
                  <div className="hidden lg:block h-6 w-px bg-border"></div>
                  <ThemeToggle />
                  <Button 
                    variant="ghost" 
                    size="icon"
                    className="h-8 w-8 sm:h-10 sm:w-10"
                    onClick={logout}
                    data-testid="button-logout"
                    title="خروج"
                  >
                    <LogOut className="w-3 h-3 sm:w-4 sm:h-4" />
                  </Button>
                </div>
              </header>
              <StatusBar />
              <main className="flex-1 overflow-auto p-3 sm:p-4 md:p-6">
                <AuthenticatedRoutes />
              </main>
            </div>
          </div>
        </SidebarProvider>
      )}
      <Toaster />
    </TooltipProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ProjectProvider>
          <AppContent />
        </ProjectProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
