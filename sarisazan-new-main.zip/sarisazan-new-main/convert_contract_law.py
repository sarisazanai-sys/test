#!/usr/bin/env python3
import json
import re

def parse_contract_text(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    articles = []
    current_chapter = None
    
    lines = content.split('\n')
    i = 0
    
    while i < len(lines):
        line = lines[i].strip()
        
        # Check for chapter
        if line.startswith('فصل '):
            current_chapter = line
            i += 1
            continue
        
        # Check for article number and title
        match = re.match(r'ماده\s+(\d+)\s*[:：]\s*(.+)', line)
        if match:
            article_num = int(match.group(1))
            article_title = match.group(2).strip()
            
            # Collect the article text
            article_text = []
            i += 1
            
            # Skip empty lines after title
            while i < len(lines) and not lines[i].strip():
                i += 1
            
            # Collect text until next article or chapter
            while i < len(lines):
                next_line = lines[i].strip()
                
                # Stop if we hit next article or chapter
                if re.match(r'ماده\s+\d+\s*[:：]', next_line) or next_line.startswith('فصل '):
                    break
                
                if next_line:
                    article_text.append(next_line)
                
                i += 1
            
            # Join the text
            full_text = ' '.join(article_text)
            
            if full_text:
                articles.append({
                    'chapter': current_chapter,
                    'article_number': article_num,
                    'article_title': article_title,
                    'text': full_text
                })
        else:
            i += 1
    
    return articles

def main():
    input_file = 'attached_assets/Pasted--1--1762149627206_1762149627208.txt'
    output_file = 'uploads/agent-documents/contract_law.jsonl'
    
    # Create directory if it doesn't exist
    import os
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    
    articles = parse_contract_text(input_file)
    
    # Write as JSONL
    with open(output_file, 'w', encoding='utf-8') as f:
        for article in articles:
            f.write(json.dumps(article, ensure_ascii=False) + '\n')
    
    print(f'✅ تبدیل موفقیت‌آمیز بود!')
    print(f'📊 تعداد مواد: {len(articles)}')
    print(f'💾 فایل ذخیره شد در: {output_file}')
    
    # Show some examples
    if articles:
        print(f'\n📝 نمونه ماده اول:')
        print(f'   شماره: {articles[0]["article_number"]}')
        print(f'   عنوان: {articles[0]["article_title"]}')
        print(f'   متن: {articles[0]["text"][:100]}...')

if __name__ == '__main__':
    main()
