#!/bin/bash
cd /home/admin/domains/Sarisazan/public_html

echo "Pulling latest code..."
git pull origin main

echo "Installing dependencies..."
npm install

echo "Building PWA..."
npm run build

echo "Reloading Nginx..."
sudo nginx -s reload

echo "Deployed at $(date)" >> deploy.log
