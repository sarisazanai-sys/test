# راهنمای استقرار سامانه سریع‌سازان البرز روی سرور VPS

این راهنما قدم به قدم نحوه استقرار سامانه مدیریت پروژه‌های ساخت سریع‌سازان البرز را روی سرور VPS شما توضیح می‌دهد.

## پیش‌نیازها

- سرور Ubuntu 20.04 یا بالاتر (یا Debian)
- دسترسی SSH به سرور
- دامنه (مثلاً `sarisazan.ae`)
- حداقل 2GB RAM و 20GB فضای دیسک

---

## مرحله 1: آماده‌سازی سرور

### 1.1. اتصال به سرور

```bash
ssh root@YOUR_SERVER_IP
```

### 1.2. به‌روزرسانی سیستم

```bash
apt update
apt upgrade -y
```

### 1.3. ایجاد کاربر جدید (اختیاری ولی توصیه می‌شود)

```bash
adduser deploy
usermod -aG sudo deploy
su - deploy
```

---

## مرحله 2: نصب Node.js

### 2.1. نصب Node.js نسخه 20

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

### 2.2. تأیید نصب

```bash
node --version  # باید 20.x نمایش دهد
npm --version
```

---

## مرحله 3: نصب PostgreSQL

### 3.1. نصب PostgreSQL

```bash
sudo apt install -y postgresql postgresql-contrib
```

### 3.2. شروع سرویس PostgreSQL

```bash
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### 3.3. ایجاد دیتابیس و کاربر

```bash
sudo -u postgres psql
```

در PostgreSQL:

```sql
CREATE DATABASE sarisazan;
CREATE USER sarisazan_user WITH ENCRYPTED PASSWORD 'YOUR_STRONG_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE sarisazan TO sarisazan_user;
ALTER DATABASE sarisazan OWNER TO sarisazan_user;
\q
```

---

## مرحله 4: دانلود و نصب پروژه

### 4.1. کلون کردن repository

```bash
cd ~
git clone https://github.com/sarisazanai-sys/test.git sarisazan
cd sarisazan
```

### 4.2. نصب packages

```bash
npm install
```

---

## مرحله 5: تنظیم Environment Variables

### 5.1. ایجاد فایل .env

```bash
nano .env
```

محتوای فایل:

```env
# Database
DATABASE_URL=postgresql://sarisazan_user:YOUR_STRONG_PASSWORD@localhost:5432/sarisazan
PGHOST=localhost
PGPORT=5432
PGUSER=sarisazan_user
PGPASSWORD=YOUR_STRONG_PASSWORD
PGDATABASE=sarisazan

# Node Environment
NODE_ENV=production

# Session
SESSION_SECRET=YOUR_RANDOM_SECRET_KEY_HERE

# Optional: XAI API (برای agent فعال کردن - اختیاری)
# XAI_API_KEY=your_xai_api_key_here
```

**نکته مهم:** `YOUR_STRONG_PASSWORD` و `YOUR_RANDOM_SECRET_KEY_HERE` را با مقادیر واقعی جایگزین کنید.

برای ایجاد SESSION_SECRET تصادفی:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

ذخیره و خروج: `Ctrl+O`, `Enter`, `Ctrl+X`

---

## مرحله 6: راه‌اندازی دیتابیس

### 6.1. Push کردن Schema به دیتابیس

```bash
npm run db:push
```

اگر خطای data-loss دریافت کردید:

```bash
npm run db:push -- --force
```

---

## مرحله 7: Build کردن پروژه

```bash
npm run build
```

این فرمان فایل‌های فرانت‌اند را در پوشه `dist/public` می‌سازد.

---

## مرحله 8: تست اجرا

قبل از راه‌اندازی دائمی، یکبار تست کنید:

```bash
npm start
```

سرور باید روی پورت 5000 اجرا شود. برای تست:

```bash
curl http://localhost:5000
```

اگر HTML دریافت کردید، یعنی کار می‌کند! با `Ctrl+C` متوقفش کنید.

---

## مرحله 9: نصب و راه‌اندازی PM2 (مدیریت Process)

### 9.1. نصب PM2

```bash
sudo npm install -g pm2
```

### 9.2. راه‌اندازی برنامه با PM2

```bash
pm2 start npm --name "sarisazan" -- start
```

### 9.3. ذخیره تنظیمات PM2

```bash
pm2 save
pm2 startup
```

دستور دوم یک خط command می‌دهد که باید اجرا کنید (با sudo).

### 9.4. دستورات مفید PM2

```bash
pm2 status              # وضعیت process ها
pm2 logs sarisazan      # مشاهده لاگ‌ها
pm2 restart sarisazan   # restart
pm2 stop sarisazan      # توقف
pm2 delete sarisazan    # حذف
```

---

## مرحله 10: نصب و تنظیم Nginx

### 10.1. نصب Nginx

```bash
sudo apt install -y nginx
```

### 10.2. تنظیم Nginx برای reverse proxy

```bash
sudo nano /etc/nginx/sites-available/sarisazan
```

محتوا:

```nginx
server {
    listen 80;
    server_name sarisazan.ae www.sarisazan.ae;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 10.3. فعال‌سازی تنظیمات

```bash
sudo ln -s /etc/nginx/sites-available/sarisazan /etc/nginx/sites-enabled/
sudo nginx -t  # تست تنظیمات
sudo systemctl restart nginx
```

---

## مرحله 11: نصب SSL با Let's Encrypt

### 11.1. نصب Certbot

```bash
sudo apt install -y certbot python3-certbot-nginx
```

### 11.2. دریافت گواهی SSL

```bash
sudo certbot --nginx -d sarisazan.ae -d www.sarisazan.ae
```

ایمیل خود را وارد کنید و شرایط را بپذیرید.

### 11.3. تنویل خودکار

Certbot به صورت خودکار تنویل را تنظیم می‌کند. برای تست:

```bash
sudo certbot renew --dry-run
```

---

## مرحله 12: تنظیمات امنیتی (اختیاری ولی توصیه می‌شود)

### 12.1. تنظیم Firewall

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### 12.2. تنظیم ایمن PostgreSQL

در `/etc/postgresql/*/main/pg_hba.conf`:

```bash
sudo nano /etc/postgresql/14/main/pg_hba.conf
```

مطمئن شوید که فقط localhost دسترسی دارد:

```
local   all             all                                     peer
host    all             all             127.0.0.1/32            md5
```

سپس:

```bash
sudo systemctl restart postgresql
```

---

## مرحله 13: تنظیمات Production در کد

فایل `server/index.ts` را باز کنید و:

### 13.1. تنظیم CORS

مطمئن شوید که دامنه‌های صحیح تنظیم شده‌اند:

```typescript
app.use(cors({
  origin: ['https://sarisazan.ae', 'https://www.sarisazan.ae'],
  credentials: true
}));
```

### 13.2. تنظیم Session Cookie

```typescript
app.use(session({
  secret: process.env.SESSION_SECRET || 'change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: true,  // فقط HTTPS
    httpOnly: true,
    maxAge: 1000 * 60 * 60 * 24 * 7 // 7 روز
  }
}));
```

بعد از تغییرات:

```bash
npm run build
pm2 restart sarisazan
```

---

## اطلاعات ورود پیش‌فرض

سیستم یک کاربر مدیر پیش‌فرض ایجاد می‌کند:

- **نام کاربری:** `admin`
- **رمز عبور:** `admin123`

**⚠️ مهم:** حتماً بعد از اولین ورود، رمز عبور را تغییر دهید!

---

## دستورات مفید برای مدیریت

### مشاهده لاگ‌ها

```bash
pm2 logs sarisazan
```

### Restart کردن سرویس

```bash
pm2 restart sarisazan
```

### مشاهده وضعیت سرورها

```bash
pm2 status
sudo systemctl status nginx
sudo systemctl status postgresql
```

### دیدن منابع مصرفی

```bash
pm2 monit
```

---

## به‌روزرسانی برنامه

وقتی نسخه جدیدی منتشر می‌شود:

```bash
cd ~/sarisazan
git pull origin main
npm install
npm run build
npm run db:push  # اگر تغییرات database دارید
pm2 restart sarisazan
```

---

## عیب‌یابی

### 1. سایت باز نمی‌شود

```bash
# چک کردن Nginx
sudo systemctl status nginx
sudo nginx -t

# چک کردن PM2
pm2 status
pm2 logs sarisazan
```

### 2. خطای دیتابیس

```bash
# چک کردن PostgreSQL
sudo systemctl status postgresql

# تست اتصال
psql -h localhost -U sarisazan_user -d sarisazan
```

### 3. مشکل در build

```bash
# پاک کردن cache و rebuild
rm -rf node_modules dist
npm install
npm run build
```

---

## پشتیبانی از دیتابیس

### Backup گرفتن

```bash
pg_dump -h localhost -U sarisazan_user sarisazan > backup_$(date +%Y%m%d).sql
```

### Restore کردن

```bash
psql -h localhost -U sarisazan_user sarisazan < backup_20241106.sql
```

---

## پشتیبانی

در صورت بروز مشکل:

1. لاگ‌های PM2 را چک کنید: `pm2 logs sarisazan`
2. لاگ‌های Nginx را چک کنید: `sudo tail -f /var/log/nginx/error.log`
3. وضعیت سرویس‌ها را بررسی کنید

---

## ملاحظات مهم

1. **امنیت:** حتماً رمزهای قوی استفاده کنید
2. **Backup:** منظماً از دیتابیس backup بگیرید
3. **به‌روزرسانی:** سیستم عامل و packages را به‌روز نگه دارید
4. **Monitoring:** لاگ‌ها را منظماً چک کنید

---

این راهنما تمام مراحل لازم برای استقرار کامل سامانه را پوشش می‌دهد. موفق باشید! 🚀
