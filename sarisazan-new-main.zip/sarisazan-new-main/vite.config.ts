import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from 'vite-plugin-pwa';
import path from "path";
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      // COMPLETELY DISABLE SERVICE WORKER
      // Service worker causes old bundles to be cached and served, breaking the app
      // We only want the manifest for PWA features, not the service worker
      registerType: 'prompt', // Change to 'prompt' to prevent auto-registration
      injectRegister: false, // Don't inject registration script
      devOptions: {
        enabled: false, // Disable in dev
        type: 'module',
      },
      // Don't generate service worker at all
      strategies: 'generateSW',
      workbox: {
        // Disable all caching strategies
        runtimeCaching: [],
        skipWaiting: false,
        clientsClaim: false,
      },
      includeAssets: ['icons/*.png', '*.ico'],
      manifest: {
        name: 'سریع‌سازان البرز',
        short_name: 'سریع‌سازان',
        description: 'سامانه مدیریت پروژه‌های ساخت',
        theme_color: '#d4af37',
        background_color: '#ffffff',
        display: 'standalone',
        start_url: '/',
        dir: 'rtl',
        lang: 'fa',
        icons: [
          {
            src: '/favicon.ico',
            sizes: 'any',
            type: 'image/x-icon',
            purpose: 'any'
          },
          {
            src: '/favicon.ico',
            sizes: '192x192',
            type: 'image/x-icon',
            purpose: 'maskable any'
          },
          {
            src: '/favicon.ico',
            sizes: '512x512',
            type: 'image/x-icon',
            purpose: 'maskable any'
          }
        ]
      }
    })
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "client", "src"),
      "@assets": path.resolve(__dirname, "attached_assets"),
    },
  },
  build: {
    sourcemap: false, // Disable source maps to prevent 404 errors when clicking on errors
  },
});
