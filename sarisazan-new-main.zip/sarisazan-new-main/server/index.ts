import 'dotenv/config'

import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { startAutoAlertScheduler } from "./auto-alerts";
import { initializePermissionsAndRoles, createDefaultAdminUser } from "./init-permissions";
import { agentService } from "./agent-service";
import { cleanupService } from "./cleanup-service";

const app = express();
// Trust proxy for rate limiting behind reverse proxy
app.set('trust proxy', true);
app.use(express.json());
app.use(express.urlencoded({ extended: false }));


import session from "express-session";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";

// امنیت
// Disable CSP in development for Vite compatibility
if (app.get("env") === "production") {
  app.use(helmet());
} else {
  app.use(helmet({
    contentSecurityPolicy: false
  }));
}
app.use(cors({
  origin: ['https://sarisazan.ae', 'https://www.sarisazan.ae'],
  credentials: true
}));

// Custom handler to ensure JSON responses for rate limit errors
const rateLimitHandler = (req: Request, res: Response) => {
  res.status(429).json({ 
    message: "درخواست‌های زیادی ارسال شده است. لطفاً چند لحظه صبر کنید و دوباره تلاش کنید." 
  });
};

// Rate limiter for general API routes
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
  skip: (req) => {
    // Skip rate limiting for login endpoint (it has its own limiter)
    return req.path === '/api/auth/login' || req.path === '/auth/login';
  }
});

// Apply rate limiter to all other API routes (login will be handled separately in routes.ts)
app.use('/api/', (req, res, next) => {
  if (req.path === '/api/auth/login' || req.path === '/auth/login') {
    return next();
  }
  return limiter(req, res, next);
});

app.use(session({
  secret: process.env.SESSION_SECRET || 'change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: true, httpOnly: true }
}));



app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, async () => {
    log(`serving on port ${port}`);
    await initializePermissionsAndRoles();
    await createDefaultAdminUser();
    await agentService.initialize();
    
    // Auto-load contract law if file exists
    const contractLawPath = 'uploads/agent-documents/contract_law.jsonl';
    try {
      const fs = await import('fs');
      if (fs.existsSync(contractLawPath)) {
        const result = await agentService.loadFromFile(contractLawPath);
        if (result.success) {
          console.log(`📚 شرایط عمومی پیمان بارگذاری شد (${result.articlesCount} ماده)`);
        }
      }
    } catch (error) {
      console.log('⚠️ فایل شرایط عمومی پیمان یافت نشد');
    }
    
    startAutoAlertScheduler();
    
    const initialCleanup = await cleanupService.cleanupTempFiles();
    if (initialCleanup.deleted.length > 0) {
      log(`🧹 Initial cleanup: ${initialCleanup.deleted.length} files removed`);
    }
    cleanupService.scheduleAutomaticCleanup(24);
  });
})();
