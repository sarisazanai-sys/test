/**
 * تست دسترسی‌های کاربر جدید
 * 
 * این تست بررسی می‌کند که:
 * 1. کاربر جدید با role="viewer" ثبت‌نام می‌کند
 * 2. کاربر viewer فقط دسترسی خواندن دارد (GET /projects)
 * 3. کاربر viewer نمی‌تواند پروژه حذف کند
 * 4. کاربر viewer نمی‌تواند کاربر ویرایش کند
 * 5. فقط admin می‌تواند role admin اختصاص دهد
 */

import { describe, it, expect, beforeAll, afterAll } from '@jest/globals';
import request from 'supertest';
import express from 'express';
import { registerRoutes } from '../routes';
import { db } from '../db';
import { users, roles, projects } from '@shared/schema';
import { eq } from 'drizzle-orm';
import bcrypt from 'bcryptjs';

// Note: This is a manual test file. To run it, you need to:
// 1. Install jest and supertest: npm install --save-dev jest @types/jest supertest @types/supertest ts-jest
// 2. Configure jest in package.json
// 3. Run: npm test

describe('User Access Control Tests', () => {
  let app: express.Application;
  let adminToken: string;
  let viewerToken: string;
  let adminUserId: string;
  let viewerUserId: string;
  let testProjectId: string;

  beforeAll(async () => {
    // Create test app
    app = express();
    app.use(express.json());
    await registerRoutes(app);

    // Create admin user for testing
    const adminPassword = await bcrypt.hash('admin123', 10);
    const [adminRole] = await db.select().from(roles).where(eq(roles.name, 'admin'));
    
    const [adminUser] = await db.insert(users).values({
      username: 'test-admin',
      password: adminPassword,
      firstName: 'Admin',
      lastName: 'Test',
      roleId: adminRole?.id || null,
      role: 'admin',
      isActive: true,
    }).returning();
    
    adminUserId = adminUser.id;

    // Create viewer user
    const viewerPassword = await bcrypt.hash('viewer123', 10);
    const [viewerRole] = await db.select().from(roles).where(eq(roles.name, 'viewer'));
    
    const [viewerUser] = await db.insert(users).values({
      username: 'test-viewer',
      password: viewerPassword,
      firstName: 'Viewer',
      lastName: 'Test',
      roleId: viewerRole?.id || null,
      role: 'viewer',
      isActive: true,
    }).returning();
    
    viewerUserId = viewerUser.id;

    // Create test project
    const [testProject] = await db.insert(projects).values({
      title: 'Test Project',
      status: 'active',
    }).returning();
    
    testProjectId = testProject.id;
  });

  afterAll(async () => {
    // Cleanup test data
    if (testProjectId) {
      await db.delete(projects).where(eq(projects.id, testProjectId));
    }
    if (adminUserId) {
      await db.delete(users).where(eq(users.id, adminUserId));
    }
    if (viewerUserId) {
      await db.delete(users).where(eq(users.id, viewerUserId));
    }
  });

  describe('User Registration', () => {
    it('should create new user with viewer role by default', async () => {
      const response = await request(app)
        .post('/api/users')
        .set('x-user-id', adminUserId)
        .send({
          username: 'new-user',
          password: 'password123',
          firstName: 'New',
          lastName: 'User',
        });

      expect(response.status).toBe(200);
      expect(response.body.roleId).toBeDefined();
      
      // Check that role is viewer
      const [userRole] = await db
        .select({ name: roles.name })
        .from(roles)
        .where(eq(roles.id, response.body.roleId));
      
      expect(userRole?.name).toBe('viewer');

      // Cleanup
      await db.delete(users).where(eq(users.id, response.body.id));
    });

    it('should not allow non-admin to assign admin role', async () => {
      const [adminRole] = await db.select().from(roles).where(eq(roles.name, 'admin'));

      const response = await request(app)
        .post('/api/users')
        .set('x-user-id', viewerUserId) // Viewer trying to create admin
        .send({
          username: 'new-admin-attempt',
          password: 'password123',
          roleId: adminRole?.id,
        });

      expect(response.status).toBe(403);
      expect(response.body.message).toContain('فقط مدیر سیستم');
    });
  });

  describe('Viewer Access Restrictions', () => {
    it('should allow viewer to GET projects', async () => {
      const response = await request(app)
        .get('/api/projects')
        .set('x-user-id', viewerUserId);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body)).toBe(true);
    });

    it('should NOT allow viewer to DELETE project', async () => {
      const response = await request(app)
        .delete(`/api/projects/${testProjectId}`)
        .set('x-user-id', viewerUserId);

      expect(response.status).toBe(403);
      expect(response.body.message).toContain('دسترسی');
    });

    it('should NOT allow viewer to EDIT user', async () => {
      const response = await request(app)
        .put(`/api/users/${adminUserId}`)
        .set('x-user-id', viewerUserId)
        .send({
          firstName: 'Updated',
        });

      expect(response.status).toBe(403);
    });

    it('should NOT allow viewer to DELETE user', async () => {
      const response = await request(app)
        .delete(`/api/users/${adminUserId}`)
        .set('x-user-id', viewerUserId);

      expect(response.status).toBe(403);
    });
  });

  describe('Admin Access', () => {
    it('should allow admin to DELETE project', async () => {
      // Create a project to delete
      const [tempProject] = await db.insert(projects).values({
        title: 'Temp Project',
        status: 'active',
      }).returning();

      const response = await request(app)
        .delete(`/api/projects/${tempProject.id}`)
        .set('x-user-id', adminUserId);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });

    it('should allow admin to EDIT user', async () => {
      const response = await request(app)
        .put(`/api/users/${viewerUserId}`)
        .set('x-user-id', adminUserId)
        .send({
          firstName: 'Updated',
        });

      expect(response.status).toBe(200);
      expect(response.body.firstName).toBe('Updated');
    });

    it('should allow admin to assign admin role', async () => {
      const [adminRole] = await db.select().from(roles).where(eq(roles.name, 'admin'));

      const response = await request(app)
        .put(`/api/users/${viewerUserId}`)
        .set('x-user-id', adminUserId)
        .send({
          roleId: adminRole?.id,
        });

      expect(response.status).toBe(200);
    });
  });
});

/**
 * دستورات برای اجرای تست:
 * 
 * 1. نصب dependencies:
 *    npm install --save-dev jest @types/jest supertest @types/supertest ts-jest
 * 
 * 2. اضافه کردن به package.json:
 *    "scripts": {
 *      "test": "jest",
 *      "test:watch": "jest --watch"
 *    }
 * 
 * 3. ایجاد jest.config.js:
 *    module.exports = {
 *      preset: 'ts-jest',
 *      testEnvironment: 'node',
 *      testMatch: ['**/tests/**/*.test.ts'],
 *      moduleNameMapper: {
 *        '^@shared/(.*)$': '<rootDir>/shared/$1',
 *      },
 *    };
 * 
 * 4. اجرای تست:
 *    npm test
 */

