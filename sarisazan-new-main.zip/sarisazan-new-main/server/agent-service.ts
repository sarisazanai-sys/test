import Fuse from "fuse.js";
import OpenAI from "openai";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface Article {
  chapter: string | null;
  article_number: number;
  article_title: string;
  text: string;
}

interface CachedResponse {
  answer: string;
  references: string[];
  source: "local" | "api";
  timestamp: number;
}

class AgentService {
  private articles: Article[] = [];
  private fuse: Fuse<Article> | null = null;
  private cache: Map<string, CachedResponse> = new Map();
  private openai: OpenAI | null = null;
  private readonly CACHE_DURATION = 7 * 24 * 60 * 60 * 1000;
  private readonly API_TIMEOUT = 30000;

  async initialize() {
    const apiKey = process.env.XAI_API_KEY;
    if (apiKey) {
      this.openai = new OpenAI({
        apiKey,
        baseURL: "https://api.x.ai/v1",
      });
      console.log("✅ Grok AI API connected - ready to answer questions");
    } else {
      console.error(
        "❌ XAI_API_KEY not set - agent cannot function without API key",
      );
    }
  }

  normalizeQuery(query: string): string {
    return query.replace(/[؟،؛]/g, "").replace(/\s+/g, " ").trim();
  }

  extractKeywords(query: string): string[] {
    const normalized = this.normalizeQuery(query);
    const stopWords = [
      "چیست",
      "چیه",
      "چند",
      "چطور",
      "چگونه",
      "کدام",
      "کدامند",
      "است",
      "هست",
      "می",
      "را",
      "رو",
      "به",
      "در",
      "از",
      "که",
    ];
    const words = normalized
      .split(" ")
      .filter((w) => w.length > 2 && !stopWords.includes(w));
    return words;
  }

  searchLocal(query: string): { articles: Article[]; score: number } {
    if (!this.fuse) {
      return { articles: [], score: 0 };
    }

    const normalized = this.normalizeQuery(query);
    const keywords = this.extractKeywords(query);

    // First try: search with full query
    let results = this.fuse.search(normalized);

    // If no results, try searching with individual keywords
    if (results.length === 0 && keywords.length > 0) {
      const allMatches = new Map<number, Fuse.FuseResult<Article>>();

      for (const keyword of keywords) {
        const keywordResults = this.fuse.search(keyword);
        for (const result of keywordResults) {
          const articleNum = result.item.article_number;
          if (
            !allMatches.has(articleNum) ||
            (result.score || 1) < (allMatches.get(articleNum)!.score || 1)
          ) {
            allMatches.set(articleNum, result);
          }
        }
      }

      results = Array.from(allMatches.values()).sort(
        (a, b) => (a.score || 0) - (b.score || 0),
      );
    }

    if (results.length === 0) {
      return { articles: [], score: 0 };
    }

    const topResults = results.slice(0, 3);
    const avgScore =
      topResults.reduce((sum, r) => sum + (1 - (r.score || 1)), 0) /
      topResults.length;

    return {
      articles: topResults.map((r) => r.item),
      score: avgScore,
    };
  }

  canAnswerLocally(
    query: string,
    searchResults: { articles: Article[]; score: number },
  ): boolean {
    if (searchResults.articles.length === 0) return false;

    const lowerQuery = query.toLowerCase();

    const simpleQuestions = [
      "چند روز",
      "چه مدت",
      "چقدر",
      "کی",
      "کجا",
      "مهلت",
      "تعریف",
      "چیست",
      "چیه",
      "یعنی",
      "منظور از",
      "تفاوت",
      "فرق",
    ];

    const isSimpleQuestion = simpleQuestions.some((keyword) =>
      lowerQuery.includes(keyword),
    );

    if (isSimpleQuestion && searchResults.score > 0.5) {
      return true;
    }

    if (searchResults.score > 0.7) {
      return true;
    }

    return false;
  }

  generateLocalAnswer(
    query: string,
    articles: Article[],
  ): { answer: string; references: string[] } {
    const references = articles.map((a) => `ماده ${a.article_number}`);

    let answer = "";

    if (articles.length === 1) {
      const art = articles[0];
      answer = `طبق ماده ${art.article_number} (${art.article_title}):\n\n${art.text}`;
    } else {
      answer = "بر اساس شرایط عمومی پیمان:\n\n";
      articles.forEach((art) => {
        answer += `📌 ماده ${art.article_number} - ${art.article_title}:\n${art.text}\n\n`;
      });
    }

    return { answer, references };
  }

  async askAPI(
    query: string,
    articles: Article[],
  ): Promise<{ answer: string; references: string[] }> {
    if (!this.openai) {
      throw new Error("Grok API not configured");
    }

    const context = articles
      .map((a) => `ماده ${a.article_number} - ${a.article_title}:\n${a.text}`)
      .join("\n\n");

    const systemPrompt = `تو یک مشاور حقوقی متخصص در شرایط عمومی پیمان‌های ساختمانی ایران هستی.
به سؤالات کاربران بر اساس مواد قانونی ارائه شده پاسخ بده.
پاسخ‌هایت باید:
- دقیق و مستند باشند
- به زبان فارسی رسمی و روان باشند
- حداکثر 300 کلمه داشته باشند
- مستقیماً به سؤال پاسخ دهند
- از مواد قانونی ارائه شده استناد کنند`;

    const userPrompt = `مواد مرتبط:
${context}

سؤال: ${query}

لطفاً بر اساس مواد بالا، پاسخ دقیق و مستند ارائه کن.`;

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.API_TIMEOUT);

      const completion = await this.openai.chat.completions.create(
        {
          model: "grok-2-1212",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          temperature: 0.2,
          max_tokens: 1000,
        },
        { signal: controller.signal as any },
      );

      clearTimeout(timeout);

      const answer =
        completion.choices[0]?.message?.content ||
        "متأسفانه نتوانستم پاسخ مناسبی تولید کنم.";
      const references = articles.map((a) => `ماده ${a.article_number}`);

      return { answer, references };
    } catch (error: any) {
      if (error.name === "AbortError") {
        throw new Error(
          "درخواست به دلیل طولانی شدن متوقف شد. لطفاً دوباره تلاش کنید.",
        );
      }
      throw error;
    }
  }

  async ask(
    query: string,
  ): Promise<{
    answer: string;
    references: string[];
    source: "local" | "api";
  }> {
    const cacheKey = this.normalizeQuery(query);

    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < this.CACHE_DURATION) {
      console.log("✅ Returning cached response");
      return {
        answer: cached.answer,
        references: cached.references,
        source: cached.source,
      };
    }

    // Re-check for API key in case it was added after initialization
    if (!this.openai && process.env.XAI_API_KEY) {
      await this.initialize();
    }

    if (!this.openai) {
      return {
        answer:
          "متأسفانه سرویس Grok AI پیکربندی نشده است. لطفاً کلید API را تنظیم کنید.",
        references: [],
        source: "api",
      };
    }

    console.log("🤖 Using Grok AI to answer question");
    try {
      const systemPrompt = `تو یک مشاور حقوقی متخصص در شرایط عمومی پیمان‌های ساختمانی ایران هستی.
تخصص اصلی تو در قوانین و مقررات ساختمانی، شرایط عمومی پیمان، و قراردادهای پیمانکاری است.

به سؤالات کاربران پاسخ‌های دقیق، کامل و کاربردی بده.
پاسخ‌هایت باید:
- مستند به قوانین و مقررات ایران باشند
- دقیق و بدون حدس و گمان باشند
- به زبان فارسی رسمی و روان باشند
- مستقیماً به سؤال پاسخ دهند
- در صورت نیاز، مثال‌های عملی و محاسبات دقیق ارائه کنند
- اگر نیاز به اطلاعات بیشتر داری، صراحتاً بگو

برای سوالات مربوط به شرایط عمومی پیمان، به مواد مرتبط اشاره کن و توضیحات کامل بده.`;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.API_TIMEOUT);

      const completion = await this.openai.chat.completions.create(
        {
          model: "grok-2-1212",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: query },
          ],
          temperature: 0.1,
          max_tokens: 2000,
        },
        { signal: controller.signal as any },
      );

      clearTimeout(timeout);

      const answer =
        completion.choices[0]?.message?.content ||
        "متأسفانه نتوانستم پاسخ مناسبی تولید کنم.";

      const response = { answer, references: [], source: "api" as const };
      this.cache.set(cacheKey, { ...response, timestamp: Date.now() });

      return response;
    } catch (error: any) {
      console.error("❌ Grok API error:", error);
      if (error.name === "AbortError") {
        return {
          answer:
            "درخواست به دلیل طولانی شدن متوقف شد. لطفاً دوباره تلاش کنید.",
          references: [],
          source: "api",
        };
      }
      return {
        answer: `متأسفانه در ارتباط با Grok خطایی رخ داد: ${error instanceof Error ? error.message : "خطای ناشناخته"}`,
        references: [],
        source: "api",
      };
    }
  }

  getArticle(articleNumber: number): Article | null {
    return (
      this.articles.find((a) => a.article_number === articleNumber) || null
    );
  }

  isConfigured(): boolean {
    return this.openai !== null;
  }

  clearExpiredCache() {
    const now = Date.now();
    const entries = Array.from(this.cache.entries());
    for (const [key, value] of entries) {
      if (now - value.timestamp > this.CACHE_DURATION) {
        this.cache.delete(key);
      }
    }
  }

  async loadFromFile(
    filePath: string,
  ): Promise<{ success: boolean; articlesCount: number; error?: string }> {
    try {
      if (!fs.existsSync(filePath)) {
        return { success: false, articlesCount: 0, error: "فایل یافت نشد" };
      }

      const content = fs.readFileSync(filePath, "utf-8");
      let newArticles: Article[] = [];

      const ext = path.extname(filePath).toLowerCase();

      if (ext === ".jsonl") {
        const lines = content
          .trim()
          .split("\n")
          .filter((line) => line.trim());
        newArticles = lines.map((line) => JSON.parse(line) as Article);
      } else if (ext === ".json") {
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed)) {
          newArticles = parsed as Article[];
        } else {
          return {
            success: false,
            articlesCount: 0,
            error: "فایل JSON باید یک آرایه از مواد باشد",
          };
        }
      } else if (ext === ".txt") {
        return {
          success: false,
          articlesCount: 0,
          error:
            "فایل‌های TXT فعلاً پشتیبانی نمی‌شوند. لطفاً از JSONL یا JSON استفاده کنید.",
        };
      } else {
        return {
          success: false,
          articlesCount: 0,
          error: "فرمت فایل پشتیبانی نمی‌شود. فقط JSONL و JSON مجاز هستند.",
        };
      }

      if (newArticles.length === 0) {
        return {
          success: false,
          articlesCount: 0,
          error: "هیچ ماده‌ای در فایل یافت نشد",
        };
      }

      this.articles = newArticles;

      this.fuse = new Fuse(this.articles, {
        keys: [
          { name: "article_title", weight: 0.4 },
          { name: "text", weight: 0.6 },
        ],
        threshold: 0.4,
        includeScore: true,
        minMatchCharLength: 3,
      });

      this.cache.clear();

      console.log(
        `✅ Agent reloaded with ${this.articles.length} articles from ${filePath}`,
      );

      return { success: true, articlesCount: this.articles.length };
    } catch (error: any) {
      console.error("❌ Error loading file:", error);
      return {
        success: false,
        articlesCount: 0,
        error: `خطا در پردازش فایل: ${error.message}`,
      };
    }
  }
}

export const agentService = new AgentService();
