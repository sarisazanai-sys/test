import { agentService } from './agent-service';
import { db } from './db';
import { projects, statements, adjustments, bitumenDiffs } from '@shared/schema';
import { eq } from 'drizzle-orm';
import OpenAI from 'openai';
import { searchConstructionInfo, searchWeb } from './web-search-helper';

interface QueryResult {
  answer: string;
  references: string[];
  source: 'database' | 'legal-local' | 'legal-api' | 'general-api';
  confidence?: number;
}

class MultiSourceAgentService {
  private openai: OpenAI | null = null;

  constructor() {
    const apiKey = process.env.XAI_API_KEY;
    if (apiKey) {
      this.openai = new OpenAI({ 
        apiKey,
        baseURL: 'https://api.x.ai/v1'
      });
    }
  }

  private normalizeText(text: string): string {
    return text
      .replace(/[ًٌٍَُِّْٰ]/g, '')
      .replace(/[؟،؛]/g, '')
      .replace(/‌/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  private async classifyQuery(query: string): Promise<'database' | 'legal' | 'general'> {
    const normalized = this.normalizeText(query);

    const databaseKeywords = [
      'پروژه', 'قرارداد', 'کارفرما', 'پیشرفت',
      'مبلغ', 'قیمت', 'بودجه', 'هزینه', 'صورت', 'وضعیت',
      'سریع', 'سازان', 'بهینه', 'مطبوع', 'خاک', 'پی', 'دنا',
      'قزوین', 'تاکستان', 'آوج', 'البرز', 'همه',
      'چند', 'کدام', 'درصد', 'تکمیل', 'انجام', 'شده'
    ];

    const legalKeywords = [
      'ماده', 'قانون', 'شرایط', 'عمومی', 'پیمان', 'فسخ',
      'تعهد', 'مسئولیت', 'حق', 'تکلیف', 'مهلت',
      'تحویل', 'تضمین', 'خسارت', 'جریمه', 'بیمه'
    ];
    
    const hasDatabaseKeyword = databaseKeywords.some(kw => normalized.includes(kw));
    const hasLegalKeyword = legalKeywords.some(kw => normalized.includes(kw));
    
    // Special cases that should always be database
    if (normalized.includes('لیست') && normalized.includes('پیمانکار')) {
      return 'database';
    }

    if (hasDatabaseKeyword && !hasLegalKeyword) {
      return 'database';
    }

    if (hasLegalKeyword) {
      return 'legal';
    }

    if (normalized.includes('لیست') || normalized.includes('همه') || normalized.includes('چند')) {
      return 'database';
    }

    const questionWords = ['چطور', 'چگونه', 'چرا'];
    if (questionWords.some(qw => normalized.includes(qw))) {
      return 'general';
    }

    return 'general';
  }

  private async queryStatements(query: string, allProjects: any[]): Promise<QueryResult | null> {
    const normalized = this.normalizeText(query);
    const contractMatch = query.match(/\d{4}/);
    
    if (contractMatch) {
      const contractNum = contractMatch[0];
      const project = allProjects.find(p => p.contractNumber?.includes(contractNum));
      
      if (project) {
        const projectStatements = await db.select().from(statements).where(eq(statements.projectId, project.id));
        const projectAdjustments = await db.select().from(adjustments).where(eq(adjustments.projectId, project.id));
        
        let answer = `📝 صورت‌وضعیت‌های قرارداد ${project.contractNumber}:\n\n`;
        answer += `📋 پروژه: ${project.title}\n\n`;
        
        if (projectStatements.length > 0) {
          answer += `💰 صورت‌وضعیت‌ها (${projectStatements.length} مورد):\n`;
          projectStatements.forEach((stmt, i) => {
            answer += `\n${i + 1}. صورت‌وضعیت شماره ${stmt.number}\n`;
            answer += `   • مبلغ: ${stmt.amount} ریال\n`;
            if (stmt.startDate) answer += `   • تاریخ شروع: ${stmt.startDate}\n`;
            if (stmt.endDate) answer += `   • تاریخ پایان: ${stmt.endDate}\n`;
            answer += `   • وضعیت: ${stmt.status}\n`;
          });
        } else {
          answer += `صورت‌وضعیتی برای این پروژه ثبت نشده است.\n`;
        }

        if (projectAdjustments.length > 0) {
          answer += `\n📊 تعدیل‌ها (${projectAdjustments.length} مورد):\n`;
          projectAdjustments.forEach((adj, i) => {
            answer += `\n${i + 1}. تعدیل شماره ${adj.number}\n`;
            answer += `   • مبلغ: ${adj.amount} ریال\n`;
            if (adj.startDate) answer += `   • تاریخ شروع: ${adj.startDate}\n`;
            if (adj.endDate) answer += `   • تاریخ پایان: ${adj.endDate}\n`;
          });
        }
        
        return {
          answer,
          references: [project.contractNumber || project.id],
          source: 'database'
        };
      }
    }
    
    return null;
  }

  private async queryDatabase(query: string): Promise<QueryResult> {
    try {
      const normalized = this.normalizeText(query);
      const allProjects = await db.select().from(projects);

      // Check for statements query first
      if (normalized.includes('صورت') && normalized.includes('وضعیت')) {
        const statementsResult = await this.queryStatements(query, allProjects);
        if (statementsResult) return statementsResult;
      }

      const matches = allProjects.filter(p => {
        const searchText = this.normalizeText([
          p.title,
          p.contractor,
          p.employer,
          p.contractNumber,
          p.location
        ].filter(Boolean).join(' '));

        const queryWords = normalized.split(' ').filter(w => w.length > 1);
        return queryWords.some(word => searchText.includes(word));
      });

      if (matches.length > 0) {
        const answer = this.formatProjectResults(query, matches);
        return {
          answer,
          references: matches.map(p => p.contractNumber || p.id),
          source: 'database'
        };
      }

      if (normalized.includes('لیست') || normalized.includes('همه') || normalized.includes('تمام') || normalized.includes('پروژه')) {
        const answer = this.formatProjectList(allProjects);
        return {
          answer,
          references: allProjects.map(p => p.contractNumber || p.id),
          source: 'database'
        };
      }

      if (normalized.includes('پیمانکار')) {
        const contractorSet = new Set(allProjects.map(p => p.contractor).filter(Boolean));
        const contractors = Array.from(contractorSet);
        return {
          answer: `پیمانکاران موجود در سیستم:\n\n${contractors.map((c, i) => `${i + 1}. ${c}`).join('\n')}\n\nبرای جزئیات بیشتر، نام پیمانکار را مشخص کنید.`,
          references: [],
          source: 'database'
        };
      }

      return {
        answer: 'متأسفانه پروژه‌ای با این مشخصات پیدا نشد. می‌توانید:\n• از کلمات کلیدی دیگری استفاده کنید\n• "لیست پروژه‌ها" را بنویسید\n• نام پیمانکار را بپرسید',
        references: [],
        source: 'database'
      };

    } catch (error) {
      console.error('❌ Database query error:', error);
      return {
        answer: 'متأسفانه در جستجوی اطلاعات پروژه مشکلی پیش آمد.',
        references: [],
        source: 'database'
      };
    }
  }

  private formatProjectList(projects: any[]): string {
    if (projects.length === 0) {
      return 'هیچ پروژه‌ای در سیستم ثبت نشده است.';
    }

    let answer = `📋 لیست پروژه‌ها (${projects.length} پروژه):\n\n`;
    
    projects.forEach((p, index) => {
      answer += `${index + 1}. ${p.title}\n`;
      answer += `   📝 شماره قرارداد: ${p.contractNumber || 'ثبت نشده'}\n`;
      answer += `   👷 پیمانکار: ${p.contractor || 'ثبت نشده'}\n`;
      if (p.progress !== null && p.progress !== undefined) {
        answer += `   📊 پیشرفت: ${p.progress}%\n`;
      }
      answer += '\n';
    });

    return answer;
  }

  private formatProjectResults(query: string, results: any[]): string {
    const normalized = this.normalizeText(query);

    if (normalized.includes('پیشرفت') || normalized.includes('درصد')) {
      let answer = '📊 وضعیت پیشرفت پروژه‌ها:\n\n';
      results.forEach(p => {
        answer += `• ${p.title}\n`;
        answer += `  پیشرفت: ${p.progress || 0}% | قرارداد: ${p.contractNumber}\n\n`;
      });
      return answer;
    }

    if (normalized.includes('مبلغ') || normalized.includes('قیمت') || normalized.includes('بودجه')) {
      let answer = '💰 اطلاعات مالی پروژه‌ها:\n\n';
      results.forEach(p => {
        answer += `• ${p.title}\n`;
        answer += `  مبلغ قرارداد: ${p.amount || 'ثبت نشده'} ریال\n`;
        answer += `  شماره قرارداد: ${p.contractNumber}\n\n`;
      });
      return answer;
    }

    if (results.length === 1) {
      const p = results[0];
      let answer = `📋 مشخصات پروژه:\n\n`;
      answer += `🔷 عنوان: ${p.title}\n\n`;
      if (p.contractNumber) answer += `📝 شماره قرارداد: ${p.contractNumber}\n`;
      if (p.contractDate) answer += `📅 تاریخ قرارداد: ${p.contractDate}\n`;
      if (p.contractor) answer += `👷 پیمانکار: ${p.contractor}\n`;
      if (p.employer) answer += `🏢 کارفرما: ${p.employer}\n`;
      if (p.amount) answer += `💰 مبلغ قرارداد: ${p.amount} ریال\n`;
      if (p.progress !== null && p.progress !== undefined) {
        answer += `📊 درصد پیشرفت: ${p.progress}%\n`;
      }
      if (p.status) answer += `🔄 وضعیت: ${p.status === 'active' ? 'فعال' : p.status}\n`;
      return answer;
    }

    let answer = `یافت شد ${results.length} پروژه:\n\n`;
    results.forEach((p, index) => {
      answer += `${index + 1}. ${p.title}\n`;
      answer += `   پیمانکار: ${p.contractor || 'نامشخص'} | `;
      answer += `پیشرفت: ${p.progress || 0}%\n\n`;
    });

    return answer;
  }

  private async askGeneralQuestion(query: string): Promise<QueryResult> {
    // First, try to use the AI API if available
    if (this.openai) {
      try {
        const systemPrompt = `تو یک دستیار هوشمند برای مدیریت پروژه‌های ساختمانی هستی.
به سوالات کاربر به زبان فارسی، واضح و کاربردی پاسخ بده.
پاسخ‌هایت باید:
- مختصر و مفید باشند (حداکثر 200 کلمه)
- مستقیماً به سوال پاسخ دهند
- در صورت لزوم، مثال عملی ارائه کنند

اگر اطلاعات کافی نداری، صادقانه اعلام کن که نمیدانی.`;

        const completion = await this.openai.chat.completions.create({
          model: 'grok-2-1212',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: query }
          ],
          temperature: 0.2,
          max_tokens: 500
        });

        const answer = completion.choices[0]?.message?.content || '';

        // If AI doesn't have a good answer, fall back to web search
        if (!answer || answer.includes('نمی‌دانم') || answer.includes('نمیدانم') || answer.includes('اطلاعات کافی ندارم')) {
          console.log('🔍 AI doesn\'t have enough info, searching the web...');
          const webAnswer = await searchConstructionInfo(query);
          return {
            answer: `🤖 پاسخ اولیه دستیار:\n${answer}\n\n${webAnswer}`,
            references: [],
            source: 'general-api'
          };
        }

        return {
          answer,
          references: [],
          source: 'general-api'
        };

      } catch (error: any) {
        console.error('❌ AI API error:', error);
        
        // Check if it's a geographic restriction error
        const errorMessage = error.message?.toLowerCase() || '';
        if (errorMessage.includes('abroad') || errorMessage.includes('geographic') || 
            errorMessage.includes('region') || errorMessage.includes('403') || 
            errorMessage.includes('forbidden')) {
          console.log('🌍 Geographic restriction detected, using web search fallback...');
          const webAnswer = await searchConstructionInfo(query);
          return {
            answer: `⚠️ دستیار هوش مصنوعی به دلیل محدودیت‌های جغرافیایی در دسترس نیست.\n\n${webAnswer}`,
            references: [],
            source: 'general-api'
          };
        }
        
        // For other errors, try web search
        console.log('🔍 API error, trying web search fallback...');
        const webAnswer = await searchConstructionInfo(query);
        return {
          answer: `⚠️ خطا در اتصال به دستیار هوش مصنوعی.\n\n${webAnswer}`,
          references: [],
          source: 'general-api'
        };
      }
    }
    
    // If no API key is configured, use web search directly
    console.log('🔍 No API key configured, using web search...');
    const webAnswer = await searchConstructionInfo(query);
    return {
      answer: webAnswer,
      references: [],
      source: 'general-api'
    };
  }

  async ask(query: string): Promise<QueryResult> {
    const queryType = await this.classifyQuery(query);
    
    console.log(`🤔 Query classified as: ${queryType}`);

    if (queryType === 'database') {
      return await this.queryDatabase(query);
    }

    if (queryType === 'legal') {
      const legalResult = await agentService.ask(query);
      return {
        answer: legalResult.answer,
        references: legalResult.references,
        source: legalResult.source === 'api' ? 'legal-api' : 'legal-local'
      };
    }

    return await this.askGeneralQuestion(query);
  }
}

export const multiSourceAgent = new MultiSourceAgentService();
