// SERVICE WORKER DISABLED
// Service worker causes old bundles to be cached and served, breaking the app
// Unregister any existing service workers
if ('serviceWorker' in navigator) {
    // Unregister all existing service workers
    navigator.serviceWorker.getRegistrations().then(registrations => {
        for (const registration of registrations) {
            registration.unregister().then(success => {
                if (success) {
                    console.log('✅ Service Worker unregistered');
                }
            });
        }
    });
    // Clear all caches
    if ('caches' in window) {
        caches.keys().then(cacheNames => {
            return Promise.all(cacheNames.map(cacheName => caches.delete(cacheName)));
        }).then(() => {
            console.log('✅ All caches cleared');
        });
    }
}
