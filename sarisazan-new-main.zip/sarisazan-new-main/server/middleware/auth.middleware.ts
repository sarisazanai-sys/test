import type { Request, Response, NextFunction } from "express";
import { db } from "../db";
import { users, roles, rolePermissions, permissions } from "@shared/schema";
import { eq, and } from "drizzle-orm";

// Extend Express Request to include user info
declare global {
  namespace Express {
    interface Request {
      userId?: string;
      userRole?: string;
      userRoleId?: string;
    }
  }
}

/**
 * Extract user info from request headers (sent from frontend)
 * In a real app, you'd validate a JWT token or session here
 */
export async function authenticateUser(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    // Get user ID from header (frontend should send this)
    const userId = req.headers["x-user-id"] as string;
    
    if (!userId) {
      res.status(401).json({ message: "احراز هویت لازم است" });
      return;
    }

    // Get user from database
    const [user] = await db
      .select({
        id: users.id,
        roleId: users.roleId,
        roleName: roles.name,
        isActive: users.isActive,
      })
      .from(users)
      .leftJoin(roles, eq(users.roleId, roles.id))
      .where(eq(users.id, userId));

    if (!user || !user.isActive) {
      res.status(401).json({ message: "کاربر معتبر نیست" });
      return;
    }

    // Attach user info to request
    req.userId = user.id;
    req.userRoleId = user.roleId || undefined;
    req.userRole = user.roleName || undefined;

    next();
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
}

/**
 * Check if user has a specific permission
 */
export function checkPermission(permissionKey: string) {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.userRoleId) {
        res.status(403).json({ message: "دسترسی لازم نیست" });
        return;
      }

      // Get permission
      const [permission] = await db
        .select()
        .from(permissions)
        .where(eq(permissions.key, permissionKey));

      if (!permission) {
        console.error(`Permission not found: ${permissionKey}. Available permissions:`, 
          (await db.select().from(permissions)).map(p => p.key).join(", "));
        res.status(500).json({ message: `مجوز یافت نشد: ${permissionKey}` });
        return;
      }

      // Check if user's role has this permission
      const [rolePerm] = await db
        .select()
        .from(rolePermissions)
        .where(
          and(
            eq(rolePermissions.roleId, req.userRoleId),
            eq(rolePermissions.permissionId, permission.id)
          )
        );

      if (!rolePerm) {
        res.status(403).json({ message: "شما دسترسی لازم را ندارید" });
        return;
      }

      next();
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  };
}

/**
 * Check if user is admin
 */
export async function requireAdmin(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.userRoleId) {
      res.status(403).json({ message: "دسترسی لازم نیست" });
      return;
    }

    // Get user's role
    const [role] = await db
      .select()
      .from(roles)
      .where(eq(roles.id, req.userRoleId));

    if (!role || role.name !== "admin") {
      res.status(403).json({ message: "فقط مدیر سیستم می‌تواند این عملیات را انجام دهد" });
      return;
    }

    next();
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
}

/**
 * Check if user is admin or manager
 */
export async function requireAdminOrManager(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.userRoleId) {
      res.status(403).json({ message: "دسترسی لازم نیست" });
      return;
    }

    // Get user's role
    const [role] = await db
      .select()
      .from(roles)
      .where(eq(roles.id, req.userRoleId));

    if (!role || (role.name !== "admin" && role.name !== "manager")) {
      res.status(403).json({ message: "شما دسترسی لازم را ندارید" });
      return;
    }

    next();
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
}

