import fs from 'fs/promises';
import fsSync from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface CleanupOptions {
  maxAge?: number;
  dryRun?: boolean;
}

export class CleanupService {
  private readonly tempDirectories = [
    path.join(__dirname, '..', 'uploads', 'temp'),
    path.join(__dirname, '..', 'uploads', 'processing'),
  ];

  private readonly tempFilePatterns = [
    /^temp_.*\.txt$/,
    /^.*_temp\.pdf$/,
    /^processing_.*\.json$/,
  ];

  async cleanupTempFiles(options: CleanupOptions = {}): Promise<{ deleted: string[]; errors: string[] }> {
    const { maxAge = 24 * 60 * 60 * 1000, dryRun = false } = options;
    const deleted: string[] = [];
    const errors: string[] = [];
    const now = Date.now();

    for (const dir of this.tempDirectories) {
      try {
        await fs.access(dir);
      } catch {
        continue;
      }

      try {
        const files = await fs.readdir(dir);

        for (const file of files) {
          const filePath = path.join(dir, file);

          try {
            const stats = await fs.stat(filePath);

            if (stats.isFile()) {
              const age = now - stats.mtimeMs;
              const shouldDelete = age > maxAge || this.tempFilePatterns.some(pattern => pattern.test(file));

              if (shouldDelete) {
                if (!dryRun) {
                  await fs.unlink(filePath);
                }
                deleted.push(filePath);
              }
            }
          } catch (error) {
            errors.push(`Failed to process ${filePath}: ${error}`);
          }
        }
      } catch (error) {
        errors.push(`Failed to read directory ${dir}: ${error}`);
      }
    }

    if (deleted.length > 0) {
      console.log(`🗑️  Cleaned up ${deleted.length} temporary file(s)`);
    }
    if (errors.length > 0) {
      console.error(`⚠️  Cleanup errors: ${errors.length} issue(s)`);
      errors.forEach(err => console.error(`  - ${err}`));
    }

    return { deleted, errors };
  }

  async cleanupEmptyDirectories(): Promise<{ deleted: string[]; errors: string[] }> {
    const deleted: string[] = [];
    const errors: string[] = [];

    const uploadDirs = [
      'uploads/agent-documents',
      'uploads/letters',
      'uploads/messages',
      'uploads/project-files',
      'uploads/sheets',
      'uploads/tasks',
    ];

    for (const relDir of uploadDirs) {
      const dir = path.join(__dirname, '..', relDir);

      try {
        await fs.access(dir);
        const files = await fs.readdir(dir);
        if (files.length === 0) {
          console.log(`📁 Empty directory: ${relDir}`);
        }
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== 'ENOENT') {
          errors.push(`Failed to check ${dir}: ${error}`);
        }
      }
    }

    return { deleted, errors };
  }

  async cleanupProcessedFiles(filePath: string): Promise<boolean> {
    try {
      await fs.access(filePath);
      await fs.unlink(filePath);
      console.log(`🗑️  Cleaned up processed file: ${filePath}`);
      return true;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') {
        console.error(`❌ Failed to cleanup ${filePath}:`, error);
      }
      return false;
    }
  }

  scheduleAutomaticCleanup(intervalHours: number = 24) {
    const intervalMs = intervalHours * 60 * 60 * 1000;

    setInterval(async () => {
      console.log('🧹 Running scheduled cleanup...');
      const result = await this.cleanupTempFiles({ maxAge: 24 * 60 * 60 * 1000 });
      console.log(`✅ Cleanup completed: ${result.deleted.length} files deleted`);
      if (result.errors.length > 0) {
        console.error(`⚠️  Cleanup errors: ${result.errors.length}`);
      }
    }, intervalMs);

    console.log(`🔄 Automatic cleanup scheduled (every ${intervalHours} hours)`);
  }
}

export const cleanupService = new CleanupService();
