import express, { type Express } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer, createLogger } from "vite";
import { type Server } from "http";
import viteConfig from "../vite.config";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const viteLogger = createLogger();

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

export async function setupVite(app: Express, server: Server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true as const,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    customLogger: viteLogger,
    server: serverOptions,
    appType: "custom",
  });

  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;

    // Skip Vite for API routes
    if (url.startsWith('/api')) {
      return next();
    }

    try {
      const clientTemplate = path.resolve(
        __dirname,
        "..",
        "client",
        "index.html",
      );

      // always reload the index.html file from disk incase it changes
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
}

export function serveStatic(app: Express) {
  // Try multiple possible build locations
  const possiblePaths = [
    path.resolve(__dirname, "..", "dist"),
    path.resolve(__dirname, "..", "dist-server", "public"),
    path.resolve(__dirname, "public"),
  ];

  let distPath: string | null = null;
  for (const possiblePath of possiblePaths) {
    if (fs.existsSync(possiblePath)) {
      const indexPath = path.resolve(possiblePath, "index.html");
      if (fs.existsSync(indexPath)) {
        distPath = possiblePath;
        break;
      }
    }
  }

  if (!distPath) {
    // Fallback: use server/public if it exists
    const fallbackPath = path.resolve(__dirname, "public");
    if (fs.existsSync(fallbackPath)) {
      distPath = fallbackPath;
      log(`Using fallback static path: ${distPath}`);
    } else {
      throw new Error(
        `Could not find the build directory. Checked: ${possiblePaths.join(", ")}. Make sure to build the client first.`,
      );
    }
  }

  log(`Serving static files from: ${distPath}`);
  
  // Serve static files (CSS, JS, images, etc.)
  app.use(express.static(distPath, { 
    index: false, // Don't serve index.html automatically for root
    fallthrough: true // Allow fallthrough to catch-all route
  }));

  // Catch-all route: serve index.html for all non-API routes
  // This enables client-side routing (SPA)
  // Must be last route to catch all unmatched paths
  app.get("*", (req, res) => {
    // Skip API routes (shouldn't reach here, but safety check)
    if (req.path.startsWith('/api')) {
      return res.status(404).json({ message: "API route not found" });
    }

    const indexPath = path.resolve(distPath!, "index.html");
    if (fs.existsSync(indexPath)) {
      log(`Serving index.html for route: ${req.path}`);
      res.sendFile(indexPath);
    } else {
      log(`ERROR: index.html not found at ${indexPath}`);
      res.status(404).send("Not Found - index.html missing");
    }
  });
}
