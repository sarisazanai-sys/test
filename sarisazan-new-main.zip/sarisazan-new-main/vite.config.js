"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const vite_1 = require("vite");
const plugin_react_1 = __importDefault(require("@vitejs/plugin-react"));
const vite_plugin_pwa_1 = require("vite-plugin-pwa");
const path_1 = __importDefault(require("path"));
const url_1 = require("url");
const __dirname = path_1.default.dirname((0, url_1.fileURLToPath)(import.meta.url));
exports.default = (0, vite_1.defineConfig)({
    plugins: [
        (0, plugin_react_1.default)(),
        (0, vite_plugin_pwa_1.VitePWA)({
            registerType: 'autoUpdate',
            includeAssets: ['icons/*.png', '*.ico'],
            manifest: {
                name: 'سریع‌سازان البرز',
                short_name: 'سریع‌سازان',
                description: 'سامانه مدیریت پروژه‌های ساخت',
                theme_color: '#d4af37',
                background_color: '#ffffff',
                display: 'standalone',
                start_url: '/',
                dir: 'rtl',
                lang: 'fa',
                icons: [
                    {
                        src: '/icons/icon-192x192.png',
                        sizes: '192x192',
                        type: 'image/png',
                        purpose: 'maskable any'
                    },
                    {
                        src: '/icons/icon-512x512.png',
                        sizes: '512x512',
                        type: 'image/png',
                        purpose: 'maskable any'
                    }
                ]
            }
        })
    ],
    resolve: {
        alias: {
            "@": path_1.default.resolve(__dirname, "client", "src"),
            "@assets": path_1.default.resolve(__dirname, "attached_assets"),
        },
    },
});
