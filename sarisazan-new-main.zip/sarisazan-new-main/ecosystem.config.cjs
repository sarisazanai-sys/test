module.exports = {
  apps: [
    {
      name: 'site-api',
      script: 'npx',
      interpreter: 'none',
      args: 'tsx server/index.ts',
      cwd: '/home/admin/domains/SiteFixer',
      env: {
        NODE_ENV: 'production',
        PORT: 5000
      },
      watch: false,
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s'
    }
  ]
};
