📦 SiteFixer Backup & Restore Guide
===================================

🕒 Date: Tue Nov 11 12:19:06 +0330 2025

This backup contains:
- dist-server/ (compiled backend)
- package.json / vite.config.js
- .env configuration
- Nginx site config (sarisazan.ae)
- Shared schema and node_modules/@shared

-----------------------------------

✅ To restore this app safely:

1️⃣ Copy this ZIP to your new server:
   scp sitefixer-backup-YYYYMMDD-HHMM.zip root@SERVER:/home/admin/domains/SiteFixer/

2️⃣ Extract it:
   cd /home/admin/domains/SiteFixer
   unzip sitefixer-backup-YYYYMMDD-HHMM.zip

3️⃣ Check package.json type:
   If project uses import/export and import.meta → must be:
       "type": "module"
   (not "commonjs")

4️⃣ Rebuild dependencies:
   rm -rf node_modules
   npm install

5️⃣ Rebuild frontend/backend:
   npm run build

6️⃣ Start with PM2:
   pm2 start dist-server/index.js --name sarisazan --interpreter node --interpreter-args="--experimental-specifier-resolution=node"
   pm2 save

7️⃣ Check health:
   curl -v http://127.0.0.1:5000/api/health

8️⃣ Nginx should proxy to 127.0.0.1:5000:
   cat /etc/nginx/sites-enabled/sarisazan.ae
   systemctl reload nginx

-----------------------------------

💡 Common issues:
- "Cannot use import.meta" → package.json missing "type": "module"
- Port 5000 not listening → build incomplete or missing .env
- Login fails → verify database credentials in .env

-----------------------------------

👨‍💻 Maintainer: (your name)
