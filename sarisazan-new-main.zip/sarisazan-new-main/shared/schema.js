"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.stickyNoteItems = exports.stickyNotes = exports.calendarNotes = exports.dailyNotes = exports.tasks = exports.insertWeeklyReportSchema = exports.insertBitumenDiffSchema = exports.insertAdjustmentSchema = exports.insertStatementSchema = exports.insertMessageReadSchema = exports.insertMessageFileSchema = exports.insertMessageSchema = exports.insertConversationMemberSchema = exports.insertConversationSchema = exports.weeklyReports = exports.bitumenDiffs = exports.adjustments = exports.statements = exports.messageReads = exports.messageFiles = exports.messages = exports.conversationMembers = exports.conversations = exports.insertSheetFileSchema = exports.insertSheetSchema = exports.insertUserProjectSchema = exports.insertAlertCommentSchema = exports.insertAlertRecipientSchema = exports.insertAlertSchema = exports.insertTenderSchema = exports.insertBitumenRecordSchema = exports.insertProjectSchema = exports.insertUserSchema = exports.sheetFiles = exports.sheets = exports.userProjects = exports.alertComments = exports.alertRecipients = exports.alerts = exports.tenders = exports.bitumenDifferences = exports.projectModifications = exports.projectStatements = exports.bitumenRecords = exports.projects = exports.users = exports.rolePermissions = exports.permissions = exports.roles = exports.userRoleEnum = void 0;
exports.insertRolePermissionSchema = exports.insertPermissionSchema = exports.insertRoleSchema = exports.insertUserPreferencesSchema = exports.insertProjectFileSchema = exports.insertLetterAttachmentSchema = exports.insertLetterRecipientSchema = exports.insertLetterSchema = exports.insertTaskAttachmentSchema = exports.insertStickyNoteItemSchema = exports.insertStickyNoteSchema = exports.insertCalendarNoteSchema = exports.insertFollowUpTaskSchema = exports.insertDailyNoteSchema = exports.insertTaskSchema = exports.userPreferences = exports.projectFiles = exports.followUpTasks = exports.letterAttachments = exports.letterRecipients = exports.letters = exports.taskAttachments = void 0;
const drizzle_orm_1 = require("drizzle-orm");
const pg_core_1 = require("drizzle-orm/pg-core");
const drizzle_zod_1 = require("drizzle-zod");
// Define role enum
exports.userRoleEnum = (0, pg_core_1.pgEnum)("user_role", ["admin", "editor", "viewer"]);
exports.roles = (0, pg_core_1.pgTable)("roles", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    name: (0, pg_core_1.text)("name").notNull().unique(),
    displayName: (0, pg_core_1.text)("display_name").notNull(),
    description: (0, pg_core_1.text)("description"),
    isSystem: (0, pg_core_1.boolean)("is_system").default(false),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.permissions = (0, pg_core_1.pgTable)("permissions", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    key: (0, pg_core_1.text)("key").notNull().unique(),
    displayName: (0, pg_core_1.text)("display_name").notNull(),
    description: (0, pg_core_1.text)("description"),
    category: (0, pg_core_1.text)("category").notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
});
exports.rolePermissions = (0, pg_core_1.pgTable)("role_permissions", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    roleId: (0, pg_core_1.varchar)("role_id").notNull().references(() => exports.roles.id, { onDelete: "cascade" }),
    permissionId: (0, pg_core_1.varchar)("permission_id").notNull().references(() => exports.permissions.id, { onDelete: "cascade" }),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
});
exports.users = (0, pg_core_1.pgTable)("users", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    username: (0, pg_core_1.text)("username").notNull().unique(),
    password: (0, pg_core_1.text)("password").notNull(),
    firstName: (0, pg_core_1.text)("first_name"),
    lastName: (0, pg_core_1.text)("last_name"),
    email: (0, pg_core_1.text)("email"),
    phone: (0, pg_core_1.text)("phone"),
    roleId: (0, pg_core_1.varchar)("role_id").references(() => exports.roles.id, { onDelete: "set null" }),
    role: (0, pg_core_1.text)("role").default("viewer"),
    isActive: (0, pg_core_1.boolean)("is_active").default(true),
    avatarPath: (0, pg_core_1.text)("avatar_path"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
    resetToken: (0, pg_core_1.text)("reset_token"),
    resetTokenExpiry: (0, pg_core_1.timestamp)("reset_token_expiry"),
    forcePasswordReset: (0, pg_core_1.boolean)("force_password_reset").default(false),
});
exports.projects = (0, pg_core_1.pgTable)("projects", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectNumber: (0, pg_core_1.text)("project_number"),
    title: (0, pg_core_1.text)("title").notNull(),
    contractNumber: (0, pg_core_1.text)("contract_number"),
    contractDate: (0, pg_core_1.text)("contract_date"),
    location: (0, pg_core_1.text)("location"),
    employer: (0, pg_core_1.text)("employer"),
    contractor: (0, pg_core_1.text)("contractor"),
    amount: (0, pg_core_1.text)("amount"),
    amount25Percent: (0, pg_core_1.text)("amount_25_percent"),
    link: (0, pg_core_1.text)("link"),
    progress: (0, pg_core_1.integer)("progress").default(0),
    status: (0, pg_core_1.text)("status").default("active"),
    startDate: (0, pg_core_1.text)("start_date"),
    renewalDate: (0, pg_core_1.text)("renewal_date"),
    // New fields for financial tracking
    lastStatementNumber: (0, pg_core_1.text)("last_statement_number"),
    lastStatementAmount: (0, pg_core_1.text)("last_statement_amount"),
    lastModificationNumber: (0, pg_core_1.text)("last_modification_number"),
    lastModificationAmount: (0, pg_core_1.text)("last_modification_amount"),
    lastBitumenDifferenceNumber: (0, pg_core_1.text)("last_bitumen_difference_number"),
    lastBitumenDifferenceAmount: (0, pg_core_1.text)("last_bitumen_difference_amount"),
    financialProgress: (0, pg_core_1.text)("financial_progress"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
});
exports.bitumenRecords = (0, pg_core_1.pgTable)("bitumen_records", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    invoiceNumber: (0, pg_core_1.text)("invoice_number"),
    invoiceDate: (0, pg_core_1.text)("invoice_date"),
    quantity: (0, pg_core_1.decimal)("quantity", { precision: 10, scale: 2 }),
    billNumber: (0, pg_core_1.text)("bill_number"),
    supplier: (0, pg_core_1.text)("supplier"),
    transportContractor: (0, pg_core_1.text)("transport_contractor"),
    guaranteeType: (0, pg_core_1.text)("guarantee_type"),
    type: (0, pg_core_1.text)("type").default("PG64-22"),
    unitPrice: (0, pg_core_1.decimal)("unit_price", { precision: 15, scale: 2 }),
    totalAmount: (0, pg_core_1.decimal)("total_amount", { precision: 15, scale: 2 }),
    hasInvoice: (0, pg_core_1.boolean)("has_invoice").default(false),
    hasBill: (0, pg_core_1.boolean)("has_bill").default(false),
    hasWaybill: (0, pg_core_1.boolean)("has_waybill").default(false),
    bitumenEntry: (0, pg_core_1.decimal)("bitumen_entry", { precision: 10, scale: 2 }),
    bitumenDeduction: (0, pg_core_1.decimal)("bitumen_deduction", { precision: 10, scale: 2 }),
    bitumenUsed: (0, pg_core_1.decimal)("bitumen_used", { precision: 10, scale: 2 }),
    notes: (0, pg_core_1.text)("notes"),
    invoiceFile: (0, pg_core_1.text)("invoice_file"),
    billFile: (0, pg_core_1.text)("bill_file"),
    waybillFile: (0, pg_core_1.text)("waybill_file"),
    invoices: (0, pg_core_1.text)("invoices"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
// Project Statements (صورت وضعیت‌ها)
exports.projectStatements = (0, pg_core_1.pgTable)("project_statements", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    statementNumber: (0, pg_core_1.text)("statement_number").notNull(),
    startDate: (0, pg_core_1.text)("start_date"),
    endDate: (0, pg_core_1.text)("end_date"),
    amount: (0, pg_core_1.text)("amount").notNull(),
    status: (0, pg_core_1.text)("status").default("confirmed"),
    notes: (0, pg_core_1.text)("notes"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
// Project Modifications (تعدیل‌ها)
exports.projectModifications = (0, pg_core_1.pgTable)("project_modifications", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    modificationNumber: (0, pg_core_1.text)("modification_number").notNull(),
    startDate: (0, pg_core_1.text)("start_date"),
    endDate: (0, pg_core_1.text)("end_date"),
    amount: (0, pg_core_1.text)("amount"),
    status: (0, pg_core_1.text)("status").default("confirmed"),
    notes: (0, pg_core_1.text)("notes"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
// Bitumen Differences (مابه‌التفاوت قیر)
exports.bitumenDifferences = (0, pg_core_1.pgTable)("bitumen_differences", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    differenceNumber: (0, pg_core_1.text)("difference_number").notNull(),
    amount: (0, pg_core_1.text)("amount").notNull(),
    status: (0, pg_core_1.text)("status").default("confirmed"),
    notes: (0, pg_core_1.text)("notes"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.tenders = (0, pg_core_1.pgTable)("tenders", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    title: (0, pg_core_1.text)("title").notNull(),
    city: (0, pg_core_1.text)("city"),
    amount: (0, pg_core_1.decimal)("amount", { precision: 15, scale: 2 }),
    announcedDate: (0, pg_core_1.text)("announced_date"),
    deadlineDate: (0, pg_core_1.text)("deadline_date"),
    client: (0, pg_core_1.text)("client"),
    companies: (0, pg_core_1.text)("companies"),
    status: (0, pg_core_1.text)("status").default("در انتظار بررسی"),
    notes: (0, pg_core_1.text)("notes"),
    createdBy: (0, pg_core_1.varchar)("created_by").references(() => exports.users.id, { onDelete: "set null" }),
    assignedToId: (0, pg_core_1.varchar)("assigned_to_id").references(() => exports.users.id, { onDelete: "set null" }),
    approvalStatus: (0, pg_core_1.text)("approval_status").default("pending"),
    approvalNotes: (0, pg_core_1.text)("approval_notes"),
    approvedBy: (0, pg_core_1.varchar)("approved_by").references(() => exports.users.id, { onDelete: "set null" }),
    approvedAt: (0, pg_core_1.timestamp)("approved_at"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.alerts = (0, pg_core_1.pgTable)("alerts", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").references(() => exports.projects.id, { onDelete: "cascade" }),
    entityType: (0, pg_core_1.text)("entity_type"),
    entityId: (0, pg_core_1.varchar)("entity_id"),
    title: (0, pg_core_1.text)("title").notNull(),
    description: (0, pg_core_1.text)("description"),
    severity: (0, pg_core_1.text)("severity").notNull().default("medium"),
    status: (0, pg_core_1.text)("status").notNull().default("open"),
    assigneeId: (0, pg_core_1.varchar)("assignee_id").references(() => exports.users.id, { onDelete: "set null" }),
    createdBy: (0, pg_core_1.varchar)("created_by").references(() => exports.users.id, { onDelete: "set null" }),
    isPersonal: (0, pg_core_1.boolean)("is_personal").default(false),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
    closedAt: (0, pg_core_1.timestamp)("closed_at"),
});
exports.alertRecipients = (0, pg_core_1.pgTable)("alert_recipients", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    alertId: (0, pg_core_1.varchar)("alert_id").notNull().references(() => exports.alerts.id, { onDelete: "cascade" }),
    userId: (0, pg_core_1.varchar)("user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    isRead: (0, pg_core_1.boolean)("is_read").default(false),
    readAt: (0, pg_core_1.timestamp)("read_at"),
});
exports.alertComments = (0, pg_core_1.pgTable)("alert_comments", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    alertId: (0, pg_core_1.varchar)("alert_id").notNull().references(() => exports.alerts.id, { onDelete: "cascade" }),
    userId: (0, pg_core_1.varchar)("user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    content: (0, pg_core_1.text)("content").notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.userProjects = (0, pg_core_1.pgTable)("user_projects", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    userId: (0, pg_core_1.varchar)("user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    assignedBy: (0, pg_core_1.varchar)("assigned_by").references(() => exports.users.id, { onDelete: "set null" }),
    assignedAt: (0, pg_core_1.timestamp)("assigned_at").defaultNow(),
});
exports.sheets = (0, pg_core_1.pgTable)("sheets", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    sheetCode: (0, pg_core_1.text)("sheet_code"),
    sheetType: (0, pg_core_1.text)("sheet_type").notNull(),
    sampleDate: (0, pg_core_1.text)("sample_date").notNull(),
    testDate: (0, pg_core_1.text)("test_date"),
    location: (0, pg_core_1.text)("location"),
    labName: (0, pg_core_1.text)("lab_name"),
    specRef: (0, pg_core_1.text)("spec_ref"),
    resultsJson: (0, pg_core_1.text)("results_json"),
    status: (0, pg_core_1.text)("status").notNull().default("pending"),
    notes: (0, pg_core_1.text)("notes"),
    createdBy: (0, pg_core_1.varchar)("created_by").references(() => exports.users.id, { onDelete: "set null" }),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
    deletedAt: (0, pg_core_1.timestamp)("deleted_at"),
});
exports.sheetFiles = (0, pg_core_1.pgTable)("sheet_files", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    sheetId: (0, pg_core_1.varchar)("sheet_id").notNull().references(() => exports.sheets.id, { onDelete: "cascade" }),
    fileName: (0, pg_core_1.text)("file_name").notNull(),
    filePath: (0, pg_core_1.text)("file_path").notNull(),
    fileType: (0, pg_core_1.text)("file_type").notNull(),
    uploadedBy: (0, pg_core_1.varchar)("uploaded_by").references(() => exports.users.id, { onDelete: "set null" }),
    uploadedAt: (0, pg_core_1.timestamp)("uploaded_at").defaultNow(),
});
exports.insertUserSchema = (0, drizzle_zod_1.createInsertSchema)(exports.users).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
    resetToken: true,
    resetTokenExpiry: true,
});
exports.insertProjectSchema = (0, drizzle_zod_1.createInsertSchema)(exports.projects).omit({ id: true, createdAt: true });
exports.insertBitumenRecordSchema = (0, drizzle_zod_1.createInsertSchema)(exports.bitumenRecords).omit({
    id: true,
    createdAt: true,
    updatedAt: true
});
exports.insertTenderSchema = (0, drizzle_zod_1.createInsertSchema)(exports.tenders).omit({
    id: true,
    createdAt: true,
    updatedAt: true
});
exports.insertAlertSchema = (0, drizzle_zod_1.createInsertSchema)(exports.alerts).omit({
    id: true,
    createdAt: true,
    updatedAt: true
});
exports.insertAlertRecipientSchema = (0, drizzle_zod_1.createInsertSchema)(exports.alertRecipients).omit({
    id: true,
    readAt: true,
});
exports.insertAlertCommentSchema = (0, drizzle_zod_1.createInsertSchema)(exports.alertComments).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
});
exports.insertUserProjectSchema = (0, drizzle_zod_1.createInsertSchema)(exports.userProjects).omit({
    id: true,
    assignedAt: true,
});
exports.insertSheetSchema = (0, drizzle_zod_1.createInsertSchema)(exports.sheets).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
    deletedAt: true,
});
exports.insertSheetFileSchema = (0, drizzle_zod_1.createInsertSchema)(exports.sheetFiles).omit({
    id: true,
    uploadedAt: true,
});
exports.conversations = (0, pg_core_1.pgTable)("conversations", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    type: (0, pg_core_1.text)("type").notNull(),
    title: (0, pg_core_1.text)("title"),
    projectId: (0, pg_core_1.varchar)("project_id").references(() => exports.projects.id, { onDelete: "cascade" }),
    createdBy: (0, pg_core_1.varchar)("created_by").references(() => exports.users.id, { onDelete: "set null" }),
    isPinned: (0, pg_core_1.boolean)("is_pinned").default(false),
    isArchived: (0, pg_core_1.boolean)("is_archived").default(false),
    isMuted: (0, pg_core_1.boolean)("is_muted").default(false),
    wallpaper: (0, pg_core_1.text)("wallpaper"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.conversationMembers = (0, pg_core_1.pgTable)("conversation_members", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    conversationId: (0, pg_core_1.varchar)("conversation_id").notNull().references(() => exports.conversations.id, { onDelete: "cascade" }),
    userId: (0, pg_core_1.varchar)("user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    isAdmin: (0, pg_core_1.boolean)("is_admin").default(false),
    joinedAt: (0, pg_core_1.timestamp)("joined_at").defaultNow(),
    lastReadAt: (0, pg_core_1.timestamp)("last_read_at"),
});
exports.messages = (0, pg_core_1.pgTable)("messages", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    conversationId: (0, pg_core_1.varchar)("conversation_id").notNull().references(() => exports.conversations.id, { onDelete: "cascade" }),
    senderId: (0, pg_core_1.varchar)("sender_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    content: (0, pg_core_1.text)("content"),
    replyToId: (0, pg_core_1.varchar)("reply_to_id"),
    forwardedFromId: (0, pg_core_1.varchar)("forwarded_from_id"),
    editedAt: (0, pg_core_1.timestamp)("edited_at"),
    deletedAt: (0, pg_core_1.timestamp)("deleted_at"),
    isPinned: (0, pg_core_1.boolean)("is_pinned").default(false),
    status: (0, pg_core_1.varchar)("status").default("pending"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.messageFiles = (0, pg_core_1.pgTable)("message_files", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    messageId: (0, pg_core_1.varchar)("message_id").notNull().references(() => exports.messages.id, { onDelete: "cascade" }),
    filename: (0, pg_core_1.text)("filename").notNull(),
    originalName: (0, pg_core_1.text)("original_name").notNull(),
    mimeType: (0, pg_core_1.text)("mime_type"),
    size: (0, pg_core_1.integer)("size"),
    path: (0, pg_core_1.text)("path").notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
});
exports.messageReads = (0, pg_core_1.pgTable)("message_reads", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    messageId: (0, pg_core_1.varchar)("message_id").notNull().references(() => exports.messages.id, { onDelete: "cascade" }),
    userId: (0, pg_core_1.varchar)("user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    readAt: (0, pg_core_1.timestamp)("read_at").defaultNow(),
});
exports.statements = (0, pg_core_1.pgTable)("statements", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    number: (0, pg_core_1.text)("number").notNull(),
    amount: (0, pg_core_1.decimal)("amount", { precision: 20, scale: 2 }).notNull(),
    status: (0, pg_core_1.text)("status").notNull().default("در انتظار"),
    filePath: (0, pg_core_1.text)("file_path"),
    announcedDate: (0, pg_core_1.text)("announced_date"),
    submissionDate: (0, pg_core_1.text)("submission_date"),
    startDate: (0, pg_core_1.text)("start_date"),
    endDate: (0, pg_core_1.text)("end_date"),
    workPeriod: (0, pg_core_1.text)("work_period"),
    baseMaterials: (0, pg_core_1.text)("base_materials"),
    notes: (0, pg_core_1.text)("notes"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
    deletedAt: (0, pg_core_1.timestamp)("deleted_at"),
});
exports.adjustments = (0, pg_core_1.pgTable)("adjustments", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    number: (0, pg_core_1.text)("number").notNull(),
    amount: (0, pg_core_1.decimal)("amount", { precision: 20, scale: 2 }).notNull(),
    status: (0, pg_core_1.text)("status").notNull().default("در انتظار"),
    startDate: (0, pg_core_1.text)("start_date"),
    endDate: (0, pg_core_1.text)("end_date"),
    indexType: (0, pg_core_1.text)("index_type"),
    upToStatementNumber: (0, pg_core_1.text)("up_to_statement_number"),
    filePath: (0, pg_core_1.text)("file_path"),
    notes: (0, pg_core_1.text)("notes"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
    deletedAt: (0, pg_core_1.timestamp)("deleted_at"),
});
exports.bitumenDiffs = (0, pg_core_1.pgTable)("bitumen_diffs", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    number: (0, pg_core_1.text)("number").notNull(),
    amount: (0, pg_core_1.decimal)("amount", { precision: 20, scale: 2 }).notNull(),
    status: (0, pg_core_1.text)("status").notNull().default("در انتظار"),
    filePath: (0, pg_core_1.text)("file_path"),
    notes: (0, pg_core_1.text)("notes"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
    deletedAt: (0, pg_core_1.timestamp)("deleted_at"),
});
exports.weeklyReports = (0, pg_core_1.pgTable)("weekly_reports", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    weekStartDate: (0, pg_core_1.text)("week_start_date").notNull(),
    weekEndDate: (0, pg_core_1.text)("week_end_date").notNull(),
    activities: (0, pg_core_1.text)("activities").notNull(),
    notes: (0, pg_core_1.text)("notes"),
    status: (0, pg_core_1.text)("status").notNull().default("ثبت شده"),
    createdBy: (0, pg_core_1.varchar)("created_by").references(() => exports.users.id, { onDelete: "set null" }),
    referredTo: (0, pg_core_1.varchar)("referred_to").references(() => exports.users.id, { onDelete: "set null" }),
    referredAt: (0, pg_core_1.timestamp)("referred_at"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.insertConversationSchema = (0, drizzle_zod_1.createInsertSchema)(exports.conversations).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
});
exports.insertConversationMemberSchema = (0, drizzle_zod_1.createInsertSchema)(exports.conversationMembers).omit({
    id: true,
    joinedAt: true,
});
exports.insertMessageSchema = (0, drizzle_zod_1.createInsertSchema)(exports.messages).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
});
exports.insertMessageFileSchema = (0, drizzle_zod_1.createInsertSchema)(exports.messageFiles).omit({
    id: true,
    createdAt: true,
});
exports.insertMessageReadSchema = (0, drizzle_zod_1.createInsertSchema)(exports.messageReads).omit({
    id: true,
    readAt: true,
});
exports.insertStatementSchema = (0, drizzle_zod_1.createInsertSchema)(exports.statements).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
    deletedAt: true,
});
exports.insertAdjustmentSchema = (0, drizzle_zod_1.createInsertSchema)(exports.adjustments).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
    deletedAt: true,
});
exports.insertBitumenDiffSchema = (0, drizzle_zod_1.createInsertSchema)(exports.bitumenDiffs).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
    deletedAt: true,
});
exports.insertWeeklyReportSchema = (0, drizzle_zod_1.createInsertSchema)(exports.weeklyReports).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
    referredAt: true,
});
exports.tasks = (0, pg_core_1.pgTable)("tasks", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    userId: (0, pg_core_1.varchar)("user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    title: (0, pg_core_1.text)("title").notNull(),
    description: (0, pg_core_1.text)("description"),
    category: (0, pg_core_1.text)("category").notNull().default("today"),
    status: (0, pg_core_1.text)("status").notNull().default("باز"),
    priority: (0, pg_core_1.text)("priority").notNull().default("medium"),
    dueDate: (0, pg_core_1.text)("due_date"),
    reminderDateTime: (0, pg_core_1.text)("reminder_date_time"),
    assigneeId: (0, pg_core_1.varchar)("assignee_id").references(() => exports.users.id, { onDelete: "set null" }),
    projectId: (0, pg_core_1.varchar)("project_id").references(() => exports.projects.id, { onDelete: "set null" }),
    requiresConfirmation: (0, pg_core_1.boolean)("requires_confirmation").default(false),
    isConfirmed: (0, pg_core_1.boolean)("is_confirmed").default(false),
    confirmedAt: (0, pg_core_1.timestamp)("confirmed_at"),
    isCompleted: (0, pg_core_1.boolean)("is_completed").default(false),
    completedAt: (0, pg_core_1.timestamp)("completed_at"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.dailyNotes = (0, pg_core_1.pgTable)("daily_notes", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    userId: (0, pg_core_1.varchar)("user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    noteDate: (0, pg_core_1.text)("note_date").notNull(),
    content: (0, pg_core_1.text)("content").notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.calendarNotes = (0, pg_core_1.pgTable)("calendar_notes", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    userId: (0, pg_core_1.varchar)("user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    date: (0, pg_core_1.text)("date").notNull(),
    content: (0, pg_core_1.text)("content").notNull(),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.stickyNotes = (0, pg_core_1.pgTable)("sticky_notes", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    userId: (0, pg_core_1.varchar)("user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    title: (0, pg_core_1.text)("title").notNull(),
    content: (0, pg_core_1.text)("content"),
    color: (0, pg_core_1.text)("color").notNull().default("yellow"),
    date: (0, pg_core_1.text)("date"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.stickyNoteItems = (0, pg_core_1.pgTable)("sticky_note_items", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    noteId: (0, pg_core_1.varchar)("note_id").notNull().references(() => exports.stickyNotes.id, { onDelete: "cascade" }),
    content: (0, pg_core_1.text)("content").notNull(),
    isCompleted: (0, pg_core_1.boolean)("is_completed").default(false),
    orderIndex: (0, pg_core_1.integer)("order_index").default(0),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
});
exports.taskAttachments = (0, pg_core_1.pgTable)("task_attachments", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    taskId: (0, pg_core_1.varchar)("task_id").notNull().references(() => exports.tasks.id, { onDelete: "cascade" }),
    fileName: (0, pg_core_1.text)("file_name").notNull(),
    filePath: (0, pg_core_1.text)("file_path").notNull(),
    fileType: (0, pg_core_1.text)("file_type"),
    uploadedAt: (0, pg_core_1.timestamp)("uploaded_at").defaultNow(),
});
exports.letters = (0, pg_core_1.pgTable)("letters", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    fromUserId: (0, pg_core_1.varchar)("from_user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    projectId: (0, pg_core_1.varchar)("project_id").references(() => exports.projects.id, { onDelete: "set null" }),
    subject: (0, pg_core_1.text)("subject").notNull(),
    content: (0, pg_core_1.text)("content").notNull(),
    isRead: (0, pg_core_1.boolean)("is_read").default(false),
    isReceiptConfirmed: (0, pg_core_1.boolean)("is_receipt_confirmed").default(false),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.letterRecipients = (0, pg_core_1.pgTable)("letter_recipients", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    letterId: (0, pg_core_1.varchar)("letter_id").notNull().references(() => exports.letters.id, { onDelete: "cascade" }),
    userId: (0, pg_core_1.varchar)("user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    isRead: (0, pg_core_1.boolean)("is_read").default(false),
    isReceiptConfirmed: (0, pg_core_1.boolean)("is_receipt_confirmed").default(false),
    readAt: (0, pg_core_1.timestamp)("read_at"),
});
exports.letterAttachments = (0, pg_core_1.pgTable)("letter_attachments", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    letterId: (0, pg_core_1.varchar)("letter_id").notNull().references(() => exports.letters.id, { onDelete: "cascade" }),
    fileName: (0, pg_core_1.text)("file_name").notNull(),
    filePath: (0, pg_core_1.text)("file_path").notNull(),
    fileType: (0, pg_core_1.text)("file_type"),
    uploadedAt: (0, pg_core_1.timestamp)("uploaded_at").defaultNow(),
});
exports.followUpTasks = (0, pg_core_1.pgTable)("follow_up_tasks", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    fromUserId: (0, pg_core_1.varchar)("from_user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    toUserId: (0, pg_core_1.varchar)("to_user_id").notNull().references(() => exports.users.id, { onDelete: "cascade" }),
    title: (0, pg_core_1.text)("title").notNull(),
    description: (0, pg_core_1.text)("description"),
    dueDate: (0, pg_core_1.text)("due_date"),
    status: (0, pg_core_1.text)("status").notNull().default("pending"),
    isConfirmed: (0, pg_core_1.boolean)("is_confirmed").default(false),
    confirmedAt: (0, pg_core_1.timestamp)("confirmed_at"),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.projectFiles = (0, pg_core_1.pgTable)("project_files", {
    id: (0, pg_core_1.varchar)("id").primaryKey().default((0, drizzle_orm_1.sql) `gen_random_uuid()`),
    projectId: (0, pg_core_1.varchar)("project_id").notNull().references(() => exports.projects.id, { onDelete: "cascade" }),
    title: (0, pg_core_1.text)("title").notNull(),
    fileName: (0, pg_core_1.text)("file_name").notNull(),
    filePath: (0, pg_core_1.text)("file_path").notNull(),
    fileType: (0, pg_core_1.text)("file_type"),
    fileSize: (0, pg_core_1.integer)("file_size"),
    uploadedBy: (0, pg_core_1.varchar)("uploaded_by").references(() => exports.users.id, { onDelete: "set null" }),
    uploadedAt: (0, pg_core_1.timestamp)("uploaded_at").defaultNow(),
});
exports.userPreferences = (0, pg_core_1.pgTable)("user_preferences", {
    userId: (0, pg_core_1.varchar)("user_id").primaryKey().references(() => exports.users.id, { onDelete: "cascade" }),
    theme: (0, pg_core_1.text)("theme").notNull().default("light"),
    customTheme: (0, pg_core_1.text)("custom_theme"),
    dashboardLayout: (0, pg_core_1.text)("dashboard_layout"),
    displaySettings: (0, pg_core_1.text)("display_settings"),
    version: (0, pg_core_1.integer)("version").default(1),
    createdAt: (0, pg_core_1.timestamp)("created_at").defaultNow(),
    updatedAt: (0, pg_core_1.timestamp)("updated_at").defaultNow(),
});
exports.insertTaskSchema = (0, drizzle_zod_1.createInsertSchema)(exports.tasks).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
    completedAt: true,
    confirmedAt: true,
});
exports.insertDailyNoteSchema = (0, drizzle_zod_1.createInsertSchema)(exports.dailyNotes).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
});
exports.insertFollowUpTaskSchema = (0, drizzle_zod_1.createInsertSchema)(exports.followUpTasks).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
    confirmedAt: true,
});
exports.insertCalendarNoteSchema = (0, drizzle_zod_1.createInsertSchema)(exports.calendarNotes).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
});
exports.insertStickyNoteSchema = (0, drizzle_zod_1.createInsertSchema)(exports.stickyNotes).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
});
exports.insertStickyNoteItemSchema = (0, drizzle_zod_1.createInsertSchema)(exports.stickyNoteItems).omit({
    id: true,
    createdAt: true,
});
exports.insertTaskAttachmentSchema = (0, drizzle_zod_1.createInsertSchema)(exports.taskAttachments).omit({
    id: true,
    uploadedAt: true,
});
exports.insertLetterSchema = (0, drizzle_zod_1.createInsertSchema)(exports.letters).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
});
exports.insertLetterRecipientSchema = (0, drizzle_zod_1.createInsertSchema)(exports.letterRecipients).omit({
    id: true,
    readAt: true,
});
exports.insertLetterAttachmentSchema = (0, drizzle_zod_1.createInsertSchema)(exports.letterAttachments).omit({
    id: true,
    uploadedAt: true,
});
exports.insertProjectFileSchema = (0, drizzle_zod_1.createInsertSchema)(exports.projectFiles).omit({
    id: true,
    uploadedAt: true,
});
exports.insertUserPreferencesSchema = (0, drizzle_zod_1.createInsertSchema)(exports.userPreferences).omit({
    createdAt: true,
    updatedAt: true,
});
exports.insertRoleSchema = (0, drizzle_zod_1.createInsertSchema)(exports.roles).omit({
    id: true,
    createdAt: true,
    updatedAt: true,
});
exports.insertPermissionSchema = (0, drizzle_zod_1.createInsertSchema)(exports.permissions).omit({
    id: true,
    createdAt: true,
});
exports.insertRolePermissionSchema = (0, drizzle_zod_1.createInsertSchema)(exports.rolePermissions).omit({
    id: true,
    createdAt: true,
});
