"use strict";
/**
 * تست دسترسی‌های کاربر جدید
 *
 * این تست بررسی می‌کند که:
 * 1. کاربر جدید با role="viewer" ثبت‌نام می‌کند
 * 2. کاربر viewer فقط دسترسی خواندن دارد (GET /projects)
 * 3. کاربر viewer نمی‌تواند پروژه حذف کند
 * 4. کاربر viewer نمی‌تواند کاربر ویرایش کند
 * 5. فقط admin می‌تواند role admin اختصاص دهد
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const globals_1 = require("@jest/globals");
const supertest_1 = __importDefault(require("supertest"));
const express_1 = __importDefault(require("express"));
const routes_1 = require("../routes");
const db_1 = require("../db");
const schema_1 = require("@shared/schema");
const drizzle_orm_1 = require("drizzle-orm");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
// Note: This is a manual test file. To run it, you need to:
// 1. Install jest and supertest: npm install --save-dev jest @types/jest supertest @types/supertest ts-jest
// 2. Configure jest in package.json
// 3. Run: npm test
(0, globals_1.describe)('User Access Control Tests', () => {
    let app;
    let adminToken;
    let viewerToken;
    let adminUserId;
    let viewerUserId;
    let testProjectId;
    (0, globals_1.beforeAll)(async () => {
        // Create test app
        app = (0, express_1.default)();
        app.use(express_1.default.json());
        await (0, routes_1.registerRoutes)(app);
        // Create admin user for testing
        const adminPassword = await bcryptjs_1.default.hash('admin123', 10);
        const [adminRole] = await db_1.db.select().from(schema_1.roles).where((0, drizzle_orm_1.eq)(schema_1.roles.name, 'admin'));
        const [adminUser] = await db_1.db.insert(schema_1.users).values({
            username: 'test-admin',
            password: adminPassword,
            firstName: 'Admin',
            lastName: 'Test',
            roleId: adminRole?.id || null,
            role: 'admin',
            isActive: true,
        }).returning();
        adminUserId = adminUser.id;
        // Create viewer user
        const viewerPassword = await bcryptjs_1.default.hash('viewer123', 10);
        const [viewerRole] = await db_1.db.select().from(schema_1.roles).where((0, drizzle_orm_1.eq)(schema_1.roles.name, 'viewer'));
        const [viewerUser] = await db_1.db.insert(schema_1.users).values({
            username: 'test-viewer',
            password: viewerPassword,
            firstName: 'Viewer',
            lastName: 'Test',
            roleId: viewerRole?.id || null,
            role: 'viewer',
            isActive: true,
        }).returning();
        viewerUserId = viewerUser.id;
        // Create test project
        const [testProject] = await db_1.db.insert(schema_1.projects).values({
            title: 'Test Project',
            status: 'active',
        }).returning();
        testProjectId = testProject.id;
    });
    (0, globals_1.afterAll)(async () => {
        // Cleanup test data
        if (testProjectId) {
            await db_1.db.delete(schema_1.projects).where((0, drizzle_orm_1.eq)(schema_1.projects.id, testProjectId));
        }
        if (adminUserId) {
            await db_1.db.delete(schema_1.users).where((0, drizzle_orm_1.eq)(schema_1.users.id, adminUserId));
        }
        if (viewerUserId) {
            await db_1.db.delete(schema_1.users).where((0, drizzle_orm_1.eq)(schema_1.users.id, viewerUserId));
        }
    });
    (0, globals_1.describe)('User Registration', () => {
        (0, globals_1.it)('should create new user with viewer role by default', async () => {
            const response = await (0, supertest_1.default)(app)
                .post('/api/users')
                .set('x-user-id', adminUserId)
                .send({
                username: 'new-user',
                password: 'password123',
                firstName: 'New',
                lastName: 'User',
            });
            (0, globals_1.expect)(response.status).toBe(200);
            (0, globals_1.expect)(response.body.roleId).toBeDefined();
            // Check that role is viewer
            const [userRole] = await db_1.db
                .select({ name: schema_1.roles.name })
                .from(schema_1.roles)
                .where((0, drizzle_orm_1.eq)(schema_1.roles.id, response.body.roleId));
            (0, globals_1.expect)(userRole?.name).toBe('viewer');
            // Cleanup
            await db_1.db.delete(schema_1.users).where((0, drizzle_orm_1.eq)(schema_1.users.id, response.body.id));
        });
        (0, globals_1.it)('should not allow non-admin to assign admin role', async () => {
            const [adminRole] = await db_1.db.select().from(schema_1.roles).where((0, drizzle_orm_1.eq)(schema_1.roles.name, 'admin'));
            const response = await (0, supertest_1.default)(app)
                .post('/api/users')
                .set('x-user-id', viewerUserId) // Viewer trying to create admin
                .send({
                username: 'new-admin-attempt',
                password: 'password123',
                roleId: adminRole?.id,
            });
            (0, globals_1.expect)(response.status).toBe(403);
            (0, globals_1.expect)(response.body.message).toContain('فقط مدیر سیستم');
        });
    });
    (0, globals_1.describe)('Viewer Access Restrictions', () => {
        (0, globals_1.it)('should allow viewer to GET projects', async () => {
            const response = await (0, supertest_1.default)(app)
                .get('/api/projects')
                .set('x-user-id', viewerUserId);
            (0, globals_1.expect)(response.status).toBe(200);
            (0, globals_1.expect)(Array.isArray(response.body)).toBe(true);
        });
        (0, globals_1.it)('should NOT allow viewer to DELETE project', async () => {
            const response = await (0, supertest_1.default)(app)
                .delete(`/api/projects/${testProjectId}`)
                .set('x-user-id', viewerUserId);
            (0, globals_1.expect)(response.status).toBe(403);
            (0, globals_1.expect)(response.body.message).toContain('دسترسی');
        });
        (0, globals_1.it)('should NOT allow viewer to EDIT user', async () => {
            const response = await (0, supertest_1.default)(app)
                .put(`/api/users/${adminUserId}`)
                .set('x-user-id', viewerUserId)
                .send({
                firstName: 'Updated',
            });
            (0, globals_1.expect)(response.status).toBe(403);
        });
        (0, globals_1.it)('should NOT allow viewer to DELETE user', async () => {
            const response = await (0, supertest_1.default)(app)
                .delete(`/api/users/${adminUserId}`)
                .set('x-user-id', viewerUserId);
            (0, globals_1.expect)(response.status).toBe(403);
        });
    });
    (0, globals_1.describe)('Admin Access', () => {
        (0, globals_1.it)('should allow admin to DELETE project', async () => {
            // Create a project to delete
            const [tempProject] = await db_1.db.insert(schema_1.projects).values({
                title: 'Temp Project',
                status: 'active',
            }).returning();
            const response = await (0, supertest_1.default)(app)
                .delete(`/api/projects/${tempProject.id}`)
                .set('x-user-id', adminUserId);
            (0, globals_1.expect)(response.status).toBe(200);
            (0, globals_1.expect)(response.body.success).toBe(true);
        });
        (0, globals_1.it)('should allow admin to EDIT user', async () => {
            const response = await (0, supertest_1.default)(app)
                .put(`/api/users/${viewerUserId}`)
                .set('x-user-id', adminUserId)
                .send({
                firstName: 'Updated',
            });
            (0, globals_1.expect)(response.status).toBe(200);
            (0, globals_1.expect)(response.body.firstName).toBe('Updated');
        });
        (0, globals_1.it)('should allow admin to assign admin role', async () => {
            const [adminRole] = await db_1.db.select().from(schema_1.roles).where((0, drizzle_orm_1.eq)(schema_1.roles.name, 'admin'));
            const response = await (0, supertest_1.default)(app)
                .put(`/api/users/${viewerUserId}`)
                .set('x-user-id', adminUserId)
                .send({
                roleId: adminRole?.id,
            });
            (0, globals_1.expect)(response.status).toBe(200);
        });
    });
});
/**
 * دستورات برای اجرای تست:
 *
 * 1. نصب dependencies:
 *    npm install --save-dev jest @types/jest supertest @types/supertest ts-jest
 *
 * 2. اضافه کردن به package.json:
 *    "scripts": {
 *      "test": "jest",
 *      "test:watch": "jest --watch"
 *    }
 *
 * 3. ایجاد jest.config.js:
 *    module.exports = {
 *      preset: 'ts-jest',
 *      testEnvironment: 'node',
 *      testMatch: ['**/ tests /**/ * .test.ts;
'],
    * moduleNameMapper;
{
        * '^@shared/(.*)$';
    '<rootDir>/shared/$1',
            * ;
}
    * ;
;
    *
    * 4.;
اجرای;
تست: 
    * npm;
test
    * /;
