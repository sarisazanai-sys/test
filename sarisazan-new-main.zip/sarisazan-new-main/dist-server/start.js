require('ts-node').register({ loader: 'ts-node/esm' });
require('./vite');
