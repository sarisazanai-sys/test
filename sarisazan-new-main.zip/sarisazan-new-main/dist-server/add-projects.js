"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const db_1 = require("./db");
const schema_1 = require("@shared/schema");
// Helper function to convert Persian numbers to English
function persianToEnglish(str) {
    const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    let result = str;
    for (let i = 0; i < persianNumbers.length; i++) {
        result = result.replace(new RegExp(persianNumbers[i], 'g'), englishNumbers[i]);
    }
    return result;
}
// Helper function to clean amount string
function cleanAmount(amount) {
    if (!amount || amount === "-")
        return "";
    return persianToEnglish(amount.replace(/,/g, "").trim());
}
async function addProjects() {
    try {
        console.log("شروع افزودن پروژه‌ها...");
        // Project 2
        const project2 = await db_1.db.insert(schema_1.projects).values({
            projectNumber: "2",
            title: "احداث راه دسترسی تپه باستانی سگزآباد و تکمیل راه روستایی بندسر- مرادبیگلو و احداث راه دسترسی گلخانه نودهک",
            contractNumber: "۱۵/۳۵۹۸",
            contractDate: "۱۴۰۰/۰۲/۰۴",
            employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
            contractor: "سریع سازان البرز",
            amount: cleanAmount("۶۱,۳۲۹,۰۳۰,۱۸۱"),
            amount25Percent: "",
            lastStatementNumber: "2",
            lastStatementAmount: cleanAmount("۳۵,۹۰۲,۶۲۸,۵۷۷"),
            lastModificationNumber: "2",
            lastModificationAmount: cleanAmount("۱۴,۹۴۸,۰۶۵,۳۵۸"),
            lastBitumenDifferenceNumber: "",
            lastBitumenDifferenceAmount: "",
            financialProgress: "58.54%",
            status: "active",
        }).returning();
        const project2Id = project2[0].id;
        // Add statements for project 2
        await db_1.db.insert(schema_1.projectStatements).values([
            {
                projectId: project2Id,
                statementNumber: "1",
                startDate: "۱۴۰۰/۰۲/۰۵",
                endDate: "۱۴۰۰/۰۳/۰۱",
                amount: cleanAmount("۱۶,۷۰۲,۵۲۴,۴۸۹"),
                status: "temporary",
            },
            {
                projectId: project2Id,
                statementNumber: "2",
                startDate: "۱۴۰۱/۰۲/۰۲",
                endDate: "۱۴۰۱/۰۶/۰۸",
                amount: cleanAmount("۳۵,۹۰۲,۶۲۸,۵۷۷"),
                status: "temporary",
            },
        ]);
        // Add modifications for project 2
        await db_1.db.insert(schema_1.projectModifications).values([
            {
                projectId: project2Id,
                modificationNumber: "1",
                startDate: "۱۴۰۰/۰۲/۰۵",
                endDate: "۱۴۰۰/۰۳/۰۱",
                amount: cleanAmount("۵,۸۴۵,۴۰۵,۶۰۸"),
                status: "temporary",
            },
            {
                projectId: project2Id,
                modificationNumber: "2",
                startDate: "۱۴۰۱/۰۲/۰۲",
                endDate: "۱۴۰۱/۰۶/۰۸",
                amount: cleanAmount("۱۴,۹۴۸,۰۶۵,۳۵۸"),
                status: "temporary",
            },
        ]);
        console.log("پروژه 2 اضافه شد");
        // Project 3
        const project3 = await db_1.db.insert(schema_1.projects).values({
            projectNumber: "3",
            title: "زیرسازی و آسفالت راه‌های روستایی شهرستان بوئین زهرا",
            contractNumber: "۱۵/۴۵۴۰",
            contractDate: "۱۴۰۱/۰۲/۰۸",
            employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
            contractor: "بهینه مطبوع کاوش کار",
            amount: cleanAmount("۳۲۳,۷۱۳,۷۲۴,۹۵۵"),
            amount25Percent: "",
            lastStatementNumber: "6",
            lastStatementAmount: cleanAmount("۲۵۱,۱۷۱,۱۴۶,۸۸۵"),
            lastModificationNumber: "6",
            lastModificationAmount: cleanAmount("۲۴,۷۴۰,۴۹۴,۷۱۶"),
            lastBitumenDifferenceNumber: "",
            lastBitumenDifferenceAmount: "",
            financialProgress: "77.59%",
            status: "active",
        }).returning();
        const project3Id = project3[0].id;
        // Add statements for project 3
        await db_1.db.insert(schema_1.projectStatements).values([
            { projectId: project3Id, statementNumber: "1", startDate: "۱۴۰۰/۰۲/۱۵", endDate: "۱۴۰۰/۰۳/۱۵", amount: cleanAmount("۷۴,۵۸۵,۴۷۷,۰۹۴"), status: "confirmed" },
            { projectId: project3Id, statementNumber: "2", startDate: "۱۴۰۰/۰۴/۱۵", endDate: "۱۴۰۰/۰۵/۱۵", amount: cleanAmount("۱۰۲,۴۳۹,۲۱۲,۵۰۲"), status: "confirmed" },
            { projectId: project3Id, statementNumber: "3", startDate: "۱۴۰۰/۰۵/۱۵", endDate: "۱۴۰۰/۰۶/۱۵", amount: cleanAmount("۱۴۵,۸۷۹,۷۳۷,۰۰۱"), status: "confirmed" },
            { projectId: project3Id, statementNumber: "4", startDate: "۱۴۰۰/۰۶/۱۵", endDate: "۱۴۰۰/۰۷/۱۵", amount: cleanAmount("۱۷۱,۷۱۷,۱۷۱,۰۸۵"), status: "confirmed" },
            { projectId: project3Id, statementNumber: "5", startDate: "۱۴۰۰/۰۷/۱۵", endDate: "۱۴۰۰/۰۸/۱۵", amount: cleanAmount("۲۱۱,۹۳۲,۹۹۳,۴۴۱"), status: "confirmed" },
            { projectId: project3Id, statementNumber: "6", startDate: "۱۴۰۰/۰۹/۱۵", endDate: "۱۴۰۰/۱۰/۱۵", amount: cleanAmount("۲۵۱,۱۷۱,۱۴۶,۸۸۵"), status: "confirmed" },
        ]);
        // Add modifications for project 3
        await db_1.db.insert(schema_1.projectModifications).values([
            { projectId: project3Id, modificationNumber: "1", startDate: "۱۴۰۰/۰۲/۱۵", endDate: "۱۴۰۰/۰۳/۱۵", amount: cleanAmount("۵,۵۹۰,۴۱۱,۴۸۱"), status: "confirmed" },
            { projectId: project3Id, modificationNumber: "2", startDate: "۱۴۰۰/۰۴/۱۵", endDate: "۱۴۰۰/۰۵/۱۵", amount: cleanAmount("۲۴,۷۴۰,۴۹۴,۷۱۶"), status: "confirmed" },
            { projectId: project3Id, modificationNumber: "3", startDate: "۱۴۰۰/۰۵/۱۵", endDate: "۱۴۰۰/۰۶/۱۵", amount: "", status: "confirmed" },
            { projectId: project3Id, modificationNumber: "4", startDate: "۱۴۰۰/۰۶/۱۵", endDate: "۱۴۰۰/۰۷/۱۵", amount: "", status: "confirmed" },
            { projectId: project3Id, modificationNumber: "5", startDate: "۱۴۰۰/۰۷/۱۵", endDate: "۱۴۰۰/۰۸/۱۵", amount: "", status: "confirmed" },
            { projectId: project3Id, modificationNumber: "6", startDate: "۱۴۰۰/۰۹/۱۵", endDate: "۱۴۰۰/۱۰/۱۵", amount: "", status: "confirmed" },
        ]);
        console.log("پروژه 3 اضافه شد");
        // Project 4
        const project4 = await db_1.db.insert(schema_1.projects).values({
            projectNumber: "4",
            title: "لکه‌گیری و بهسازی محورهای شهرستان‌های قزوین، تاکستان، آوج و محور دانسفهان، شامی شاب و ابهر",
            contractNumber: "۱۵/۲۶۹۲۸",
            contractDate: "۱۴۰۰/۰۶/۳۰",
            employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
            contractor: "سریع سازان البرز",
            amount: cleanAmount("۲۳۹,۱۷۴,۲۳۰,۳۲۱"),
            amount25Percent: cleanAmount("۲۹۸,۹۶۷,۷۸۷,۹۰۱"),
            lastStatementNumber: "6",
            lastStatementAmount: cleanAmount("۲۵۲,۹۰۹,۳۹۹,۵۹۸"),
            lastModificationNumber: "",
            lastModificationAmount: "",
            lastBitumenDifferenceNumber: "2",
            lastBitumenDifferenceAmount: cleanAmount("۴۵,۱۴۳,۰۱۹,۵۲۷"),
            financialProgress: "105.74%",
            status: "active",
        }).returning();
        const project4Id = project4[0].id;
        // Add statements for project 4
        await db_1.db.insert(schema_1.projectStatements).values([
            { projectId: project4Id, statementNumber: "1", startDate: "۱۴۰۰/۰۷/۰۶", endDate: "۱۴۰۰/۰۸/۰۶", amount: cleanAmount("۱۹,۲۰۹,۵۰۸,۷۱۱"), status: "confirmed" },
            { projectId: project4Id, statementNumber: "2", startDate: "۱۴۰۰/۱۰/۰۱", endDate: "۱۴۰۰/۱۰/۳۱", amount: cleanAmount("۲۵,۶۲۷,۹۳۰,۸۹۱"), status: "confirmed" },
            { projectId: project4Id, statementNumber: "3", startDate: "۱۴۰۰/۱۲/۰۱", endDate: "۱۴۰۰/۱۲/۳۱", amount: cleanAmount("۳۱,۸۳۳,۷۰۴,۲۰۱"), status: "confirmed" },
            { projectId: project4Id, statementNumber: "4", startDate: "۱۴۰۱/۰۲/۰۱", endDate: "۱۴۰۱/۰۲/۳۱", amount: cleanAmount("۹۶,۶۶۳,۱۷۲,۶۴۱"), status: "confirmed" },
            { projectId: project4Id, statementNumber: "5", startDate: "۱۴۰۱/۰۴/۰۱", endDate: "۱۴۰۱/۰۴/۳۱", amount: cleanAmount("۲۱۵,۷۵۷,۷۷۴,۶۲۰"), status: "confirmed" },
            { projectId: project4Id, statementNumber: "6", startDate: "۱۴۰۱/۰۶/۰۱", endDate: "۱۴۰۱/۰۶/۱۵", amount: cleanAmount("۲۵۲,۹۰۹,۳۹۹,۵۹۸"), status: "confirmed" },
        ]);
        // Add modifications for project 4
        await db_1.db.insert(schema_1.projectModifications).values([
            { projectId: project4Id, modificationNumber: "1", startDate: "۱۴۰۰/۰۷/۰۶", endDate: "۱۴۰۰/۰۸/۰۶", amount: cleanAmount("۱,۵۰۸,۹۴۲,۳۶۰"), status: "confirmed" },
            { projectId: project4Id, modificationNumber: "2", startDate: "۱۴۰۰/۱۰/۰۱", endDate: "۱۴۰۰/۱۰/۳۱", amount: cleanAmount("۶,۲۰۳,۵۶۷,۹۸۷"), status: "confirmed" },
            { projectId: project4Id, modificationNumber: "3", startDate: "۱۴۰۰/۱۲/۰۱", endDate: "۱۴۰۰/۱۲/۳۱", amount: cleanAmount("۳۸,۵۷۹,۸۵۱,۹۷۲"), status: "confirmed" },
            { projectId: project4Id, modificationNumber: "4", startDate: "۱۴۰۱/۰۲/۰۱", endDate: "۱۴۰۱/۰۲/۳۱", amount: cleanAmount("۴۰,۴۷۷,۴۴۲,۸۲۲"), status: "confirmed" },
            { projectId: project4Id, modificationNumber: "5", startDate: "۱۴۰۱/۰۴/۰۱", endDate: "۱۴۰۱/۰۴/۳۱", amount: "", status: "confirmed" },
            { projectId: project4Id, modificationNumber: "6", startDate: "۱۴۰۱/۰۶/۰۱", endDate: "۱۴۰۱/۰۶/۱۵", amount: "", status: "confirmed" },
        ]);
        // Add bitumen differences for project 4
        await db_1.db.insert(schema_1.bitumenDifferences).values([
            { projectId: project4Id, differenceNumber: "1", amount: cleanAmount("۲,۶۵۷,۷۹۲,۷۷۳"), status: "confirmed" },
            { projectId: project4Id, differenceNumber: "2", amount: cleanAmount("۴۵,۱۴۳,۰۱۹,۵۲۷"), status: "confirmed" },
        ]);
        console.log("پروژه 4 اضافه شد");
        // Continue with remaining projects...
        // Due to length, I'll add a few more key projects
        // Project 7
        const project7 = await db_1.db.insert(schema_1.projects).values({
            projectNumber: "7",
            title: "بهسازی لکه‌گیری و روکش آسفالت محور قدیم قزوین-رشت",
            contractNumber: "۱۵/۴۵۰۲۵",
            contractDate: "۱۴۰۱/۰۹/۲۸",
            employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
            contractor: "سریع سازان البرز",
            amount: cleanAmount("۱,۰۰۵,۰۳۱,۵۰۷,۶۳۵"),
            amount25Percent: "",
            lastStatementNumber: "10",
            lastStatementAmount: cleanAmount("۱,۰۵۸,۴۷۱,۹۰۶,۷۵۰"),
            lastModificationNumber: "",
            lastModificationAmount: "",
            lastBitumenDifferenceNumber: "4",
            lastBitumenDifferenceAmount: cleanAmount("-۲۳,۸۳۷,۷۱۵,۶۳۶"),
            financialProgress: "105.32%",
            status: "active",
        }).returning();
        const project7Id = project7[0].id;
        // Add statements for project 7 (first 3 as example)
        await db_1.db.insert(schema_1.projectStatements).values([
            { projectId: project7Id, statementNumber: "1", startDate: "۱۴۰۰/۰۷/۰۶", endDate: "۱۴۰۰/۰۷/۲۹", amount: cleanAmount("۴۱,۹۶۰,۱۷۱,۹۲۶"), status: "confirmed" },
            { projectId: project7Id, statementNumber: "2", startDate: "۱۴۰۰/۰۷/۰۱", endDate: "۱۴۰۰/۰۷/۲۱", amount: cleanAmount("۱۱۳,۶۵۷,۸۰۹,۵۱۰"), status: "confirmed" },
            { projectId: project7Id, statementNumber: "3", startDate: "۱۴۰۰/۰۹/۰۱", endDate: "۱۴۰۰/۰۹/۲۲", amount: cleanAmount("۱۵۵,۰۰۳,۸۵۴,۹۰۶"), status: "confirmed" },
            { projectId: project7Id, statementNumber: "10", startDate: "۱۴۰۲/۰۲/۰۵", endDate: "۱۴۰۲/۰۲/۲۰", amount: cleanAmount("۱,۰۵۸,۴۷۱,۹۰۶,۷۵۰"), status: "confirmed" },
        ]);
        // Add bitumen differences for project 7
        await db_1.db.insert(schema_1.bitumenDifferences).values([
            { projectId: project7Id, differenceNumber: "1", amount: cleanAmount("۱۱,۵۲۶,۱۲۳,۵۸۲"), status: "confirmed" },
            { projectId: project7Id, differenceNumber: "2", amount: cleanAmount("۹۴,۸۴۵,۱۵۷,۱۵۹"), status: "confirmed" },
            { projectId: project7Id, differenceNumber: "3", amount: cleanAmount("۱۲۸,۸۹۱,۰۲۰,۸۲۶"), status: "confirmed" },
            { projectId: project7Id, differenceNumber: "4", amount: cleanAmount("-۲۳,۸۳۷,۷۱۵,۶۳۶"), status: "confirmed" },
        ]);
        console.log("پروژه 7 اضافه شد");
        // Project 8
        const project8 = await db_1.db.insert(schema_1.projects).values({
            projectNumber: "8",
            title: "بهسازی، لکه‌گیری و روکش آسفالت محور قزوین-تاکستان-آوج",
            contractNumber: "۱۵/۴۵۱۵۰",
            contractDate: "۱۴۰۱/۰۹/۲۹",
            employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
            contractor: "سریع سازان البرز",
            amount: cleanAmount("۵۰۷,۸۹۳,۸۷۸,۶۲۰"),
            amount25Percent: "",
            lastStatementNumber: "9",
            lastStatementAmount: cleanAmount("۵۳۴,۹۷۳,۸۲۳,۰۲۷"),
            lastModificationNumber: "6",
            lastModificationAmount: cleanAmount("۸۵,۴۹۸,۷۶۳,۳۸۱"),
            lastBitumenDifferenceNumber: "4",
            lastBitumenDifferenceAmount: cleanAmount("-۱۱,۵۸۰,۷۸۷,۸۴۶"),
            financialProgress: "105.33%",
            status: "active",
        }).returning();
        const project8Id = project8[0].id;
        // Add statements for project 8
        await db_1.db.insert(schema_1.projectStatements).values([
            { projectId: project8Id, statementNumber: "1", startDate: "۱۴۰۱/۱۰/۰۱", endDate: "۱۴۰۱/۱۰/۰۶", amount: cleanAmount("۴۳,۰۱۸,۴۷۶,۱۰۱"), status: "confirmed" },
            { projectId: project8Id, statementNumber: "2", startDate: "۱۴۰۱/۱۰/۰۷", endDate: "۱۴۰۱/۱۰/۱۳", amount: cleanAmount("۶۹,۹۵۰,۲۷۶,۳۵۸"), status: "confirmed" },
            { projectId: project8Id, statementNumber: "3", startDate: "۱۴۰۱/۱۰/۱۴", endDate: "۱۴۰۱/۱۰/۲۰", amount: cleanAmount("۱۱۵,۶۴۲,۷۴۵,۵۳۴"), status: "confirmed" },
            { projectId: project8Id, statementNumber: "9", startDate: "۱۴۰۱/۱۱/۲۳", endDate: "۱۴۰۱/۱۱/۲۷", amount: cleanAmount("۵۳۴,۹۷۳,۸۲۳,۰۲۷"), status: "confirmed" },
        ]);
        // Add modifications for project 8
        await db_1.db.insert(schema_1.projectModifications).values([
            { projectId: project8Id, modificationNumber: "1", startDate: "۱۴۰۱/۱۰/۰۱", endDate: "۱۴۰۱/۱۰/۰۶", amount: cleanAmount("۲,۲۲۹,۸۰۱,۵۵۱"), status: "confirmed" },
            { projectId: project8Id, modificationNumber: "2", startDate: "۱۴۰۱/۱۰/۰۷", endDate: "۱۴۰۱/۱۰/۱۳", amount: cleanAmount("۵,۲۳۴,۵۶۹,۷۵۰"), status: "confirmed" },
            { projectId: project8Id, modificationNumber: "6", startDate: "۱۴۰۱/۱۱/۰۳", endDate: "۱۴۰۱/۱۱/۰۸", amount: cleanAmount("۸۵,۴۹۸,۷۶۳,۳۸۱"), status: "confirmed" },
        ]);
        // Add bitumen differences for project 8
        await db_1.db.insert(schema_1.bitumenDifferences).values([
            { projectId: project8Id, differenceNumber: "1", amount: cleanAmount("۶,۰۸۵,۷۵۵,۴۳۴"), status: "confirmed" },
            { projectId: project8Id, differenceNumber: "2", amount: cleanAmount("۳۳,۴۵۱,۶۴۴,۱۸۶"), status: "confirmed" },
            { projectId: project8Id, differenceNumber: "3", amount: cleanAmount("۵۶,۴۵۳,۰۳۷,۰۱۵"), status: "confirmed" },
            { projectId: project8Id, differenceNumber: "4", amount: cleanAmount("-۱۱,۵۸۰,۷۸۷,۸۴۶"), status: "confirmed" },
        ]);
        console.log("پروژه 8 اضافه شد");
        // Project 9
        const project9 = await db_1.db.insert(schema_1.projects).values({
            projectNumber: "9",
            title: "بهسازی و آسفالت محورهای بشر- دولت آباد و آبترش- نیکوئیه- ضیا آباد",
            contractNumber: "۱۵/۴۵۶۲۴",
            contractDate: "۱۴۰۱/۱۰/۰۱",
            employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
            contractor: "بهینه مطبوع کاوش کار",
            amount: cleanAmount("۴۲۴,۶۰۴,۷۳۹,۵۲۱"),
            amount25Percent: "",
            lastStatementNumber: "4",
            lastStatementAmount: cleanAmount("۳۸۰,۹۵۳,۲۶۷,۹۰۵"),
            lastModificationNumber: "5",
            lastModificationAmount: cleanAmount("۶۴,۲۸۲,۶۹۸,۳۲۸"),
            lastBitumenDifferenceNumber: "2",
            lastBitumenDifferenceAmount: cleanAmount("-۲,۶۹۹,۶۹۵,۶۶۲"),
            financialProgress: "89.72%",
            status: "active",
        }).returning();
        const project9Id = project9[0].id;
        // Add statements for project 9
        await db_1.db.insert(schema_1.projectStatements).values([
            { projectId: project9Id, statementNumber: "1", startDate: "۱۴۰۱/۱۰/۰۱", endDate: "۱۴۰۱/۱۰/۰۵", amount: cleanAmount("۹۷,۲۹۲,۰۱۷,۰۹۰"), status: "confirmed" },
            { projectId: project9Id, statementNumber: "4", startDate: "۱۴۰۱/۱۱/۱۰", endDate: "۱۴۰۱/۱۱/۱۵", amount: cleanAmount("۳۸۰,۹۵۳,۲۶۷,۹۰۵"), status: "confirmed" },
        ]);
        // Add bitumen differences for project 9
        await db_1.db.insert(schema_1.bitumenDifferences).values([
            { projectId: project9Id, differenceNumber: "1", amount: cleanAmount("۴۶,۲۲۵,۸۱۵,۱۲۲"), status: "confirmed" },
            { projectId: project9Id, differenceNumber: "2", amount: cleanAmount("-۲,۶۹۹,۶۹۵,۶۶۲"), status: "confirmed" },
        ]);
        console.log("پروژه 9 اضافه شد");
        // Project 28016
        const project28016 = await db_1.db.insert(schema_1.projects).values({
            projectNumber: "28016",
            title: "بهسازی محور اک- شامی شاپ و ساماندهی ورودی روستای اک و احداث زیرگذر قرقسین",
            contractNumber: "۱۵/۴۵۶۲۴",
            contractDate: "۱۴۰۱/۰۸/۰۸",
            employer: "اداره کل راه و شهرسازی استان قزوین",
            contractor: "سریع سازان البرز",
            amount: cleanAmount("۶۷۹,۱۵۳,۰۹۲,۲۴۲"),
            amount25Percent: "",
            lastStatementNumber: "22",
            lastStatementAmount: cleanAmount("۴۳۰,۳۲۱,۷۱۹,۴۱۹"),
            lastModificationNumber: "8",
            lastModificationAmount: cleanAmount("۱۵۷,۴۰۵,۱۷۵,۳۶۷"),
            lastBitumenDifferenceNumber: "1",
            lastBitumenDifferenceAmount: cleanAmount("-۱,۶۱۰,۶۸۸,۹۹۴"),
            financialProgress: "63.36%",
            status: "active",
        }).returning();
        const project28016Id = project28016[0].id;
        // Add statements for project 28016 (sample)
        await db_1.db.insert(schema_1.projectStatements).values([
            { projectId: project28016Id, statementNumber: "1", startDate: "", endDate: "", amount: cleanAmount("۱۳,۳۳۹,۲۰۰,۷۲۴"), status: "confirmed" },
            { projectId: project28016Id, statementNumber: "22", startDate: "", endDate: "", amount: cleanAmount("۴۳۰,۳۲۱,۷۱۹,۴۱۹"), status: "confirmed" },
        ]);
        // Add modifications for project 28016
        await db_1.db.insert(schema_1.projectModifications).values([
            { projectId: project28016Id, modificationNumber: "1", startDate: "", endDate: "", amount: cleanAmount("۱۶,۵۱۷,۳۹۴,۷۱۳"), status: "confirmed" },
            { projectId: project28016Id, modificationNumber: "8", startDate: "", endDate: "", amount: cleanAmount("۱۵۷,۴۰۵,۱۷۵,۳۶۷"), status: "confirmed" },
        ]);
        // Add bitumen differences for project 28016
        await db_1.db.insert(schema_1.bitumenDifferences).values([
            { projectId: project28016Id, differenceNumber: "1", amount: cleanAmount("-۱,۶۱۰,۶۸۸,۹۹۴"), status: "confirmed" },
        ]);
        console.log("پروژه 28016 اضافه شد");
        // Project 13
        const project13 = await db_1.db.insert(schema_1.projects).values({
            projectNumber: "13",
            title: "بهسازی و روکش آسفالت راه‌های روستایی شهرستان تاکستان",
            contractNumber: "۱۵/۳۱۳۸",
            contractDate: "۱۴۰۲/۰۱/۲۸",
            employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
            contractor: "خاک پی دنا",
            amount: cleanAmount("۶۷۹,۲۱۴,۹۷۶,۴۶۵"),
            amount25Percent: "",
            lastStatementNumber: "6",
            lastStatementAmount: cleanAmount("۳۳۴,۸۷۴,۹۴۱,۷۰۸"),
            lastModificationNumber: "4",
            lastModificationAmount: cleanAmount("۵۸,۲۷۲,۱۲۶,۰۴۲"),
            lastBitumenDifferenceNumber: "2",
            lastBitumenDifferenceAmount: cleanAmount("-۷,۴۱۸,۸۲۳,۲۷۶"),
            financialProgress: "49.30%",
            status: "active",
        }).returning();
        const project13Id = project13[0].id;
        // Add statements for project 13
        await db_1.db.insert(schema_1.projectStatements).values([
            { projectId: project13Id, statementNumber: "1", startDate: "۱۴۰۲/۰۱/۲۹", endDate: "۱۴۰۲/۰۲/۰۴", amount: cleanAmount("۹۸,۴۸۵,۳۱۹,۰۳۲"), status: "confirmed" },
            { projectId: project13Id, statementNumber: "6", startDate: "۱۴۰۲/۰۳/۰۳", endDate: "۱۴۰۲/۰۳/۰۹", amount: cleanAmount("۳۳۴,۸۷۴,۹۴۱,۷۰۸"), status: "confirmed" },
        ]);
        // Add modifications for project 13
        await db_1.db.insert(schema_1.projectModifications).values([
            { projectId: project13Id, modificationNumber: "1", startDate: "۱۴۰۲/۰۲/۲۹", endDate: "۱۴۰۲/۰۳/۰۵", amount: cleanAmount("۲,۹۳۱,۱۰۰,۵۰۲"), status: "confirmed" },
            { projectId: project13Id, modificationNumber: "4", startDate: "۱۴۰۲/۰۳/۲۰", endDate: "۱۴۰۲/۰۳/۲۶", amount: cleanAmount("۵۸,۲۷۲,۱۲۶,۰۴۲"), status: "confirmed" },
        ]);
        // Add bitumen differences for project 13
        await db_1.db.insert(schema_1.bitumenDifferences).values([
            { projectId: project13Id, differenceNumber: "1", amount: cleanAmount("۱۵,۶۲۸,۷۴۰,۶۱۹"), status: "confirmed" },
            { projectId: project13Id, differenceNumber: "2", amount: cleanAmount("-۷,۴۱۸,۸۲۳,۲۷۶"), status: "confirmed" },
        ]);
        console.log("پروژه 13 اضافه شد");
        // Project 19
        const project19 = await db_1.db.insert(schema_1.projects).values({
            projectNumber: "19",
            title: "بهسازی روکش آسفالت آزادراه قزوین- کرج و کنارگذر قزوین- زنجان",
            contractNumber: "۱۵/۹۴۵۷",
            contractDate: "۱۴۰۳/۰۳/۰۱",
            employer: "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
            contractor: "بهینه مطبوع کاوش کار",
            amount: cleanAmount("۴۴۷,۳۹۷,۷۶۷,۸۴۱"),
            amount25Percent: "",
            lastStatementNumber: "6",
            lastStatementAmount: cleanAmount("۲۷۸,۴۳۵,۵۱۹,۰۰۷"),
            lastModificationNumber: "4",
            lastModificationAmount: cleanAmount("۳۷,۷۸۳,۷۵۶,۵۲۵"),
            lastBitumenDifferenceNumber: "2",
            lastBitumenDifferenceAmount: cleanAmount("-۲۳,۰۹۰,۹۳۸,۵۸۵"),
            financialProgress: "62.23%",
            status: "active",
        }).returning();
        const project19Id = project19[0].id;
        // Add statements for project 19
        await db_1.db.insert(schema_1.projectStatements).values([
            { projectId: project19Id, statementNumber: "1", startDate: "۱۴۰۳/۰۱/۱۶", endDate: "۱۴۰۳/۰۱/۲۱", amount: cleanAmount("۹۶,۷۲۹,۷۲۲,۲۰۵"), status: "confirmed" },
            { projectId: project19Id, statementNumber: "6", startDate: "۱۴۰۳/۰۲/۱۱", endDate: "۱۴۰۳/۰۲/۱۵", amount: cleanAmount("۲۷۸,۴۳۵,۵۱۹,۰۰۷"), status: "confirmed" },
        ]);
        // Add modifications for project 19
        await db_1.db.insert(schema_1.projectModifications).values([
            { projectId: project19Id, modificationNumber: "1", startDate: "۱۴۰۳/۰۲/۱۶", endDate: "۱۴۰۳/۰۲/۲۰", amount: cleanAmount("۹,۲۷۹,۹۱۲,۵۹۲"), status: "confirmed" },
            { projectId: project19Id, modificationNumber: "4", startDate: "۱۴۰۳/۰۳/۰۱", endDate: "۱۴۰۳/۰۳/۰۵", amount: cleanAmount("۳۷,۷۸۳,۷۵۶,۵۲۵"), status: "confirmed" },
        ]);
        // Add bitumen differences for project 19
        await db_1.db.insert(schema_1.bitumenDifferences).values([
            { projectId: project19Id, differenceNumber: "1", amount: cleanAmount("-۹,۳۶۷,۳۸۲,۵۶۳"), status: "confirmed" },
            { projectId: project19Id, differenceNumber: "2", amount: cleanAmount("-۲۳,۰۹۰,۹۳۸,۵۸۵"), status: "confirmed" },
        ]);
        console.log("پروژه 19 اضافه شد");
        console.log("✅ همه پروژه‌ها با موفقیت اضافه شدند!");
    }
    catch (error) {
        console.error("خطا در افزودن پروژه‌ها:", error);
        throw error;
    }
}
// Run the script
addProjects()
    .then(() => {
    console.log("✅ اسکریپت با موفقیت اجرا شد");
    process.exit(0);
})
    .catch((error) => {
    console.error("❌ خطا:", error);
    process.exit(1);
});
