"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireAdminOrManager = exports.requireAdmin = exports.checkPermission = exports.authenticateUser = void 0;
const db_1 = require("../db");
const schema_1 = require("@shared/schema");
const drizzle_orm_1 = require("drizzle-orm");
/**
 * Extract user info from request headers (sent from frontend)
 * In a real app, you'd validate a JWT token or session here
 */
async function authenticateUser(req, res, next) {
    try {
        // Get user ID from header (frontend should send this)
        const userId = req.headers["x-user-id"];
        if (!userId) {
            res.status(401).json({ message: "احراز هویت لازم است" });
            return;
        }
        // Get user from database
        const [user] = await db_1.db
            .select({
            id: schema_1.users.id,
            roleId: schema_1.users.roleId,
            roleName: schema_1.roles.name,
            isActive: schema_1.users.isActive,
        })
            .from(schema_1.users)
            .leftJoin(schema_1.roles, (0, drizzle_orm_1.eq)(schema_1.users.roleId, schema_1.roles.id))
            .where((0, drizzle_orm_1.eq)(schema_1.users.id, userId));
        if (!user || !user.isActive) {
            res.status(401).json({ message: "کاربر معتبر نیست" });
            return;
        }
        // Attach user info to request
        req.userId = user.id;
        req.userRoleId = user.roleId || undefined;
        req.userRole = user.roleName || undefined;
        next();
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
}
exports.authenticateUser = authenticateUser;
/**
 * Check if user has a specific permission
 */
function checkPermission(permissionKey) {
    return async (req, res, next) => {
        try {
            if (!req.userRoleId) {
                res.status(403).json({ message: "دسترسی لازم نیست" });
                return;
            }
            // Get permission
            const [permission] = await db_1.db
                .select()
                .from(schema_1.permissions)
                .where((0, drizzle_orm_1.eq)(schema_1.permissions.key, permissionKey));
            if (!permission) {
                res.status(500).json({ message: "مجوز یافت نشد" });
                return;
            }
            // Check if user's role has this permission
            const [rolePerm] = await db_1.db
                .select()
                .from(schema_1.rolePermissions)
                .where((0, drizzle_orm_1.and)((0, drizzle_orm_1.eq)(schema_1.rolePermissions.roleId, req.userRoleId), (0, drizzle_orm_1.eq)(schema_1.rolePermissions.permissionId, permission.id)));
            if (!rolePerm) {
                res.status(403).json({ message: "شما دسترسی لازم را ندارید" });
                return;
            }
            next();
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    };
}
exports.checkPermission = checkPermission;
/**
 * Check if user is admin
 */
async function requireAdmin(req, res, next) {
    try {
        if (!req.userRoleId) {
            res.status(403).json({ message: "دسترسی لازم نیست" });
            return;
        }
        // Get user's role
        const [role] = await db_1.db
            .select()
            .from(schema_1.roles)
            .where((0, drizzle_orm_1.eq)(schema_1.roles.id, req.userRoleId));
        if (!role || role.name !== "admin") {
            res.status(403).json({ message: "فقط مدیر سیستم می‌تواند این عملیات را انجام دهد" });
            return;
        }
        next();
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
}
exports.requireAdmin = requireAdmin;
/**
 * Check if user is admin or manager
 */
async function requireAdminOrManager(req, res, next) {
    try {
        if (!req.userRoleId) {
            res.status(403).json({ message: "دسترسی لازم نیست" });
            return;
        }
        // Get user's role
        const [role] = await db_1.db
            .select()
            .from(schema_1.roles)
            .where((0, drizzle_orm_1.eq)(schema_1.roles.id, req.userRoleId));
        if (!role || (role.name !== "admin" && role.name !== "manager")) {
            res.status(403).json({ message: "شما دسترسی لازم را ندارید" });
            return;
        }
        next();
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }
}
exports.requireAdminOrManager = requireAdminOrManager;
