"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.searchConstructionInfo = exports.searchWeb = void 0;
/**
 * Helper function to search the web using a search API
 * This is used as a fallback when the AI API is unavailable or when more information is needed
 */
async function searchWeb(query) {
    try {
        // Using a simple DuckDuckGo instant answer API as a fallback
        // You can replace this with any other search API
        const encodedQuery = encodeURIComponent(query);
        // Create a timeout promise
        const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Request timeout')), 10000));
        const response = await Promise.race([
            fetch(`https://api.duckduckgo.com/?q=${encodedQuery}&format=json&no_html=1&skip_disambig=1`, {
                headers: {
                    'User-Agent': 'Sarisazan Construction Management System/1.0'
                }
            }),
            timeoutPromise
        ]);
        if (!response.ok) {
            throw new Error(`Search API returned ${response.status}`);
        }
        const data = await response.json();
        let answer = '';
        const sources = [];
        // Check for instant answer
        if (data.AbstractText) {
            answer = data.AbstractText;
            if (data.AbstractSource) {
                sources.push(data.AbstractSource);
            }
        }
        else if (data.RelatedTopics && data.RelatedTopics.length > 0) {
            // Get the first related topic
            const firstTopic = data.RelatedTopics[0];
            if (firstTopic.Text) {
                answer = firstTopic.Text;
            }
            if (firstTopic.FirstURL) {
                sources.push(firstTopic.FirstURL);
            }
        }
        if (!answer) {
            return {
                success: false,
                answer: 'متأسفانه نتیجه‌ای از جستجوی اینترنت پیدا نشد. لطفاً سؤال خود را با جزئیات بیشتری مطرح کنید.',
                sources: []
            };
        }
        return {
            success: true,
            answer: `🌐 اطلاعات از اینترنت:\n\n${answer}\n\n📌 منبع: ${sources.join(', ') || 'جستجوی وب'}`,
            sources
        };
    }
    catch (error) {
        console.error('❌ Web search error:', error);
        return {
            success: false,
            answer: 'متأسفانه در جستجوی اینترنت مشکلی پیش آمد.',
            sources: []
        };
    }
}
exports.searchWeb = searchWeb;
/**
 * Fallback search specifically for construction and engineering topics
 * Uses multiple search strategies
 */
async function searchConstructionInfo(query) {
    // Try web search first
    const webResult = await searchWeb(query);
    if (webResult.success) {
        return webResult.answer;
    }
    // If web search fails, provide helpful guidance
    return `🔍 برای جستجوی اطلاعات بیشتر درباره "${query}"، پیشنهاد می‌کنم:

• از منابع معتبر ساختمانی ایران مانند:
  - سایت نظام مهندسی ساختمان
  - مرکز تحقیقات راه، مسکن و شهرسازی
  - دفتر نظام فنی و اجرایی

• یا سؤال خود را با جزئیات بیشتری در سیستم مطرح کنید.

🔧 اگر سؤال شما درباره پروژه‌های موجود در سیستم است، از کلمات کلیدی مانند "پروژه"، "قرارداد"، "صورت‌وضعیت" استفاده کنید.`;
}
exports.searchConstructionInfo = searchConstructionInfo;
