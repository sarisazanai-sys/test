"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cleanupService = exports.CleanupService = void 0;
const promises_1 = __importDefault(require("fs/promises"));
const path_1 = __importDefault(require("path"));
const url_1 = require("url");
const __filename = (0, url_1.fileURLToPath)(import.meta.url);
const __dirname = path_1.default.dirname(__filename);
class CleanupService {
    tempDirectories = [
        path_1.default.join(__dirname, '..', 'uploads', 'temp'),
        path_1.default.join(__dirname, '..', 'uploads', 'processing'),
    ];
    tempFilePatterns = [
        /^temp_.*\.txt$/,
        /^.*_temp\.pdf$/,
        /^processing_.*\.json$/,
    ];
    async cleanupTempFiles(options = {}) {
        const { maxAge = 24 * 60 * 60 * 1000, dryRun = false } = options;
        const deleted = [];
        const errors = [];
        const now = Date.now();
        for (const dir of this.tempDirectories) {
            try {
                await promises_1.default.access(dir);
            }
            catch {
                continue;
            }
            try {
                const files = await promises_1.default.readdir(dir);
                for (const file of files) {
                    const filePath = path_1.default.join(dir, file);
                    try {
                        const stats = await promises_1.default.stat(filePath);
                        if (stats.isFile()) {
                            const age = now - stats.mtimeMs;
                            const shouldDelete = age > maxAge || this.tempFilePatterns.some(pattern => pattern.test(file));
                            if (shouldDelete) {
                                if (!dryRun) {
                                    await promises_1.default.unlink(filePath);
                                }
                                deleted.push(filePath);
                            }
                        }
                    }
                    catch (error) {
                        errors.push(`Failed to process ${filePath}: ${error}`);
                    }
                }
            }
            catch (error) {
                errors.push(`Failed to read directory ${dir}: ${error}`);
            }
        }
        if (deleted.length > 0) {
            console.log(`🗑️  Cleaned up ${deleted.length} temporary file(s)`);
        }
        if (errors.length > 0) {
            console.error(`⚠️  Cleanup errors: ${errors.length} issue(s)`);
            errors.forEach(err => console.error(`  - ${err}`));
        }
        return { deleted, errors };
    }
    async cleanupEmptyDirectories() {
        const deleted = [];
        const errors = [];
        const uploadDirs = [
            'uploads/agent-documents',
            'uploads/letters',
            'uploads/messages',
            'uploads/project-files',
            'uploads/sheets',
            'uploads/tasks',
        ];
        for (const relDir of uploadDirs) {
            const dir = path_1.default.join(__dirname, '..', relDir);
            try {
                await promises_1.default.access(dir);
                const files = await promises_1.default.readdir(dir);
                if (files.length === 0) {
                    console.log(`📁 Empty directory: ${relDir}`);
                }
            }
            catch (error) {
                if (error.code !== 'ENOENT') {
                    errors.push(`Failed to check ${dir}: ${error}`);
                }
            }
        }
        return { deleted, errors };
    }
    async cleanupProcessedFiles(filePath) {
        try {
            await promises_1.default.access(filePath);
            await promises_1.default.unlink(filePath);
            console.log(`🗑️  Cleaned up processed file: ${filePath}`);
            return true;
        }
        catch (error) {
            if (error.code !== 'ENOENT') {
                console.error(`❌ Failed to cleanup ${filePath}:`, error);
            }
            return false;
        }
    }
    scheduleAutomaticCleanup(intervalHours = 24) {
        const intervalMs = intervalHours * 60 * 60 * 1000;
        setInterval(async () => {
            console.log('🧹 Running scheduled cleanup...');
            const result = await this.cleanupTempFiles({ maxAge: 24 * 60 * 60 * 1000 });
            console.log(`✅ Cleanup completed: ${result.deleted.length} files deleted`);
            if (result.errors.length > 0) {
                console.error(`⚠️  Cleanup errors: ${result.errors.length}`);
            }
        }, intervalMs);
        console.log(`🔄 Automatic cleanup scheduled (every ${intervalHours} hours)`);
    }
}
exports.CleanupService = CleanupService;
exports.cleanupService = new CleanupService();
