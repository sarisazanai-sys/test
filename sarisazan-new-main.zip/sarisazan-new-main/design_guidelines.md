# Design Guidelines: Sarisazan Alborz Construction Management System

## Design Approach
**Selected Framework**: Design System Approach with Material Design 3 principles, adapted for RTL Persian/Farsi interface
**Justification**: Construction project management requires data-dense displays, complex forms, clear hierarchies, and consistent patterns. Material Design 3 provides robust components for tables, charts, and data visualization while maintaining accessibility and RTL compatibility.

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary: 210 95% 45% (Professional blue - trust and stability)
- Primary Container: 210 90% 92%
- Secondary: 25 85% 55% (Construction orange - energy and action)
- Surface: 0 0% 98%
- Surface Variant: 210 20% 95%
- Background: 0 0% 100%
- Error: 0 85% 55%
- Success: 140 70% 45%

**Dark Mode:**
- Primary: 210 85% 65%
- Primary Container: 210 80% 25%
- Secondary: 25 75% 65%
- Surface: 210 15% 12%
- Surface Variant: 210 12% 18%
- Background: 210 15% 8%
- Error: 0 75% 65%
- Success: 140 60% 55%

### B. Typography
**Font Stack**: 
- Primary: 'Vazirmatn' (Persian optimized), system-ui fallback
- Monospace: 'JetBrains Mono' for data/numbers

**Hierarchy:**
- H1: text-4xl (36px) font-bold - Page titles
- H2: text-2xl (24px) font-semibold - Section headers
- H3: text-xl (20px) font-semibold - Card headers
- Body: text-base (16px) font-normal - Primary content
- Small: text-sm (14px) - Secondary info, table data
- Caption: text-xs (12px) - Metadata, timestamps

### C. Layout System
**Spacing Units**: Tailwind scale of 4, 6, 8, 12 (p-4, m-6, gap-8, space-x-12)
**Grid System**: 12-column responsive grid with RTL support
**Container Max-widths**: max-w-7xl for main content, max-w-2xl for forms
**Card Padding**: p-6 standard, p-8 for primary cards

### D. Component Library

**Navigation:**
- Persistent RTL sidebar (280px) with collapsible support
- Top app bar with user profile, notifications badge, quick actions
- Breadcrumb navigation for deep hierarchies
- Tab navigation for multi-view pages (Material Design tabs)

**Data Display:**
- Elevated cards with subtle shadow (shadow-md) on surface
- Data tables with sticky headers, zebra striping, sortable columns
- Status badges with color coding (rounded-full px-3 py-1)
- Progress bars with percentage overlays
- Chart containers with consistent 16:9 aspect ratio

**Forms:**
- Outlined text fields (Material Design 3 outlined style)
- Floating labels for RTL Persian text
- Date pickers showing Shamsi calendar with Gregorian conversion
- File upload zones with drag-drop and preview thumbnails
- Multi-step forms with stepper progress indicator

**Interactive Elements:**
- Primary buttons: filled with primary color
- Secondary buttons: outlined variant
- Icon buttons: 40x40px touch target
- FAB (Floating Action Button) for primary actions
- Dropdown menus with elevation and smooth transitions

**Overlays:**
- Modal dialogs: centered with backdrop blur
- Side sheets: 400px RTL slide-in for details/filters
- Toast notifications: top-right (RTL) with auto-dismiss
- Alert banners: full-width with close action

### E. Animations
Use sparingly - only for meaningful transitions:
- Page transitions: 200ms ease-out fade
- Dropdown/menu: 150ms ease-in-out slide
- Card hover: subtle lift with shadow increase
- No decorative animations

## RTL-Specific Adaptations
- All margins/padding reversed (mr becomes ml)
- Icons positioned on right side of text
- Charts and graphs maintain left-to-right data flow
- Navigation drawer slides from right
- Form labels and validation messages align right
- Table alignment: numbers left-aligned, text right-aligned

## Page-Specific Guidelines

**Dashboard:**
- 4-column metric cards (grid-cols-1 md:grid-cols-2 lg:grid-cols-4)
- Timeline feed with RTL alignment
- Quick action FAB in bottom-left corner
- Chart widgets in 2-column layout below metrics

**Project List:**
- Card-based layout with project thumbnails
- Status indicators with color-coded badges
- Search and filter bar with chips for active filters
- "New Project" prominent CTA button

**Daily Reports:**
- 3-tab interface: Submit | List | Details
- Photo gallery grid (3 columns) with lightbox
- Comment thread with threaded replies
- Material Design date picker with Shamsi calendar

**Project Analysis:**
- Full-width S-Curve chart with dual y-axis
- Filter panel as collapsible side sheet
- Financial summary table with alternating row colors
- Export CSV button in outlined secondary style

**User Profile:**
- 2-column layout: info panel | assigned projects
- Avatar upload with circular crop preview
- Inbox with unread count badge
- Message threads with attachment previews

## Images
No hero images required - this is a utility-focused business application. Use:
- Project thumbnail placeholders (16:9 aspect ratio)
- User avatars (circular, 40px standard, 80px profile)
- Daily report photos (uploaded by users, displayed in galleries)
- Document/attachment preview thumbnails (square, 60px)