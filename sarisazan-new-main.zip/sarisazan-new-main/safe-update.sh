#!/bin/bash
set -e

DRY_RUN=false
if [[ "$1" == "--dry-run" ]]; then
    DRY_RUN=true
    echo "DRY RUN MODE: هیچ تغییری اعمال نمی‌شود"
fi

PROJECT_DIR="/home/admin/domains/SiteFixer"
BACKUP_DIR="/backups/sitefixer"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="$BACKUP_DIR/backup_$TIMESTAMP.tar.gz"

echo "شروع آپدیت ایمن..."

# 1. بک‌آپ
mkdir -p $BACKUP_DIR
echo "در حال بک‌آپ: $BACKUP_FILE"
tar --exclude="$PROJECT_DIR/node_modules" \
    --exclude="$PROJECT_DIR/dist" \
    -czf $BACKUP_FILE $PROJECT_DIR

# 2. دیتابیس
mkdir -p $PROJECT_DIR/data
if [ ! -f "$PROJECT_DIR/data/db.sqlite" ]; then
    echo "دیتابیس وجود ندارد → ایجاد می‌شود"
    npx prisma migrate deploy > /dev/null 2>&1
    npx tsx server/init-permissions.ts > /dev/null 2>&1
fi
cp $PROJECT_DIR/data/db.sqlite $BACKUP_DIR/db_$TIMESTAMP.sqlite 2>/dev/null || echo "دیتابیس خالی بود"

# 3. تست بیلد
echo "تست بیلد فرانت‌اند..."
npm run build > /tmp/build.log 2>&1 || {
    echo "بیلد ناموفق! لاگ:"
    cat /tmp/build.log
    exit 1
}

# 4. تست سرور موازی
echo "اجرای سرور تست روی پورت 5001..."
pm2 start "npx tsx server/index.ts" --name "site-test" -f -- --port 5001 > /dev/null 2>&1
sleep 10

# 5. تست سلامت
if curl -s http://127.0.0.1:5001/api/health | grep -q '"status":"ok"'; then
    echo "API سالم است"
else
    echo "API کار نمی‌کند!"
    pm2 delete site-test 2>/dev/null || true
    exit 1
fi

# 6. تست لاگین
if curl -s -X POST http://127.0.0.1:5001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}' | grep -q '"id"'; then
    echo "لاگین موفق"
else
    echo "لاگین ناموفق!"
    pm2 delete site-test 2>/dev/null || true
    exit 1
fi

echo "همه تست‌ها موفق!"

# فقط اگه تست‌ها اوکی بود → اعمال
if [ "$DRY_RUN" = true ]; then
    echo "حالت تست: هیچ تغییری اعمال نشد"
    pm2 delete site-test 2>/dev/null || true
    exit 0
fi

pm2 delete site-test 2>/dev/null || true
git pull origin main
npm install
npm run build
rm -rf server/public/*
cp -r dist/* server/public/
pm2 restart site-api --update-env

echo "آپدیت با موفقیت انجام شد!"
echo "بک‌آپ: $BACKUP_FILE"
