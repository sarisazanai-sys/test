import { agentService } from './server/agent-service.js';

async function main() {
  console.log('🔄 در حال بارگذاری فایل شرایط عمومی پیمان...');
  
  await agentService.initialize();
  
  const result = await agentService.loadFromFile('uploads/agent-documents/contract_law.jsonl');
  
  if (result.success) {
    console.log(`✅ بارگذاری موفقیت‌آمیز بود!`);
    console.log(`📊 تعداد مواد بارگذاری شده: ${result.articlesCount}`);
  } else {
    console.error(`❌ خطا در بارگذاری: ${result.error}`);
  }
}

main().catch(console.error);
