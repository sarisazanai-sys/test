import fs from 'fs';
import path from 'path';

interface Article {
  chapter: string | null;
  article_number: number;
  article_title: string;
  text: string;
}

function parseContractText(filePath: string): Article[] {
  const content = fs.readFileSync(filePath, 'utf-8');
  const articles: Article[] = [];
  let currentChapter: string | null = null;
  
  const lines = content.split('\n');
  let i = 0;
  
  while (i < lines.length) {
    const line = lines[i].trim();
    
    // Check for chapter (فصل)
    if (line.startsWith('فصل ')) {
      currentChapter = line;
      i++;
      continue;
    }
    
    // Check for article number and title
    const match = line.match(/ماده\s+(\d+)\s*[:：]\s*(.+)/);
    if (match) {
      const articleNum = parseInt(match[1]);
      const articleTitle = match[2].trim();
      
      // Collect the article text
      const articleText: string[] = [];
      i++;
      
      // Skip empty lines after title
      while (i < lines.length && !lines[i].trim()) {
        i++;
      }
      
      // Collect text until next article or chapter
      while (i < lines.length) {
        const nextLine = lines[i].trim();
        
        // Stop if we hit next article or chapter
        if (/ماده\s+\d+\s*[:：]/.test(nextLine) || nextLine.startsWith('فصل ')) {
          break;
        }
        
        if (nextLine) {
          articleText.push(nextLine);
        }
        
        i++;
      }
      
      // Join the text
      const fullText = articleText.join(' ');
      
      if (fullText) {
        articles.push({
          chapter: currentChapter,
          article_number: articleNum,
          article_title: articleTitle,
          text: fullText
        });
      }
    } else {
      i++;
    }
  }
  
  return articles;
}

async function main() {
  const inputFile = 'attached_assets/Pasted--1--1762149627206_1762149627208.txt';
  const outputFile = 'uploads/agent-documents/contract_law.jsonl';
  
  // Create directory if it doesn't exist
  const dir = path.dirname(outputFile);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  const articles = parseContractText(inputFile);
  
  // Write as JSONL
  const jsonlContent = articles.map(article => JSON.stringify(article)).join('\n');
  fs.writeFileSync(outputFile, jsonlContent, 'utf-8');
  
  console.log('✅ تبدیل موفقیت‌آمیز بود!');
  console.log(`📊 تعداد مواد: ${articles.length}`);
  console.log(`💾 فایل ذخیره شد در: ${outputFile}`);
  
  // Show some examples
  if (articles.length > 0) {
    console.log('\n📝 نمونه مواد:');
    for (let i = 0; i < Math.min(3, articles.length); i++) {
      const article = articles[i];
      console.log(`\n${i + 1}. ماده ${article.article_number}: ${article.article_title}`);
      console.log(`   فصل: ${article.chapter || 'ندارد'}`);
      console.log(`   متن: ${article.text.substring(0, 100)}...`);
    }
  }
}

main().catch(console.error);
