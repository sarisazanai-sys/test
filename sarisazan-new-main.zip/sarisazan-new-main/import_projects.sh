#!/bin/bash
API_URL="http://localhost:5000/api/admin/import-projects"
TOKEN=""  # اگر نیاز به توکن داری اینجا بذار: Bearer eyJh...

DATA='[
  {
    "projectNumber": 2,
    "title": "احداث راه دسترسی تپه باستانی سگزآباد و تکمیل راه روستایی بندسر- مرادبیگلو و احداث راه دسترسی گلخانه نودهک",
    "contractNumber": "15/3598",
    "contractDate": "1400/02/04",
    "contractAmount": 61329030181,
    "contractor": "سریع سازان البرز",
    "employer": "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
    "lastStatusNumber": 2,
    "lastStatusAmount": 35902628577,
    "lastAdjustmentNumber": 2,
    "lastAdjustmentAmount": 14948065358,
    "bitumenDifference": 0,
    "progressPercent": 58.54
  },
  {
    "projectNumber": 3,
    "title": "زیرسازی و آسفالت راه‌های روستایی شهرستان بوئین زهرا",
    "contractNumber": "15/4540",
    "contractDate": "1401/02/08",
    "contractAmount": 323713724955,
    "contractor": "بهینه مطبوع کاوش کار",
    "employer": "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
    "lastStatusNumber": 6,
    "lastStatusAmount": 251171146885,
    "lastAdjustmentNumber": 6,
    "lastAdjustmentAmount": 24740494716,
    "bitumenDifference": 0,
    "progressPercent": 77.59
  },
  {
    "projectNumber": 4,
    "title": "لکه‌گیری و بهسازی محورهای شهرستان‌های قزوین، تاکستان، آوج و محور دانسفهان، شامی شاب و ابهر",
    "contractNumber": "15/26928",
    "contractDate": "1400/06/30",
    "contractAmount": 239174230321,
    "contractor": "سریع سازان البرز",
    "employer": "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
    "lastStatusNumber": 6,
    "lastStatusAmount": 252909399598,
    "progressPercent": 105.74
  },
  {
    "projectNumber": 7,
    "title": "بهسازی لکه‌گیری و روکش آسفالت محور قدیم قزوین-رشت",
    "contractNumber": "15/45025",
    "contractDate": "1401/09/28",
    "contractAmount": 1005031507635,
    "contractor": "سریع سازان البرز",
    "employer": "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
    "lastStatusNumber": 10,
    "lastStatusAmount": 1058471906750,
    "progressPercent": 105.32
  },
  {
    "projectNumber": 8,
    "title": "بهسازی، لکه‌گیری و روکش آسفالت محور قزوین-تاکستان-آوج",
    "contractNumber": "15/45150",
    "contractDate": "1401/09/29",
    "contractAmount": 507893878620,
    "contractor": "سریع سازان البرز",
    "employer": "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
    "lastStatusNumber": 9,
    "lastStatusAmount": 534973823027,
    "progressPercent": 105.33
  },
  {
    "projectNumber": 9,
    "title": "بهسازی و آسفالت محورهای بشر- دولت آباد و آبترش- نیکوئیه- ضیا آباد",
    "contractNumber": "15/45624",
    "contractDate": "1401/10/01",
    "contractAmount": 424604739521,
    "contractor": "بهینه مطبوع کاوش کار",
    "employer": "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
    "lastStatusNumber": 4,
    "lastStatusAmount": 380953267905,
    "progressPercent": 89.72
  },
  {
    "projectNumber": 28016,
    "title": "بهسازی محور اک- شامی شاپ و ساماندهی ورودی روستای اک و احداث زیرگذر قرقسین",
    "contractNumber": "15/45624",
    "contractDate": "1401/08/08",
    "contractAmount": 679153092242,
    "contractor": "سریع سازان البرز",
    "employer": "اداره کل راه و شهرسازی استان قزوین",
    "lastStatusNumber": 22,
    "lastStatusAmount": 430321719419,
    "progressPercent": 63.36
  },
  {
    "projectNumber": 13,
    "title": "بهسازی و روکش آسفالت راه‌های روستایی شهرستان تاکستان",
    "contractNumber": "15/3138",
    "contractDate": "1402/01/28",
    "contractAmount": 679214976465,
    "contractor": "خاک پی دنا",
    "employer": "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
    "lastStatusNumber": 6,
    "lastStatusAmount": 334874941708,
    "progressPercent": 49.30
  },
  {
    "projectNumber": 19,
    "title": "بهسازی روکش آسفالت آزادراه قزوین- کرج و کنارگذر قزوین- زنجان",
    "contractNumber": "15/9457",
    "contractDate": "1403/03/01",
    "contractAmount": 447397767841,
    "contractor": "بهینه مطبوع کاوش کار",
    "employer": "اداره کل راهداری و حمل و نقل جاده‌ای استان قزوین",
    "lastStatusNumber": 6,
    "lastStatusAmount": 278435519007,
    "progressPercent": 62.23
  }
]'

curl -X POST $API_URL \
  -H "Content-Type: application/json" \
  -H "Authorization: $TOKEN" \
  -d "$DATA"

