# راهنمای پاک کردن Cache و Service Worker

## مشکل: Sidebar و خطاهای 429 به دلیل Cache قدیمی

Service Worker (Workbox) فایل‌های قدیمی را cache کرده و هنوز نسخه قدیمی کد را اجرا می‌کند.

## راه حل فوری (در Console):

در Console (F12) این کد را اجرا کنید:

```javascript
// Unregister Service Worker
navigator.serviceWorker.getRegistrations().then(registrations => {
  for (const registration of registrations) {
    registration.unregister().then(success => {
      if (success) {
        console.log('✅ Service Worker unregistered');
        // Clear all caches
        caches.keys().then(cacheNames => {
          return Promise.all(cacheNames.map(cacheName => {
            console.log('🗑️ Deleting cache:', cacheName);
            return caches.delete(cacheName);
          }));
        }).then(() => {
          console.log('✅ All caches cleared');
          // Reload page
          window.location.reload();
        });
      }
    });
  }
});
```

## راه حل از طریق DevTools:

1. **F12** را بزنید
2. به تب **Application** بروید
3. در سمت چپ، **Service Workers** را انتخاب کنید
4. روی **Unregister** کلیک کنید
5. در همان تب، **Storage** → **Clear site data** را بزنید
6. صفحه را **Refresh** کنید (Ctrl+Shift+R)

## راه حل دائمی:

بعد از unregister کردن، باید:
1. پروژه را rebuild کنید: `npm run build`
2. سرور را restart کنید
3. صفحه را hard refresh کنید: `Ctrl+Shift+R`

